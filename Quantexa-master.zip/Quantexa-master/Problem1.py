import os
import pandas as pd

#ifp = open('Input/transactions.txt', 'r').read().split(',')
ifp = pd.read_csv('Input/transactions.txt')
#ofp = open('Output/output1', 'w')
#ifp = ifp.groupby(['transactionDay'],as_index=False).agg({'transactionAmount': 'sum'}).reset_index()
ifp = ifp.groupby(['transactionDay']).agg({'transactionAmount': 'sum'})
print(ifp)

ifp.to_csv('Output/output1.csv')







