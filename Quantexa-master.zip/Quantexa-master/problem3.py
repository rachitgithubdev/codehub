import logging
from pyspark.sql import SparkSession
import numpy as np
from pyspark.sql.window import Window
import pyspark.sql.functions as F
import pandas as pd
logger = logging.getLogger(__name__)


class Rolling_Average():


   def __init__(self):
      self.spark = SparkSession \
       .builder \
       .appName("PySpark clickstream") \
       .getOrCreate()
      self.df = self.spark.read.csv("Input/transactions.txt", header=True)

   def execute(self):
        self.df = self.df.withColumn("transactionDay", self.df.transactionDay.cast('integer'))
        w = Window.partitionBy('accountId').orderBy('transactionDay').rangeBetween(-6, -1)
        w1 = Window.partitionBy(['accountId', 'category']).orderBy('transactionDay').rangeBetween(-6, -1)
        w2 = Window.partitionBy(['accountId']).orderBy('transactionDay').rangeBetween(-6, -1)
        self.df = self.df.withColumn('Average', F.avg('transactionAmount').over((w)))
        self.df = self.df.withColumn('Maximum', F.max('transactionAmount').over((w2)))
        self.df = self.df.withColumn('Total Value', F.sum('transactionAmount').over((w1)))
        self.df.show(truncate=False)
        self.df = self.df.select("*").toPandas()#.to_csv('Output/output4.csv')
        table = pd.pivot_table(data=self.df, index=['transactionDay', 'accountId'], columns=['category'],values='Total Value')
        print(self.df)
        print(table)
        #self.df.to_csv('Output/output4.csv')
        table.to_csv('Output/Table.csv')
        result = pd.concat([self.df, table], axis=1)
        print(result)
        result.to_csv('Output/output3.csv')


if __name__ == '__main__':
    x = Rolling_Average()
    x.execute()
