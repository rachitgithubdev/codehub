import pandas as pd

#from pandas._typing import F
#from pyspark.sql.functions import regexp_extract

ifp = pd.read_csv('Input/transactions.txt')
# ifp = open('Input/transactions.txt', 'r').read().split(',')
#ofp = open('Output/output1', 'w')
#ifp = ifp.sort_values(regexp_extract(F.col("accountId"), r"\d+", 0).cast('int'))
ifp = ifp.groupby(['accountId','category']).agg({'transactionAmount': 'mean'})
#ifp = ifp.sort_values('accountId')
print(ifp)

ifp.to_csv('Output/output2.csv')