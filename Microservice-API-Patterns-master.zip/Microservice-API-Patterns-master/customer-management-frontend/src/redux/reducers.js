// @flow

import { reducer as restEasy } from "@brigad/redux-rest-easy"
import { combineReducers } from "redux"

const reducers = combineReducers({
  restEasy,
})

export default reducers
