# ================================Revision History=================================================
# #
#  Change Version,  Change Author,        Change Date,    Change Component
#  0.1              Arvind Shrivastava    21-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to l2-l3 pr4 sales billing into conform zone
# Author        :- Arvind Shrivastava
# Date          :- 09-Mar-2021
# Version       :- 21-Apr-2021
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from pyspark.sql.window import Window as Window
from awsglue.job import Job
from datetime import datetime as dt
import pandas as pd


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 13:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 13")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment',
                                   'sb_hist_end_date',
                                   'sb_start_date'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = ['l2_pr4_us_sales_billing', 'l2_pr4_us_sales_billing_hist']
        self.report_file = "l3_pr4_sales_billing"

        # generic variables  ===========================================
        self.sb_hist_end_date = args['sb_hist_end_date']
        self.sb_start_date = args['sb_start_date']

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))
        print('it will process {} tables'.format(self.input_table))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # current_year_month_01 = dt.today().strftime("%Y-%m")
        # print('Current Year-Month 01 :- ', current_year_month_01)

        startdate = '2000-01-01'
        enddate = self.sb_hist_end_date
        sb_hist_month_range = pd.date_range(startdate, enddate, freq='MS').strftime("%Y%m").tolist()
        # print('Month Range',sb_hist_month_range)

        startdate = self.sb_start_date
        sb_month_range = pd.date_range(startdate, dt.today(), freq='MS').strftime("%Y%m").tolist()
        # print('****Month Value:- ******',sb_month_range)

        # get source database
        input_table_sb = self.input_table[0]
        # print('Input Table 01 :- ', input_table_sb)

        input_table_sb_hist = self.input_table[1]
        # ('Input Table 02 :- ', input_table_sb_hist)

        # sb_hist_month_range = self.sales_billing_month_range
        # print('*****SB Month Range ****** :- ', sb_hist_month_range)

        source_database = self.source_database

        # # read data from country specific table argument passed(database, table)
        df_input_table_sb1 = self._get_table(source_database, input_table_sb).toDF()

        df_input_table_sb = self._get_table(source_database, input_table_sb).toDF()
        print("data count of table {}.{} is {}".format(source_database, input_table_sb, df_input_table_sb.count()))

        df_input_table_sb_hist = self._get_table(source_database, input_table_sb_hist).toDF()
        print("data count of table {}.{} is {}".format(source_database, input_table_sb_hist,
                                                       df_input_table_sb_hist.count()))

        # apply transformation on the dataframe argument passed
        df_tfx_result = self._apply_tfx(df_input_table_sb, df_input_table_sb_hist, sb_hist_month_range, sb_month_range)
        print("data count after transformation ", df_tfx_result.count())

        final_result_df = df_tfx_result
        print("Final Write", final_result_df.count())

        self.write_results(final_result_df)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table_sb, df_input_table_sb_hist, sb_hist_month_range, sb_month_range):
        # convert all the columns alias to lower case

        sb_hist = df_input_table_sb_hist.select([f.col(x).alias(x.lower()) for x in df_input_table_sb_hist.columns])
        # print('month {}.{}'.format(type(month), month))

        sb = df_input_table_sb.select([f.col(x).alias(x.lower()) for x in df_input_table_sb.columns])
        # print('Dataframe of table df_input_table_sb',df_input_table_sb)

        df_tfx_result_sb_hist = sb_hist.filter(
            sb_hist.month_id.isin(sb_hist_month_range)) \
            .select(f.col('month_id'),
                    f.col('ref_id'),
                    f.col('source_system'),
                    f.col('vblen_billing_doc'),
                    f.col('line_number'),
                    f.col('delivery_num'),
                    f.col('aubel_sales_document'),
                    f.col('prsdt_pricing_date').cast('date'),
                    f.col('delivery_date').cast('date'),
                    f.col('fkdat_billing_date').cast('date'),
                    f.col('pu'),
                    f.col('cluster'),
                    f.col('aland_country'),
                    f.col('airport_terminal'),
                    f.col('iata_code_bo'),
                    f.col('average_of_latitude'),
                    f.col('average_of_longitude'),
                    f.col('name'),
                    f.col('supply_envelope'),
                    f.col('supply_pricing'),
                    f.col('terminal'),
                    f.col('customer_country'),
                    f.col('global_ref_num'),
                    f.col('cust_acct_name'),
                    f.col('global_acct_ref_num'),
                    f.col('lead_account_holder_name'),
                    f.col('account_holder_name'),
                    f.col('sector'),
                    f.col('segment'),
                    f.col('local_non_nordics_ah_account_holder'),
                    f.col('vkorg_sales_org'),
                    f.col('werks_plant'),
                    f.col('kunnr_customer_shipto'),
                    f.col('party_description'),
                    f.col('matnr_material'),
                    f.col('matx_material_description'),
                    f.col('ib_global_cust_ref'),
                    f.col('sold_to'),
                    f.col('sold_to_name'),
                    f.col('cmwae_currency'),
                    f.col('currency_description'),
                    f.col('qty_m3').cast('double'),
                    f.col('qty_ugl').cast('double'),
                    f.col('debit_credit_ind'),
                    f.col('flightnum'),
                    f.col('aircraftreg'),
                    f.col('mot'),
                    f.col('delivery_note_number'),
                    f.col('posting_date').cast('date'),
                    f.col('payernum'),
                    f.col('billtonum'),
                    f.col('feed_type'),
                    f.col('source_extract_as_at'),
                    f.lit("").cast("string").alias("doccreatedate"),
                    f.col('creation_date'),
                    f.col('source_file_name'))

        print('Count of table is df_tfx_result_sb_hist', df_tfx_result_sb_hist.count())

        df_tfx_result_sb_rn = sb.filter(f.col("month_id").isin(sb_month_range)) \
            .select(f.col("month_id"),
                    f.col('ref_id'),
                    f.col('source_system'),
                    f.col('vblen_billing_doc'),
                    f.col('line_number'),
                    f.col('delivery_num'),
                    f.col('aubel_sales_document'),
                    f.col('prsdt_pricing_date').cast('date'),
                    f.col('delivery_date').cast('date'),
                    f.col('fkdat_billing_date').cast('date'),
                    f.col('pu'),
                    f.col('cluster'),
                    f.col('aland_country'),
                    f.col('airport_terminal'),
                    f.col('iata_code_bo'),
                    f.col('average_of_latitude'),
                    f.col('average_of_longitude'),
                    f.col('name'),
                    f.col('supply_envelope'),
                    f.col('supply_pricing'),
                    f.col('terminal'),
                    f.col('customer_country'),
                    f.col('global_ref_num'),
                    f.col('cust_acct_name'),
                    f.col('global_acct_ref_num'),
                    f.col('lead_account_holder_name'),
                    f.col('account_holder_name'),
                    f.col('sector'),
                    f.col('segment'),
                    f.col('local_non_nordics_ah_account_holder'),
                    f.col('vkorg_sales_org'),
                    f.col('werks_plant'),
                    f.col('kunnr_customer_shipto'),
                    f.col('party_description'),
                    f.col('matnr_material'),
                    f.col('matx_material_description'),
                    f.col('ib_global_cust_ref'),
                    f.col('sold_to'),
                    f.col('sold_to_name'),
                    f.col('cmwae_currency'),
                    f.col('currency_description'),
                    f.col('qty_m3').cast('double'),
                    f.col('qty_ugl').cast('double'),
                    f.col('debit_credit_ind'),
                    f.col('flightnum'),
                    f.col('aircraftreg'),
                    f.col('mot'),
                    f.col('delivery_note_number'),
                    f.col('posting_date').cast('date'),
                    f.col('payernum'),
                    f.col('billtonum'),
                    f.col('feed_type'),
                    f.col('source_extract_as_at'),
                    f.col('doccreatedate'),
                    f.col('creation_date'),
                    f.col('source_file_name'),
                    f.dense_rank().over(Window.partitionBy(f.col("month_id")).orderBy(sb.creation_date.desc())).alias(
                        'rn')
                    )

        sb_rn = df_tfx_result_sb_rn

        df_tfx_result_sb = sb_rn.filter(
            sb_rn.rn.isin(1)) \
            .select(f.col("month_id"),
                    f.col('ref_id'),
                    f.col('source_system'),
                    f.col('vblen_billing_doc'),
                    f.col('line_number'),
                    f.col('delivery_num'),
                    f.col('aubel_sales_document'),
                    f.col('prsdt_pricing_date').cast('date'),
                    f.col('delivery_date').cast('date'),
                    f.col('fkdat_billing_date').cast('date'),
                    f.col('pu'),
                    f.col('cluster'),
                    f.col('aland_country'),
                    f.col('airport_terminal'),
                    f.col('iata_code_bo'),
                    f.col('average_of_latitude'),
                    f.col('average_of_longitude'),
                    f.col('name'),
                    f.col('supply_envelope'),
                    f.col('supply_pricing'),
                    f.col('terminal'),
                    f.col('customer_country'),
                    f.col('global_ref_num'),
                    f.col('cust_acct_name'),
                    f.col('global_acct_ref_num'),
                    f.col('lead_account_holder_name'),
                    f.col('account_holder_name'),
                    f.col('sector'),
                    f.col('segment'),
                    f.col('local_non_nordics_ah_account_holder'),
                    f.col('vkorg_sales_org'),
                    f.col('werks_plant'),
                    f.col('kunnr_customer_shipto'),
                    f.col('party_description'),
                    f.col('matnr_material'),
                    f.col('matx_material_description'),
                    f.col('ib_global_cust_ref'),
                    f.col('sold_to'),
                    f.col('sold_to_name'),
                    f.col('cmwae_currency'),
                    f.col('currency_description'),
                    f.col('qty_m3').cast('double'),
                    f.col('qty_ugl').cast('double'),
                    f.col('debit_credit_ind'),
                    f.col('flightnum'),
                    f.col('aircraftreg'),
                    f.col('mot'),
                    f.col('delivery_note_number'),
                    f.col('posting_date').cast('date'),
                    f.col('payernum'),
                    f.col('billtonum'),
                    f.col('feed_type'),
                    f.col('source_extract_as_at'),
                    f.col('doccreatedate'),
                    f.col('creation_date'),
                    f.col('source_file_name'))

        print('Count of table is df_tfx_result_sb', df_tfx_result_sb.count())

        df_tfx_result = df_tfx_result_sb_hist.union(df_tfx_result_sb)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL1()
    trl.execute()