# ================================Revision History=================================================
# #
#  Change Version,  Change Author,        Change Date,    Change Component
#  0.1              Arvind Shrivastava    21-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to l2-l3 pr4 sales billing into conform zone
# Author        :- Arvind Shrivastava
# Date          :- 09-Mar-2021
# Version       :- 21-Apr-2021
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from pyspark.sql.window import Window as Window
from awsglue.job import Job
from datetime import datetime as dt
import pandas as pd


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 12:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 12")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment',
                                   'sales_billing_date_range',
                                   'sales_billing_start_date'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = ['l2_pr4_us_sales_billing', 'l2_pr4_us_sales_billing_hist']
        self.report_file = "l3_pr4_raw_sales_billing_latest"

        # generic variables  ===========================================
        self.sales_billing_month_range = args['sales_billing_date_range']
        self.sales_billing_start_date = args['sales_billing_start_date']
        
        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))
        print('it will process {} tables'.format(self.input_table))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # current_year_month_01 = dt.today().strftime("%Y-%m")
        # print('Current Year-Month 01 :- ', current_year_month_01)
        
        startdate = self.sales_billing_start_date
        sb_month_range = pd.date_range(startdate,dt.today(),freq='MS').strftime("%Y%m").tolist()
        #print('****Month Value:- ******',sb_month_range)

        # get source database
        input_table_sb = self.input_table[0]
        #print('Input Table 01 :- ', input_table_sb)

        input_table_sb_hist = self.input_table[1]
        #('Input Table 02 :- ', input_table_sb_hist)
        
        sb_hist_month_range = self.sales_billing_month_range
        #print('*****SB Month Range ****** :- ', sb_hist_month_range)
        

        source_database = self.source_database

        # # read data from country specific table argument passed(database, table)
        df_input_table_sb = self._get_table(source_database, input_table_sb).toDF()
        print("data count of table {}.{} is {}".format(source_database, input_table_sb, df_input_table_sb.count()))

        df_input_table_sb_hist = self._get_table(source_database, input_table_sb_hist).toDF()
        print("data count of table {}.{} is {}".format(source_database, input_table_sb_hist,
                                                          df_input_table_sb_hist.count()))
        
        # apply transformation on the dataframe argument passed
        df_tfx_result = self._apply_tfx(df_input_table_sb, df_input_table_sb_hist,sb_hist_month_range,sb_month_range)
        print("data count after transformation ", df_tfx_result.count())

        final_result_df = df_tfx_result
        print("Final Write", final_result_df.count())

        self.write_results(final_result_df)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)


    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table_sb, df_input_table_sb_hist,sb_hist_month_range,sb_month_range):
        
        # convert all the columns alias to lower case

        sb_hist = df_input_table_sb_hist.select([f.col(x).alias(x.lower()) for x in df_input_table_sb_hist.columns])
        # print('month {}.{}'.format(type(month), month))
        
        sb = df_input_table_sb.select([f.col(x).alias(x.lower()) for x in df_input_table_sb.columns])
       # print('Dataframe of table df_input_table_sb',df_input_table_sb)


        df_tfx_result_sb_hist = sb_hist.filter(
            sb_hist.month_id.isin(sb_hist_month_range.split())) \
            .select(sb_hist.month_id,
                    sb_hist.ref_id,
                    sb_hist.source_system,
                    sb_hist.vblen_billing_doc,
                    sb_hist.line_number,
                    sb_hist.delivery_num,
                    sb_hist.aubel_sales_document,
                    sb_hist.prsdt_pricing_date,
                    sb_hist.delivery_date,
                    sb_hist.fkdat_billing_date,
                    sb_hist.pu,
                    sb_hist.cluster,
                    sb_hist.aland_country,
                    sb_hist.airport_terminal,
                    sb_hist.iata_code_bo,
                    sb_hist.average_of_latitude,
                    sb_hist.average_of_longitude,
                    sb_hist.name,
                    sb_hist.supply_envelope,
                    sb_hist.supply_pricing,
                    sb_hist.terminal,
                    sb_hist.customer_country,
                    sb_hist.global_ref_num,
                    sb_hist.cust_acct_name,
                    sb_hist.global_acct_ref_num,
                    sb_hist.lead_account_holder_name,
                    sb_hist.account_holder_name,
                    sb_hist.sector,
                    sb_hist.segment,
                    sb_hist.local_non_nordics_ah_account_holder,
                    sb_hist.vkorg_sales_org,
                    sb_hist.werks_plant,
                    sb_hist.kunnr_customer_shipto,
                    sb_hist.party_description,
                    sb_hist.matnr_material,
                    sb_hist.matx_material_description,
                    sb_hist.ib_global_cust_ref,
                    sb_hist.sold_to,
                    sb_hist.sold_to_name,
                    sb_hist.cmwae_currency,
                    sb_hist.currency_description,
                    sb_hist.qty_m3,
                    sb_hist.qty_ugl,
                    sb_hist.debit_credit_ind,
                    sb_hist.flightnum,
                    sb_hist.aircraftreg,
                    sb_hist.mot,
                    sb_hist.delivery_note_number,
                    sb_hist.posting_date,
                    sb_hist.payernum,
                    sb_hist.billtonum,
                    sb_hist.feed_type,
                    sb_hist.source_extract_as_at,
                    sb_hist.creation_date,
                    sb_hist.source_file_name)
        
        print('Count of table is df_tfx_result_sb_hist',df_tfx_result_sb_hist.count())
        
        
        df_tfx_result_sb_rn = sb.filter(
            sb.month_id.isin(sb_month_range)) \
             .select(f.col('*'),
                f.dense_rank().over(Window.partitionBy(sb.month_id).orderBy(sb.creation_date.desc())).alias('rn')
                )
        
        sb_rn = df_tfx_result_sb_rn
        
        df_tfx_result_sb = sb_rn.filter(
            sb_rn.rn.isin(1)) \
             .select(sb_rn.month_id,
                sb_rn.ref_id,
                sb_rn.source_system,
                sb_rn.vblen_billing_doc,
                sb_rn.line_number,
                sb_rn.delivery_num,
                sb_rn.aubel_sales_document,
                sb_rn.prsdt_pricing_date,
                sb_rn.delivery_date,
                sb_rn.fkdat_billing_date,
                sb_rn.pu,
                sb_rn.cluster,
                sb_rn.aland_country,
                sb_rn.airport_terminal,
                sb_rn.iata_code_bo,
                sb_rn.average_of_latitude,
                sb_rn.average_of_longitude,
                sb_rn.name,
                sb_rn.supply_envelope,
                sb_rn.supply_pricing,
                sb_rn.terminal,
                sb_rn.customer_country,
                sb_rn.global_ref_num,
                sb_rn.cust_acct_name,
                sb_rn.global_acct_ref_num,
                sb_rn.lead_account_holder_name,
                sb_rn.account_holder_name,
                sb_rn.sector,
                sb_rn.segment,
                sb_rn.local_non_nordics_ah_account_holder,
                sb_rn.vkorg_sales_org,
                sb_rn.werks_plant,
                sb_rn.kunnr_customer_shipto,
                sb_rn.party_description,
                sb_rn.matnr_material,
                sb_rn.matx_material_description,
                sb_rn.ib_global_cust_ref,
                sb_rn.sold_to,
                sb_rn.sold_to_name,
                sb_rn.cmwae_currency,
                sb_rn.currency_description,
                sb_rn.qty_m3,
                sb_rn.qty_ugl,
                sb_rn.debit_credit_ind,
                sb_rn.flightnum,
                sb_rn.aircraftreg,
                sb_rn.mot,
                sb_rn.delivery_note_number,
                sb_rn.posting_date,
                sb_rn.payernum,
                sb_rn.billtonum,
                sb_rn.feed_type,
                sb_rn.source_extract_as_at,
                sb_rn.creation_date,
                sb_rn.source_file_name
                )
                
        print('Count of table is df_tfx_result_sb',df_tfx_result_sb.count())

        df_tfx_result = df_tfx_result_sb_hist.union(df_tfx_result_sb)
        
        return df_tfx_result

if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()
