# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      08-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to create tender header tables in conform zone
# Author        :- Bakul Seth
# Date          :- 20-Jan-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class TMMipETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_mip_steadystate"
        self.l21_report_file = "mip_layer_2.1/l2.1_mip_steadystate"
        self.l31_report_file = "mip_layer_3.1/l3.1_mip_steadystate"
        self.l32_report_file = "mip_layer_3.2/l3.2_mip_steadystate"
        self.l4_report_file = "mip_layer_4/l4_mip_steadystate"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # read data from specific table argument passed(database, table)
        df_input = self._get_table(self.source_database, self.input_table).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_input.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe)
        df_tfx = self._apply_tfx(df_input)

        # write final result to l21 destination
        self.write_results(df_tfx[0], self.l21_report_file)

        # write final result to l31 destination
        self.write_results(df_tfx[1], self.l31_report_file)

        # write final result to l31 destination
        self.write_results(df_tfx[2], self.l32_report_file)

        # write final result to l4 destination
        self.write_results(df_tfx[3], self.l4_report_file)

    def write_results(self, target_dataset, report):
        final_path = self.destination_bucket + "/" + report
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input):
        # convert all the columns alias to lower case
        df_input = df_input.select([f.col(x).alias(x.lower()) for x in df_input.columns])
        print("*********************", df_input.printSchema())
        df_tfx_l21 = df_input. \
            select(df_input.tenderkey, df_input.month, df_input.locationcode, df_input.locationname,
                   df_input.productcode, df_input.globalrefnumber, df_input.contractstart, df_input.contractend,
                   df_input.unitofmeasure, df_input.currency, df_input.volume, df_input.forecastedvolume,
                   df_input.actualvolume, df_input.tenderedvolume, df_input.averageuplift, df_input.differential,
                   df_input.netdifferential, df_input.rebate, df_input.grossprofit, df_input.forecastedgrossprofit,
                   df_input.actualgrossprofit, df_input.salesforcetenderid,
                   df_input.salesforcetenderlocationlineitemid, df_input.tmstenderid, df_input.tmstenderseq,
                   df_input.createdon, df_input.infa_ext_dt, df_input.baseunitcosts, df_input.buyingprice,
                   df_input.costofproduct, df_input.creditdays, df_input.creditors, df_input.csofixed,
                   df_input.csospecificfixed, df_input.csospecificvariable, df_input.csovariable,
                   df_input.currencycode, df_input.datadelay, df_input.debtors, df_input.deliverycount,
                   df_input.fixedcosts, df_input.fullybuiltup, df_input.grossmargin, df_input.incomefixed,
                   df_input.incomespecificfixed, df_input.incomespecificvariable, df_input.incomevariable,
                   df_input.inventory, df_input.invoicingfrequency, df_input.ishedged,
                   df_input.locationneutralpaymentterms, df_input.measureunitcode, df_input.oaffixed,
                   df_input.oafspecificfixed, df_input.oafspecificvariable, df_input.oafvariable,
                   df_input.overheadfixed, df_input.overheadspecificfixed, df_input.overheadspecificvariable,
                   df_input.overheadvariable, df_input.paffixed, df_input.pafspecificfixed,
                   df_input.pafspecificvariable, df_input.pafvariable, df_input.paymentterm, df_input.premium,
                   df_input.premiumdescriptor, df_input.pricebasis, df_input.pricingpricebasis, df_input.productloss,
                   df_input.revenue, df_input.revenuefixed, df_input.revenuespecificfixed,
                   df_input.revenuespecificvariable, df_input.revenuevariable, df_input.sellingprice,
                   df_input.sourcecostofproduct, df_input.stockdays, df_input.suppliercreditdays,
                   df_input.supplierinvoicingfrequency, df_input.supplierpaymentterm, df_input.supplychain,
                   df_input.temperatureadjustment, df_input.temperaturegain, df_input.unitfloorprice,
                   df_input.unitgrossmargin, df_input.unitgrossprofit, df_input.unitofmeasureadjustment,
                   df_input.variablecosts, df_input.workingcapital, df_input.abmcsovariable, df_input.abmcsofixed,
                   df_input.abmcsospecificvariable, df_input.abmcsospecificfixed, df_input.abmincomevariable,
                   df_input.abmincomefixed, df_input.abmincomespecificvariable, df_input.abmincomespecificfixed,
                   df_input.abmpafvariable, df_input.abmpaffixed, df_input.abmpafspecificvariable,
                   df_input.abmpafspecificfixed, df_input.abmoafvariable, df_input.abmoaffixed,
                   df_input.abmoafspecificvariable, df_input.abmoafspecificfixed,
                   df_input.abmrevenuevariable, df_input.abmrevenuefixed,
                   df_input.abmrevenuespecificvariable, df_input.abmrevenuespecificfixed,
                   df_input.abmoverheadvariable, df_input.abmoverheadfixed, df_input.abmoverheadspecificvariable,
                   df_input.abmoverheadspecificfixed, df_input.isdebriefed, df_input.isproposedcontract,
                   df_input.isproposedbusiness, df_input.islocationadjustment,
                   df_input.key).where(df_input.infa_ext_dt >= '20210115 14:00:00')

        print("*********************", df_tfx_l21.printSchema())

        df_tfx_l31 = df_tfx_l21. \
            select(df_tfx_l21.tenderkey,
                   f.to_date(f.substring(df_tfx_l21.month, 1, 10), 'MM/dd/yyyy').alias('month'),
                   df_tfx_l21.locationcode, df_tfx_l21.locationname, df_tfx_l21.productcode, df_tfx_l21.globalrefnumber,
                   f.date_format(f.to_date(f.substring(df_tfx_l21.contractstart, 1, 10), 'MM/dd/yyyy'),
                                 'MM/dd/yyyy').alias('contractstart'),
                   f.date_format(f.to_date(f.substring(df_tfx_l21.contractend, 1, 10), 'MM/dd/yyyy'),
                                 'MM/dd/yyyy').alias('contractend'), df_tfx_l21.unitofmeasure, df_tfx_l21.currency,
                   df_tfx_l21.volume.cast('double'), df_tfx_l21.forecastedvolume.cast('double'),
                   df_tfx_l21.actualvolume.cast('double'), df_tfx_l21.tenderedvolume.cast('double'),
                   df_tfx_l21.averageuplift.cast('double'), df_tfx_l21.differential.cast('double'),
                   df_tfx_l21.netdifferential.cast('double'), df_tfx_l21.rebate.cast('double'),
                   df_tfx_l21.grossprofit.cast('double'), df_tfx_l21.forecastedgrossprofit.cast('double'),
                   df_tfx_l21.actualgrossprofit.cast('double'), df_tfx_l21.salesforcetenderid,
                   df_tfx_l21.salesforcetenderlocationlineitemid, df_tfx_l21.tmstenderid, df_tfx_l21.tmstenderseq,
                   f.date_format(f.to_date(f.substring(df_tfx_l21.createdon, 1, 10), 'MM/dd/yyyy'),
                                 'MM/dd/yyyy').alias('createdon'),
                   f.date_format(f.to_timestamp(df_tfx_l21.infa_ext_dt, 'yyyyMMdd HH:mm:ss'),
                                 "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").alias('infa_ext_dt'),
                   df_tfx_l21.baseunitcosts.cast('double'), df_tfx_l21.buyingprice.cast('double'),
                   df_tfx_l21.costofproduct.cast('double'), df_tfx_l21.creditdays.cast('double'),
                   df_tfx_l21.creditors.cast('double'), df_tfx_l21.csofixed.cast('double'),
                   df_tfx_l21.csospecificfixed.cast('double'), df_tfx_l21.csospecificvariable.cast('double'),
                   df_tfx_l21.csovariable.cast('double'), df_tfx_l21.currencycode.cast('double'),
                   df_tfx_l21.datadelay.cast('double'), df_tfx_l21.debtors.cast('double'),
                   df_tfx_l21.deliverycount.cast('double'), df_tfx_l21.fixedcosts.cast('double'),
                   df_tfx_l21.fullybuiltup.cast('double'), df_tfx_l21.grossmargin.cast('double'),
                   df_tfx_l21.incomefixed.cast('double'), df_tfx_l21.incomespecificfixed.cast('double'),
                   df_tfx_l21.incomespecificvariable.cast('double'), df_tfx_l21.incomevariable.cast('double'),
                   df_tfx_l21.inventory.cast('double'), df_tfx_l21.invoicingfrequency.cast('double'),
                   df_tfx_l21.ishedged.cast('boolean'), df_tfx_l21.locationneutralpaymentterms.cast('double'),
                   df_tfx_l21.measureunitcode, df_tfx_l21.oaffixed.cast('double'),
                   df_tfx_l21.oafspecificfixed.cast('double'), df_tfx_l21.oafspecificvariable.cast('double'),
                   df_tfx_l21.oafvariable.cast('double'),
                   df_tfx_l21.overheadfixed.cast('double'), df_tfx_l21.overheadspecificfixed.cast('double'),
                   df_tfx_l21.overheadspecificvariable.cast('double'), df_tfx_l21.overheadvariable.cast('double'),
                   df_tfx_l21.paffixed.cast('double'), df_tfx_l21.pafspecificfixed.cast('double'),
                   df_tfx_l21.pafspecificvariable.cast('double'), df_tfx_l21.pafvariable.cast('double'),
                   df_tfx_l21.paymentterm.cast('double'), df_tfx_l21.premium.cast('double'),
                   df_tfx_l21.premiumdescriptor, df_tfx_l21.pricebasis, df_tfx_l21.pricingpricebasis,
                   df_tfx_l21.productloss.cast('double'), df_tfx_l21.revenue.cast('double'),
                   df_tfx_l21.revenuefixed.cast('double'), df_tfx_l21.revenuespecificfixed.cast('double'),
                   df_tfx_l21.revenuespecificvariable.cast('double'), df_tfx_l21.revenuevariable.cast('double'),
                   df_tfx_l21.sellingprice.cast('double'), df_tfx_l21.sourcecostofproduct.cast('double'),
                   df_tfx_l21.stockdays.cast('double'),
                   df_tfx_l21.suppliercreditdays.cast('double'), df_tfx_l21.supplierinvoicingfrequency.cast('double'),
                   df_tfx_l21.supplierpaymentterm.cast('double'), df_tfx_l21.supplychain,
                   df_tfx_l21.temperatureadjustment.cast('double'), df_tfx_l21.temperaturegain.cast('double'),
                   df_tfx_l21.unitfloorprice.cast('double'), df_tfx_l21.unitgrossmargin.cast('double'),
                   df_tfx_l21.unitgrossprofit.cast('double'), df_tfx_l21.unitofmeasureadjustment.cast('double'),
                   df_tfx_l21.variablecosts.cast('double'), df_tfx_l21.workingcapital.cast('double'),
                   df_tfx_l21.abmcsovariable.cast('double'), df_tfx_l21.abmcsofixed.cast('double'),
                   df_tfx_l21.abmcsospecificvariable.cast('double'), df_tfx_l21.abmcsospecificfixed.cast('double'),
                   df_tfx_l21.abmincomevariable.cast('double'), df_tfx_l21.abmincomefixed.cast('double'),
                   df_tfx_l21.abmincomespecificvariable.cast('double'),
                   df_tfx_l21.abmincomespecificfixed.cast('double'), df_tfx_l21.abmpafvariable.cast('double'),
                   df_tfx_l21.abmpaffixed.cast('double'), df_tfx_l21.abmpafspecificvariable.cast('double'),
                   df_tfx_l21.abmpafspecificfixed.cast('double'), df_tfx_l21.abmoafvariable.cast('double'),
                   df_tfx_l21.abmoaffixed.cast('double'), df_tfx_l21.abmoafspecificvariable.cast('double'),
                   df_tfx_l21.abmoafspecificfixed.cast('double'), df_tfx_l21.abmrevenuevariable.cast('double'),
                   df_tfx_l21.abmrevenuefixed.cast('double'), df_tfx_l21.abmrevenuespecificvariable.cast('double'),
                   df_tfx_l21.abmrevenuespecificfixed.cast('double'), df_tfx_l21.abmoverheadvariable.cast('double'),
                   df_tfx_l21.abmoverheadfixed.cast('double'), df_tfx_l21.abmoverheadspecificvariable.cast('double'),
                   df_tfx_l21.abmoverheadspecificfixed.cast('double'), df_tfx_l21.isdebriefed.cast('boolean'),
                   df_tfx_l21.isproposedcontract.cast('boolean'), df_tfx_l21.isproposedbusiness.cast('boolean'),
                   df_tfx_l21.islocationadjustment.cast('boolean'), df_tfx_l21.key
                   )

        max_date = df_tfx_l31.agg({"infa_ext_dt": "max"}).collect()[0][0]
        print("*********************", df_tfx_l31.printSchema())
        df_tfx_l32 = df_tfx_l31.filter(df_tfx_l31.infa_ext_dt == max_date).\
            select(df_tfx_l31.tenderkey, df_tfx_l31.month, df_tfx_l31.locationcode, df_tfx_l31.locationname,
                   df_tfx_l31.productcode, df_tfx_l31.globalrefnumber, df_tfx_l31.contractstart, df_tfx_l31.contractend,
                   df_tfx_l31.unitofmeasure, df_tfx_l31.currency, df_tfx_l31.volume, df_tfx_l31.forecastedvolume,
                   df_tfx_l31.actualvolume, df_tfx_l31.tenderedvolume, df_tfx_l31.averageuplift,
                   df_tfx_l31.differential,
                   df_tfx_l31.netdifferential, df_tfx_l31.rebate, df_tfx_l31.grossprofit,
                   df_tfx_l31.forecastedgrossprofit, df_tfx_l31.actualgrossprofit, df_tfx_l31.salesforcetenderid,
                   df_tfx_l31.salesforcetenderlocationlineitemid, df_tfx_l31.tmstenderid, df_tfx_l31.tmstenderseq,
                   df_tfx_l31.createdon, df_tfx_l31.infa_ext_dt,
                   f.md5(f.concat(df_tfx_l31.tenderkey, df_tfx_l31.month, df_tfx_l31.locationcode,
                                  df_tfx_l31.locationname, df_tfx_l31.productcode, df_tfx_l31.globalrefnumber,
                                  df_tfx_l31.contractstart, df_tfx_l31.contractend, df_tfx_l31.volume,
                                  df_tfx_l31.differential, df_tfx_l31.tmstenderid)).alias('checksum')
                   )
        df_tfx_l4 = df_tfx_l32. \
            select(df_tfx_l32.tenderkey, df_tfx_l32.month, df_tfx_l32.locationcode, df_tfx_l32.locationname,
                   df_tfx_l32.productcode, df_tfx_l32.globalrefnumber, df_tfx_l32.contractstart,
                   df_tfx_l32.contractend, df_tfx_l32.unitofmeasure, df_tfx_l32.currency, df_tfx_l32.tmstenderid,
                   df_tfx_l32.tmstenderseq, df_tfx_l32.volume, df_tfx_l32.forecastedvolume, df_tfx_l32.actualvolume,
                   df_tfx_l32.tenderedvolume, df_tfx_l32.averageuplift, df_tfx_l32.differential,
                   df_tfx_l32.netdifferential, df_tfx_l32.rebate, df_tfx_l32.grossprofit,
                   df_tfx_l32.forecastedgrossprofit, df_tfx_l32.actualgrossprofit, df_tfx_l32.infa_ext_dt
                   )

        df_tfx_result = [df_tfx_l21, df_tfx_l31, df_tfx_l32, df_tfx_l4]

        return df_tfx_result


if __name__ == '__main__':
    trl = TMMipETL()
    trl.execute()
