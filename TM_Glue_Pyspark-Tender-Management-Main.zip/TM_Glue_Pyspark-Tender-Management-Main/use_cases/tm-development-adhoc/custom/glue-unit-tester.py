# testing the Deployment of Glue job using different branch
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import re
from pyspark.sql import functions as f

gc = GlueContext(SparkContext.getOrCreate())
spark = gc.sparkSession
job = Job(gc)

args = getResolvedOptions(sys.argv, ['JOB_NAME'])

job.init(args['JOB_NAME'], args)
source_path = 's3://sdlf-aviation-921380586770-artifacts/insight_hub/unit_test_results/'

db_tbl_list = ['conform_main_aviation.l42_prot_dim_cost_loaded_date',
               'conform_main_aviation.l42_prot_dim_pricing_conditions',
               'conform_main_aviation.l42_prot_fact_sales_billing_cost_allocation',
               'conform_main_aviation.l42_prot_fact_sales_billing_cost_allocation_final',
               'conform_main_aviation.l42_prot_fact_sales_billing_estimated_cost',
               'conform_main_aviation.l42_prot_fact_sales_pricing_conditions']

for table in db_tbl_list:
    database, inp_table = map(str, table.split('.'))
    print('processing {}.{}'.format(database, inp_table))
    input_df = gc.create_dynamic_frame.from_catalog(database=database, table_name=inp_table,
                                                    transformation_ctx='target_table').toDF()

    global_count = input_df.count()
    # input_df.select(input_df.infa_ext_dt).show()
    schema_string = input_df._jdf.schema().treeString()
    # print(global_count, schema_string)

    columns = ['summary']
    row = ['type']
    counter = ['global_count']

    for col in schema_string.split('\n'):

        element = tuple(re.sub('(\(nullable = true\)|\|--|\s+)', '', col).split(":"))

        if len(element) > 1:
            columns.append(element[0])
            row.append(element[1])
            counter.append(str(global_count))

    row_data = [tuple(row), tuple(counter)]
    # print(row_data)

    new_df = spark.createDataFrame(data=row_data, schema=columns)
    # new_df.show()
    # new_df.printSchema()
    input_df1 = input_df.select([f.col(c).cast("string") for c in input_df.columns])
    input_df1.printSchema()
    detail_df = input_df1.describe()
    # detail_df.show()
    # detail_df.printSchema()
    select_column = detail_df.schema.names
    result = new_df.select(select_column).union(detail_df)

    table_part_list = inp_table.split('_')
    layer, use_case = table_part_list[0], table_part_list[1]

    layer_aws = {'l21': 'layer_2.1', 'l3': 'layer_3', 'l31': 'layer_3.1', 'l32': 'layer_3.2', 'l4': 'layer_4',
                 'l41': 'layer_4.1', 'l42': 'layer_4.2', 'l5': 'layer_5', 'l51': 'layer_5.1', 'l52': 'layer_5.2',
                 'l6': 'layer_6'}

    path = source_path + use_case + '_' + layer_aws.get(layer, layer) + '/' + inp_table
    result.repartition(1).sortWithinPartitions("summary").write.option('header', 'true').mode("overwrite").csv(path)