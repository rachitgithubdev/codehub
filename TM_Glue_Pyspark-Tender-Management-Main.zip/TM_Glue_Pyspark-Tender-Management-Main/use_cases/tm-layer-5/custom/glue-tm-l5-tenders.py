# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      26-Feb-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to create L4 fact tenders salsforce tables in conform zone
# Author        :- Bakul Seth
# Date          :- 26-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================


import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class TMMipETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        # input tables for JOB
        self.input_tables = ["l51_summary", "l4_location_mapping_isp", "l4_location_mapping_pre",
                             "l4_location_mapping_pr4", "l4_location_mapping_pro", "l4_location_mapping_sun",
                             "l4_dim_location", "dim_location", "l4_isp_dim_location", "l5_dim_org_hierarchy_geography"]

        # output file for JOB
        self.l5_tenders = "l5_tm_tenders"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # read data from specific table argument passed(database, table_list)
        print("starting to read tables from glue catalog for processing")
        df_inputs = self._get_table(self.source_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe)
        print("starting to apply transformations on the tables")
        df_tfx = self._apply_tfx(df_inputs)

        print("starting to write the result to the location")
        # write final result to l5 destination
        self.write_results(df_tfx, self.l5_tenders)

    def write_results(self, target_dataset, report):
        final_path = self.destination_bucket + "/" + report
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, tables_name):
        print('reading summary data from {}.{}'.format(source_database, tables_name[0]))
        df_summary = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[0], transformation_ctx='target_table').toDF()

        print('reading location_mapping_isp data from {}.{}'.format(source_database, tables_name[1]))
        df_map_isp = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[1], transformation_ctx='target_table').toDF()

        print('reading location_mapping_pre data from {}.{}'.format(source_database, tables_name[2]))
        df_map_pre = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[2], transformation_ctx='target_table').toDF()

        print('reading location_mapping_pr4 data from {}.{}'.format(source_database, tables_name[3]))
        df_map_pr4 = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[3], transformation_ctx='target_table').toDF()

        print('reading location_mapping_pro data from {}.{}'.format(source_database, tables_name[4]))
        df_map_pro = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[4], transformation_ctx='target_table').toDF()

        print('reading location_mapping_sun data from {}.{}'.format(source_database, tables_name[5]))
        df_map_sun = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[5], transformation_ctx='target_table').toDF()

        print('reading l4_dim_location data from {}.{}'.format(source_database, tables_name[6]))
        df_l4_loc = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[6], transformation_ctx='target_table').toDF()

        print('reading dim_location data from {}.{}'.format(source_database, tables_name[7]))
        df_dim_loc = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[7], transformation_ctx='target_table').toDF()

        print('reading l4_isp_dim_location data from {}.{}'.format(source_database, tables_name[8]))
        df_isp_loc = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[8], transformation_ctx='target_table').toDF()

        print('reading l5_dim_org_hierarchy_geography data from {}.{}'.format(source_database, tables_name[9]))
        df_geo = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[9], transformation_ctx='target_table').toDF()

        return [df_summary, df_map_isp, df_map_pre, df_map_pr4, df_map_pro, df_map_sun, df_l4_loc, df_dim_loc,
                df_isp_loc, df_geo]

    @staticmethod
    def _apply_tfx(df_input):
        df_tfx_result = df_input[0].alias('summary') \
            .join(df_input[1].alias('isp_map'), (f.trim(f.substring(f.col('summary.trx_loc_key'), 13, 14)) ==
                                                 f.col('isp_map.isp_mapping')) & (f.col('summary.source_system') ==
                                                                                  f.lit('ISP')), 'left') \
            .join(df_input[2].alias('pre_map'), (f.col('summary.trx_loc_key') == f.col('pre_map.pre_mapping'))
                  & (f.col('summary.source_system') == f.lit('PRE')), "left") \
            .join(df_input[3].alias('pr4_map'), (f.col('summary.trx_loc_key') == f.col('pr4_map.pr4_mapping')) &
                  (f.col('summary.source_system') == f.lit('PR4_HIST')), 'left') \
            .join(df_input[4].alias('pro_map'), (f.col('summary.trx_loc_key') == f.col('pro_map.pro_mapping')) &
                  (f.col('summary.source_system') == f.lit('BRA')), 'left') \
            .join(df_input[5].alias('sun_map'), (f.col('summary.trx_loc_key') ==
                                                 f.concat(f.col('sun_map.sun_mapping'), f.lit('_'),
                                                          f.col('sun_map.iso_code2'))
                                                 & f.col('summary.source_system') == f.lit('SUN')), 'left') \
            .join(df_input[6].alias('l4_loc'), (f.col('l4_loc.locationid') ==
                                                (f.when(f.col('summary.source_system') == f.lit('ISP'),
                                                        f.col('isp_map.location_id'))
                                                 .when(f.col('summary.source_system') == f.lit('PRE'),
                                                       f.col('pre_map.location_id'))
                                                 .when(f.col('summary.source_system') == f.lit('PR4_HIST'),
                                                       f.col('pr4_map.location_id'))
                                                 .when(f.col('summary.source_system') == f.lit('BRA'),
                                                       f.col('pro_map.location_id'))
                                                 .when(f.col('summary.source_system') == f.lit('SUN'),
                                                       f.col('sun_map.location_id')).otherwise(f.lit('1'))))) \
            .join(df_input[7].alias('dim_loc'), (f.col('dim_loc.plant')) ==
                  (f.when(f.col('summary.source_system') == f.lit('PRE'), f.col('summary.trx_loc_key')).otherwise(
                      f.lit('1')))) \
            .join(df_input[8].alias('isp_loc'), f.col('isp_loc.ref_id') ==
                  (f.when(f.col('summary.source_system') == f.lit('ISP'), f.col('summary.trx_loc_key')).otherwise(
                      f.lit('1')))) \
            .join(df_input[9].alias('df_geo'), f.col('df_geo.iso_code_2') ==
                  (f.when(f.col('summary.source_system') == f.lit('ISP'), f.col('isp_loc.country_iso2'))
                   .when(f.col('summary.source_system') == f.lit('PRE'), f.col('dim_loc.country_iso2'))
                   .otherwise(f.lit('1')))).filter(f.year(f.col('summary.delivery_date')) >= f.lit('2017') &
                                                   f.col('summary.intercompany_flag') == f.lit('N')) \
            .groupby(f.col('summary.date'), f.col('summary.grn'), f.col('summary.sector'), f.col('summary.iata'),
                     f.col('dim_loc.icao'), f.col('summary.material_description'), f.col('summary.local_currency'),
                     f.when(f.col('summary.source_system') == f.lit('PRE') & f.col('summary.trx_loc_key')
                            .isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629', '5732', '9280', '5527') &
                            f.col('summary.sales_organisation').isin('DE01', 'AT0H'), f.lit('Continental Europe'))
                     .when(f.col('summary.source_system') == f.lit('PRE') & f.col('summary.trx_loc_key')
                           .isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629', '5732', '9280', '5527') &
                           f.col('summary.sales_organisation').isin('DE01', 'AT0H') == False, f.lit('UK & Nordics'))
                     .when(f.col('dim_loc.cluster').isNull() & f.col('summary.source_system') == f.lit('PR4_HIST'),
                           f.lit('N America'))
                     .when(f.col('dim_loc.cluster').isNull(), f.col('df_geo.cluster')).otherwise(
                         f.col('dim_loc.cluster')),
                     f.when(f.col('dim_loc.location_country') == f.lit('PORTUGAL/AZORES'), f.lit('PORTUGAL'))
                     .when(f.col('dim_loc.location_country') == f.lit('SPAIN/CANARY ISLANDS'), f.lit('SPAIN'))
                     .when(f.col('summary.source_system') == f.lit('PRE') &
                           f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                             '5732',
                                                             '9280', '5527') &
                           f.col('summary.sales_organisation') == f.lit('SE03'), f.lit('SWEDEN'))
                     .when(f.col('summary.source_system') == f.lit('PRE') &
                           f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                             '5732',
                                                             '9280', '5527') &
                           f.col('summary.sales_organisation') == f.lit('NO01'), f.lit('NORWAY'))
                     .when(f.col('summary.source_system') == f.lit('PRE') &
                           f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                             '5732',
                                                             '9280', '5527') &
                           f.col('summary.sales_organisation') == f.lit('DK01'), f.lit('DENMARK'))
                     .when(f.col('summary.source_system') == f.lit('PRE') &
                           f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                             '5732',
                                                             '9280', '5527') &
                           f.col('summary.sales_organisation') == f.lit('DE01'), f.lit('GERMANY'))
                     .when(f.col('summary.source_system') == f.lit('PRE') &
                           f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                             '5732',
                                                             '9280', '5527') &
                           f.col('summary.sales_organisation') == f.lit('AT0H'), f.lit('AUSTRIA'))
                     .when(f.col('dim_loc.location_country').inNull() & f.col('summary.source_system') == f.lit(
                         'PR4_HIST'),
                           f.lit('USA'))
                     .when(f.col('dim_loc.location_country').isNull(), f.col('df_geo.country')),
                     f.when(f.col('l4_loc.location_name').isNull() & f.col('summary.source_system') == f.lit('PRE'),
                            f.col('dim_loc.location_name'))
                     .when(f.col('l4_loc.location_name').isNull() & f.col('summary.source_system') == f.lit('ISP'),
                           f.col('isp_loc.location_name'))
                     .when(f.col('l4_loc.location_name').isNull() & f.col('summary.source_system') == f.lit('PR4_HIST'),
                           f.col('summary.trx_loc_key')).otherwise('summary.location_name')) \
            .agg(f.sum(f.coalesce(f.col('summary.qty_in_usg'), f.lit(0))).alias('qty_in_usg'),
                 f.sum(f.coalesce(f.col('summary.qty_in_litres'), f.lit(0))).alias('qty_in_litres'),
                 f.sum(f.coalesce(f.col('summary.gross_profit_usd'), f.lit(0))).alias('gross_profit_usd'),
                 f.sum(f.coalesce(f.col('summary.gross_profit_lc'), f.lit(0))).alias('gross_profit_lc'),
                 f.sum(f.coalesce(f.col('summary.l4_on_airfield_costs_usd'), f.lit(0)) +
                       f.coalesce(f.col('summary.l4_pre_airfield_sh_usd'), f.lit(0)) +
                       f.coalesce(f.col('summary.l4_pre_airfield_transport_usd'), f.lit(0))).alias(
                     'fully_built_up_cost_usd'),
                 f.sum(f.coalesce(f.col('summary.l4_on_airfield_costs_lc'), f.lit(0)) +
                       f.coalesce(f.col('summary.l4_pre_airfield_sh_lc'), f.lit(0)) +
                       f.coalesce(f.col('summary.l4_pre_airfield_transport_lc'), f.lit(0))).alias(
                     'fully_built_up_cost_lc')) \
            .select(f.to_date(f.col('summary.delivery_date')).alias('date'), f.col('summary.grn'),
                    f.coalesce(f.trim(f.col('summary.sector')), f.lit('')).alias('sector'), f.col('summary.iata'),
                    f.col('dim_loc.icao'), f.col('material_description'),
                    f.col('summary.local_currency').alias('currency'),
                    f.when(f.col('summary.source_system') == f.lit('PRE') &
                           f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                             '5732', '9280', '5527') &
                           f.col('summary.sales_organisation').isin('DE01', 'AT0H'), f.lit('Continental Europe'))
                    .when(f.col('summary.source_system') == f.lit('PRE') &
                          f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                            '5732', '9280', '5527') &
                          f.col('summary.sales_organisation').isin('DE01', 'AT0H') == False, f.lit('UK & Nordics'))
                    .when(f.col('dim_loc.cluster').isNull() & f.col('summary.source_system') == f.lit('PR4_HIST'),
                          f.lit('N America'))
                    .when(f.col('dim_loc.cluster').isNull(), f.lit('df_geo.cluster'))
                    .otherwise(f.col('dim_loc.location_country')),
                    f.when(f.col('dim_loc.location_country') == f.lit('PORTUGAL/AZORES'), f.lit('PORTUGAL'))
                    .when(f.col('dim_loc.location_country') == f.lit('SPAIN/CANARY ISLANDS'), f.lit('SPAIN'))
                    .when(f.col('summary.source_system') == f.lit('PRE') &
                          f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                            '5732',
                                                            '9280', '5527') &
                          f.col('summary.sales_organisation') == f.lit('SE03'), f.lit('SWEDEN'))
                    .when(f.col('summary.source_system') == f.lit('PRE') &
                          f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                            '5732',
                                                            '9280', '5527') &
                          f.col('summary.sales_organisation') == f.lit('NO01'), f.lit('NORWAY'))
                    .when(f.col('summary.source_system') == f.lit('PRE') &
                          f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                            '5732',
                                                            '9280', '5527') &
                          f.col('summary.sales_organisation') == f.lit('DK01'), f.lit('DENMARK'))
                    .when(f.col('summary.source_system') == f.lit('PRE') &
                          f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                            '5732',
                                                            '9280', '5527') &
                          f.col('summary.sales_organisation') == f.lit('DE01'), f.lit('GERMANY'))
                    .when(f.col('summary.source_system') == f.lit('PRE') &
                          f.col('summary.trx_loc_key').isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                            '5732',
                                                            '9280', '5527') &
                          f.col('summary.sales_organisation') == f.lit('AT0H'), f.lit('AUSTRIA'))
                    .when(f.col('dim_loc.location_country').inNull() & f.col('summary.source_system') == f.lit(
                        'PR4_HIST'),
                          f.lit('USA'))
                    .when(f.col('dim_loc.location_country').isNull(), f.col('df_geo.country'))
                    .otherwise(f.col('dim_loc.location_country')).alias('country'),
                    f.when(f.col('l4_loc.location_name').isNull() & f.col('summary.source_system') == f.lit('PRE'),
                           f.col('dim_loc.location_name'))
                    .when(f.col('l4_loc.location_name').isNull() & f.col('summary.source_system') == f.lit('ISP'),
                          f.col('isp_loc.location_name'))
                    .when(f.col('l4_loc.location_name').isNull() & f.col('summary.source_system') == f.lit('PR4_HIST'),
                          f.col('summary.trx_loc_key')).otherwise('summary.location_name').alias('location_name'))

        return df_tfx_result


if __name__ == '__main__':
    trl = TMMipETL()
    trl.execute()
