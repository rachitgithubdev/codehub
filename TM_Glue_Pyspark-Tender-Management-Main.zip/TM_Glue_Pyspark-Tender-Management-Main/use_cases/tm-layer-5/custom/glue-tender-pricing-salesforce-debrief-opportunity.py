# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      08-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to create tender Pricing_SalesForce_Debrief_Main tables
#                   in conform zone
# Author        :- Bakul Seth
# Date          :- 23-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================


import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class TMMipETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        # input tables for JOB
        self.input_tables = ['l2_performance_reporting_performance_mappings', 'l6_all_lcpsummary',
                             'l4_fact_tenders_salesforce', 'l32_salesforce_tender_location_line_item',
                             'l32_salesforce_tender_location', 'l2_performance_reporting_customer_mappings',
                             'l2_v_customer', 'l2_salesforce_account_holders', 'l4_dim_location',
                             'l2_l5_fact_tms_tender', 'l2_stg2_account', 'l2_manager_mapping_table', 'l2_dim_currency',
                             'l2_dim_uom', 'l2_ranking_master']

        # output file for JOB
        self.l5_pricing_salesforce_debrief_opportunity = 'l5_tm_pricing_salesforce_debrief_opportunity'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # read data from specific table argument passed(database, table_list)
        print('starting to read tables from glue catalog for processing')
        df_inputs = self._get_table(self.source_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe)
        print('starting to apply transformations on the tables')
        df_tfx = self._apply_tfx(df_inputs)

        print('starting to write the result to the location')
        # write final result to l5 destination
        self.write_results(df_tfx, self.l5_pricing_salesforce_debrief_opportunity)

    def write_results(self, target_dataset, report):
        final_path = self.destination_bucket + '/' + report
        print('final_path', final_path)
        target_dataset \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, tables_name):
        print('reading performance_reporting_location_mappings data from {}.{}'.format(source_database, tables_name[0]))
        df_loc_map = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[0], transformation_ctx='target_table').toDF()

        print('reading l6_all_lcpsummary data from {}.{}'.format(source_database, tables_name[1]))
        df_l6_summary = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[1], transformation_ctx='target_table').toDF()

        print('reading sf l4_fact_tenders_salesforce data from {}.{}'.format(source_database, tables_name[2]))
        df_fact_sf = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[2], transformation_ctx='target_table').toDF()

        print('reading sf tender_location_line_item data from {}.{}'.format(source_database, tables_name[3]))
        df_line_item = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[3], transformation_ctx='target_table').toDF()

        print('reading sf tender_location data from {}.{}'.format(source_database, tables_name[4]))
        df_loccation = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[4], transformation_ctx='target_table').toDF()

        print('reading performance_reporting_customer_mappings data from {}.{}'.format(source_database, tables_name[5]))
        df_cust_map = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[5], transformation_ctx='target_table').toDF()

        print('reading l2_v_customer data from {}.{}'.format(source_database, tables_name[6]))
        df_v_cust = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[6], transformation_ctx='target_table').toDF()

        print('reading l2_salesforce_account_holders data from {}.{}'.format(source_database, tables_name[7]))
        df_acc_hold = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[7], transformation_ctx='target_table').toDF()

        print('reading l4_dim_location data from {}.{}'.format(source_database, tables_name[8]))
        df_l4_dim_loc = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[8], transformation_ctx='target_table').toDF()

        print('reading fact_tms_tender data from {}.{}'.format(source_database, tables_name[9]))
        df_l4_tms = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[9], transformation_ctx='target_table').toDF()

        print('reading stg2_account data from {}.{}'.format(source_database, tables_name[10]))
        df_stg2_acc = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[10], transformation_ctx='target_table').toDF()

        print('reading manager_mapping_table data from {}.{}'.format(source_database, tables_name[11]))
        df_man_map = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[11], transformation_ctx='target_table').toDF()

        print('reading dim_currency data from {}.{}'.format(source_database, tables_name[12]))
        df_dim_curr = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[12], transformation_ctx='target_table').toDF()

        print('reading dim_uom data from {}.{}'.format(source_database, tables_name[13]))
        df_dim_uom = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[13], transformation_ctx='target_table').toDF()

        print('reading ranking_master data from {}.{}'.format(source_database, tables_name[14]))
        df_rank_master = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[14], transformation_ctx='target_table').toDF()

        return [df_loc_map, df_l6_summary, df_fact_sf, df_line_item, df_loccation, df_cust_map, df_v_cust, df_acc_hold,
                df_l4_dim_loc, df_l4_tms, df_stg2_acc, df_man_map, df_dim_curr, df_dim_uom, df_rank_master]

    @staticmethod
    def _apply_tfx(df_input):

        df_loc_map2 = df_input[0]\
            .select(f.col('country'), f.col('cluster'), f.col('performance_unit')).distinct()

        df_lcpsummary = df_input[1].select(f.col('plant'), f.col('pu'), f.col('country'),
                                           f.when(f.col('cluster') == f.lit('UK & Nordics'), f.lit('UK & Nordics'))
                                           .when(f.col('cluster') == f.lit('S America'), f.lit('S. America'))
                                           .otherwise(f.col('cluster')).alias('cluster')).distinct()
        #
        df_result1 = df_input[2].alias('sf').filter(f.col('sf.tender_line_item_status') != f.lit('Not Represented'))\
            .join(df_input[3].alias('loc_line'), f.col('sf.tender_key') == f.col('loc_line.id'), 'inner')\
            .join(df_input[4].alias('loc'), f.col('loc_line.aitm_location__c') == f.col('loc.aitm_location__c') &
                  f.col('loc_line.aitm_tender_location__c') == f.col('loc.id'), 'inner') \
            .join(df_input[5].alias('cust_map'), f.col('sf.grn') == f.col('cust_map.grn'), 'left') \
            .join(df_input[0].alias('loc_map'), f.col('sf.location_code') == f.col('loc_map.iata_code'), 'left') \
            .join(df_input[6].alias('vcust'), f.col('sf.grn') == f.col('vcust.v_customergrn'), 'left') \
            .join(df_input[7].alias('acc_hold'), f.col("sf.grn") == f.col("acc_hold.grn"), 'left') \
            .join(df_input[8].alias('dim_loc'), f.col('sf.location_code') == f.col('loc.iata'), 'left') \
            .join(df_loc_map2.alias('loc_map2'), f.lower(f.col('loc_map.country')) == f.lower('loc_map2.country'),
                  'left') \
            .join(df_lcpsummary.alias('l6_data'), f.col('sf.tender_line_item_status') == f.col('l6_data.plant'),
                  'left') \
            .select(f.col('sf.tender_name'), f.col('f.requested_volume_usg'), f.col('sf.offered_volume'),
                    f.col('sf.result'),
                    f.when(f.coalesce(f.col('loc_map.loc_airport_name'), f.lit('')) != f.lit(''),
                           f.col('loc_map.loc_airport_name'))
                    .otherwise(f.lower(f.col('loc.aitm_title__c'))).alias('loc_airport_name'),
                    f.when(f.coalesce(f.col('loc_map.country'), f.lit('')) != f.lit(''),
                           f.initcap(f.col('loc_map.country')))
                    .when(f.coalesce(f.col('l6_data.country'), f.lit('')) != f.lit(''), f.col('l6_data.country'))
                    .otherwise(f.initcap(f.col('loc.aitm_country__c'))).alias('country'),
                    f.col('loc_line.aitm_start_date__c').alias('start_date'), f.col('sf.sector'),
                    f.col('sf.aitm_depe_pricing_basis__c'),
                    f.when(f.coalesce(f.col('cust_map.customer'), f.lit('')) != f.lit(''), f.col('cust_map.customer'))
                    .when((f.coalesce(f.col('cust_map.customer'), f.lit('')) == f.lit('')) &
                          (f.coalesce(f.col('cust_map.carrier'), f.lit('')) != f.lit('')), f.col('cust_map.carrier'))
                    .when((f.coalesce(f.col('cust_map.customer'), f.lit('')) == f.lit('')) &
                          (f.coalesce(f.col('cust_map.group'), f.lit('')) != f.lit('')), f.col('cust_map.group'))
                    .otherwise(f.coalesce(f.col('sf.customer_name'), f.lit('Other'))).alias('customername'),
                    f.when((f.col('sf.sector') == f.lit('GA')) &
                           (f.coalesce(f.col('loc.ga_location_manager'), f.lit('')) != f.lit('')),
                           f.col('loc.ga_location_manager'))
                    .when((f.col('sf.sector') == f.lit('CA')) &
                          (f.coalesce(f.col('loc.ga_location_manager'), f.lit('')) != f.lit('')),
                          f.col('loc.ca_location_manager'))
                    .when((f.col('sf.sector') == f.lit('Military')) &
                          (f.coalesce(f.col('loc.ga_location_manager'), f.lit('')) != f.lit('')),
                          f.col('loc.ca_location_manager'))
                    .otherwise(f.col('sf.location_manager')).alias('location_manager'),
                    f.col('loc_line.aitm_end_date__c').alias('end_date'), f.col('awarded_volume'), f.col('sf.grn'),
                    f.col('offered_differential'), f.col('currency').alias('offereddifferentialcurrency'),
                    f.col('UOM').alias('offereddifferentialuom'),
                    f.when(f.coalesce(f.initcap(f.col('cust_map.account_holder')), f.lit('Other')) != 'Other',
                           f.coalesce(f.initcap(f.col('cust_map.account_holder')), f.lit('Other')))
                    .when(f.coalesce(f.initcap(f.col('acc_hold.account_owner')), f.lit('Other')) != 'Other',
                          f.coalesce(f.initcap(f.col('acc_hold.account_owner')), f.lit('Other')))
                    .otherwise(f.col('sf.account_manager')).alias('account_manager'),
                    f.col('cust_map.rsm').alias('rsm'),
                    f.when(f.coalesce(f.col('loc_map.cluster'), f.lit('')) != f.lit(''), f.col('loc_map.cluster'))
                    .when(f.coalesce(f.col('l6_data.cluster'), f.lit('')) != f.lit(''), f.col('l6_data.cluster'))
                    .otherwise(f.col('loc_map2.cluster')).alias('cluster'),
                    f.when(f.coalesce(f.col('loc_map.performance_unit'), f.lit('')) != f.lit(''),
                           f.col('loc_map.performance_unit'))
                    .when(f.coalesce(f.col('l6_data.pu'), f.lit('')) != f.lit(''), f.col('l6_data.pu'))
                    .otherwise(f.col('loc_map2.performance_unit')).alias('performance_unit'),
                    f.lit('').alias('pricng_basis'), f.col('cust_map.carrier'),
                    f.to_date(f.col('aitm_debrief_email_sent_date__c'), 'MM/dd/yyyy').alias(
                        'aitm_debrief_email_sent_date__c'),
                    f.when(f.coalesce(f.col('aitm_debrief_email_sent_date__c'), f.lit('')) == f.lit(''),
                           f.col('loc_line.aitm_start_date__c'))
                    .when(f.datediff(f.to_date(f.col('loc_line.aitm_start_date__c'), 'MM/dd/yyyy'),
                                     f.to_date(f.col('aitm_debrief_email_sent_date__c'), 'MM/dd/yyyy')) < f.lit(0),
                          f.col('loc_line.aitm_start_date__c'))
                    .otherwise(f.to_date(f.col('aitm_debrief_email_sent_date__c'), 'MM/dd/yyyy')).alias(
                        'decision_date'),
                    f.when(f.coalesce(f.col('cust_map.group'), f.lit('')) != f.lit(''), f.col('cust_map.group'))
                    .when((f.coalesce(f.col('cust_map.group'), f.lit('')) == f.lit('')) &
                          (f.coalesce(f.col('cust_map.customer'), f.lit('')) != f.lit('')),
                          f.coalesce(f.col('cust_map.customer'), f.lit('Other')))
                    .otherwise(f.coalesce(f.col('sf.customer_name'), f.lit('Other'))).alias('customergroup'),
                    f.round(f.months_between(f.col('loc_line.aitm_end_date__c'),
                                             f.col('loc_line.aitm_start_date__c')), 0).alias('contractmonths'),
                    f.date_add(f.col('loc_line.aitm_end_date__c'), 1).alias('startdatenewcontract'),
                    f.add_months(f.col('loc_line.aitm_end_date__c'), f.col('sf.contract_length')).alias(
                        'enddatanewcontract'),
                    f.coalesce((f.col('sf.requested_volume_usg') - f.col('awarded_volume')), f.lit(0)).alias(
                        'oppertunity'),
                    f.col('sf.location_code'), f.col('loc_line.aitm_start_date__c').alias('start1'),
                    f.col('loc_line.aitm_end_date__c').alias('end1'),
                    f.when(f.year(f.col('loc_line.aitm_end_date__c')) == f.lit('2020'),
                           f.month(f.col('loc_line.aitm_end_date__c')))
                    .when(f.year(f.col('loc_line.aitm_end_date__c')) < f.lit('2020') |
                          f.year(f.col('loc_line.aitm_start_date__c')) > f.lit('2020'), f.lit(0).alias('2020_months')),
                    f.col('sf.last_refreshed_date'))

        df_result2 = df_input[9].alias('tms').filter(f.col('tms.status') != f.lit('Not Represented')) \
            .join(df_input[3].alias('line_item'),
                  f.concat(f.col('line_item.aitm_tender__c'), f.col('li.aitm_account__c'), f.col('li.aitm_location__c'),
                           f.col('li.aitm_seq_no__c')) == f.col('tms.tender_key'), 'inner') \
            .join(df_input[7].alias('acc_hold'), f.col('tms.grn') == f.col('acc_hold.grn'), 'left') \
            .join(df_input[8].alias('dim_loc'), f.col('tms.location_code') == f.col('dim_loc.iata'), 'left') \
            .join(df_input[5].alias('cust_map'), f.col('tms.grn') == f.col('cust_map.grn'),
                  'left') \
            .join(df_input[0].alias('loc_map'),
                  f.col('TMS.Location_Code') == f.col('perf_loc.iata_code')) \
            .join(df_input[6].alias('vcust'), f.col('tms.grn') == f.col('vcust.v_customergrn'), 'left') \
            .join(df_input[10].alias('acc'), f.col('line_item.aitm_tender__c') == f.col('acc.aitm_tender__c') &
                  f.col('line_item.aitm_account__c') == f.col('acc.aitm_grn__c'), 'left') \
            .select(f.col('tms.tender_name'), f.col('tms.requested_volume_usg'), f.col('tms.offered_volume'),
                    f.col('tms.result'), f.col('loc_map.loc_airport_name'), f.col('loc_map.country').alias('country'),
                    f.col('tms.start_date').alias('start_date'), f.col('tms.sector'),
                    f.lit('').alias('aitm_depe_pricing_basis__c'),
                    f.when(f.coalesce(f.col('cust_map.customer'), f.lit('')) != f.lit(''), f.col('cust_map.customer'))
                    .when((f.coalesce(f.col('cust_map.customer'), f.lit('')) == f.lit('')) &
                          (f.coalesce(f.col('cust_map.carrier'), f.lit('') != f.lit(''))), f.col('cust_map.carrier'))
                    .when((f.coalesce(f.col('cust_map.customer'), f.lit('')) == f.lit('')) &
                          (f.coalesce(f.col('cust_map.group'), f.lit('') != f.lit(''))), f.col('cust_map.group'))
                    .otherwise(f.coalesce(f.col('tms.customer_name'), f.lit('Other'))).alias('customername'),
                    f.when((f.col('tms.sector') == f.lit('GA')) &
                           (f.coalesce(f.col('loc.ga_location_manager'), f.lit('')) != f.lit('')),
                           f.col('loc.ga_location_manager'))
                    .when((f.col('tms.sector') == f.lit('CA')) &
                          (f.coalesce(f.col('loc.ca_location_manager'), f.lit('')) != f.lit('')),
                          f.col('loc.ca_location_manager'))
                    .when((f.col('tms.sector') == f.lit('Military')) &
                          (f.coalesce(f.col('loc.ca_location_manager'), f.lit('')) != f.lit('')),
                          f.col('loc.ca_location_manager'))
                    .otherwise(f.col('tms.location_manager')).alias('location_manager'),
                    f.col('tms.end_date').alias('end_date'), f.col('tms.awarded_volume'), f.col('tms.grn'),
                    f.col('tms.offered_differntial').alias('offered_differential'),
                    f.col('tms.currency').alias('offereddifferentialcurrency'),
                    f.col('tms.uom').alias('offereddifferentialuom'),
                    f.when(f.coalesce(f.initcap(f.col('cust_map.account_holder')), f.lit('Other')) != f.lit('Other'),
                           f.coalesce(f.initcap(f.col('cust_map.account_holder')), f.lit('Other')))
                    .when(f.coalesce(f.initcap(f.col('acc_hold.account_owner')), f.lit('Other')) != f.lit('Other'),
                          f.coalesce(f.initcap(f.col('acc_hold.account_owner')), f.lit('Other')))
                    .otherwise(f.lit('Other')).alias('account_owner'),
                    f.col('cust_map.rsm').alias('rsm'), f.col('loc_map.cluster').alias('cluster'),
                    f.col('loc_map.performance_unit').alias('performance_unit'),
                    f.lit('').alias('pricng_basis'), f.col('cust_map.carrier'),
                    f.to_date(f.col('tms.start_date'), 'MM/dd/yyyy').alias('aitm_debrief_email_sent_date__c'),
                    f.to_date(f.col('tms.start_date'), 'MM/dd/yyyy').alias('decision_date'),
                    f.when(f.coalesce(f.col('cust_map.group'), f.lit('')) != f.lit(''), f.col('cust_map.group'))
                    .otherwise(f.coalesce(f.col('tms.customer_name'), f.lit('Other'))).alias('customergroup'),
                    f.col('tms.contract_length').alias('contractmonths'),
                    f.date_add(f.col('tms.end_date'), 1).alias('startdatenewcontract'),
                    f.add_months(f.col('tms.end_date'), f.col('tms.contract_length')).alias('enddatanewcontract'),
                    f.coalesce((f.col('tms.requested_volume_usg') - f.col('awarded_volume')), f.lit(0)).alias(
                        'oppertunity'),
                    f.col('tms.location_code'), f.col('tms.start_date').alias('start1'),
                    f.col('tms.end_date').alias('end1'),
                    f.when(f.year(f.col('tms.end_date')) == f.lit('2020'), f.month(f.col('tms.end_date')))
                    .when((f.year(f.col('tms.end_date')) < f.lit('2020')) or
                          (f.year(f.col('ms.end_date')) > f.lit('2020')), f.lit(0))
                    .otherwise(12 - f.month(f.col('tms.start_date'))).alias('2020_months'), f.lit(''))

        df_tfx_result = df_result1.union(df_result2) \
            .filter(f.col('df_result2.start_date') < f.lit('2020-04-01') |
                    (f.col('df_result2.start_date') >= f.lit('2020-04-01') &
                     f.coalesce(f.col('df_result2.aitm_debrief_email_sent_date__c'), f.lit('')) != f.lit(''))) \
            .join(df_input[11].alias('man_map'),
                  f.initcap(f.col('df_result2.account_manager') == f.initcap(f.col('man_map.original_name'))), 'left') \
            .join(df_input[11].alias('man_map2'),
                  f.initcap(f.col('df_result2.location_manager') == f.initcap(f.col('acc_mapping1.original_name'))),
                  'left') \
            .join(df_input[12].alias('dim_curr'),
                  f.date_sub(f.col('decision_date'), f.dayofmonth(f.col('decision_date') - 1)) == f.col(
                      'dim_curr.month') &
                  f.col('df_result2.offereddifferentialcurrency') == f.col('dim_curr.source') &
                  f.col('dim_curr.target') == f.lit('USD')) \
            .join(df_input[13].alias('dim_uom'), f.col('df_result2.offereddifferentialuom') == f.col('dim_oum.source') &
                  f.col('uom.target') == f.lit('USG')) \
            .join(df_input[14].alias('rank_mast'),
                  f.col('df_result2.customergroup') == f.col('rank_mast.customergroup')) \
            .select(f.col('tender_name'),
                    f.coalesce(f.col('requested_volume_usg'), f.lit(0)).alias('requested_volume_usg'),
                    f.coalesce(f.col('offered_volume'), f.lit(0)).alias('offered_volume'),
                    (f.coalesce(f.col('offered_volume'), f.lit(0))) * f.col('dim_uom.factor').alias(
                        'offered_volume_usg'),
                    f.col('result'), f.col('loc_airport_name'), f.col('country'), f.col('start_date'), f.col('sector'),
                    f.col('aitm_depe_pricing_basis__c'), f.col('customername'),
                    f.coalesce(f.col('man_map2.mapped_name'), f.lit('Other')).alias('location_manager'),
                    f.col('end_date'),
                    f.coalesce(f.col('awarded_volume'), f.lit(0)).alias('awarded_volume'), f.col('grn'),
                    f.col('offered_differential'), f.col('offereddifferentialcurrency'),
                    (f.col('offered_differential') * f.col('dim_curr.rate')).alias('offered_differential_usd'),
                    (f.col('offered_differential') * f.col('dim_curr.rate') *
                     f.coalesce(f.col('offered_volume'), f.lit(0))).alias('Offered_Differential_Amount_USD'),
                    f.date_sub(f.col('decision_date'), f.dayofmonth(f.col('decision_date') - 1)).alias(
                        'exchange_rate_date'),
                    f.col('dim_curr.rate'), f.col('offereddifferentialuom'),
                    f.coalesce(f.col('acc_mapping.mapped_name'), f.lit('Other')).alias('account_manager'), f.col('rsm'),
                    f.col('cluster'), f.col('performance_unit'), f.col('pricng_basis'), f.col('carrier'),
                    f.col('aitm_debrief_email_sent_date__c'), f.col('decision_date'), f.col('df_result2.customergroup'),
                    f.when(f.coalesce(f.col('rank_mast.demark'), f.lit(999)) == f.lit(999), f.lit(0.5))
                    .otherwise(f.col('rank_mast.demark')).alias('customerranking'), f.col('contractmonths'),
                    f.col('startdatenewcontract'), f.col('enddatanewcontract'), f.col('oppertunity'),
                    f.col('location_code'),
                    f.col('Start1'), f.col('end1'), f.col('2020_Months'), f.col('last_refreshed_date'))

        return df_tfx_result


if __name__ == '__main__':
    trl = TMMipETL()
    trl.execute()
