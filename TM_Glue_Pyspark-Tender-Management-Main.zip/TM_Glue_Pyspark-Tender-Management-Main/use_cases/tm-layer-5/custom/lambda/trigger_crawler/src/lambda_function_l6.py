import boto3

client = boto3.client('glue')


def lambda_handler(event, context):
    print('Start the glue crawler')
    response = client.start_crawler(Name='aviation-tm-layer-6-crawler')
    print('***********')
