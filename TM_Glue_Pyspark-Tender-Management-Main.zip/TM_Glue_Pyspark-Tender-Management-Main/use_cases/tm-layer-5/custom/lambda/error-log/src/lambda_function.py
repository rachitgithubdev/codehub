from datalake_library.commons import init_logger
from datalake_library.configuration.resource_configs import DynamoConfiguration, SQSConfiguration
from datalake_library.interfaces.dynamo_interface import DynamoInterface
from datalake_library.interfaces.s3_interface import S3Interface
from datalake_library.interfaces.sqs_interface import SQSInterface
from datalake_library import octagon
from datalake_library.octagon import Artifact, EventReasonEnum, peh

logger = init_logger(__name__)


def lambda_handler(event, context):
    logger.info('Fetching event data from previous step')

    logger.info('Initializing Octagon client')
    component = context.function_name.split('-')[-2].title()
    octagon_client = (octagon.OctagonClient().with_run_lambda(True).with_configuration_instance(event['env']).build())
    peh_detail = octagon.peh.PipelineExecutionHistoryAPI(octagon_client).retrieve_pipeline_execution(event['peh_id'])
    # print(peh_detail)

    logger.info('Initializing DynamoDB config and Interface')
    dynamo_config = DynamoConfiguration()
    dynamo_interface = DynamoInterface(dynamo_config)

    logger.info('Logging error details into Octagon')
    octagon_client.end_pipeline_execution_failed(component=component,
                                                 issue_comment="Error Details: {}".format(event))

    return event