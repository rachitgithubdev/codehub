# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      08-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to create tender Pricing_SalesForce_Debrief_Main tables
#                   in conform zone
# Author        :- Bakul Seth
# Date          :- 23-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================


import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
import boto3
import json


class TMMipETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 13:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 13')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'netapp_database',
                                   'tms_database',
                                   'mip_database',
                                   'destination_bucket',
                                   'enrich_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.netapp_database = args['netapp_database']
        self.tms_database = args['tms_database']
        self.mip_database = args['mip_database']
        self.destination_bucket = args['destination_bucket']
        self.enrich_bucket = args['enrich_bucket']

        # report specific =============================================
        # input tables for JOB
        self.input_tables = ['l2_performance_reporting_location_mappings', 'l4_tm_fact_tenders_salesforce',
                             'l2_performance_reporting_customer_mappings', 'l2_l5_fact_tms_tender',
                             'l2_manager_mapping_table', 'l2_mip_currency', 'l2_mip_uom']

        # output file for JOB
        self.report1 = 'l5_tm_pricing_salesforce_debrief_main'
        self.report2 = 'l5_tm_pricing_salesforce_debrief_opportunity'
        self.report3 = 'l6_tm_pricing_salesforce_debrief'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # read data from specific table argument passed(database, table_list)
        print('starting to read tables from glue catalog for processing')
        df_inputs = self._get_table(self.source_database, self.netapp_database, self.tms_database, self.mip_database,
                                    self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe)
        print('starting to apply transformations on the tables')
        df_tfx = self._apply_tfx(df_inputs)

        print('starting to write the result to the location')
        # write final result to l5 destination
        self.write_results(df_tfx, self.report1, self.report2, self.report3)

        print(" Invoking of Detokenization Lambdas")
        eb_client = boto3.client('events')

        subtenant_id = 'aviation'
        source_glue_db_name = 'enrich_main_aviation_insight_hub'
        source_glue_table_name = 'l6_tm_pricing_salesforce_debrief'
        detok_app_name = 'l6_tm_pricing_salesforce_debrief'

        app_data_id = f'{subtenant_id}/{source_glue_db_name}/{source_glue_table_name}/{detok_app_name}'

        resp = eb_client.put_events(
            Entries=[
                {
                    'Source': 'com.bp.datahub.detok',
                    'DetailType': 'invoke_detok',
                    'Detail': json.dumps({'app_data_id': app_data_id}),
                    'EventBusName': f'subtenant-{subtenant_id}'
                }
            ]
        )
        
        print(" Invoking of Detokenization Completed")

    def write_results(self, target_dataset, report1, report2, report3):
        final_path1 = self.destination_bucket + '/' + report1
        print('final_path', final_path1)
        target_dataset[0] \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path1)

        final_path2 = self.destination_bucket + '/' + report2
        print('final_path', final_path2)
        target_dataset[1] \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path2)

        final_path3 = self.enrich_bucket + '/' + report3
        print('final_path', final_path3)
        target_dataset[2] \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path3)

    def _get_table(self, source_database, netapp_database, tms_database, mip_database, tables_name):
        print('reading performance_reporting_location_mappings data from {}.{}'.format(netapp_database, tables_name[0]))
        df_loc_map = self._gc.create_dynamic_frame.from_catalog(
            database=netapp_database, table_name=tables_name[0], transformation_ctx='target_table').toDF()

        print('reading sf l4_fact_tenders_salesforce data from {}.{}'.format(source_database, tables_name[1]))
        df_fact_sf = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[1], transformation_ctx='target_table').toDF()

        print('reading performance_reporting_customer_mappings data from {}.{}'.format(netapp_database, tables_name[2]))
        df_cust_map = self._gc.create_dynamic_frame.from_catalog(
            database=netapp_database, table_name=tables_name[2], transformation_ctx='target_table').toDF()

        print('reading fact_tms_tender data from {}.{}'.format(tms_database, tables_name[3]))
        df_l4_tms = self._gc.create_dynamic_frame.from_catalog(
            database=tms_database, table_name=tables_name[3], transformation_ctx='target_table').toDF()

        print('reading manager_mapping_table data from {}.{}'.format(netapp_database, tables_name[4]))
        df_man_map = self._gc.create_dynamic_frame.from_catalog(
            database=netapp_database, table_name=tables_name[4], transformation_ctx='target_table').toDF()

        print('reading dim_currency data from {}.{}'.format(mip_database, tables_name[5]))
        df_dim_curr = self._gc.create_dynamic_frame.from_catalog(
            database=mip_database, table_name=tables_name[5], transformation_ctx='target_table').toDF()

        print('reading dim_uom data from {}.{}'.format(mip_database, tables_name[6]))
        df_dim_uom = self._gc.create_dynamic_frame.from_catalog(
            database=mip_database, table_name=tables_name[6], transformation_ctx='target_table').toDF()

        return [df_loc_map, df_fact_sf, df_cust_map, df_l4_tms, df_man_map,
                df_dim_curr, df_dim_uom]

    @staticmethod
    def _apply_tfx(df_input):
        # convert all the columns alias to lower case
        df_loc_map = df_input[0].select([f.col(x).alias(x.lower()) for x in df_input[0].columns])

        sf = df_input[1]
        print('****************************', sf.count())

        df_cust_map = df_input[2].select([f.col(x).alias(x.lower()) for x in df_input[2].columns])

        df_l4_tms = df_input[3].select([f.col(x).alias(x.lower()) for x in df_input[3].columns])
        print('****************************', df_l4_tms.count())

        df_man_map = df_input[4].select([f.col(x).alias(x.lower()) for x in df_input[4].columns])

        df_dim_curr = df_input[5].select([f.col(x).alias(x.lower()) for x in df_input[5].columns])

        df_dim_uom = df_input[6].select([f.col(x).alias(x.lower()) for x in df_input[6].columns])

        print('starting to calculate df_results1')
        df_result1 = sf.alias('sf').filter(f.col('sf.tender_line_item_status') != f.lit('Not Represented')) \
            .join(df_cust_map.alias('cust_map'), f.col('sf.grn') == f.col('cust_map.grn'), 'left') \
            .join(df_loc_map.alias('loc_map'), f.col('sf.location_code') == f.col('loc_map.location_code'), 'left') \
            .select(f.col('sf.tender_name'), f.col('sf.requested_volume_usg'), f.col('sf.offered_volume'),
                    f.col('sf.result'), f.lit('').alias('loc_airport_name'),
                    f.when(f.coalesce(f.col('loc_map.country'), f.lit('')) != f.lit(''),
                           f.initcap(f.col('loc_map.country')))
                    .otherwise(f.lit('')).alias('country'),
                    f.col('sf.line_item_start_date').alias('start_date'), f.col('sf.sector'),
                    f.col('sf.aitm_depe_pricing_basis__c'),
                    f.when(f.coalesce(f.col('cust_map.customer'), f.lit('')) != f.lit(''), f.col('cust_map.customer'))
                    .when(((f.coalesce(f.col('cust_map.customer'), f.lit('')) == f.lit('')) &
                           (f.coalesce(f.col('cust_map.carrier'), f.lit('')) != f.lit(''))), f.col('cust_map.carrier'))
                    .when(((f.coalesce(f.col('cust_map.customer'), f.lit('')) == f.lit('')) &
                           (f.coalesce(f.col('cust_map.group'), f.lit('')) != f.lit(''))), f.col('cust_map.group'))
                    .otherwise(f.coalesce(f.col('sf.customer_name'), f.lit('Other'))).alias('customername'),
                    f.col('sf.location_manager').alias('location_manager'),
                    f.col('sf.line_item_end_date').alias('end_date'), f.col('awarded_volume'), f.col('sf.grn'),
                    f.col('offered_differential'), f.col('loc_map.currency').alias('offereddifferentialcurrency'),
                    f.col('UOM').alias('offereddifferentialuom'),
                    f.when(f.coalesce(f.initcap(f.col('cust_map.account_holder')), f.lit('Other')) != 'Other',
                           f.coalesce(f.initcap(f.col('cust_map.account_holder')), f.lit('Other')))
                    .otherwise(f.col('sf.account_manager')).alias('account_manager'),
                    f.col('cust_map.rsm').alias('rsm'),
                    f.when(f.coalesce(f.col('loc_map.cluster'), f.lit('')) != f.lit(''), f.lit(''))
                    .otherwise(f.lit('')).alias('cluster'),
                    f.lit('').alias('performance_unit'),
                    f.lit('').alias('pricng_basis'), f.col('cust_map.carrier'),
                    f.to_date(f.col('aitm_debrief_email_sent_date__c'), 'MM/dd/yyyy').alias(
                        'aitm_debrief_email_sent_date__c'),
                    f.when(f.coalesce(f.col('aitm_debrief_email_sent_date__c'), f.lit('')) == f.lit(''),
                           f.col('sf.line_item_start_date'))
                    .when(f.datediff(f.to_date(f.col('sf.line_item_start_date'), 'MM/dd/yyyy'),
                                     f.to_date(f.col('aitm_debrief_email_sent_date__c'), 'MM/dd/yyyy')) < f.lit(0),
                          f.col('sf.line_item_start_date'))
                    .otherwise(f.to_date(f.col('aitm_debrief_email_sent_date__c'), 'MM/dd/yyyy')).alias(
                        'decision_date'),
                    f.when(f.coalesce(f.col('cust_map.group'), f.lit('')) != f.lit(''), f.col('cust_map.group'))
                    .when(((f.coalesce(f.col('cust_map.group'), f.lit('')) == f.lit('')) &
                           (f.coalesce(f.col('cust_map.customer'), f.lit('')) != f.lit(''))),
                          f.coalesce(f.col('cust_map.customer'), f.lit('Other')))
                    .otherwise(f.coalesce(f.col('sf.customer_name'), f.lit('Other'))).alias('customergroup'),
                    f.round(f.months_between(f.col('sf.line_item_end_date'),
                                             f.col('sf.line_item_start_date')), 0).alias('contractmonths'),
                    f.date_add(f.col('sf.line_item_end_date'), 1).alias('startdatenewcontract'),
                    f.expr("add_months(sf.line_item_end_date, sf.contract_length)").alias('enddatanewcontract'),
                    f.coalesce((f.col('sf.requested_volume_usg') - f.col('awarded_volume')), f.lit(0)).alias(
                        'oppertunity'),
                    f.col('sf.location_code'), f.col('sf.line_item_start_date').alias('start1'),
                    f.col('sf.line_item_end_date').alias('end1'),
                    f.when(f.year(f.col('sf.line_item_end_date')) == f.lit('2020'),
                           f.month(f.col('sf.line_item_end_date')))
                    .when(((f.year(f.col('sf.line_item_end_date')) < f.lit('2020')) |
                           (f.year(f.col('sf.line_item_start_date')) > f.lit('2020'))),
                          f.lit(0)).otherwise((f.lit(12) - f.month(f.col('sf.line_item_start_date'))))
                    .alias('2020_months'), f.col('sf.last_refreshed_date'))

        print('df_result1 done')
        df_result1.printSchema()
        print(df_result1.count())
        print('starting df_result2')

        df_result2 = df_l4_tms.alias('tms').filter(f.col('tms.status') != f.lit('Not Represented')) \
            .join(df_cust_map.alias('cust_map'), f.col('tms.grn') == f.col('cust_map.grn'),
                  'left') \
            .join(df_loc_map.alias('loc_map'),
                  f.col('tms.location_code') == f.col('loc_map.location_code'), 'left') \
            .select(f.col('tms.tender_name'), f.col('tms.requested_volume_usg'), f.col('tms.offered_volume'),
                    f.col('tms.result'), f.lit('').alias('loc_airport_name'), f.col('loc_map.country').alias('country'),
                    f.col('tms.start_date').alias('start_date'), f.col('tms.sector'),
                    f.lit('').alias('aitm_depe_pricing_basis__c'),
                    f.when(f.coalesce(f.col('cust_map.customer'), f.lit('')) != f.lit(''), f.col('cust_map.customer'))
                    .when(((f.coalesce(f.col('cust_map.customer'), f.lit('')) == f.lit('')) &
                           (f.coalesce(f.col('cust_map.carrier'), f.lit('')) != f.lit(''))), f.col('cust_map.carrier'))
                    .when(((f.coalesce(f.col('cust_map.customer'), f.lit('')) == f.lit('')) &
                           (f.coalesce(f.col('cust_map.group'), f.lit('')) != f.lit(''))), f.col('cust_map.group'))
                    .otherwise(f.coalesce(f.col('tms.customer_name'), f.lit('Other'))).alias('customername'),
                    f.col('tms.location_manager').alias('location_manager'),
                    f.col('tms.end_date').alias('end_date'), f.col('tms.awarded_volume'), f.col('tms.grn'),
                    f.col('tms.offered_differntial').alias('offered_differential'),
                    f.col('tms.currency').alias('offereddifferentialcurrency'),
                    f.col('tms.uom').alias('offereddifferentialuom'),
                    f.when(f.coalesce(f.initcap(f.col('cust_map.account_holder')), f.lit('Other')) != f.lit('Other'),
                           f.coalesce(f.initcap(f.col('cust_map.account_holder')), f.lit('Other')))
                    .otherwise(f.lit('Other')).alias('account_owner'),
                    f.col('cust_map.rsm').alias('rsm'), f.col('loc_map.cluster').alias('cluster'),
                    f.lit('').alias('performance_unit'),
                    f.lit('').alias('pricng_basis'), f.col('cust_map.carrier'),
                    f.to_date(f.col('tms.start_date'), 'MM/dd/yyyy').alias('aitm_debrief_email_sent_date__c'),
                    f.to_date(f.col('tms.start_date'), 'MM/dd/yyyy').alias('decision_date'),
                    f.when(f.coalesce(f.col('cust_map.group'), f.lit('')) != f.lit(''), f.col('cust_map.group'))
                    .otherwise(f.coalesce(f.col('tms.customer_name'), f.lit('Other'))).alias('customergroup'),
                    f.col('tms.contract_length').alias('contractmonths'),
                    f.date_add(f.col('tms.end_date'), 1).alias('startdatenewcontract'),
                    f.expr('add_months(tms.end_date, tms.contract_length)').alias('enddatanewcontract'),
                    f.coalesce((f.col('tms.requested_volume_usg') - f.col('awarded_volume')), f.lit(0)).alias(
                        'oppertunity'),
                    f.col('tms.location_code'), f.col('tms.start_date').alias('start1'),
                    f.col('tms.end_date').alias('end1'),
                    f.when(f.year(f.col('tms.end_date')) == f.lit('2020'), f.month(f.col('tms.end_date')))
                    .when(((f.year(f.col('tms.end_date')) < f.lit('2020')) |
                           (f.year(f.col('tms.end_date')) > f.lit('2020'))), f.lit(0))
                    .otherwise((f.lit(12) - f.month(f.col('tms.start_date')))).alias('2020_months'),
                    f.lit('').alias('last_refreshed_date'))

        print('df_result2 done')
        df_result2.printSchema()
        print(df_result2.count())
        print('starting df_tfx_result')

        df_tfx_temp = df_result1.union(df_result2)
        print(df_tfx_temp.count())

        print('****************************************************************')
        df_tfx_temp.printSchema()

        df_tfx_result1 = df_tfx_temp.alias('df_tfx_temp') \
            .filter((f.col('df_tfx_temp.start_date') < f.lit('2020-04-01')) |
                    ((f.col('df_tfx_temp.start_date') >= f.lit('2020-04-01')) &
                     (f.coalesce(f.col('df_tfx_temp.aitm_debrief_email_sent_date__c'), f.lit('')) != f.lit('')))) \
            .join(df_man_map.alias('man_map'),
                  f.initcap(f.col('df_tfx_temp.account_manager')) == f.initcap(f.col('man_map.original_name')), 'left') \
            .join(df_man_map.alias('man_map2'),
                  f.initcap(f.col('df_tfx_temp.location_manager')) == f.initcap(f.col('man_map2.original_name')),
                  'left') \
            .join(df_dim_curr.alias('dim_curr'),
                  (f.expr('date_sub(decision_date, (dayofmonth(decision_date) -1 ))') == f.col('dim_curr.month')) &
                  (f.col('offereddifferentialcurrency') == f.col('dim_curr.source')) &
                  (f.col('dim_curr.target') == f.lit('USD')), 'left') \
            .join(df_dim_uom.alias('dim_uom'), (f.col('offereddifferentialuom') == f.col('dim_uom.source'))
                  & (f.col('dim_uom.target') == f.lit('USG')), 'left') \
            .select(f.col('tender_name'),
                    f.coalesce(f.col('requested_volume_usg'), f.lit(0)).alias('requested_volume_usg'),
                    f.coalesce(f.col('offered_volume'), f.lit(0)).alias('offered_volume'),
                    (f.coalesce(f.col('offered_volume'), f.lit(0)) * f.col('dim_uom.factor'))
                    .alias('offered_volume_usg'),
                    f.col('result'), f.col('loc_airport_name'), f.col('country'), f.col('start_date'), f.col('sector'),
                    f.col('aitm_depe_pricing_basis__c'), f.col('customername'),
                    f.coalesce(f.col('man_map2.mapped_name'), f.lit('Other')).alias('location_manager'),
                    f.col('end_date'),
                    f.coalesce(f.col('awarded_volume'), f.lit(0)).alias('awarded_volume'), f.col('grn'),
                    f.col('offered_differential'), f.col('offereddifferentialcurrency'),
                    (f.col('offered_differential') * f.col('dim_curr.rate')).alias('offered_differential_usd'),
                    (f.col('offered_differential') * f.col('dim_curr.rate') *
                     f.coalesce(f.col('offered_volume'), f.lit(0))).alias('offered_differential_amount_usd'),
                    f.expr('date_sub(decision_date, (dayofmonth(decision_date) -1))').alias('exchange_rate_date'),
                    f.col('dim_curr.rate'), f.col('offereddifferentialuom'),
                    f.coalesce(f.col('man_map.mapped_name'), f.lit('Other')).alias('account_manager'), f.col('rsm'),
                    f.col('cluster'), f.col('performance_unit'), f.col('pricng_basis'), f.col('carrier'),
                    f.col('aitm_debrief_email_sent_date__c'), f.col('decision_date'), f.col('customergroup'),
                    f.lit('').alias('customerranking'), f.col('contractmonths'), f.col('startdatenewcontract'),
                    f.col('enddatanewcontract'), f.col('oppertunity'), f.col('location_code'),
                    f.col('Start1'), f.col('end1'), f.col('2020_Months'), f.col('last_refreshed_date'))

        print('df_tfx_result1 done')
        df_tfx_result1.printSchema()
        print(df_tfx_result1.count())

        df_tfx_result2 = df_tfx_temp.alias('df_tfx_temp') \
            .filter(((f.col('df_tfx_temp.start_date') < f.lit('2020-04-01')) |
                     ((f.col('df_tfx_temp.start_date') >= f.lit('2020-04-01')) &
                      (f.coalesce(f.col('df_tfx_temp.aitm_debrief_email_sent_date__c'), f.lit('')) != f.lit('')))) &
                    (f.abs(f.coalesce('requested_volume_usg', f.lit(0)) /
                           f.coalesce('awarded_volume', f.lit(0))) > f.lit(1.05))) \
            .join(df_man_map.alias('man_map'),
                  f.initcap(f.col('df_tfx_temp.account_manager')) == f.initcap(f.col('man_map.original_name')), 'left') \
            .join(df_man_map.alias('man_map2'),
                  f.initcap(f.col('df_tfx_temp.location_manager')) == f.initcap(f.col('man_map2.original_name')),
                  'left') \
            .join(df_dim_curr.alias('dim_curr'),
                  (f.expr('date_sub(decision_date, (dayofmonth(decision_date) -1 ))') == f.col('dim_curr.month')) &
                  (f.col('offereddifferentialcurrency') == f.col('dim_curr.source')) &
                  (f.col('dim_curr.target') == f.lit('USD')), 'left') \
            .join(df_dim_uom.alias('dim_uom'), (f.col('offereddifferentialuom') == f.col('dim_uom.source'))
                  & (f.col('dim_uom.target') == f.lit('USG')), 'left') \
            .select(f.col('tender_name'),
                    f.coalesce(f.col('requested_volume_usg'), f.lit(0)).alias('requested_volume_usg'),
                    f.coalesce(f.col('offered_volume'), f.lit(0)).alias('offered_volume'),
                    (f.coalesce(f.col('offered_volume'), f.lit(0)) * f.col('dim_uom.factor'))
                    .alias('offered_volume_usg'),
                    f.lit('MI').alias('result'), f.col('loc_airport_name'), f.col('country'), f.col('start_date'),
                    f.col('sector'), f.col('aitm_depe_pricing_basis__c'), f.col('customername'),
                    f.coalesce(f.col('man_map2.mapped_name'), f.lit('Other')).alias('location_manager'),
                    f.col('end_date'),
                    f.coalesce(f.col('awarded_volume'), f.lit(0)).alias('awarded_volume'), f.col('grn'),
                    f.col('offered_differential'), f.col('offereddifferentialcurrency'),
                    (f.col('offered_differential') * f.col('dim_curr.rate')).alias('offered_differential_usd'),
                    (f.col('offered_differential') * f.col('dim_curr.rate') *
                     f.coalesce(f.col('offered_volume'), f.lit(0))).alias('offered_differential_amount_usd'),
                    f.expr('date_sub(decision_date, (dayofmonth(decision_date) -1))').alias('exchange_rate_date'),
                    f.col('dim_curr.rate'), f.col('offereddifferentialuom'),
                    f.coalesce(f.col('man_map.mapped_name'), f.lit('Other')).alias('account_manager'), f.col('rsm'),
                    f.col('cluster'), f.col('performance_unit'), f.col('pricng_basis'), f.col('carrier'),
                    f.col('aitm_debrief_email_sent_date__c'), f.col('decision_date'), f.col('customergroup'),
                    f.lit('').alias('customerranking'), f.col('contractmonths'), f.col('startdatenewcontract'),
                    f.col('enddatanewcontract'), f.col('oppertunity'), f.col('location_code'),
                    f.col('Start1'), f.col('end1'), f.col('2020_Months'), f.col('last_refreshed_date'))

        print('df_tfx_result2 done')
        df_tfx_result2.printSchema()
        print(df_tfx_result2.count())

        df_tfx_result3 = df_tfx_result1.union(df_tfx_result2)

        print('df_tfx_result3 done')
        df_tfx_result3.printSchema()
        print(df_tfx_result3.count())

        return [df_tfx_result1, df_tfx_result2, df_tfx_result3]


if __name__ == '__main__':
    trl = TMMipETL()
    trl.execute()
