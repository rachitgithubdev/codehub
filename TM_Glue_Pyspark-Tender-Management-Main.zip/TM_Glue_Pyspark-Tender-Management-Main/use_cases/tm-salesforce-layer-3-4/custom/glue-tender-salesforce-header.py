# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      08-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to create tender header tables in conform zone
# Author        :- Bakul Seth
# Date          :- 20-Jan-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class TMSalesForceETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_tender_header"
        self.l21_report_file = "salesforce_layer_2.1/l21_tm_salesforce_tender_header"
        self.l31_report_file = "salesforce_layer_3.1/l31_tm_salesforce_tender_header"
        self.l32_report_file = "salesforce_layer_3.2/l32_tm_salesforce_tender_header"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # read data from country specific table argument passed(database, table)
        df_input = self._get_table(self.source_database, self.input_table).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_input.count()))

        # apply transformation on the dataframe argument passed(dataframe)
        df_tfx = self._apply_tfx(df_input)

        # write final result to l21 destination
        self.write_results(df_tfx[0], self.l21_report_file)

        # write final result to l31 destination
        self.write_results(df_tfx[1], self.l31_report_file)

        # write final result to l31 destination
        self.write_results(df_tfx[2], self.l32_report_file)

    def write_results(self, target_dataset, report):
        final_path = self.destination_bucket + "/" + report
        print('final_path', final_path)
        target_dataset\
            .write.option("compression", "snappy")\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input):

        # convert all the columns alias to lower case
        df_input = df_input.select([f.col(x).alias(x.lower()) for x in df_input.columns])
        # df_input.printSchema()
        df_tfx_l21 = df_input.\
            select(df_input.aitm_arl_prfl_and_tndr_information__c, df_input.aitm_contract_is_sent_to_a_customer__c,
                   df_input.aitm_cust_talk_influence_req_conducted__c, df_input.aitm_email__c,
                   df_input.aitm_debrief_email_sent_date__c, df_input.aitm_gross_profit_new_contract__c,
                   df_input.aitm_gross_profit_notes__c, df_input.aitm_gross_profit_previous_contract__c,
                   df_input.aitm_is_customer_talk_infl_req_conducted__c,
                   df_input.aitm_is_multi_year_int_scheme_offered__c, df_input.aitm_is_pro_active_package_offered__c,
                   df_input.aitm_last_look_to_incumbent__c, df_input.aitm_multi_year_int_offered_comment__c,
                   df_input.aitm_no_feedback_progress_to_de_brief__c, df_input.aitm_notes_for_tender__c,
                   df_input.aitm_notes_on_feedback__c, df_input.aitm_offer_sent_to_a_customer__c,
                   df_input.aitm_phone__c, df_input.aitm_pro_active_package_offered_comment__c,
                   df_input.aitm_produce_customer_email__c, df_input.aitm_quality_of_feedback__c,
                   df_input.aitm_rowc_notes__c, df_input.aitm_recognition_and_shout_outs__c,
                   df_input.aitm_record_name__c, df_input.aitm_tender_contact__c, df_input.aitm_tender_context__c,
                   df_input.aitm_tender_preparation__c, df_input.aitm_tender_process__c, df_input.aitm_volume_notes__c,
                   df_input.aitm_what_could_have_gone_better__c, df_input.aitm_what_have_we_learnt__c,
                   df_input.aitm_what_went_well__c, df_input.aitm_working_capital_notes__c,
                   df_input.aitm_tender_information__c, df_input.id, df_input.ownerid, df_input.isdeleted,
                   df_input.name, df_input.currencyisocode, df_input.createddate, df_input.createdbyid,
                   df_input.lastmodifieddate, df_input.lastmodifiedbyid, df_input.systemmodstamp,
                   df_input.lastvieweddate, df_input.lastreferenceddate, df_input.aitm_bids_in_by__c,
                   df_input.aitm_currency__c, df_input.aitm_density__c, df_input.aitm_end_date__c,
                   df_input.aitm_number_of_rounds__c, df_input.aitm_price_perf_index_new_contract__c,
                   df_input.aitm_price_perf_index_prev_contract__c, df_input.aitm_price_performance_index_notes__c,
                   df_input.aitm_rowc_new_contract__c, df_input.aitm_rowc_previous_contract__c, df_input.aitm_stage__c,
                   df_input.aitm_start_date__c, df_input.aitm_title__c, df_input.aitm_unit_of_measure__c,
                   df_input.aitm_volume_new_contract__c, df_input.aitm_volume_previous_contract__c,
                   df_input.aitm_working_capital_new_contract__c, df_input.aitm_working_capital_previous_contract__c,
                   df_input.aitm_number_of_customers__c, df_input.aitm_number_of_locations__c,
                   df_input.aitm_total_volume__c, df_input.aitm_send_invitation_notification__c,
                   df_input.aitm_tender_sector__c, df_input.aitm_offer_valid_until__c, df_input.aitm_historic_tender__c,
                   df_input.aitm_send_feedback_notification__c, df_input.aitm_send_labp_feedback_notification__c,
                   df_input.aitm_tender_unique_id__c, df_input.infa_ext_dt)
        print("***********************", "df_tfx_l21")
        df_tfx_l21.printSchema()

        df_tfx_l31 = df_tfx_l21. \
            select(df_tfx_l21.id, df_tfx_l21.ownerid, df_tfx_l21.name, df_tfx_l21.currencyisocode,
                   df_tfx_l21.aitm_arl_prfl_and_tndr_information__c, df_tfx_l21.aitm_bids_in_by__c,
                   df_tfx_l21.aitm_contract_is_sent_to_a_customer__c, df_tfx_l21.aitm_currency__c,
                   df_tfx_l21.aitm_cust_talk_influence_req_conducted__c, df_tfx_l21.aitm_density__c.cast('double'),
                   df_tfx_l21.aitm_email__c, df_tfx_l21.aitm_debrief_email_sent_date__c,
                   f.date_format(f.to_date(f.substring(df_tfx_l21.aitm_end_date__c, 1, 10), 'MM/dd/yyyy'),
                                 'MM/dd/yyyy').alias('aitm_end_date__c'),
                   df_tfx_l21.aitm_gross_profit_new_contract__c.cast('double'), df_tfx_l21.aitm_gross_profit_notes__c,
                   df_tfx_l21.aitm_gross_profit_previous_contract__c.cast('double'),
                   df_tfx_l21.aitm_is_customer_talk_infl_req_conducted__c,
                   df_tfx_l21.aitm_is_multi_year_int_scheme_offered__c,
                   df_tfx_l21.aitm_is_pro_active_package_offered__c, df_tfx_l21.aitm_last_look_to_incumbent__c,
                   df_tfx_l21.aitm_multi_year_int_offered_comment__c,
                   df_tfx_l21.aitm_no_feedback_progress_to_de_brief__c, df_tfx_l21.aitm_tender_unique_id__c,
                   df_tfx_l21.aitm_notes_on_feedback__c, df_tfx_l21.aitm_number_of_rounds__c.cast('double'),
                   df_tfx_l21.aitm_offer_sent_to_a_customer__c, df_tfx_l21.aitm_phone__c,
                   df_tfx_l21.aitm_price_perf_index_new_contract__c.cast('double'),
                   df_tfx_l21.aitm_price_perf_index_prev_contract__c.cast('double'),
                   df_tfx_l21.aitm_price_performance_index_notes__c,
                   df_tfx_l21.aitm_pro_active_package_offered_comment__c, df_tfx_l21.aitm_produce_customer_email__c,
                   df_tfx_l21.aitm_quality_of_feedback__c, df_tfx_l21.aitm_rowc_new_contract__c.cast('double'),
                   df_tfx_l21.aitm_rowc_notes__c, df_tfx_l21.aitm_rowc_previous_contract__c.cast('double'),
                   df_tfx_l21.aitm_offer_valid_until__c, df_tfx_l21.aitm_record_name__c, df_tfx_l21.aitm_stage__c,
                   f.date_format(f.to_date(f.substring(df_tfx_l21.aitm_start_date__c, 1, 10), 'MM/dd/yyyy'),
                                 'MM/dd/yyyy').alias('aitm_start_date__c'),
                   df_tfx_l21.aitm_tender_contact__c, df_tfx_l21.aitm_historic_tender__c, df_tfx_l21.aitm_title__c,
                   df_tfx_l21.aitm_unit_of_measure__c, df_tfx_l21.aitm_volume_new_contract__c.cast('double'),
                   df_tfx_l21.aitm_volume_notes__c, df_tfx_l21.aitm_volume_previous_contract__c.cast('double'),
                   df_tfx_l21.aitm_tender_information__c,
                   df_tfx_l21.aitm_working_capital_new_contract__c.cast('double'),
                   df_tfx_l21.aitm_working_capital_notes__c,
                   df_tfx_l21.aitm_working_capital_previous_contract__c.cast('double'),
                   df_tfx_l21.aitm_number_of_customers__c.cast('double'),
                   df_tfx_l21.aitm_number_of_locations__c.cast('double'),
                   df_tfx_l21.aitm_total_volume__c.cast('double'), df_tfx_l21.aitm_send_invitation_notification__c,
                   df_tfx_l21.aitm_tender_sector__c, df_tfx_l21.aitm_notes_for_tender__c,
                   df_tfx_l21.aitm_recognition_and_shout_outs__c, df_tfx_l21.aitm_tender_context__c,
                   df_tfx_l21.aitm_tender_preparation__c, df_tfx_l21.aitm_tender_process__c,
                   df_tfx_l21.aitm_what_could_have_gone_better__c, df_tfx_l21.aitm_what_have_we_learnt__c,
                   df_tfx_l21.aitm_what_went_well__c, df_tfx_l21.infa_ext_dt)
        print("***********************", "df_tfx_l31")
        df_tfx_l31.printSchema()
        df_tfx_l32 = df_tfx_l31.\
            select(df_tfx_l31.id, df_tfx_l31.ownerid, df_tfx_l31.name, df_tfx_l31.currencyisocode,
                   df_tfx_l31.aitm_arl_prfl_and_tndr_information__c, df_tfx_l31.aitm_bids_in_by__c,
                   df_tfx_l31.aitm_contract_is_sent_to_a_customer__c, df_tfx_l31.aitm_currency__c,
                   df_tfx_l31.aitm_cust_talk_influence_req_conducted__c, df_tfx_l31.aitm_density__c,
                   df_tfx_l31.aitm_email__c, df_tfx_l31.aitm_debrief_email_sent_date__c, df_tfx_l31.aitm_end_date__c,
                   df_tfx_l31.aitm_gross_profit_new_contract__c, df_tfx_l31.aitm_gross_profit_notes__c,
                   df_tfx_l31.aitm_gross_profit_previous_contract__c,
                   df_tfx_l31.aitm_is_customer_talk_infl_req_conducted__c,
                   df_tfx_l31.aitm_is_multi_year_int_scheme_offered__c,
                   df_tfx_l31.aitm_is_pro_active_package_offered__c, df_tfx_l31.aitm_last_look_to_incumbent__c,
                   df_tfx_l31.aitm_multi_year_int_offered_comment__c,
                   df_tfx_l31.aitm_no_feedback_progress_to_de_brief__c, df_tfx_l31.aitm_tender_unique_id__c,
                   df_tfx_l31.aitm_notes_on_feedback__c, df_tfx_l31.aitm_number_of_rounds__c,
                   df_tfx_l31.aitm_offer_sent_to_a_customer__c, df_tfx_l31.aitm_phone__c,
                   df_tfx_l31.aitm_price_perf_index_new_contract__c, df_tfx_l31.aitm_price_perf_index_prev_contract__c,
                   df_tfx_l31.aitm_price_performance_index_notes__c,
                   df_tfx_l31.aitm_pro_active_package_offered_comment__c, df_tfx_l31.aitm_produce_customer_email__c,
                   df_tfx_l31.aitm_quality_of_feedback__c, df_tfx_l31.aitm_rowc_new_contract__c,
                   df_tfx_l31.aitm_rowc_notes__c, df_tfx_l31.aitm_rowc_previous_contract__c,
                   df_tfx_l31.aitm_offer_valid_until__c, df_tfx_l31.aitm_record_name__c, df_tfx_l31.aitm_stage__c,
                   df_tfx_l31.aitm_start_date__c, df_tfx_l31.aitm_tender_contact__c, df_tfx_l31.aitm_historic_tender__c,
                   df_tfx_l31.aitm_title__c, df_tfx_l31.aitm_unit_of_measure__c, df_tfx_l31.aitm_volume_new_contract__c,
                   df_tfx_l31.aitm_volume_notes__c, df_tfx_l31.aitm_volume_previous_contract__c,
                   df_tfx_l31.aitm_tender_information__c, df_tfx_l31.aitm_working_capital_new_contract__c,
                   df_tfx_l31.aitm_working_capital_notes__c, df_tfx_l31.aitm_working_capital_previous_contract__c,
                   df_tfx_l31.aitm_number_of_customers__c, df_tfx_l31.aitm_number_of_locations__c,
                   df_tfx_l31.aitm_total_volume__c, df_tfx_l31.aitm_send_invitation_notification__c,
                   df_tfx_l31.aitm_tender_sector__c, df_tfx_l31.aitm_notes_for_tender__c,
                   df_tfx_l31.aitm_recognition_and_shout_outs__c, df_tfx_l31.aitm_tender_context__c,
                   df_tfx_l31.aitm_tender_preparation__c, df_tfx_l31.aitm_tender_process__c,
                   df_tfx_l31.aitm_what_could_have_gone_better__c, df_tfx_l31.aitm_what_have_we_learnt__c,
                   df_tfx_l31.aitm_what_went_well__c,
                   f.md5(f.concat(df_tfx_l31.id, df_tfx_l31.ownerid, df_tfx_l31.name, df_tfx_l31.aitm_end_date__c,
                                  df_tfx_l31.aitm_tender_unique_id__c, df_tfx_l31.aitm_stage__c,
                                  df_tfx_l31.aitm_start_date__c, df_tfx_l31.aitm_title__c,
                                  df_tfx_l31.aitm_total_volume__c)).alias('checkSum'),
                   df_tfx_l31.infa_ext_dt)

        df_tfx_result = [df_tfx_l21, df_tfx_l31, df_tfx_l32]

        return df_tfx_result


if __name__ == '__main__':
    trl = TMSalesForceETL()
    trl.execute()
