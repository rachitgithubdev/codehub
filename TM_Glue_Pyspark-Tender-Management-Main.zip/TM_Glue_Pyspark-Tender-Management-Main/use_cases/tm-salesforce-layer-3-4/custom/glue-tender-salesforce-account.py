# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      08-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to create tender account tables in conform zone
# Author        :- Bakul Seth
# Date          :- 20-Jan-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class TMSalesForceETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_tender_account"
        self.l21_report_file = "salesforce_layer_2.1/l21_tm_salesforce_tender_account"
        self.l31_report_file = "salesforce_layer_3.1/l31_tm_salesforce_tender_account"
        self.l32_report_file = "salesforce_layer_3.2/l32_tm_salesforce_tender_account"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # read data from country specific table argument passed(database, table)
        df_input = self._get_table(self.source_database, self.input_table).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_input.count()))

        # apply transformation on the dataframe argument passed(dataframe)
        df_tfx = self._apply_tfx(df_input)

        # write final result to l21 destination
        self.write_results(df_tfx[0], self.l21_report_file)

        # write final result to l31 destination
        self.write_results(df_tfx[1], self.l31_report_file)

        # write final result to l31 destination
        self.write_results(df_tfx[2], self.l32_report_file)

    def write_results(self, target_dataset, report):
        final_path = self.destination_bucket + "/" + report
        print('final_path', final_path)
        target_dataset\
            .write.option("compression", "snappy")\
            .mode('overwrite')\
            .parquet(final_path)

    @staticmethod
    def union_dataframe(final_result_df, country_df):
        # union the dataframe
        if bool(final_result_df.head(1)):
            final_result_df = final_result_df.union(country_df)
        else:
            final_result_df = country_df
        return final_result_df

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input):

        # convert all the columns alias to lower case
        df_input = df_input.select([f.col(x).alias(x.lower()) for x in df_input.columns])
        df_tfx_l21 = df_input.\
            select(df_input.aitm_contact_name__c, df_input.aitm_contracting_entity_signatory__c,
                   df_input.aitm_contracting_entity_title__c, df_input.aitm_description__c, df_input.aitm_email__c,
                   df_input.aitm_phone__c, df_input.aitm_security_text_on_offer__c, df_input.aitm_security_type_c,
                   df_input.jv_terms_c, df_input.id, df_input.isdeleted, df_input.name, df_input.currencyisocode,
                   df_input.createddate, df_input.createdbyid, df_input.lastmodifieddate, df_input.lastmodifiedbyid,
                   df_input.systemmodstamp, df_input.lastvieweddate, df_input.lastreferenceddate,
                   df_input.aitm_tender__c, df_input.aitm_account__c, df_input.aitm_affiliates__c,
                   df_input.aitm_aircraft_fleet__c, df_input.aitm_credit_days__c, df_input.aitm_credit_terms__c,
                   df_input.aitm_customer_name__c, df_input.aitm_customer_segment__c, df_input.aitm_customer_type__c,
                   df_input.aitm_grn__c, df_input.aitm_invoice_frequency__c, df_input.aitm_payment_currency__c,
                   df_input.aitm_preferred_service_level__c, df_input.aitm_resellers__c, df_input.aitm_title__c,
                   df_input.aitm_tender_unique_id__c, df_input.aitm_credit_days1__c,
                   df_input.aitm_affiliates_account__c, df_input.aitm_legal_entity__c,
                   df_input.aitm_account_classification__c, df_input.infa_ext_dt)

        df_tfx_l31 = df_tfx_l21.\
            select(df_tfx_l21.id, df_tfx_l21.name, df_tfx_l21.currencyisocode, df_tfx_l21.aitm_tender__c,
                   df_tfx_l21.aitm_account__c, df_tfx_l21.aitm_affiliates__c, df_tfx_l21.aitm_aircraft_fleet__c,
                   df_tfx_l21.aitm_contact_name__c, df_tfx_l21.aitm_contracting_entity_signatory__c,
                   df_tfx_l21.aitm_contracting_entity_title__c, df_tfx_l21.aitm_credit_days__c.cast('double'),
                   df_tfx_l21.aitm_credit_terms__c, df_tfx_l21.aitm_customer_name__c,
                   df_tfx_l21.aitm_customer_segment__c, df_tfx_l21.aitm_customer_type__c,
                   df_tfx_l21.aitm_description__c, df_tfx_l21.aitm_email__c, df_tfx_l21.aitm_grn__c,
                   df_tfx_l21.aitm_invoice_frequency__c, df_tfx_l21.aitm_payment_currency__c, df_tfx_l21.aitm_phone__c,
                   df_tfx_l21.aitm_preferred_service_level__c, df_tfx_l21.aitm_resellers__c,
                   df_tfx_l21.aitm_security_text_on_offer__c, df_tfx_l21.aitm_security_type_c,
                   df_tfx_l21.aitm_title__c, df_tfx_l21.jv_terms_c, df_tfx_l21.aitm_tender_unique_id__c,
                   df_tfx_l21.aitm_credit_days1__c, df_tfx_l21.aitm_affiliates_account__c,
                   df_tfx_l21.aitm_legal_entity__c, df_tfx_l21.aitm_account_classification__c, df_tfx_l21.infa_ext_dt)

        df_tfx_l32 = df_tfx_l31.\
            select(df_tfx_l31.id, df_tfx_l31.name, df_tfx_l31.currencyisocode, df_tfx_l31.aitm_tender__c,
                   df_tfx_l31.aitm_account__c, df_tfx_l31.aitm_affiliates__c, df_tfx_l31.aitm_aircraft_fleet__c,
                   df_tfx_l31.aitm_contact_name__c, df_tfx_l31.aitm_contracting_entity_signatory__c,
                   df_tfx_l31.aitm_contracting_entity_title__c, df_tfx_l31.aitm_credit_days__c,
                   df_tfx_l31.aitm_credit_terms__c, df_tfx_l31.aitm_customer_name__c,
                   df_tfx_l31.aitm_customer_segment__c, df_tfx_l31.aitm_customer_type__c,
                   df_tfx_l31.aitm_description__c, df_tfx_l31.aitm_email__c, df_tfx_l31.aitm_grn__c,
                   df_tfx_l31.aitm_invoice_frequency__c, df_tfx_l31.aitm_payment_currency__c, df_tfx_l31.aitm_phone__c,
                   df_tfx_l31.aitm_preferred_service_level__c, df_tfx_l31.aitm_resellers__c,
                   df_tfx_l31.aitm_security_text_on_offer__c, df_tfx_l31.aitm_security_type_c,
                   df_tfx_l31.aitm_title__c, df_tfx_l31.jv_terms_c, df_tfx_l31.aitm_tender_unique_id__c,
                   df_tfx_l31.aitm_credit_days1__c, df_tfx_l31.aitm_affiliates_account__c,
                   df_tfx_l31.aitm_legal_entity__c, df_tfx_l31.aitm_account_classification__c,
                   f.md5(f.concat(df_tfx_l31.id, df_tfx_l31.name, df_tfx_l31.aitm_tender__c, df_tfx_l31.aitm_account__c,
                                  df_tfx_l31.aitm_affiliates__c, df_tfx_l31.aitm_customer_name__c,
                                  df_tfx_l31.aitm_description__c, df_tfx_l31.aitm_grn__c, df_tfx_l31.aitm_title__c,
                                  df_tfx_l31.aitm_tender_unique_id__c, df_tfx_l31.aitm_legal_entity__c))
                   .alias('checksum'), df_tfx_l31.infa_ext_dt)

        df_tfx_result = [df_tfx_l21, df_tfx_l31, df_tfx_l32]

        return df_tfx_result


if __name__ == '__main__':
    trl = TMSalesForceETL()
    trl.execute()

