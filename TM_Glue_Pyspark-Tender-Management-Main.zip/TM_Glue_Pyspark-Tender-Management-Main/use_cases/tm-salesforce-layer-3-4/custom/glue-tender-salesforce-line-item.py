# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      08-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to create tender line item tables in conform zone
# Author        :- Bakul Seth
# Date          :- 20-Jan-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class TMSalesForceETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_tender_location_line_item"
        self.l21_report_file = "salesforce_layer_2.1/l21_tm_salesforce_tender_location_line_item"
        self.l31_report_file = "salesforce_layer_3.1/l31_tm_salesforce_tender_location_line_item"
        self.l32_report_file = "salesforce_layer_3.2/l32_tm_salesforce_tender_location_line_item"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # read data from country specific table argument passed(database, table)
        df_input = self._get_table(self.source_database, self.input_table).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_input.count()))

        # apply transformation on the dataframe argument passed(dataframe)
        df_tfx = self._apply_tfx(df_input)

        # write final result to l21 destination
        self.write_results(df_tfx[0], self.l21_report_file)

        # write final result to l31 destination
        self.write_results(df_tfx[1], self.l31_report_file)

        # write final result to l31 destination
        self.write_results(df_tfx[2], self.l32_report_file)

    def write_results(self, target_dataset, report):
        final_path = self.destination_bucket + "/" + report
        print('final_path', final_path)
        target_dataset\
            .write.option("compression", "snappy")\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input):

        # convert all the columns alias to lower case
        df_input = df_input.select([f.col(x).alias(x.lower()) for x in df_input.columns])
        df_input.printSchema()
        df_tfx_l21 = df_input.\
            select(df_input.aitm_credit_rating_of_customer__c, df_input.aitm_debrief_notes__c,
                   df_input.aitm_include_on_debrief__c, df_input.aitm_pricing_basis_description_c,
                   df_input.aitm_delivery_point_info__c, df_input.aitm_tender_owner_profile__c,
                   df_input.aitm_taxes_fees__c, df_input.id, df_input.ownerid, df_input.isdeleted, df_input.name,
                   df_input.currencyisocode, df_input.recordtypeid, df_input.createddate, df_input.createdbyid,
                   df_input.lastmodifieddate, df_input.lastmodifiedbyid, df_input.systemmodstamp,
                   df_input.lastvieweddate, df_input.lastreferenceddate, df_input.aitm_account__c,
                   df_input.aitm_ad_hoc_volume__c, df_input.aitm_additional_margin_from_line_items__c,
                   df_input.aitm_adjusted_differential__c, df_input.aitm_awarded_volume__c, df_input.aitm_base_cost__c,
                   df_input.aitm_bid_expiry_data__c, df_input.aitm_buying_power_value__c, df_input.aitm_cso_costs__c,
                   df_input.aitm_contract_length__c, df_input.aitm_cost_of_product__c,
                   df_input.aitm_credit_days_adjustment__c, df_input.aitm_credit_terms_adjustment__c,
                   df_input.aitm_currency_pricing_basis__c, df_input.aitm_currency_rebate__c,
                   df_input.aitm_currency_winning_differential__c, df_input.aitm_currency__c,
                   df_input.aitm_current_round__c, df_input.aitm_current_value__c,
                   df_input.aitm_customer_location_specific_revenue__c,
                   df_input.aitm_customer_specific_into_plane_costs__c, df_input.aitm_data_capture_delay__c,
                   df_input.aitm_data_pricing_calculation_provided__c, df_input.aitm_days__c,
                   df_input.aitm_delivery_method__c, df_input.aitm_delivery_point__c,
                   df_input.aitm_density_adjustments__c, df_input.aitm_description__c, df_input.aitm_details_context__c,
                   df_input.aitm_duration__c, df_input.aitm_end_date__c, df_input.aitm_estimated_floor_price__c,
                   df_input.aitm_exchange__c, df_input.aitm_floor_price__c, df_input.aitm_grn__c,
                   df_input.aitm_gross_profit__c, df_input.aitm_instrument__c, df_input.aitm_invoice_frequency__c,
                   df_input.aitm_is_current_round__c, df_input.aitm_jv_profit_dividend__c,
                   df_input.aitm_last_call_to_pricing_system__c, df_input.aitm_last_tender_result__c,
                   df_input.aitm_level_of_interest__c, df_input.aitm_line_item_margins__c,
                   df_input.aitm_line_item_name_account__c, df_input.aitm_pricer_no_default_delivery_points__c,
                   df_input.aitm_location_neutral_wc_payment_days__c, df_input.aitm_location_size__c,
                   df_input.aitm_location_strategy__c, df_input.aitm_location__c,
                   df_input.aitm_mark_up_customer_buying_power__c, df_input.aitm_mark_up_customer_segment__c,
                   df_input.aitm_mark_up_location_strategy__c, df_input.aitm_market_structure_cost__c,
                   df_input.aitm_offered_differential__c, df_input.aitm_offered_volume__c,
                   df_input.aitm_on_airfield_fixed__c, df_input.aitm_on_airfield_variable__c,
                   df_input.aitm_other_income_fixed__c, df_input.aitm_other_income_variable__c,
                   df_input.aitm_overall_credit_days_customer__c, df_input.aitm_ppi__c,
                   df_input.aitm_percentage_volume_offered__c, df_input.aitm_platts_index__c,
                   df_input.aitm_pre_airfield_fixed__c, df_input.aitm_pre_airfield_variable__c,
                   df_input.aitm_premium__c, df_input.aitm_pricing_basis_c, df_input.aitm_pricing_excellence__c,
                   df_input.aitm_pricing_service_call_status__c, df_input.aitm_product_loss__c,
                   df_input.aitm_quantity__c, df_input.aitm_rebate__c, df_input.aitm_replenishment_pricing_basis__c,
                   df_input.aitm_requested_volume_usg__c, df_input.aitm_requested_volume_uom__c,
                   df_input.aitm_return_on_wc__c, df_input.aitm_round__c, df_input.aitm_specification__c,
                   df_input.aitm_start_date__c, df_input.aitm_stock_days__c, df_input.aitm_supplier_credit_days__c,
                   df_input.aitm_target_price__c, df_input.aitm_temperature_adjustment_at_location__c,
                   df_input.aitm_tender_id__c, df_input.aitm_tender_location__c, df_input.aitm_tender_result__c,
                   df_input.aitm_tender__c, df_input.aitm_title__c, df_input.aitm_unit_gp__c,
                   df_input.aitm_unit_of_measure_rebate__c, df_input.aitm_unit_of_measure_winning_differentia__c,
                   df_input.aitm_unit_of_measure__c, df_input.aitm_unit_of_measure_pricing_basis__c,
                   df_input.aitm_variance__c, df_input.aitm_volume_overall_location_size__c, df_input.aitm_volume__c,
                   df_input.aitm_winning_differential__c, df_input.aitm_winning_supplier__c,
                   df_input.aitm_winning_terms__c, df_input.aitm_working_capital__c, df_input.aitm_yearly_volume__c,
                   df_input.aitm_is_pricing_basis_not_represented__c, df_input.aitm_replenishment_pricing_period__c,
                   df_input.aitm_sales_pricing_period__c, df_input.aitm_account_manager_notes_instructions__c,
                   df_input.aitm_history_line_item__c, df_input.aitm_lm_context_strategic_rationale_info__c,
                   df_input.aitm_location_manager_level_of_interest__c, df_input.aitm_payment_currency__c,
                   df_input.aitm_security_text_on_offer__c, df_input.aitm_security_type__c,
                   df_input.aitm_credit_rating__c, df_input.aitm_currency_pricing_basis1__c,
                   df_input.aitm_currency_rebate1__c, df_input.aitm_previous_round_differential__c,
                   df_input.aitm_unit_of_measure_rebate1__c, df_input.aitm_unit_of_measure_pricing_basis1__c,
                   df_input.aitm_status__c, df_input.aitm_tender_unique_id__c, df_input.aitm_credit_days__c,
                   df_input.aitm_minimum_selling_price__c, df_input.aitm_bid_expiry_date__c,
                   df_input.aitm_previous_tlli_id__c, df_input.aitm_additional_notes_taxes_and_fees__c,
                   df_input.aitm_additional_refueling_information__c, df_input.aitm_delivery_by__c,
                   df_input.aitm_include_notes_in_contract__c, df_input.aitm_include_taxes_and_fees_in_contract__c,
                   df_input.aitm_measure__c, df_input.aitm_product_default__c, df_input.aitm_product_specification__c,
                   df_input.aitm_depe_pricing_basis__c, df_input.aitm_iata_internal_code__c, df_input.infa_ext_dt)
        print("df_tfx_l21")
        df_tfx_l21.printSchema()

        df_tfx_l31 = df_tfx_l21. \
            select(df_tfx_l21.id, df_tfx_l21.ownerid, df_tfx_l21.name, df_tfx_l21.currencyisocode,
                   df_tfx_l21.recordtypeid, df_tfx_l21.aitm_account__c, df_tfx_l21.aitm_ad_hoc_volume__c,
                   df_tfx_l21.aitm_additional_margin_from_line_items__c.cast('double'),
                   df_tfx_l21.aitm_adjusted_differential__c.cast('double'),
                   df_tfx_l21.aitm_awarded_volume__c.cast('double'), df_tfx_l21.aitm_base_cost__c.cast('double'),
                   df_tfx_l21.aitm_bid_expiry_data__c,df_tfx_l21.aitm_buying_power_value__c,
                   df_tfx_l21.aitm_cso_costs__c.cast('double'), df_tfx_l21.aitm_contract_length__c.cast('double'),
                   df_tfx_l21.aitm_cost_of_product__c.cast('double'),
                   df_tfx_l21.aitm_credit_days_adjustment__c.cast('double'),
                   df_tfx_l21.aitm_is_pricing_basis_not_represented__c,
                   df_tfx_l21.aitm_credit_terms_adjustment__c.cast('double'), df_tfx_l21.aitm_currency_pricing_basis__c,
                   df_tfx_l21.aitm_currency_rebate__c, df_tfx_l21.aitm_currency_winning_differential__c,
                   df_tfx_l21.aitm_currency__c, df_tfx_l21.aitm_current_round__c.cast('double'),
                   df_tfx_l21.aitm_current_value__c.cast('double'),
                   df_tfx_l21.aitm_customer_location_specific_revenue__c.cast('double'),
                   df_tfx_l21.aitm_customer_specific_into_plane_costs__c.cast('double'),
                   df_tfx_l21.aitm_data_capture_delay__c.cast('double'),
                   df_tfx_l21.aitm_data_pricing_calculation_provided__c, df_tfx_l21.aitm_days__c.cast('double'),
                   df_tfx_l21.aitm_debrief_notes__c, df_tfx_l21.aitm_delivery_point__c.cast('double'),
                   df_tfx_l21.aitm_density_adjustments__c.cast('double'), df_tfx_l21.aitm_description__c,
                   df_tfx_l21.aitm_details_context__c, df_tfx_l21.aitm_duration__c,
                   f.date_format(f.to_date(f.substring(df_tfx_l21.aitm_end_date__c, 1, 10), 'MM/dd/yyyy'), 'MM/dd/yyyy')
                   .alias('aitm_end_date__c'), df_tfx_l21.aitm_estimated_floor_price__c.cast('double'),
                   df_tfx_l21.aitm_exchange__c, df_tfx_l21.aitm_floor_price__c.cast('double'), df_tfx_l21.aitm_grn__c,
                   df_tfx_l21.aitm_gross_profit__c.cast('double'), df_tfx_l21.aitm_include_on_debrief__c,
                   df_tfx_l21.aitm_instrument__c, df_tfx_l21.aitm_invoice_frequency__c,
                   df_tfx_l21.aitm_is_current_round__c, df_tfx_l21.aitm_jv_profit_dividend__c.cast('double'),
                   df_tfx_l21.aitm_last_call_to_pricing_system__c, df_tfx_l21.aitm_last_tender_result__c,
                   df_tfx_l21.aitm_level_of_interest__c, df_tfx_l21.aitm_line_item_margins__c,
                   df_tfx_l21.aitm_line_item_name_account__c, df_tfx_l21.aitm_currency_pricing_basis1__c,
                   df_tfx_l21.aitm_location_neutral_wc_payment_days__c.cast('double'),
                   df_tfx_l21.aitm_mark_up_customer_buying_power__c.cast('double'),
                   df_tfx_l21.aitm_mark_up_customer_segment__c.cast('double'),
                   df_tfx_l21.aitm_mark_up_location_strategy__c.cast('double'),
                   df_tfx_l21.aitm_market_structure_cost__c.cast('double'),
                   df_tfx_l21.aitm_offered_differential__c.cast('double'),
                   df_tfx_l21.aitm_offered_volume__c.cast('double'),
                   df_tfx_l21.aitm_overall_credit_days_customer__c.cast('double'),
                   df_tfx_l21.aitm_ppi__c.cast('double'),
                   df_tfx_l21.aitm_percentage_volume_offered__c.cast('double'),
                   df_tfx_l21.aitm_platts_index__c.cast('double'), df_tfx_l21.aitm_premium__c.cast('double'),
                   df_tfx_l21.aitm_pricing_basis_description_c, df_tfx_l21.aitm_pricing_excellence__c,
                   df_tfx_l21.aitm_pricing_service_call_status__c, df_tfx_l21.aitm_quantity__c.cast('double'),
                   df_tfx_l21.aitm_rebate__c.cast('double'), df_tfx_l21.aitm_requested_volume_usg__c.cast('double'),
                   df_tfx_l21.aitm_requested_volume_uom__c, df_tfx_l21.aitm_return_on_wc__c.cast('double'),
                   df_tfx_l21.aitm_round__c.cast('double'), df_tfx_l21.aitm_specification__c,
                   f.date_format(f.to_date(f.substring(df_tfx_l21.aitm_start_date__c, 1, 10), 'MM/dd/yyyy'),
                                 'MM/dd/yyyy').alias('aitm_start_date__c'),
                   df_tfx_l21.aitm_stock_days__c.cast('double'), df_tfx_l21.aitm_supplier_credit_days__c.cast('double'),
                   df_tfx_l21.aitm_target_price__c.cast('double'),
                   df_tfx_l21.aitm_temperature_adjustment_at_location__c.cast('double'), df_tfx_l21.aitm_tender_id__c,
                   df_tfx_l21.aitm_tender_location__c, df_tfx_l21.aitm_location__c, df_tfx_l21.aitm_tender_result__c,
                   df_tfx_l21.aitm_tender__c, df_tfx_l21.aitm_title__c, df_tfx_l21.aitm_unit_gp__c.cast('double'),
                   df_tfx_l21.aitm_unit_of_measure_rebate__c, df_tfx_l21.aitm_unit_of_measure_winning_differentia__c,
                   df_tfx_l21.aitm_unit_of_measure__c, df_tfx_l21.aitm_unit_of_measure_pricing_basis__c,
                   df_tfx_l21.aitm_variance__c.cast('double'),
                   df_tfx_l21.aitm_volume_overall_location_size__c.cast('double'),
                   df_tfx_l21.aitm_volume__c.cast('double'), df_tfx_l21.aitm_winning_differential__c.cast('double'),
                   df_tfx_l21.aitm_winning_supplier__c, df_tfx_l21.aitm_winning_terms__c,
                   df_tfx_l21.aitm_working_capital__c.cast('double'), df_tfx_l21.aitm_yearly_volume__c.cast('double'),
                   df_tfx_l21.aitm_credit_rating_of_customer__c, df_tfx_l21.aitm_delivery_method__c,
                   df_tfx_l21.aitm_location_size__c.cast('double'), df_tfx_l21.aitm_location_strategy__c,
                   df_tfx_l21.aitm_on_airfield_fixed__c.cast('double'),
                   df_tfx_l21.aitm_on_airfield_variable__c.cast('double'),
                   df_tfx_l21.aitm_other_income_fixed__c.cast('double'),
                   df_tfx_l21.aitm_other_income_variable__c.cast('double'),
                   df_tfx_l21.aitm_pre_airfield_fixed__c.cast('double'),
                   df_tfx_l21.aitm_pre_airfield_variable__c.cast('double'), df_tfx_l21.aitm_product_loss__c,
                   df_tfx_l21.aitm_replenishment_pricing_period__c, df_tfx_l21.aitm_sales_pricing_period__c,
                   df_tfx_l21.aitm_delivery_point_info__c, df_tfx_l21.aitm_account_manager_notes_instructions__c,
                   df_tfx_l21.aitm_history_line_item__c, df_tfx_l21.aitm_lm_context_strategic_rationale_info__c,
                   df_tfx_l21.aitm_location_manager_level_of_interest__c, df_tfx_l21.aitm_payment_currency__c,
                   df_tfx_l21.aitm_security_text_on_offer__c, df_tfx_l21.aitm_security_type__c,
                   df_tfx_l21.aitm_currency_rebate1__c, df_tfx_l21.aitm_unit_of_measure_rebate1__c,
                   df_tfx_l21.aitm_unit_of_measure_pricing_basis1__c, df_tfx_l21.aitm_credit_rating__c.cast('double'),
                   df_tfx_l21.aitm_previous_round_differential__c.cast('double'), df_tfx_l21.aitm_status__c,
                   df_tfx_l21.aitm_tender_unique_id__c, df_tfx_l21.aitm_credit_days__c.cast('double'),
                   df_tfx_l21.aitm_minimum_selling_price__c.cast('double'),
                   df_tfx_l21.aitm_bid_expiry_date__c.cast('date'), df_tfx_l21.aitm_previous_tlli_id__c,
                   df_tfx_l21.aitm_tender_owner_profile__c, df_tfx_l21.aitm_additional_notes_taxes_and_fees__c,
                   df_tfx_l21.aitm_additional_refueling_information__c, df_tfx_l21.aitm_delivery_by__c,
                   df_tfx_l21.aitm_include_notes_in_contract__c, df_tfx_l21.aitm_include_taxes_and_fees_in_contract__c,
                   df_tfx_l21.aitm_measure__c, df_tfx_l21.aitm_product_default__c,
                   df_tfx_l21.aitm_product_specification__c, df_tfx_l21.aitm_depe_pricing_basis__c,
                   df_tfx_l21.aitm_taxes_fees__c, df_tfx_l21.createdbyid,
                   f.date_format(f.to_date(df_tfx_l21.infa_ext_dt, 'yyyyMMdd'), 'yyyyMMdd').alias('infa_ext_dt'))
        print("df_tfx_l31")
        df_tfx_l31.printSchema()

        df_tfx_l32 = df_tfx_l31.\
            select(f.when(f.length(df_tfx_l31.id) == 18, f.substring(df_tfx_l31.id, 1, 15))
                   .otherwise(df_tfx_l31.id).alias('id'), df_tfx_l31.ownerid, df_tfx_l31.name,
                   df_tfx_l31.currencyisocode, df_tfx_l31.recordtypeid, df_tfx_l31.aitm_account__c,
                   df_tfx_l31.aitm_ad_hoc_volume__c, df_tfx_l31.aitm_additional_margin_from_line_items__c,
                   df_tfx_l31.aitm_adjusted_differential__c, df_tfx_l31.aitm_awarded_volume__c,
                   df_tfx_l31.aitm_base_cost__c, df_tfx_l31.aitm_bid_expiry_data__c,
                   df_tfx_l31.aitm_buying_power_value__c, df_tfx_l31.aitm_cso_costs__c,
                   df_tfx_l31.aitm_contract_length__c, df_tfx_l31.aitm_cost_of_product__c,
                   df_tfx_l31.aitm_credit_days_adjustment__c,
                   df_tfx_l31.aitm_is_pricing_basis_not_represented__c,
                   df_tfx_l31.aitm_credit_terms_adjustment__c, df_tfx_l31.aitm_currency_pricing_basis__c,
                   df_tfx_l31.aitm_currency_rebate__c, df_tfx_l31.aitm_currency_winning_differential__c,
                   df_tfx_l31.aitm_currency__c, df_tfx_l31.aitm_current_round__c,
                   df_tfx_l31.aitm_current_value__c, df_tfx_l31.aitm_customer_location_specific_revenue__c,
                   df_tfx_l31.aitm_customer_specific_into_plane_costs__c, df_tfx_l31.aitm_data_capture_delay__c,
                   df_tfx_l31.aitm_data_pricing_calculation_provided__c, df_tfx_l31.aitm_days__c,
                   df_tfx_l31.aitm_debrief_notes__c, df_tfx_l31.aitm_delivery_point__c,
                   df_tfx_l31.aitm_density_adjustments__c, df_tfx_l31.aitm_description__c,
                   df_tfx_l31.aitm_details_context__c, df_tfx_l31.aitm_duration__c, df_tfx_l31.aitm_end_date__c,
                   df_tfx_l31.aitm_estimated_floor_price__c, df_tfx_l31.aitm_exchange__c,
                   df_tfx_l31.aitm_floor_price__c, df_tfx_l31.aitm_grn__c, df_tfx_l31.aitm_gross_profit__c,
                   df_tfx_l31.aitm_include_on_debrief__c, df_tfx_l31.aitm_instrument__c,
                   df_tfx_l31.aitm_invoice_frequency__c, df_tfx_l31.aitm_is_current_round__c,
                   df_tfx_l31.aitm_jv_profit_dividend__c, df_tfx_l31.aitm_last_call_to_pricing_system__c,
                   df_tfx_l31.aitm_last_tender_result__c, df_tfx_l31.aitm_level_of_interest__c,
                   df_tfx_l31.aitm_line_item_margins__c, df_tfx_l31.aitm_line_item_name_account__c,
                   df_tfx_l31.aitm_currency_pricing_basis1__c,
                   df_tfx_l31.aitm_location_neutral_wc_payment_days__c,
                   df_tfx_l31.aitm_mark_up_customer_buying_power__c, df_tfx_l31.aitm_mark_up_customer_segment__c,
                   df_tfx_l31.aitm_mark_up_location_strategy__c, df_tfx_l31.aitm_market_structure_cost__c,
                   df_tfx_l31.aitm_offered_differential__c, df_tfx_l31.aitm_offered_volume__c,
                   df_tfx_l31.aitm_overall_credit_days_customer__c, df_tfx_l31.aitm_ppi__c,
                   df_tfx_l31.aitm_percentage_volume_offered__c, df_tfx_l31.aitm_platts_index__c,
                   df_tfx_l31.aitm_premium__c, df_tfx_l31.aitm_pricing_basis_description_c,
                   df_tfx_l31.aitm_pricing_excellence__c, df_tfx_l31.aitm_pricing_service_call_status__c,
                   df_tfx_l31.aitm_quantity__c, df_tfx_l31.aitm_rebate__c,
                   df_tfx_l31.aitm_requested_volume_usg__c, df_tfx_l31.aitm_requested_volume_uom__c,
                   df_tfx_l31.aitm_return_on_wc__c, df_tfx_l31.aitm_round__c, df_tfx_l31.aitm_specification__c,
                   df_tfx_l31.aitm_start_date__c, df_tfx_l31.aitm_stock_days__c,
                   df_tfx_l31.aitm_supplier_credit_days__c, df_tfx_l31.aitm_target_price__c,
                   df_tfx_l31.aitm_temperature_adjustment_at_location__c, df_tfx_l31.aitm_tender_id__c,
                   df_tfx_l31.aitm_location__c, df_tfx_l31.aitm_tender_location__c,
                   df_tfx_l31.aitm_tender_result__c, df_tfx_l31.aitm_tender__c, df_tfx_l31.aitm_title__c,
                   df_tfx_l31.aitm_unit_gp__c, df_tfx_l31.aitm_unit_of_measure_rebate__c,
                   df_tfx_l31.aitm_unit_of_measure_winning_differentia__c, df_tfx_l31.aitm_unit_of_measure__c,
                   df_tfx_l31.aitm_unit_of_measure_pricing_basis__c, df_tfx_l31.aitm_variance__c,
                   df_tfx_l31.aitm_volume_overall_location_size__c, df_tfx_l31.aitm_volume__c,
                   df_tfx_l31.aitm_winning_differential__c, df_tfx_l31.aitm_winning_supplier__c,
                   df_tfx_l31.aitm_winning_terms__c, df_tfx_l31.aitm_working_capital__c,
                   df_tfx_l31.aitm_yearly_volume__c, df_tfx_l31.aitm_credit_rating_of_customer__c,
                   df_tfx_l31.aitm_delivery_method__c, df_tfx_l31.aitm_location_size__c,
                   df_tfx_l31.aitm_location_strategy__c, df_tfx_l31.aitm_on_airfield_fixed__c,
                   df_tfx_l31.aitm_on_airfield_variable__c, df_tfx_l31.aitm_other_income_fixed__c,
                   df_tfx_l31.aitm_other_income_variable__c, df_tfx_l31.aitm_pre_airfield_fixed__c,
                   df_tfx_l31.aitm_pre_airfield_variable__c, df_tfx_l31.aitm_product_loss__c,
                   df_tfx_l31.aitm_replenishment_pricing_period__c, df_tfx_l31.aitm_sales_pricing_period__c,
                   df_tfx_l31.aitm_delivery_point_info__c, df_tfx_l31.aitm_account_manager_notes_instructions__c,
                   df_tfx_l31.aitm_history_line_item__c, df_tfx_l31.aitm_lm_context_strategic_rationale_info__c,
                   df_tfx_l31.aitm_location_manager_level_of_interest__c, df_tfx_l31.aitm_payment_currency__c,
                   df_tfx_l31.aitm_security_text_on_offer__c, df_tfx_l31.aitm_security_type__c,
                   df_tfx_l31.aitm_currency_rebate1__c, df_tfx_l31.aitm_unit_of_measure_rebate1__c,
                   df_tfx_l31.aitm_unit_of_measure_pricing_basis1__c, df_tfx_l31.aitm_credit_rating__c,
                   df_tfx_l31.aitm_previous_round_differential__c, df_tfx_l31.aitm_status__c,
                   df_tfx_l31.aitm_tender_unique_id__c, df_tfx_l31.aitm_credit_days__c,
                   df_tfx_l31.aitm_minimum_selling_price__c, df_tfx_l31.aitm_bid_expiry_date__c,
                   df_tfx_l31.aitm_previous_tlli_id__c,
                   df_tfx_l31.aitm_tender_owner_profile__c, df_tfx_l31.aitm_additional_notes_taxes_and_fees__c,
                   df_tfx_l31.aitm_additional_refueling_information__c, df_tfx_l31.aitm_delivery_by__c,
                   df_tfx_l31.aitm_include_notes_in_contract__c,
                   df_tfx_l31.aitm_include_taxes_and_fees_in_contract__c, df_tfx_l31.aitm_measure__c,
                   df_tfx_l31.aitm_product_default__c, df_tfx_l31.aitm_product_specification__c,
                   df_tfx_l31.aitm_depe_pricing_basis__c, df_tfx_l31.aitm_taxes_fees__c,
                   f.when(df_tfx_l31.aitm_tender_unique_id__c.isNull(), f.lit('SF')).otherwise(f.lit('TMS'))
                   .alias('source_system'),
                   f.md5(f.concat(df_tfx_l31.id, df_tfx_l31.ownerid, df_tfx_l31.name, df_tfx_l31.aitm_account__c,
                                  df_tfx_l31.aitm_end_date__c, df_tfx_l31.aitm_start_date__c,
                                  df_tfx_l31.aitm_tender_id__c, df_tfx_l31.aitm_tender_location__c,
                                  df_tfx_l31.aitm_tender_result__c, df_tfx_l31.aitm_tender__c,
                                  df_tfx_l31.aitm_volume__c, df_tfx_l31.aitm_status__c,
                                  df_tfx_l31.aitm_tender_unique_id__c)).alias('checksum'),
                   df_tfx_l31.createdbyid, df_tfx_l31.infa_ext_dt)
        print("df_tfx_l32")
        df_tfx_l32.printSchema()

        df_tfx_result = [df_tfx_l21, df_tfx_l31, df_tfx_l32]

        return df_tfx_result


if __name__ == '__main__':
    trl = TMSalesForceETL()
    trl.execute()
