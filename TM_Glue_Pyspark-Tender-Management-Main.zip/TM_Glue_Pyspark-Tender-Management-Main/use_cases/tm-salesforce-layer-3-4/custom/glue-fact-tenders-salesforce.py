# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      18-Feb-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to create tender L5 tables in conform zone
# Author        :- Bakul Seth
# Date          :- 18-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================


import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class TMSalesForceETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database1 = args['source_database1']
        self.source_database2 = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        # input tables for JOB
        self.input_tables = ['l32_tm_salesforce_tender_location_line_item', 'l32_tm_salesforce_tender_header',
                             'l32_tm_salesforce_tender_account', 'l32_tm_salesforce_tender_location',
                             'l2_performance_reporting_customer_mappings', 'l2_performance_reporting_location_mappings']

        # output file for JOB
        self.l4_fact_tenders = 'salesforce_layer_4/l4_tm_fact_tenders_salesforce'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database1, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # read data from specific table argument passed(database, table_list)
        print('starting to read tables from glue catalog for processing')
        df_inputs = self._get_table(self.source_database1, self.source_database2, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe)
        print('starting to apply transformations on the tables')
        df_tfx = self._apply_tfx(df_inputs)

        print('starting to write the result to the location')
        # write final result to l5 destination
        self.write_results(df_tfx, self.l4_fact_tenders)

    def write_results(self, target_dataset, report):
        final_path = self.destination_bucket + '/' + report
        print('final_path', final_path)
        target_dataset \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, source_database2, tables_name):
        print('reading sf tender_location_line_item data from {}.{}'.format(source_database, tables_name[0]))
        df_line_item = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[0], transformation_ctx='target_table').toDF()

        print('reading sf tender_header data from {}.{}'.format(source_database, tables_name[1]))
        df_header = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[1], transformation_ctx='target_table').toDF()

        print('reading sf tender_account data from {}.{}'.format(source_database, tables_name[2]))
        df_account = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[2], transformation_ctx='target_table').toDF()

        print('reading sf tender_location data from {}.{}'.format(source_database, tables_name[3]))
        df_location = self._gc.create_dynamic_frame.from_catalog(
            database=source_database, table_name=tables_name[3], transformation_ctx='target_table').toDF()

        print('reading performance_reporting_customer_mappings data from {}.{}'.format(source_database, tables_name[4]))
        df_cust_map = self._gc.create_dynamic_frame.from_catalog(
            database=source_database2, table_name=tables_name[4], transformation_ctx='target_table').toDF()

        print('reading performance_reporting_location_mappings data from {}.{}'.format(source_database, tables_name[5]))
        df_loc_map = self._gc.create_dynamic_frame.from_catalog(
            database=source_database2, table_name=tables_name[5], transformation_ctx='target_table').toDF()

        return [df_line_item, df_header, df_account, df_location, df_cust_map, df_loc_map]

    @staticmethod
    def _apply_tfx(df_input):

        df_tfx_result = df_input[0].alias('line') \
            .join(df_input[1].alias('head'), f.col('line.aitm_tender__c') == f.col('head.id'), 'inner')\
            .join(df_input[2].alias('acc'), (f.col('line.aitm_account__c') == f.col('acc.aitm_account__c')) &
                  (f.col('line.aitm_tender__c') == f.col('acc.aitm_tender__c')), 'inner')\
            .join(df_input[3].alias('loc'), (f.col('line.aitm_location__c') == f.col('loc.aitm_location__c')) &
                  (f.col('line.aitm_tender_location__c') == f.col('loc.id')), 'inner') \
            .join(df_input[4].alias('cust_map'),
                  f.col('acc.aitm_grn__c') == f.col('cust_map.grn'), 'left') \
            .join(df_input[5].alias('loc_map'),
                  f.col('loc.aitm_iata__c') == f.col('loc_map.location_code'), 'left')\
            .filter((f.col('line.source_system') == f.lit('SF')) &
                    ((f.coalesce(f.col('line.aitm_tender_result__c'), f.lit('')) != f.lit('')) |
                     (f.coalesce(f.col('line.aitm_tender_result__c')) == f.lit('')) &
                     (f.col('line.aitm_is_current_round__c') == f.lit('1')) &
                     (f.col('line.aitm_status__c') == f.lit('Not Represented'))) &
                    (f.col('head.name').like('TEST%') == False) &
                    (f.col('line.recordtypeid').substr(15, 1) == f.lit('g')) &
                    (f.col('line.aitm_is_current_round__c') == f.lit('1')) &
                    (f.col('loc.aitm_is_current_round__c') == f.lit('1')))\
            .select(f.col('line.id').alias('tender_key'), f.col('head.id').alias('tender_id'),
                    f.col('line.recordtypeid').alias('recordtypeid'), f.col('head.name').alias('tender_name'),
                    f.col('line.aitm_tender_unique_id__c').alias('tms_unique_id'),
                    f.col('head.aitm_tender_sector__c').alias('sector'),
                    f.col('head.aitm_stage__c').alias('stag'), f.col('line.aitm_unit_of_measure__c').alias('uom'),
                    f.col('acc.id').alias('tender_account_id'), f.col('acc.aitm_grn__c').alias('grn'),
                    f.col('acc.aitm_customer_name__c').alias('customer_name'), f.col('line.aitm_depe_pricing_basis__c'),
                    f.col('head.aitm_debrief_email_sent_date__c'),
                    f.col('line.id').alias('tender_location_line_item_id'),
                    f.col('line.name').alias('tender_location_line_item_name'),
                    f.col('line.aitm_ad_hoc_volume__c').alias('ad_hoc_volume'),
                    f.col('line.aitm_currency_rebate__c').alias('currency_rebate'),
                    f.col('line.aitm_currency_winning_differential__c').alias('currency_winning_differential'),
                    f.col('line.aitm_currency__c').alias('currency'),
                    f.col('line.aitm_description__c').alias('description'),
                    f.col('line.aitm_last_tender_result__c').alias('last_result'),
                    f.col('line.aitm_requested_volume_uom__c').alias('requested_volume_uom'),
                    f.col('head.aitm_start_date__c').alias('start_date'),
                    f.col('head.aitm_end_date__c').alias('end_date'),
                    f.col('line.aitm_start_date__c').alias('line_item_start_date'),
                    f.col('line.aitm_end_date__c').alias('line_item_end_date'),
                    f.round(f.months_between(f.col('head.aitm_end_date__c'),
                                             f.col('head.aitm_start_date__c')), 0).alias('contract_length'),
                    f.col('line.aitm_tender_result__c').alias('result'),
                    f.col('line.aitm_title__c').alias('tender_title'),
                    f.col('line.aitm_status__c').alias('tender_line_item_status'),
                    f.col('loc.id').alias('tender_location_id'), f.col('loc.name').alias('location_name'),
                    f.when(f.coalesce(f.col('loc_map.location_manager'), f.lit('')) != f.lit(''),
                           f.coalesce(f.col('loc_map.location_manager'), f.lit('Other')))
                    .otherwise(f.lit('Other')).alias('location_manager'),
                    f.when((f.coalesce(f.col('head.aitm_tender_sector__c'), f.lit('')) == f.lit('CA')) &
                           (f.coalesce(f.col('cust_map.account_holder'), f.lit('')) != f.lit('')),
                           f.coalesce(f.col('cust_map.account_holder'), f.lit('Other')))
                    .otherwise(f.lit('Other')).alias('account_manager'),
                    f.col('line.aitm_product_default__c').alias('grade'),
                    f.col('head.aitm_density__c').alias('density'),
                    f.col('line.aitm_adjusted_differential__c').alias('adjusted_differential'),
                    f.when(f.col('line.aitm_tender_result__c') == f.lit('LB'), f.lit(0))
                    .otherwise(f.col('line.aitm_awarded_volume__c')).alias('awarded_volume'),
                    f.col('line.aitm_current_round__c').alias('current_round'),
                    f.col('line.aitm_current_value__c').alias('current_value'),
                    f.col('line.aitm_gross_profit__c').alias('gross_profit'),
                    f.col('line.aitm_offered_volume__c').alias('offered_volume'),
                    f.col('line.aitm_percentage_volume_offered__c').alias('percentage_volume_offered'),
                    f.col('line.aitm_quantity__c').alias('quantity1'), f.col('line.aitm_volume__c').alias('volume'),
                    f.col('line.aitm_rebate__c').alias('rebate'),
                    f.col('line.aitm_requested_volume_usg__c').alias('requested_volume_usg'),
                    f.col('line.aitm_winning_differential__c').alias('winning_differential'),
                    f.col('line.aitm_offered_differential__c').alias('offered_differential'),
                    f.col('line.aitm_yearly_volume__c').alias('yearly_volume'),
                    f.col('loc.aitm_iata__c').alias('location_code'), f.col('loc.aitm_iata__c').alias('iata'),
                    f.split(f.col('loc.aitm_iata_icao__c'), '/').getItem(1).alias('icao'),
                    f.col('head.aitm_quality_of_feedback__c').alias('quality_of_feedback'),
                    f.col('head.aitm_last_look_to_incumbent__c'),
                    f.col('line.infa_ext_dt').alias('last_refreshed_date'))

        print(df_tfx_result.count())

        return df_tfx_result


if __name__ == '__main__':
    trl = TMSalesForceETL()
    trl.execute()
