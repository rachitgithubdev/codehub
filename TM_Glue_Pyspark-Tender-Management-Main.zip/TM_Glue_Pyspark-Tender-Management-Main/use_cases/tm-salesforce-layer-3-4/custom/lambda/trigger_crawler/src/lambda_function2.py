import boto3

client = boto3.client('glue')


def lambda_handler(event, context):
    print('Start the glue crawler aviation-tm-salesforce-layer-2-3-crawler')
    response = client.start_crawler(Name='aviation-tm-salesforce-layer-4-crawler')
    print('***********', event)
