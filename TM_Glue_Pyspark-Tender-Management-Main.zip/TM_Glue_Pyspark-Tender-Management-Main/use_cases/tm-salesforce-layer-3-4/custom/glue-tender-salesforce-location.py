# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      08-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to create tender location tables in conform zone
# Author        :- Bakul Seth
# Date          :- 20-Jan-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class TMSalesForceETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_tender_location"
        self.l21_report_file = "salesforce_layer_2.1/l21_tm_salesforce_tender_location"
        self.l31_report_file = "salesforce_layer_3.1/l31_tm_salesforce_tender_location"
        self.l32_report_file = "salesforce_layer_3.2/l32_tm_salesforce_tender_location"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # read data from country specific table argument passed(database, table)
        df_input = self._get_table(self.source_database, self.input_table).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_input.count()))

        # apply transformation on the dataframe argument passed(dataframe)
        df_tfx = self._apply_tfx(df_input)

        # write final result to l21 destination
        self.write_results(df_tfx[0], self.l21_report_file)

        # write final result to l31 destination
        self.write_results(df_tfx[1], self.l31_report_file)

        # write final result to l31 destination
        self.write_results(df_tfx[2], self.l32_report_file)

    def write_results(self, target_dataset, report):
        final_path = self.destination_bucket + "/" + report
        print('final_path', final_path)
        target_dataset\
            .write.option("compression", "snappy")\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input):

        # convert all the columns alias to lower case
        df_input = df_input.select([f.col(x).alias(x.lower()) for x in df_input.columns])
        df_input.printSchema()
        df_tfx_l21 = df_input.\
            select(df_input.aitm_additional_notes__c, df_input.aitm_comments__c, df_input.aitm_competition__c,
                   df_input.aitm_competitor_info_other__c, df_input.aitm_competitor_info__c,
                   df_input.aitm_has_feedback__c, df_input.aitm_include_notes_in_contract__c,
                   df_input.aitm_competition_ga__c, df_input.id, df_input.isdeleted, df_input.name,
                   df_input.currencyisocode, df_input.createddate, df_input.createdbyid, df_input.lastmodifieddate,
                   df_input.lastmodifiedbyid, df_input.systemmodstamp, df_input.lastvieweddate,
                   df_input.lastreferenceddate, df_input.aitm_location__c, df_input.aitm_tender__c,
                   df_input.aitm_ad_hoc_volume__c, df_input.aitm_aircraft_type__c, df_input.aitm_classification__c,
                   df_input.aitm_contracted__c, df_input.aitm_country__c, df_input.aitm_current_round__c,
                   df_input.aitm_delivery_by__c, df_input.aitm_delivery_method__c, df_input.aitm_density__c,
                   df_input.aitm_distance_from_leading_bid__c, df_input.aitm_iata_icao__c, df_input.aitm_iata__c,
                   df_input.aitm_include_in_revised_offer__c, df_input.aitm_include_taxes_fees_in_contract__c,
                   df_input.aitm_into_plane__c, df_input.aitm_is_current_round__c,
                   df_input.aitm_last_look_to_incumbent__c, df_input.aitm_leading_bid_currency__c,
                   df_input.aitm_leading_bid_uom__c, df_input.aitm_leading_bid__c, df_input.aitm_location_manager__c,
                   df_input.aitm_location_size__c, df_input.aitm_location_summary_details_context__c,
                   df_input.aitm_measure__c, df_input.aitm_number_of_bidders__c, df_input.aitm_number_of_rounds__c,
                   df_input.aitm_offered_differential_currency__c, df_input.aitm_offered_differential_uom__c,
                   df_input.aitm_offered_differential__c, df_input.aitm_position__c, df_input.aitm_primary_supply__c,
                   df_input.aitm_product__c, df_input.aitm_quality_of_feedback__c,
                   df_input.aitm_recalculate_total_volume__c, df_input.aitm_round__c, df_input.aitm_service_level__c,
                   df_input.aitm_specification__c, df_input.aitm_status__c, df_input.aitm_taxes_fees__c,
                   df_input.aitm_title__c, df_input.aitm_total_volume_offered_to_the_group__c,
                   df_input.aitm_unit_of_measure__c, df_input.aitm_volume__c, df_input.aitm_sector__c,
                   df_input.aitm_bids_in_by__c, df_input.aitm_stage__c, df_input.aitm_distance_from_leading_bid1__c,
                   df_input.aitm_tender_unique_id__c, df_input.aitm_no_revision__c, df_input.aitm_apply_to_all__c,
                   df_input.aitm_depe_product__c, df_input.aitm_airport_classification_ga__c,
                   df_input.aitm_bp_location_volume_ga__c, df_input.aitm_location_segmentation_ga__c,
                   df_input.aitm_location_strategy_ga__c, df_input.aitm_market_classification_ga__c,
                   df_input.aitm_overall_location_size_ga__c, df_input.aitm_primary_airport_supply_ga__c,
                   df_input.aitm_primary_product_supply_ga__c, df_input.aitm_sales_organisation_ga__c,
                   df_input.aitm_suppliers_total_volume_ga__c, df_input.aitm_total_requested_volume__c,
                   df_input.aitm_locations_filter__c, df_input.aitm_is_straddled__c,
                   df_input.apply_all_tax_free_check__c, df_input.aitm_apply_all_tax_fee_check__c,
                   f.current_date().alias('infa_ext_dt'))
        print("df_tfx_l21")
        df_tfx_l21.printSchema()

        df_tfx_l31 = df_tfx_l21. \
            select(df_tfx_l21.id, df_tfx_l21.name, df_tfx_l21.currencyisocode, df_tfx_l21.aitm_tender__c,
                   df_tfx_l21.aitm_ad_hoc_volume__c, df_tfx_l21.aitm_additional_notes__c,
                   df_tfx_l21.aitm_aircraft_type__c, df_tfx_l21.aitm_classification__c, df_tfx_l21.aitm_comments__c,
                   df_tfx_l21.aitm_competition__c, df_tfx_l21.aitm_competitor_info_other__c,
                   df_tfx_l21.aitm_competitor_info__c, df_tfx_l21.aitm_contracted__c, df_tfx_l21.aitm_country__c,
                   df_tfx_l21.aitm_current_round__c.cast('double'), df_tfx_l21.aitm_delivery_by__c,
                   df_tfx_l21.aitm_delivery_method__c, df_tfx_l21.aitm_density__c.cast('double'),
                   df_tfx_l21.aitm_distance_from_leading_bid__c, df_tfx_l21.aitm_has_feedback__c,
                   df_tfx_l21.aitm_iata_icao__c, df_tfx_l21.aitm_iata__c, df_tfx_l21.aitm_include_in_revised_offer__c,
                   df_tfx_l21.aitm_include_notes_in_contract__c, df_tfx_l21.aitm_include_taxes_fees_in_contract__c,
                   df_tfx_l21.aitm_into_plane__c, df_tfx_l21.aitm_is_current_round__c,
                   df_tfx_l21.aitm_last_look_to_incumbent__c, df_tfx_l21.aitm_leading_bid_currency__c,
                   df_tfx_l21.aitm_leading_bid_uom__c, df_tfx_l21.aitm_leading_bid__c.cast('double'),
                   df_tfx_l21.aitm_location_manager__c, df_tfx_l21.aitm_location_size__c.cast('double'),
                   df_tfx_l21.aitm_location_summary_details_context__c, df_tfx_l21.aitm_location__c,
                   df_tfx_l21.aitm_measure__c, df_tfx_l21.aitm_number_of_bidders__c.cast('double'),
                   df_tfx_l21.aitm_number_of_rounds__c.cast('double'), df_tfx_l21.aitm_offered_differential_currency__c,
                   df_tfx_l21.aitm_offered_differential_uom__c, df_tfx_l21.aitm_offered_differential__c.cast('double'),
                   df_tfx_l21.aitm_position__c.cast('double'), df_tfx_l21.aitm_primary_supply__c,
                   df_tfx_l21.aitm_product__c, df_tfx_l21.aitm_quality_of_feedback__c,
                   df_tfx_l21.aitm_recalculate_total_volume__c, df_tfx_l21.aitm_round__c.cast('double'),
                   df_tfx_l21.aitm_service_level__c, df_tfx_l21.aitm_specification__c, df_tfx_l21.aitm_status__c,
                   df_tfx_l21.aitm_taxes_fees__c, df_tfx_l21.aitm_title__c,
                   df_tfx_l21.aitm_total_volume_offered_to_the_group__c.cast('double'),
                   df_tfx_l21.aitm_unit_of_measure__c, df_tfx_l21.aitm_volume__c.cast('double'),
                   df_tfx_l21.aitm_sector__c, df_tfx_l21.aitm_bids_in_by__c, df_tfx_l21.aitm_stage__c,
                   df_tfx_l21.aitm_distance_from_leading_bid1__c.cast('double'), df_tfx_l21.aitm_tender_unique_id__c,
                   df_tfx_l21.aitm_apply_to_all__c, df_tfx_l21.aitm_depe_product__c,
                   df_tfx_l21.aitm_airport_classification_ga__c, df_tfx_l21.aitm_bp_location_volume_ga__c.cast('double'),
                   df_tfx_l21.aitm_competition_ga__c, df_tfx_l21.aitm_location_segmentation_ga__c,
                   df_tfx_l21.aitm_location_strategy_ga__c, df_tfx_l21.aitm_market_classification_ga__c,
                   df_tfx_l21.aitm_overall_location_size_ga__c.cast('double'),
                   df_tfx_l21.aitm_primary_airport_supply_ga__c, df_tfx_l21.aitm_primary_product_supply_ga__c,
                   df_tfx_l21.aitm_suppliers_total_volume_ga__c.cast('double'), df_tfx_l21.infa_ext_dt.cast('date'))
        print("df_tfx_l31")
        df_tfx_l31.printSchema()

        df_tfx_l32 = df_tfx_l31.\
            select(df_tfx_l31.id, df_tfx_l31.name, df_tfx_l31.currencyisocode, df_tfx_l31.aitm_tender__c,
                   df_tfx_l31.aitm_ad_hoc_volume__c, df_tfx_l31.aitm_additional_notes__c,
                   df_tfx_l31.aitm_aircraft_type__c, df_tfx_l31.aitm_classification__c, df_tfx_l31.aitm_comments__c,
                   df_tfx_l31.aitm_competition__c, df_tfx_l31.aitm_competitor_info_other__c,
                   df_tfx_l31.aitm_competitor_info__c, df_tfx_l31.aitm_contracted__c, df_tfx_l31.aitm_country__c,
                   df_tfx_l31.aitm_current_round__c, df_tfx_l31.aitm_delivery_by__c, df_tfx_l31.aitm_delivery_method__c,
                   df_tfx_l31.aitm_density__c, df_tfx_l31.aitm_distance_from_leading_bid__c,
                   df_tfx_l31.aitm_has_feedback__c, df_tfx_l31.aitm_iata_icao__c, df_tfx_l31.aitm_iata__c,
                   df_tfx_l31.aitm_include_in_revised_offer__c, df_tfx_l31.aitm_include_notes_in_contract__c,
                   df_tfx_l31.aitm_include_taxes_fees_in_contract__c, df_tfx_l31.aitm_into_plane__c,
                   df_tfx_l31.aitm_is_current_round__c, df_tfx_l31.aitm_last_look_to_incumbent__c,
                   df_tfx_l31.aitm_leading_bid_currency__c, df_tfx_l31.aitm_leading_bid_uom__c,
                   df_tfx_l31.aitm_leading_bid__c, df_tfx_l31.aitm_location_manager__c,
                   df_tfx_l31.aitm_location_size__c, df_tfx_l31.aitm_location_summary_details_context__c,
                   df_tfx_l31.aitm_location__c, df_tfx_l31.aitm_measure__c, df_tfx_l31.aitm_number_of_bidders__c,
                   df_tfx_l31.aitm_number_of_rounds__c, df_tfx_l31.aitm_offered_differential_currency__c,
                   df_tfx_l31.aitm_offered_differential_uom__c, df_tfx_l31.aitm_offered_differential__c,
                   df_tfx_l31.aitm_position__c, df_tfx_l31.aitm_primary_supply__c, df_tfx_l31.aitm_product__c,
                   df_tfx_l31.aitm_quality_of_feedback__c, df_tfx_l31.aitm_recalculate_total_volume__c,
                   df_tfx_l31.aitm_round__c, df_tfx_l31.aitm_service_level__c, df_tfx_l31.aitm_specification__c,
                   df_tfx_l31.aitm_status__c, df_tfx_l31.aitm_taxes_fees__c, df_tfx_l31.aitm_title__c,
                   df_tfx_l31.aitm_total_volume_offered_to_the_group__c, df_tfx_l31.aitm_unit_of_measure__c,
                   df_tfx_l31.aitm_volume__c, df_tfx_l31.aitm_sector__c, df_tfx_l31.aitm_bids_in_by__c,
                   df_tfx_l31.aitm_stage__c, df_tfx_l31.aitm_distance_from_leading_bid1__c,
                   df_tfx_l31.aitm_tender_unique_id__c, df_tfx_l31.aitm_apply_to_all__c, df_tfx_l31.aitm_depe_product__c,
                   df_tfx_l31.aitm_airport_classification_ga__c, df_tfx_l31.aitm_bp_location_volume_ga__c,
                   df_tfx_l31.aitm_competition_ga__c, df_tfx_l31.aitm_location_segmentation_ga__c,
                   df_tfx_l31.aitm_location_strategy_ga__c, df_tfx_l31.aitm_market_classification_ga__c,
                   df_tfx_l31.aitm_overall_location_size_ga__c, df_tfx_l31.aitm_primary_airport_supply_ga__c,
                   df_tfx_l31.aitm_primary_product_supply_ga__c, df_tfx_l31.aitm_suppliers_total_volume_ga__c,
                   f.md5(f.concat(df_tfx_l31.id, df_tfx_l31.name, df_tfx_l31.aitm_tender__c, df_tfx_l31.aitm_country__c,
                                  df_tfx_l31.aitm_density__c, df_tfx_l31.aitm_iata__c,
                                  df_tfx_l31.aitm_location_manager__c, df_tfx_l31.aitm_product__c,
                                  df_tfx_l31.aitm_service_level__c, df_tfx_l31.aitm_title__c, df_tfx_l31.aitm_volume__c,
                                  df_tfx_l31.aitm_tender_unique_id__c)).alias('checksum'),
                   df_tfx_l31.infa_ext_dt)

        print("df_tfx_l32")
        df_tfx_l32.printSchema()

        df_tfx_result = [df_tfx_l21, df_tfx_l31, df_tfx_l32]

        return df_tfx_result


if __name__ == '__main__':
    trl = TMSalesForceETL()
    trl.execute()
