########################################################
## Blueprint example of a custom transformation
## that runs a Lambda function
#######################################################
## License: Apache 2.0
#######################################################
## Author: garetheagar
#######################################################

import boto3
import json
import time
import datetime as dt
from datalake_library.commons import init_logger
from datalake_library.configuration.resource_configs import S3Configuration


logger = init_logger(__name__)

# Create boto3 clients for SSM (parameter store) and stepfunctions
ssm = boto3.client('ssm')
sfn = boto3.client('stepfunctions')
lambda_client = boto3.client('lambda')

def datetimeconverter(o):
    if isinstance(o, dt.datetime):
        return o.__str__()

class CustomTransform():
    def __init__(self):
        logger.info("SDLF Light Transform initiated - Custom Lambda Runner")

    def transform_object(self, bucket, key, team, dataset, database):
        #######################################################
        ## We assume a custom Lambda Function has already
        ## been created based on subtenant requirements.
        ## This function makes an API call to run it
        #######################################################

        logger.info(f"Running light_transform_lambda-runner from datalake library")
        
        # Log the parameters passed to the light transform
        logger.info("Parameters received by Lambda function")
        logger.info("--------------------------------------")
        logger.info(f'team: {team}')
        logger.info(f'dataset: {dataset}')
        logger.info(f'database: {database}')
        logger.info(f'bucket: {bucket}')
        logger.info(f'key: {key}')

        # Generate the S3 paths and get environment information
        source_bucket = bucket
        target_bucket = S3Configuration().transform_bucket
        key_split = key.split("/")
        source_database = key_split[0]
        source_table = key_split[1]
        source_path = f'{source_database}/{source_table}'
        target_path = f'custom/main/{team}/{source_database}/pre_{source_table}'
        env = ssm.get_parameter(Name='/Datahub/Misc/pEnvironment')['Parameter']['Value']

        # Log the dervied parameters and paths
        logger.info("Parameters derived in Lambda function")
        logger.info("-------------------------------------")
        logger.info(f'source_bucket: {source_bucket}')
        logger.info(f'source_path: {source_path}')
        logger.info(f'source_database: {source_database}')
        logger.info(f'source_table: {source_table}')
        logger.info(f'target_bucket: {target_bucket}')
        logger.info(f'env: {env}')
        

        # Configure the input_data that will be passed to the Lambda function
        input_data = {}
        input_data['team'] = team
        input_data['dataset'] = dataset
        input_data['database'] = database
        input_data['key'] = key
        
        input_data['env'] = env
        input_data['source_bucket'] = source_bucket
        input_data['source_path'] = source_path
        input_data['source_database'] = source_database
        input_data['source_table'] = source_table
        input_data['target_bucket'] = target_bucket

        lambda_input = json.dumps(input_data)

        # The custom CFN template that created the Lambda function
        # should also have created an associated SSM parameter
        lambda_SSM_parameter = f'/Datahub/Lambda/{team}/stageA/{dataset}-custom'
        logger.info(f"lambda_SSM_parameter: {lambda_SSM_parameter}")
        lambda_arn = ssm.get_parameter(Name=lambda_SSM_parameter)['Parameter']['Value']
        logger.info(f'Calling StageA Step Function state machine with ARN: {lambda_arn}')

        # Call the custom transform Lambda sync
        lambda_response = lambda_client.invoke(FunctionName=lambda_arn,
                     InvocationType='RequestResponse',
                     Payload=lambda_input)

        print(f'Lambda response: {lambda_response}')

        response_payload = json.loads(lambda_response['Payload'].read().decode("utf-8"))

        print(f"response_payload: {response_payload}")

        # Collecting details about Lambda Function after submission
        processed_keys = []
        processed_keys = response_payload

        print(f'Processed Keys returned from custom Lambda: {processed_keys}')

        #######################################################
        ## IMPORTANT
        ## This function must return a Python list
        ## of transformed S3 paths. Example:
        ## ['pre-stage/engineering/legislators/persons_parsed.json']
        #######################################################

        return processed_keys
