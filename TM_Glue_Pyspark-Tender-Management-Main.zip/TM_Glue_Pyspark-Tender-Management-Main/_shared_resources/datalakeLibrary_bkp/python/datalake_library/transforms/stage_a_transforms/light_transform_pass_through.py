#######################################################
# Blueprint example of a custom transformation
# where a JSON file is dowloaded from RAW to /tmp
# then parsed before being re-uploaded to STAGE
#######################################################
# License: Apache 2.0
#######################################################
# Author: jaidi
#######################################################

#######################################################
# Import section
# common-pipLibrary_bkp repository can be leveraged
# to add external libraries as a layer if need be
#######################################################
import json

#######################################################
# Use S3 Interface to interact with S3 objects
# For example to download/upload them
#######################################################
from datalake_library.commons import init_logger

logger = init_logger(__name__)


class CustomTransform():
    def __init__(self):
        logger.info("S3 Blueprint Light Transform initiated")

    def transform_object(self, bucket, key, team, dataset, database):
        # IMPORTANT This stage is purely a pass through
        # Raw key will be passed to Stage B

        # IMPORTANT S3 path(s) must be stored in a list
        processed_keys = [key]
        return processed_keys
