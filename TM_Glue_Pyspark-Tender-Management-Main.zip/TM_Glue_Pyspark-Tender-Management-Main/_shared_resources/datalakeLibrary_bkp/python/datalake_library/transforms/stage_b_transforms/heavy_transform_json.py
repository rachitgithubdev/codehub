#######################################################
## Blueprint example of a custom transformation
## where a number of CSV files are dowloaded from
## Stage bucket and then submitted to a Glue Job
#######################################################
## License: Apache 2.0
#######################################################
## Author: jaidi
#######################################################

#######################################################
## Import section
## common-pipLibrary_bkp repository can be leveraged
## to add external libraries as a layer
#######################################################
import json
import datetime as dt

import boto3

from datalake_library.commons import init_logger

logger = init_logger(__name__)

# Create a client for the AWS Analytical service to use
client = boto3.client('glue')
ssm = boto3.client('ssm')

def datetimeconverter(o):
    if isinstance(o, dt.datetime):
        return o.__str__()

class CustomTransform():
    def __init__(self):
        logger.info("Glue Job Blueprint Heavy Transform initiated")

    def transform_object(self, bucket, keys, team, database, dataset):
        #######################################################
        ## We assume a Glue Job has already been created based on
        ## customer needs. This function makes an API call to start it
        #######################################################
        env = ssm.get_parameter(Name='/Datahub/Misc/pEnvironment')['Parameter']['Value']
        job_name = f'{team}-{env}-{dataset}-glue-job'
        logger.info(f'Running glue job : {job_name}')

        # Generate the S3 paths for Source data to be processed
        raw_bucket = ssm.get_parameter(Name='/Datahub/S3/RawBucket')['Parameter']['Value']
        source_key_list = []
        for key in keys:
            source_key_list.append(f's3://{raw_bucket}/{key}')

        # Generate the S3 path for Target data
        transform_bucket = ssm.get_parameter(Name='/Datahub/S3/TransformBucket')['Parameter']['Value']
        key_split = keys[0].split('/')
        database = key_split[0]
        table = key_split[1]
        processed_keys_path = f's3://{transform_bucket}/custom/main/{team}/{database}/clean_{table}/'

        # Submitting a new Glue Job
        job_response = client.start_job_run(
            JobName= job_name,
            Arguments={
                # Specify any arguments needed based on bucket and keys (e.g. input/output S3 locations)
                '--JOB_NAME': job_name,
                '--SOURCE_S3_PATH_LIST': json.dumps(source_key_list),
                '--TARGET_S3_PATH': processed_keys_path
            },
            MaxCapacity=2.0
        )
        # Collecting details about Glue Job after submission (e.g. jobRunId for Glue)
        json_data = json.loads(json.dumps(job_response, default=datetimeconverter))
        job_details = {
            "jobName" : job_name,
            "jobRunId": json_data.get('JobRunId'),
            "jobStatus": 'STARTED'
        }

        #######################################################
        ## IMPORTANT
        ## This function must return a dictionary object with at least a reference to:
        ## 1) processedKeysPath (i.e. S3 path where job outputs data without the s3://stage-bucket/ prefix)
        ## 2) jobDetails (i.e. a Dictionary holding information about the job
        ## e.g. jobName and jobId for Glue or clusterId and stepId for EMR
        ## A jobStatus key MUST be present in jobDetails as it's used to determine the status of the job) 
        ## Example: {processedKeysPath' = 'post-stage/engineering/legislators',
        ## 'jobDetails': {'jobName': 'legislators-glue-job', 'jobId': 'jr-2ds438nfinev34', 'jobStatus': 'STARTED'}}
        #######################################################
        response = {
            'processedKeysPath': processed_keys_path,
            'jobDetails': job_details
        }

        return response

    def check_job_status(self, bucket, keys, processed_keys_path, job_details):
        # This function checks the status of the currently running job
        job_response = client.get_job_run(JobName=job_details['jobName'], RunId=job_details['jobRunId'])
        json_data = json.loads(json.dumps(job_response, default=datetimeconverter))
        # IMPORTANT update the status of the job based on the job_response (e.g RUNNING, SUCCEEDED, FAILED)
        job_details['jobStatus'] = json_data.get('JobRun').get('JobRunState')

        #######################################################
        ## IMPORTANT
        ## This function must return a dictionary object with at least a reference to:
        ## 1) processedKeysPath (i.e. S3 path where job outputs data without the s3://stage-bucket/ prefix)
        ## 2) jobDetails (i.e. a Dictionary holding information about the job
        ## e.g. jobName and jobId for Glue or clusterId and stepId for EMR
        ## A jobStatus key MUST be present in jobDetails as it's used to determine the status of the job) 
        ## Example: {processedKeysPath' = 'post-stage/legislators',
        ## 'jobDetails': {'jobName': 'legislators-glue-job', 'jobId': 'jr-2ds438nfinev34', 'jobStatus': 'RUNNING'}}
        #######################################################
        response = {
            'processedKeysPath': processed_keys_path,
            'jobDetails': job_details
        }
        
        return response
