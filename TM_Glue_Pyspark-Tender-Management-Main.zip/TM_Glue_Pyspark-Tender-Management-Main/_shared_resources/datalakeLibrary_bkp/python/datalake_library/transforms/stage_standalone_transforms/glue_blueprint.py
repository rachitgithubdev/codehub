#######################################################
## Blueprint example of a custom transformation
## where a number of CSV files are dowloaded from
## Stage bucket and then submitted to a Glue Job
#######################################################
## License: Apache 2.0
#######################################################
## Author: jaidi
#######################################################

#######################################################
## Import section
## common-pipLibrary_bkp repository can be leveraged
## to add external libraries as a layer
#######################################################
import json
import datetime as dt

import boto3

from datalake_library.commons import init_logger

logger = init_logger(__name__)

# Create a client for the AWS Analytical service to use
client = boto3.client('glue')
ssm = boto3.client('ssm')

def datetimeconverter(o):
    if isinstance(o, dt.datetime):
        return o.__str__()

class CustomTransform():
    def __init__(self):
        logger.info("Standalone Glue Job Blueprint initiated")
        
    def transform_object(self, team, dataset):
        #######################################################
        ## We assume a Glue Job has already been created based on
        ## customer needs. This function makes an API call to start it
        #######################################################
        penv = ssm.get_parameter(Name='/Datahub/Misc/Environment')
        print(penv['Parameter']['Value'])
        env = penv['Parameter']['Value']
        job_name = 'lubes-{}-glue_json_conversion'.format(env)

        # Name of the Glue Job
        # lubes-dev-glue-json_conversion
        # S3 Path where Glue Job outputs processed keys
        # IMPORTANT: Build the output s3_path without the s3://stage-bucket/

        # processed_keys_path = 'post-stage/{}/{}'.format(team, dataset)
        # Submitting a new Glue Job
        job_response = client.start_job_run(
            JobName= job_name,
            MaxCapacity=2.0
        )
        # Collecting details about Glue Job after submission (e.g. jobRunId for Glue)
        json_data = json.loads(json.dumps(job_response, default=datetimeconverter))
        job_details = {
            "jobName" : job_name,
            "jobRunId": json_data.get('JobRunId'),
            "jobStatus": 'STARTED'
        }

        #######################################################
        ## IMPORTANT
        ## This function must return a dictionary object with at least a reference to:
        ## 1) processedKeysPath (i.e. S3 path where job outputs data without the s3://stage-bucket/ prefix)
        ## 2) jobDetails (i.e. a Dictionary holding information about the job
        ## e.g. jobName and jobId for Glue or clusterId and stepId for EMR
        ## A jobStatus key MUST be present in jobDetails as it's used to determine the status of the job) 
        ## Example: {processedKeysPath' = 'post-stage/engineering/legislators',
        ## 'jobDetails': {'jobName': 'legislators-glue-job', 'jobId': 'jr-2ds438nfinev34', 'jobStatus': 'STARTED'}}
        #######################################################
        response = {
            'jobDetails': job_details
        }

        return response

    def check_job_status(self, job_details):
        # This function checks the status of the currently running job
        job_response = client.get_job_run(JobName=job_details['jobName'], RunId=job_details['jobRunId'])
        json_data = json.loads(json.dumps(job_response, default=datetimeconverter))
        # IMPORTANT update the status of the job based on the job_response (e.g RUNNING, SUCCEEDED, FAILED)
        job_details['jobStatus'] = json_data.get('JobRun').get('JobRunState')

        #######################################################
        ## IMPORTANT
        ## This function must return a dictionary object with at least a reference to:
        ## 1) processedKeysPath (i.e. S3 path where job outputs data without the s3://stage-bucket/ prefix)
        ## 2) jobDetails (i.e. a Dictionary holding information about the job
        ## e.g. jobName and jobId for Glue or clusterId and stepId for EMR
        ## A jobStatus key MUST be present in jobDetails as it's used to determine the status of the job) 
        ## Example: {processedKeysPath' = 'post-stage/legislators',
        ## 'jobDetails': {'jobName': 'legislators-glue-job', 'jobId': 'jr-2ds438nfinev34', 'jobStatus': 'RUNNING'}}
        #######################################################
        response = {
            'jobDetails': job_details
        }
        
        return response
