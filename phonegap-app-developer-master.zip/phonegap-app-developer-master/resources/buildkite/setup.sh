#!/usr/bin/env bash
NODE_PATH=/Users/phonegap/.nvm/v4.2.1/bin
$NODE_PATH/node -v
echo "$ npm install"
$NODE_PATH/npm install


