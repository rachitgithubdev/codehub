package guru.learningjournal.examples.kafka.streamingaggregates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamingAggregatesApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreamingAggregatesApplication.class, args);
	}

}
