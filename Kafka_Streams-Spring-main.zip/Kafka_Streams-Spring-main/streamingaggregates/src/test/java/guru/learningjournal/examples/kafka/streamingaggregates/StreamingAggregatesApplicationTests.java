package guru.learningjournal.examples.kafka.streamingaggregates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamingAggregatesApplicationTests {

	@Test
	void contextLoads() {
	}

}
