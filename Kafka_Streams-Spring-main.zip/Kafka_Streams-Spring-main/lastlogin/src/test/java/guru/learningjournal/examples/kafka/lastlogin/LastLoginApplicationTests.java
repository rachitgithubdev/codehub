package guru.learningjournal.examples.kafka.lastlogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LastLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
