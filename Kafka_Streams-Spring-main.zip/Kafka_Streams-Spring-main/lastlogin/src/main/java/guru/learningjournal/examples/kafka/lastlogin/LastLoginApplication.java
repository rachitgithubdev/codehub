package guru.learningjournal.examples.kafka.lastlogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LastLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(LastLoginApplication.class, args);
	}

}
