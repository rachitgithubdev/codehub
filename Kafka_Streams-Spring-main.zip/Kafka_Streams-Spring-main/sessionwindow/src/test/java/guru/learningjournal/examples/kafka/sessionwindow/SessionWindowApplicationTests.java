package guru.learningjournal.examples.kafka.sessionwindow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SessionWindowApplicationTests {

	@Test
	void contextLoads() {
	}

}
