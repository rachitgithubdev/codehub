package guru.learningjournal.examples.kafka.avroposgen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvroPosGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
