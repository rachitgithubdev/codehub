package guru.learningjournal.examples.kafka.kstreamaggregate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KStreamAggregateApplication {

	public static void main(String[] args) {
		SpringApplication.run(KStreamAggregateApplication.class, args);
	}

}
