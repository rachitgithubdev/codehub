package guru.learningjournal.examples.kafka.advertclicks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvertClicksApplicationTests {

	@Test
	void contextLoads() {
	}

}
