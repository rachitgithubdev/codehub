package guru.learningjournal.examples.kafka.otpvalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtpValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtpValidationApplication.class, args);
	}

}
