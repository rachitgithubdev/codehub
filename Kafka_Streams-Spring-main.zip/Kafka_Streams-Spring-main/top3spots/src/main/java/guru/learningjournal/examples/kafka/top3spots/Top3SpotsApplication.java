package guru.learningjournal.examples.kafka.top3spots;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Top3SpotsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Top3SpotsApplication.class, args);
	}

}
