package guru.learningjournal.examples.kafka.top3spots;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Top3SpotsApplicationTests {

	@Test
	void contextLoads() {
	}

}
