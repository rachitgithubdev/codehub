package guru.learningjournal.examples.kafka.xmlbranching;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlBranchingApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmlBranchingApplication.class, args);
	}

}
