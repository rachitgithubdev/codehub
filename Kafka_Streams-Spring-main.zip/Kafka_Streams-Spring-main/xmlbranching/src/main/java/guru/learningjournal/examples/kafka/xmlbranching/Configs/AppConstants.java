package guru.learningjournal.examples.kafka.xmlbranching.Configs;

public class AppConstants {
    public static String VALID_ORDER = "ValidOrder";
    public static String PARSE_ERROR = "ParseError";
    public static String ADDRESS_ERROR = "AddressError";
}
