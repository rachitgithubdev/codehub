package guru.learningjournal.examples.kafka.jsonposfanout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonPosFanoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonPosFanoutApplication.class, args);
	}

}
