package guru.learningjournal.examples.kafka.jsonposfanout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonPosFanoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
