package guru.learningjournal.examples.kafka.hellostreams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloStreamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
