package guru.learningjournal.examples.kafka.windowcount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WindowCountApplicationTests {

	@Test
	void contextLoads() {
	}

}
