package guru.learningjournal.examples.kafka.rewards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RewardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
