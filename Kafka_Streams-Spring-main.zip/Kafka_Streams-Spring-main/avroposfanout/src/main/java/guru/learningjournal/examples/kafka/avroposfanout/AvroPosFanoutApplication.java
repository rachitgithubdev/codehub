package guru.learningjournal.examples.kafka.avroposfanout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvroPosFanoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvroPosFanoutApplication.class, args);
	}

}
