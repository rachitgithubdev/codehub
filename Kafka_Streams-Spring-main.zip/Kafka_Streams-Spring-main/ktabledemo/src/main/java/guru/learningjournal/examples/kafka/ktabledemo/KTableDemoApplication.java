package guru.learningjournal.examples.kafka.ktabledemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KTableDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(KTableDemoApplication.class, args);
	}

}
