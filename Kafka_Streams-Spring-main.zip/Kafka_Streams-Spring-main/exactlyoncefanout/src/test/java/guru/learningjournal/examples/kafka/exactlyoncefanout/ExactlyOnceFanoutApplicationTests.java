package guru.learningjournal.examples.kafka.exactlyoncefanout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExactlyOnceFanoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
