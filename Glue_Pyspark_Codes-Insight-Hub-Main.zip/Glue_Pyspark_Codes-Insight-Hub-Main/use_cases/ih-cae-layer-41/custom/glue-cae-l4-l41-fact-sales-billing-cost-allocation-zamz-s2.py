# ================================Revision History=================================================
# #
#  Change Version,  Change Author,          Change Date,    Change Component
#  0.1              Arvind Shrivastava      05-Mar-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate data l41_isp_fact_sales_billing_cost_allocation_zamz_s2
#                  into conform zone
# Author        :- Arvind Shrivastava
# Date          :- 15-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        
        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_zamz_s2"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        # generate input table list
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, 'l41_isp_fact_sales_billing_cost_allocation_s1').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l41_isp_fact_sales_billing_cost_allocation_s1',
                                                       df_table_1.count()))
        df_table_2 = self._get_table(source_database, 'l3_isp_cost_data_sec_zamz').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l3_isp_cost_data_sec_zamz',
                                                       df_table_2.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign tables from *args
        S = args[0]
        C = args[1]

        # join and filter dataframes
        df_tfx_result = S.alias('S').join(C.alias('C'), (f.col('S.country_mnmc') == f.col('C.country'))
                                          & (f.col('S.sector') == f.col('C.sector'))
                        & (f.col('S.delivery_date').between(f.col('C.start_date'), f.col('C.end_date'))),'left') \
                .filter((f.col('S.country_mnmc') == 'MZ') | (f.col('S.country_mnmc') == 'ZA')) \
            .select(f.col('S.*'),
                    (f.col('S.ugl') * (f.coalesce(f.col('C.adj_rate'), f.lit(0)) / f.col('lre_exch_rate'))).alias('lcl_adj_val'),
                    (f.col('S.ugl') * (f.coalesce(f.col('C.cop_rate'), f.lit(0)) / f.col('lre_exch_rate'))).alias('lcl_cop_val'),
                    f.lit(0).cast('double').alias('lcl_lag_val'),
                    f.lit(0).cast('double').alias('lcl_cso_val'),
                    (f.col('S.ugl') * (f.coalesce(f.col('C.oic_rate'), f.lit(0)) / f.col('lre_exch_rate'))).alias('lcl_oic_val'),
                    (f.col('S.ugl') * (f.coalesce(f.col('C.oaf_rate'), f.lit(0)) / f.col('lre_exch_rate'))).alias('lcl_oaf_val'),
                    (f.col('S.ugl') * (f.coalesce(f.col('C.oav_rate'), f.lit(0)) / f.col('lre_exch_rate'))).alias('lcl_oav_val'),
                    (f.col('S.ugl') * (f.coalesce(f.col('C.paf_rate'), f.lit(0)) / f.col('lre_exch_rate'))).alias('lcl_paf_val'),
                    (f.col('S.ugl') * (f.coalesce(f.col('C.pav_rate'), f.lit(0)) / f.col('lre_exch_rate'))).alias('lcl_pav_val'),
                    (f.col('S.ugl') * f.coalesce(f.col('C.adj_rate'), f.lit(0))).alias('usd_adj_val'),
                    (f.col('S.ugl') * f.coalesce(f.col('C.cop_rate'), f.lit(0))).alias('usd_cop_val'),
                    f.lit(0).cast('double').alias('usd_lag_val'),
                    f.lit(0).cast('double').alias('usd_cso_val'),
                    (f.col('S.ugl') * f.coalesce(f.col('C.oic_rate'), f.lit(0))).alias('usd_oic_val'),
                    (f.col('S.ugl') * f.coalesce(f.col('C.oaf_rate'), f.lit(0))).alias('usd_oaf_val'),
                    (f.col('S.ugl') * f.coalesce(f.col('C.oav_rate'), f.lit(0))).alias('usd_oav_val'),
                    (f.col('S.ugl') * f.coalesce(f.col('C.paf_rate'), f.lit(0))).alias('usd_paf_val'),
                    (f.col('S.ugl') * f.coalesce(f.col('C.pav_rate'), f.lit(0))).alias('usd_pav_val')
                    )

        # print("df_tfx_result", df_tfx_result.count())

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()