# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    05-Mar-2021     Initial version
#  0.2              Tingting Wan    26-May-2021     Change Logs
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_tr_s2
#                  into conform zone
# Author        :- Tingting Wan
# Date          :- 05-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================

        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_tr_s2"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(self.source_database, 'l41_isp_fact_sales_billing_cost_allocation_s1').toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, 'l41_isp_fact_sales_billing_cost_allocation_s1',
        #                                               df_table_1.count()))
        df_table_2 = self._get_table(self.source_database, 'l3_isp_other_income_tr').toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, 'l3_isp_other_income_tr',
        #                                               df_table_2.count()))
        df_table_3 = self._get_table(self.source_database, 'l3_isp_cost_data_tr').toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, 'l3_isp_cost_data_tr',
        #                                               df_table_3.count()))

        # apply transformation on the dataframe argument passed(dataframe)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2, df_table_3)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign tables and select only TR country_mnmc
        df_table_S = args[0].filter(f.col('country_mnmc') == 'TR').cache()
        df_table_oic_tr = args[1]
        df_table_cst_tr = args[2]

        # Create MC and MV tables
        df_table_MC = df_table_cst_tr.groupBy(
            f.col('airport'), f.col('period')
        ) \
            .agg(
            f.sum(f.col('cogs')).alias('cogs')
        ).select(
            f.col('airport'),
            f.col('period'),
            f.col('cogs')
        )

        df_table_MV = df_table_S.filter(f.col('delivery_date') <= f.col('cop_last_loaded_date')) \
            .groupBy(
            f.col('airport_mnmc'), f.last_day(f.col('delivery_date')).alias('period')
        ) \
            .agg(
            f.sum(f.col('litres')).alias('litres_tot')
        ).select(
            f.col('airport_mnmc'),
            f.col('period'),
            f.col('litres_tot')
        )

        # Create AC and AV tables
        df_table_AC = df_table_cst_tr.groupBy(
            f.col('airport'), f.year(f.col('period')).alias('del_year')
        ) \
            .agg(
            f.sum(f.col('oic')).alias('oic'),
            f.sum(f.col('oav')).alias('oav'),
            f.sum(f.col('oaf')).alias('oaf'),
            f.sum(f.col('pav')).alias('pav'),
            f.sum(f.col('paf')).alias('paf')
        ).select(
            f.col('airport'),
            f.col('del_year'),
            f.col('oic'), f.col('oav'), f.col('oaf'), f.col('pav'), f.col('paf')
        )

        df_table_AV = df_table_S.filter(f.col('delivery_date') <= f.col('apc_last_loaded_date')) \
            .groupBy(
            f.col('airport_mnmc'), f.year(f.col('delivery_date')).alias('del_year')
        ) \
            .agg(
            f.sum(f.col('litres')).alias('litres_tot')
        ).select(
            f.col('airport_mnmc'),
            f.col('del_year'),
            f.col('litres_tot')
        )

        # Create SC and SV tables
        df_table_SC = df_table_oic_tr.groupBy(
            f.col('sector'), f.year(f.col('period')).alias('del_year')
        ) \
            .agg(
            f.sum(f.col('oic')).alias('oic')
        ).select(
            f.col('sector'),
            f.col('del_year'),
            f.col('oic')
        )

        df_table_SV = df_table_S.filter(f.col('delivery_date') <= f.col('apc_last_loaded_date')) \
            .groupBy(
            f.col('sector'), f.year(f.col('delivery_date')).alias('del_year')
        ) \
            .agg(
            f.sum(f.col('litres')).alias('litres_tot')
        ).select(
            f.col('sector'),
            f.col('del_year'),
            f.col('litres_tot')
        )
        print('finished SV')
        # join and filter dataframes
        df_union1 = df_table_S.alias('S').join(df_table_MC.alias('MC'),
                                               (f.col('S.airport_mnmc') == f.col('MC.airport'))
                                               & (f.last_day(f.col('S.delivery_date')) == f.col('MC.period')),
                                               'left') \
            .join(df_table_MV.alias('MV'),
                  (f.col('S.airport_mnmc') == f.col('MV.airport_mnmc'))
                  & (f.last_day(f.col('S.delivery_date')) == f.col('MV.period')),
                  'left') \
            .join(df_table_AC.alias('AC'),
                  (f.col('S.airport_mnmc') == f.col('AC.airport'))
                  & (f.year(f.col('S.delivery_date')) == f.col('AC.del_year')),
                  'left') \
            .join(df_table_AV.alias('AV'),
                  (f.col('S.airport_mnmc') == f.col('AV.airport_mnmc'))
                  & (f.year(f.col('S.delivery_date')) == f.col('AV.del_year')),
                  'left') \
            .join(df_table_SC.alias('SC'), (f.col('S.sector') == f.col('SC.sector'))
                  & (f.year(f.col('S.delivery_date')) == f.col('SC.del_year')),
                  'left') \
            .join(df_table_SV.alias('SV'), (f.col('S.sector') == f.col('SV.sector'))
                  & (f.year(f.col('S.delivery_date')) == f.col('SV.del_year')),
                  'left') \
            .filter(f.col('S.delivery_date') <= f.col('S.apc_last_loaded_date')) \
            .select(f.col('S.*'),
                    f.lit(0).cast('double').alias('lcl_adj_val'),
                    f.when(f.abs(f.col('MV.litres_tot')).cast('int') > 0,
                           f.coalesce(f.col('MC.cogs'), f.lit(0)) * (f.col('S.litres') / f.col('MV.litres_tot')))
                    .otherwise(f.lit(0)).alias('lcl_cop_val'),
                    f.lit(0).cast('double').alias('lcl_lag_val'),
                    f.lit(0).cast('double').alias('lcl_cso_val'),
                    ((f.when(f.abs(f.col('AV.litres_tot')).cast('int') > 0,
                             f.coalesce(f.col('AC.oic'), f.lit(0)) * (f.col('S.litres') / f.col('AV.litres_tot')))
                      .otherwise(f.lit(0))) +
                     (f.when(f.abs(f.col('SV.litres_tot')).cast('int') > 0,
                             f.coalesce(f.col('SC.oic'), f.lit(0)) * (f.col('S.litres') / f.col('SV.litres_tot')))
                      .otherwise(f.lit(0)))).alias('lcl_oic_val'),
                    f.when(f.abs(f.col('AV.litres_tot')).cast('int') > 0,
                           f.coalesce(f.col('AC.oav'), f.lit(0)) * (f.col('S.litres') / f.col('AV.litres_tot')))
                    .otherwise(f.lit(0)).alias('lcl_oav_val'),
                    f.when(f.abs(f.col('AV.litres_tot')).cast('int') > 0,
                           f.coalesce(f.col('AC.oaf'), f.lit(0)) * (f.col('S.litres') / f.col('AV.litres_tot')))
                    .otherwise(f.lit(0)).alias('lcl_oaf_val'),
                    f.when(f.abs(f.col('AV.litres_tot')).cast('int') > 0,
                           f.coalesce(f.col('AC.pav'), f.lit(0)) * (f.col('S.litres') / f.col('AV.litres_tot')))
                    .otherwise(f.lit(0)).alias('lcl_pav_val'),
                    f.when(f.abs(f.col('AV.litres_tot')).cast('int') > 0,
                           f.coalesce(f.col('AC.paf'), f.lit(0)) * (f.col('S.litres') / f.col('AV.litres_tot')))
                    .otherwise(f.lit(0)).alias('lcl_paf_val'),
                    f.lit(0).cast('double').alias('usd_adj_val'),
                    f.when(f.abs(f.col('MV.litres_tot')).cast('int') > 0,
                           (f.coalesce(f.col('MC.cogs'), f.lit(0)) * f.col('S.lre_exch_rate')) * (
                                   f.col('S.litres') / f.col('MV.litres_tot')))
                    .otherwise(f.lit(0)).alias('usd_cop_val'),
                    f.lit(0).cast('double').alias('usd_lag_val'),
                    f.lit(0).cast('double').alias('usd_cso_val'),
                    ((f.when(f.abs(f.col('AV.litres_tot')).cast('int') > 0,
                             (f.coalesce(f.col('AC.oic'), f.lit(0)) * f.col('S.lre_exch_rate')) * (
                                     f.col('S.litres') / f.col('AV.litres_tot')))
                      .otherwise(f.lit(0))) +
                     (f.when(f.abs(f.col('SV.litres_tot')).cast('int') > 0,
                             (f.coalesce(f.col('SC.oic'), f.lit(0)) * f.col('S.lre_exch_rate')) * (
                                     f.col('S.litres') / f.col('SV.litres_tot')))
                      .otherwise(f.lit(0)))).alias('usd_oic_val'),
                    f.when(f.abs(f.col('AV.litres_tot')).cast('int') > 0,
                           (f.coalesce(f.col('AC.oav'), f.lit(0)) * f.col('S.lre_exch_rate')) * (
                                   f.col('S.litres') / f.col('AV.litres_tot')))
                    .otherwise(f.lit(0)).alias('usd_oav_val'),
                    f.when(f.abs(f.col('AV.litres_tot')).cast('int') > 0,
                           (f.coalesce(f.col('AC.oaf'), f.lit(0)) * f.col('S.lre_exch_rate')) * (
                                   f.col('S.litres') / f.col('AV.litres_tot')))
                    .otherwise(f.lit(0)).alias('usd_oaf_val'),
                    f.when(f.abs(f.col('AV.litres_tot')).cast('int') > 0,
                           (f.coalesce(f.col('AC.pav'), f.lit(0)) * f.col('S.lre_exch_rate')) * (
                                   f.col('S.litres') / f.col('AV.litres_tot')))
                    .otherwise(f.lit(0)).alias('usd_pav_val'),
                    f.when(f.abs(f.col('AV.litres_tot')).cast('int') > 0,
                           (f.coalesce(f.col('AC.paf'), f.lit(0)) * f.col('S.lre_exch_rate')) * (
                                   f.col('S.litres') / f.col('AV.litres_tot')))
                    .otherwise(f.lit(0)).alias('usd_paf_val')
                    )

        # join and filter dataframes
        df_union2 = df_table_S.filter(f.col('delivery_date') > f.col('apc_last_loaded_date')) \
            .select(f.col('*'),
                    f.lit(0).cast('double').alias('lcl_adj_val'),
                    f.lit(0).cast('double').alias('lcl_cop_val'),
                    f.lit(0).cast('double').alias('lcl_lag_val'),
                    f.lit(0).cast('double').alias('lcl_cso_val'),
                    f.lit(0).cast('double').alias('lcl_oic_val'),
                    f.lit(0).cast('double').alias('lcl_oaf_val'),
                    f.lit(0).cast('double').alias('lcl_oav_val'),
                    f.lit(0).cast('double').alias('lcl_paf_val'),
                    f.lit(0).cast('double').alias('lcl_pav_val'),
                    f.lit(0).cast('double').alias('usd_adj_val'),
                    f.lit(0).cast('double').alias('usd_cop_val'),
                    f.lit(0).cast('double').alias('usd_lag_val'),
                    f.lit(0).cast('double').alias('usd_cso_val'),
                    f.lit(0).cast('double').alias('usd_oic_val'),
                    f.lit(0).cast('double').alias('usd_oav_val'),
                    f.lit(0).cast('double').alias('usd_oaf_val'),
                    f.lit(0).cast('double').alias('usd_pav_val'),
                    f.lit(0).cast('double').alias('usd_paf_val')

                    )

        # union All tables
        df_tfx_result = df_union1.unionAll(df_union2)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()

