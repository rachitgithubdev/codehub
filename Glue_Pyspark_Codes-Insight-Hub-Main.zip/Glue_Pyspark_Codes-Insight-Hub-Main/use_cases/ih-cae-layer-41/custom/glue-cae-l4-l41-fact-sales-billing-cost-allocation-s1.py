# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      23-Apr-2021     Initial version
#  0.2              Tingting Wan    26-May-2021     Change Logs
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_s1
#                  into conform zone
# Author        :- Liz Harvey
# Date          :- 23-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================

        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_s1"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        # generate input table list
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, 'l4_isp_fact_sales_billing').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l4_isp_fact_sales_billing',
        #                                               df_table_1.count()))
        df_table_2 = self._get_table(source_database, 'l3_isp_imi_prod_grps_man').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_isp_imi_prod_grps_man',
        #                                               df_table_2.count()))
        df_table_3 = self._get_table(source_database, 'l3_isp_iop_line_all').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_isp_iop_line_all',
        #                                               df_table_3.count()))
        df_table_4 = self._get_table(source_database, 'l3_isp_inv_sales_line_all').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_isp_inv_sales_line_all',
        #                                               df_table_4.count()))
        df_table_5 = self._get_table(source_database, 'l3_isp_fuel_point_all').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_isp_fuel_point_all',
        #                                               df_table_5.count()))
        df_table_6 = self._get_table(source_database, 'l4_isp_dim_location').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l4_isp_dim_location',
        #                                               df_table_6.count()))
        df_table_7 = self._get_table(source_database, 'l4_location_mapping_isp').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l4_location_mapping_isp',
        #                                               df_table_7.count()))
        df_table_8 = self._get_table(source_database, 'l4_dim_location').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l4_dim_location',
        #                                               df_table_8.count()))
        df_table_9 = self._get_table(source_database, 'l4_isp_dim_customer').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l4_isp_dim_customer',
        #                                               df_table_9.count()))
        df_table_10 = self._get_table(source_database, 'l5_ytd_xrates_all').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l5_ytd_xrates_all',
        #                                               df_table_10.count()))
        df_table_11 = self._get_table(source_database, 'l3_isp_dim_cost_loaded_date').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_isp_dim_cost_loaded_date',
        #                                               df_table_11.count()))
        df_table_12 = self._get_table(source_database, 'l4_sun_fact_sales_billing').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l4_sun_fact_sales_billing',
        #                                               df_table_12.count()))
        df_table_13 = self._get_table(source_database, 'l4_sun_dim_customer').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l4_sun_dim_customer',
        #                                               df_table_13.count()))
        df_table_14 = self._get_table(source_database, 'l4_location_mapping_sun').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l4_location_mapping_sun',
        #                                               df_table_14.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2, df_table_3, df_table_4, df_table_5, df_table_6,
                                       df_table_7, df_table_8, df_table_9, df_table_10, df_table_11, df_table_12,
                                       df_table_13, df_table_14)
        #print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # Assign tables from arguements
        # l4_isp_fact_sales_billing
        FSB = args[0].cache()
        # l31_isp_imi_prod_grps_man
        IPG = args[1]
        # l31_isp_iop_line_all
        IPL = args[2]
        # l31_isp_inv_sales_line_all
        ISL = args[3]
        # l31_isp_fuel_point_all
        IFP = args[4]
        # l4_isp_dim_location
        LOC = args[5]
        # l4_location_mapping_isp
        LMI = args[6]
        # l4_dim_location
        SEM = args[7].cache()
        # l4_isp_dim_customer
        CUS = args[8]
        # CUS.printSchema()

        # l5_ytd_xrates_all
        LLRE = args[9].cache()
        # create LLREM from l5_ytd_xrates_all
        LLREM = LLRE.groupby(f.col('from_cur_mnmc'), f.col('to_cur_mnmc'),
                             f.year(f.col('start_date')).alias('exrt_year')) \
            .agg(f.max(f.col('start_date')).alias('max_date')) \
            .select(
            f.col('from_cur_mnmc'), f.col('to_cur_mnmc'), f.col('exrt_year'), f.col('max_date')
        )

        # l3_isp_dim_cost_loaded_date
        table_loaded_data = args[10].cache()

        # join and filter dataframes
        df_union1 = FSB.join(IPG, FSB.material_mnmc == IPG.product, 'left') \
            .join(IPL, (f.split(FSB.ref_id, '_').getItem(2) == IPL.inv_id)
                  & (f.split(FSB.ref_id, '_').getItem(3) == IPL.item_num)
                  & (f.split(FSB.ref_id, '_').getItem(4) == IPL.item_seq_num)
                  & (FSB.source_system == IPL.source_system), 'left') \
            .join(ISL, (IPL.inv_id == ISL.inv_sales_id)
                  & (IPL.inv_seq_num == ISL.seq_num)
                  & (FSB.source_system == ISL.source_system)
                  , 'left') \
            .join(IFP, ISL.fk_fuel_point_id == IFP.ref_id, 'left') \
            .join(LOC, FSB.plant == LOC.ref_id, 'left') \
            .join(LMI, f.split(FSB.plant, '_').getItem(2) == LMI.isp_mapping, 'left') \
            .join(SEM, LMI.location_id == SEM.locationid, 'left') \
            .join(CUS, FSB.shipto_party == CUS.ref_isp_id, 'left') \
            .join(LLRE, (LLRE.from_cur_mnmc == 'USD')
                  & (LLRE.to_cur_mnmc == f.when(FSB.local_currency == 'YTL', f.lit('TRY'))
                     .otherwise(FSB.local_currency))
                  & (f.year(LLRE.start_date) == f.year(FSB.delivery_date)), 'left') \
            .join(LLREM, (LLREM.from_cur_mnmc == LLRE.from_cur_mnmc)
                  & (LLREM.to_cur_mnmc == LLRE.to_cur_mnmc)
                  & (LLREM.exrt_year == f.year(LLRE.start_date))
                  & (LLREM.max_date == LLRE.start_date), 'inner') \
            .join(table_loaded_data.alias('CLD'), (FSB.country == f.col('CLD.country_mnmc'))
                  & (f.col('CLD.cost_type').isin('COP', 'ALL')), 'left') \
            .join(table_loaded_data.alias('ALD'), (FSB.country == f.col('ALD.country_mnmc'))
                  & (f.col('ALD.cost_type').isin('APC', 'ALL')), 'left') \
            .filter(
            (FSB.country.isin('AE', 'AL', 'BH', 'CH', 'CY', 'EG', 'FR', 'GB', 'GR', 'HR', 'IE', 'IT', 'LB', 'MZ',
                              'RO', 'TN', 'TR', 'ZA'))
            & (f.year(FSB.delivery_date) >= 2018)) \
            .select(
            FSB.ref_id,
            FSB.billing_document,
            FSB.billing_item,
            FSB.source_system,
            f.when(FSB.country == 'TN', f.lit('EG'))
                .otherwise(FSB.country).alias('country_mnmc'),
            f.when(FSB.shipto_party == 'ISP_ESP0762_7620000110464', f.lit('Commercial Airlines'))
                .when(FSB.shipto_party == 'ISP_ESP0762_5250274606412', f.lit('General Aviation'))
                .when(FSB.shipto_party == 'ISP_ESP0762_5250012313042', f.lit('General Aviation'))
                .when(FSB.shipto_party == 'ISP_ESP0762_5250265710387', f.lit('General Aviation'))
                .when(FSB.shipto_party == 'ISP_ESP0762_5250155225173', f.lit('General Aviation'))
                .when(FSB.shipto_party == 'ISP_ESP0762_5250149303851', f.lit('General Aviation'))
                .when(FSB.shipto_party == 'ISP_ESP0762_5250104341580', f.lit('General Aviation'))
                .otherwise(CUS.sector).alias('sector'),
            FSB.sales_organisation,
            IPG.product_grp_1.alias('prod_grp'),
            FSB.item_category,
            FSB.material_number,
            FSB.material_mnmc,
            SEM.locationid.cast('string').alias('sem_loc_id'),
            SEM.location_name.cast('string').alias('sem_loc_name'),
            LOC.ref_id.alias('airport_id'),
            f.when(LOC.plant == 'IST', f.lit('ISL'))
                .otherwise(LOC.plant).alias('airport_mnmc'),

            LOC.location_name.alias('airport_name'),
            FSB.plant,
            f.lit(None).cast('string').alias('sun_plant_mnmc'),
            FSB.location_of_sale,
            FSB.shipto_party.alias('customer_id'),
            CUS.grn.alias('customer_number'),
            CUS.grn_header.alias('customer_header'),
            CUS.customer_account_name.alias('customer_name'),
            f.when(FSB.country.isNull(), f.lit('N'))
                .when(FSB.country == CUS.customer_country_key, f.lit('N'))
                .otherwise(f.lit('Y')).alias('int_customer_ind'),
            f.when((FSB.country == 'GB') & (IFP.mnmc == 'F0898'), f.lit('H2211'))
                .otherwise(IFP.mnmc).alias('fuel_point_mnmc'),
            IFP.name.alias('fuel_point_name'),
            FSB.delivery_date,
            FSB.billing_date,
            f.col('CLD.last_loaded_date').alias('cop_last_loaded_date'),
            f.col('ALD.last_loaded_date').alias('apc_last_loaded_date'),
            FSB.m3, FSB.ugl, FSB.litres,
            FSB.metric_tons, FSB.std_volume, FSB.document_currency, FSB.local_currency,
            FSB.ile_exchange_rate.alias('exchange_rate'),
            f.coalesce(FSB.ile_exchange_rate, f.lit(0)).alias('ile_exch_rate'),
            f.coalesce(1 / LLRE.ytd_exch_rate, f.lit(0)).alias('lre_exch_rate'),
            FSB.net_value,
            (f.coalesce(FSB.net_value, f.lit(0)) * f.coalesce(FSB.ile_exchange_rate, f.lit(0))).alias('lcl_net_val'),
            (f.coalesce(FSB.net_value, f.lit(0)) * f.coalesce(FSB.ile_exchange_rate, f.lit(0)) * f.coalesce(
                1 / LLRE.ytd_exch_rate, f.lit(0))).alias('usd_net_val')
        )
        print('df_union1 finished')

        # Union All table - SUN tables
        # l4_sun_fact_sales_billing,l4_sun_dim_customer, l4_location_mapping_sun
        SUN_FSB = args[11].cache()
        SUN_CUS = args[12].cache()
        SUN_LMS = args[13].cache()
        w = Window.partitionBy("location_id").orderBy(f.col("isp_mapping"))

        SUN_LMI = LMI.withColumn('tiebreak', f.monotonically_increasing_id()) \
            .withColumn('rank', f.rank().over(w)) \
            .withColumn("join_cond", f.concat(f.lit('ISP_ESP0721_'), LMI.isp_mapping)) \
            .filter(f.col('rank') == 1).drop('rank', 'tiebreak')

        # SUN_LMI = LMI.groupby(f.col('location_id')) \
        #     .agg(f.first(f.col('isp_mapping')).alias('isp_mapping')) \
        #     .select(f.col('location_id'), f.col('isp_mapping'))

        df_union2 = SUN_FSB.join(SUN_CUS, SUN_FSB.shipto_party == SUN_CUS.ref_erp_id, 'left') \
            .join(SUN_LMS, (SUN_FSB.plant == SUN_LMS.sun_mapping)
                  & (SUN_FSB.country == SUN_LMS.iso_code2), 'left') \
            .join(SEM, SUN_LMS.location_id == SEM.locationid, 'left') \
            .join(SUN_LMI, SEM.locationid == SUN_LMI.location_id, 'left') \
            .join(LOC, (SUN_LMI.join_cond == LOC.ref_id)
                  & (SUN_FSB.country == LOC.country_iso2), 'left') \
            .join(LLRE, (LLRE.from_cur_mnmc == 'USD')
                  & (LLRE.to_cur_mnmc == f.when(SUN_FSB.local_currency == 'YTL', f.lit('TRY'))
                     .otherwise(SUN_FSB.local_currency))
                  & (f.year(LLRE.start_date) == f.year(SUN_FSB.delivery_date)), 'left') \
            .join(LLREM, (LLREM.from_cur_mnmc == LLRE.from_cur_mnmc)
                  & (LLREM.to_cur_mnmc == LLRE.to_cur_mnmc)
                  & (LLREM.exrt_year == f.year(LLRE.start_date))
                  & (LLREM.max_date == LLRE.start_date), 'inner') \
            .join(table_loaded_data.alias('CLD'), (SUN_FSB.country == f.col('CLD.country_mnmc'))
                  & (f.col('CLD.cost_type').isin('COP', 'ALL')), 'left') \
            .join(table_loaded_data.alias('ALD'), (SUN_FSB.country == f.col('ALD.country_mnmc'))
                  & (f.col('ALD.cost_type').isin('APC', 'ALL')), 'left') \
            .filter(f.year(SUN_FSB.delivery_date) >= 2018) \
            .select(
            SUN_FSB.ref_id,
            SUN_FSB.billing_document,
            SUN_FSB.billing_item,
            SUN_FSB.source_system,
            SUN_FSB.country.alias('country_mnmc'),
            SUN_CUS.sector.alias('sector'),
            SUN_FSB.sales_organisation,
            SUN_FSB.product_group_1.alias('prod_grp'),
            (f.when(f.substring(SUN_FSB.material_number, 1, 3) == 'A08', f.lit(1))
             .otherwise(f.lit(4))).alias('item_category'),
            SUN_FSB.material_number,
            SUN_FSB.material_mnmc,
            SEM.locationid.alias('sem_loc_id'),
            SEM.location_name.alias('sem_loc_name'),
            LOC.ref_id.alias('airport_id'),
            LOC.plant.alias('airport_mnmc'),
            LOC.location_name.alias('airport_name'),
            SUN_FSB.plant,
            SUN_FSB.plant.alias('sun_plant_mnmc'),
            f.lit(None).cast('string').alias('location_of_sale'),
            SUN_FSB.shipto_party.alias('customer_id'),
            SUN_CUS.grn.alias('customer_number'),
            SUN_CUS.grn_header.alias('customer_header'),
            SUN_CUS.customer_account_name.alias('customer_name'),
            f.when(SUN_FSB.country.isNull(), f.lit('N'))
                .when(SUN_FSB.country == SUN_CUS.customer_country_key, f.lit('N'))
                .otherwise(f.lit('Y')).alias('int_customer_ind'),
            f.lit(None).cast('string').alias('fuel_point_mnmc'),
            SUN_FSB.fuel_point_name,
            SUN_FSB.delivery_date,
            SUN_FSB.billing_date,
            f.col('CLD.last_loaded_date').alias('cop_last_loaded_date'),
            f.col('ALD.last_loaded_date').alias('apc_last_loaded_date'),
            SUN_FSB.m3,
            SUN_FSB.ugl,
            SUN_FSB.litres,
            SUN_FSB.metric_tons,
            f.lit(0).cast('double').alias('std_volume'),
            SUN_FSB.document_currency,
            SUN_FSB.local_currency,
            f.coalesce(SUN_FSB.ile_exchange_rate, f.lit(0)).alias('exchange_rate'),
            f.coalesce(SUN_FSB.ile_exchange_rate, f.lit(0)).alias('ile_exch_rate'),
            f.coalesce(LLRE.ytd_exch_rate, f.lit(0)).alias('lre_exch_rate'),
            SUN_FSB.net_value,
            (f.coalesce(SUN_FSB.net_value, f.lit(0)) * f.coalesce(SUN_FSB.ile_exchange_rate, f.lit(0))).alias(
                'lcl_net_val'),
            (f.coalesce(SUN_FSB.net_value, f.lit(0)) * f.coalesce(SUN_FSB.ile_exchange_rate, f.lit(0)) * f.coalesce(
                1 / LLRE.ytd_exch_rate, f.lit(0))).alias('usd_net_val')

        )
        print('df_union2 finished')
        df_tfx_result = df_union1.unionAll(df_union2)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()



