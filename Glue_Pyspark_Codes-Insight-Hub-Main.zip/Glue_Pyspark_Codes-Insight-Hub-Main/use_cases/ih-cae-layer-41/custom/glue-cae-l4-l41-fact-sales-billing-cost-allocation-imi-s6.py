# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    11-Feb-2021     Initial version
#  0.2              Tingting Wan    26-May-2021     Change log - left join A and L
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_imi_s6
#                  into conform zone
# Author        :- Tingting Wan
# Date          :- 11-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================

        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_imi_s6"

        # print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
        #                                                                  self.destination_bucket))

    def execute(self):
        # generate input table list
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, 'l41_isp_fact_sales_billing_cost_allocation_imi_s5').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l41_isp_fact_sales_billing_cost_allocation_imi_s5',
        #                                                df_table_1.count()))
        df_table_2 = self._get_table(source_database, 'l3_isp_imi_cop_cso_add_all').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_isp_imi_cop_cso_add_all',
        #                                                df_table_2.count()))
        df_table_3 = self._get_table(source_database, 'l3_isp_cop_lag_data_uk').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_isp_cop_lag_data_uk',
        #                                                df_table_3.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2, df_table_3)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # convert all the columns alias to lower case
        S = args[0].cache()
        C = args[1]
        L = args[2]

        # Create table A
        A = S.filter((f.col('country_mnmc') == 'GB')
                     & (((f.year(f.col('delivery_date')) * 100) + f.month(f.col('delivery_date'))) > 201799))\
            .groupby(f.col('airport_mnmc'), f.col('prod_grp'), f.col('customer_number'), f.col('fuel_point_mnmc'),
                         ((f.year(f.col('delivery_date')) * 100) + f.month(f.col('delivery_date'))).alias(
                             'delivery_month')) \
            .agg(f.sum(f.col('litres')).alias('total_liters')) \
            .select(f.col('airport_mnmc'), f.col('prod_grp'), f.col('customer_number'),
                    f.col('fuel_point_mnmc'), f.col('delivery_month'), f.col('total_liters'))

        # create new columns
        # join and filter dataframes
        df_tfx_result = S.alias('S').join(C, (f.col('S.country_mnmc') == C.country)
                                          & (f.col('S.sector') == C.sector)
                                          & (f.col('S.prod_grp') == C.prod_grp)
                                          & (f.col('S.delivery_date').between(C.start_date, C.end_date)),
                                          'left') \
            .join(A.alias('A'), (f.col('A.airport_mnmc') == f.col('S.airport_mnmc'))
                  & (f.col('A.prod_grp') == f.col('S.prod_grp'))
                  & (f.col('A.customer_number') == f.col('S.customer_number'))
                  & (f.col('A.fuel_point_mnmc') == f.col('S.fuel_point_mnmc'))
                  & (((f.year(f.col('S.delivery_date')) * 100) + f.month(f.col('S.delivery_date'))) == f.col(
            'A.delivery_month'))
                  & (f.col('S.country_mnmc') == 'GB'),
                  'left') \
            .join(L.alias('L'), (f.col('L.iata_code') == f.col('S.airport_mnmc'))
                  & (f.col('L.product_group') == f.col('S.prod_grp'))
                  & (f.col('L.customer_grn') == f.col('S.customer_number'))
                  & (f.col('L.fuel_point') == f.col('S.fuel_point_mnmc'))
                  & (((f.year(f.col('S.delivery_date')) * 100) + f.month(f.col('S.delivery_date'))) == f.col(
            'L.delivery_month'))
                  & (f.col('S.country_mnmc') == 'GB'),
                  'left') \
            .filter(f.col('S.country_mnmc') != 'AL') \
            .select(f.col('S.*'),
                    f.lit(0).cast('double').alias('lcl_adj_val'),
                    f.coalesce(f.col('S.litres') * f.col('S.cop_rate'), f.lit(0)).alias('lcl_cop_val'),
                    f.col('L.usd_lag_value'),
                    f.when(f.col('S.country_mnmc') == 'GB', (
                    (f.col('L.usd_lag_value') * (f.col('S.litres') / f.col('A.total_liters'))) * (-1)))
                    .otherwise(f.lit(0).cast('double')).alias('lcl_lag_val'),
                    f.coalesce(f.col('S.litres') * C.lcl_cso_add, f.lit(0)).alias('lcl_cso_val'),
                    f.coalesce(f.col('S.litres') * f.col('S.oic_rate'), f.lit(0)).alias('lcl_oic_val'),
                    f.coalesce(f.col('S.litres') * f.col('S.oaf_rate'), f.lit(0)).alias('lcl_oaf_val'),
                    f.coalesce(f.col('S.litres') * f.col('S.oav_rate'), f.lit(0)).alias('lcl_oav_val'),
                    f.coalesce(f.col('S.litres') * f.col('S.paf_rate'), f.lit(0)).alias('lcl_paf_val'),
                    f.coalesce(f.col('S.litres') * f.col('S.pav_rate'), f.lit(0)).alias('lcl_pav_val')

        )


        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()

