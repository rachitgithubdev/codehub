# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      16-Jun-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_imi_s2
#                  into conform zone
# Author        :- Bakul Seth
# Date          :- 16-Jun-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = 'l41_isp_fact_sales_billing_cost_allocation_s1, l3_isp_imi_cost_data_add_all'
        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_imi_s2"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
                                                                         self.destination_bucket))

    def execute(self):
        # generate input table list
        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(self.source_database, self.input_table_list[0]).toDF()
        print("Schema of table {}.{} is ".format(self.source_database, self.input_table_list[0]))
        df_table_1.printSchema()

        df_table_2 = self._get_table(self.source_database, self.input_table_list[1]).toDF()
        print("Schema of table {}.{} is ".format(self.source_database, self.input_table_list[1]))
        df_table_2.printSchema()

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('Applying the transformations')
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2)
        print("Schema after transformation ")
        df_tfx_table.printSchema()

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('Reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):

        # assign tables
        s1 = args[0]

        imi_cost = args[1].cache()

        # join and filter dataframes
        df_tfx_result = s1.alias('s1').join(imi_cost.alias('dcop'), (f.col('dcop.cost_type') == "COP_RATE")
                                          & (f.col('s1.prod_grp') == f.col('dcop.prod_grp'))
                                          & (f.col('dcop.sector') == "Default")
                                          & (f.col('s1.country_mnmc') == f.col('dcop.cty_mnmc'))
                                          & (f.col('dcop.airport').isNull())
                                          & (f.col('dcop.fuel_point').isNull())
                                          & (f.col('dcop.customer_number').isNull())
                                          & (f.to_date(f.col('s1.delivery_date')).between(f.col('dcop.start_date'),
                                                                                         f.col('dcop.end_date'))),
                                          'left') \
            .join(imi_cost.alias('scop'), (f.col('scop.cost_type') == "COP_RATE")
                  & (f.col('s1.prod_grp') == f.col('scop.prod_grp'))
                  & (f.col('scop.sector') == f.col('s1.sector'))
                  & (f.col('s1.country_mnmc') == f.col('scop.cty_mnmc'))
                  & (f.col('scop.airport').isNull())
                  & (f.col('scop.fuel_point').isNull())
                  & (f.col('scop.customer_number').isNull())
                  & (f.to_date(f.col('s1.delivery_date')).between(f.col('scop.start_date'), f.col('scop.end_date'))),
                  'left') \
            .join(imi_cost.alias('doaf'), (f.col('doaf.cost_type') == "ONAIRFIELD_FXD")
                  & (f.col('s1.prod_grp') == f.col('doaf.prod_grp'))
                  & (f.col('doaf.sector') == "Default")
                  & (f.col('s1.country_mnmc') == f.col('doaf.cty_mnmc'))
                  & (f.col('doaf.airport').isNull())
                  & (f.col('doaf.fuel_point').isNull())
                  & (f.col('doaf.customer_number').isNull())
                  & (f.to_date(f.col('s1.delivery_date')).between(f.col('doaf.start_date'), f.col('doaf.end_date'))),
                  'left') \
            .join(imi_cost.alias('soaf'), (f.col('soaf.cost_type') == "ONAIRFIELD_FXD")
                  & (f.col('s1.prod_grp') == f.col('soaf.prod_grp'))
                  & (f.col('s1.sector') == f.col('soaf.sector'))
                  & (f.col('s1.country_mnmc') == f.col('soaf.cty_mnmc'))
                  & (f.col('soaf.airport').isNull())
                  & (f.col('soaf.fuel_point').isNull())
                  & (f.col('soaf.customer_number').isNull())
                  & (f.to_date(f.col('s1.delivery_date')).between(f.col('soaf.start_date'), f.col('soaf.end_date'))),
                  'left') \
            .join(imi_cost.alias('doav'), (f.col('doav.cost_type') == "ONAIRFIELD_VAR")
                  & (f.col('s1.prod_grp') == f.col('doav.prod_grp'))
                  & (f.col('doav.sector') == "Default")
                  & (f.col('s1.country_mnmc') == f.col('doav.cty_mnmc'))
                  & (f.col('doav.airport').isNull())
                  & (f.col('doav.fuel_point').isNull())
                  & (f.col('doav.customer_number').isNull())
                  & (f.to_date(f.col('s1.delivery_date')).between(f.col('doav.start_date'), f.col('doav.end_date'))),
                  'left') \
            .join(imi_cost.alias('soav'), (f.col('soav.cost_type') == "ONAIRFIELD_VAR")
                  & (f.col('s1.prod_grp') == f.col('soav.prod_grp'))
                  & (f.col('s1.sector') == f.col('soav.sector'))
                  & (f.col('s1.country_mnmc') == f.col('soav.cty_mnmc'))
                  & (f.col('soav.airport').isNull())
                  & (f.col('soav.fuel_point').isNull())
                  & (f.col('soav.customer_number').isNull())
                  & (f.to_date(f.col('s1.delivery_date')).between(f.col('soav.start_date'), f.col('soav.end_date'))),
                  'left') \
            .join(imi_cost.alias('dpaf'), (f.col('dpaf.cost_type') == "PREAIRFIELD_FXD")
                  & (f.col('s1.prod_grp') == f.col('dpaf.prod_grp'))
                  & (f.col('dpaf.sector') == "Default")
                  & (f.col('s1.country_mnmc') == f.col('dpaf.cty_mnmc'))
                  & (f.col('dpaf.airport').isNull())
                  & (f.col('dpaf.fuel_point').isNull())
                  & (f.col('dpaf.customer_number').isNull())
                  & (f.to_date(f.col('s1.delivery_date')).between(f.col('dpaf.start_date'), f.col('dpaf.end_date'))),
                  'left') \
            .join(imi_cost.alias('spaf'), (f.col('spaf.cost_type') == "PREAIRFIELD_FXD")
                  & (f.col('s1.prod_grp') == f.col('spaf.prod_grp'))
                  & (f.col('s1.sector') == f.col('spaf.sector'))
                  & (f.col('s1.country_mnmc') == f.col('spaf.cty_mnmc'))
                  & (f.col('spaf.airport').isNull())
                  & (f.col('spaf.fuel_point').isNull())
                  & (f.col('spaf.customer_number').isNull())
                  & (f.to_date(f.col('s1.delivery_date')).between(f.col('spaf.start_date'), f.col('spaf.end_date'))),
                  'left') \
            .join(imi_cost.alias('dpav'), (f.col('dpav.cost_type') == "PREAIRFIELD_VAR")
                  & (f.col('s1.prod_grp') == f.col('dpav.prod_grp'))
                  & (f.col('dpav.sector') == "Default")
                  & (f.col('s1.country_mnmc') == f.col('dpav.cty_mnmc'))
                  & (f.col('dpav.airport').isNull())
                  & (f.col('dpav.fuel_point').isNull())
                  & (f.col('dpav.customer_number').isNull())
                  & (f.to_date(f.col('s1.delivery_date')).between(f.col('dpav.start_date'), f.col('dpav.end_date'))),
                  'left') \
            .join(imi_cost.alias('SPAV'), (f.col('SPAV.cost_type') == "PREAIRFIELD_VAR")
                  & (f.col('s1.prod_grp') == f.col('SPAV.prod_grp'))
                  & (f.col('s1.sector') == f.col('SPAV.sector'))
                  & (f.col('s1.country_mnmc') == f.col('SPAV.cty_mnmc'))
                  & (f.col('SPAV.airport').isNull())
                  & (f.col('SPAV.fuel_point').isNull())
                  & (f.col('SPAV.customer_number').isNull())
                  & (f.to_date(f.col('s1.delivery_date')).between(f.col('SPAV.start_date'), f.col('SPAV.end_date'))),
                  'left') \
            .join(imi_cost.alias('DOIC'), (f.col('DOIC.cost_type') == "OTHER_INCOME")
                  & (f.col('s1.prod_grp') == f.col('DOIC.prod_grp'))
                  & (f.col('DOIC.sector') == "Default")
                  & (f.col('s1.country_mnmc') == f.col('DOIC.cty_mnmc'))
                  & (f.col('DOIC.airport').isNull())
                  & (f.col('DOIC.fuel_point').isNull())
                  & (f.col('DOIC.customer_number').isNull())
                  & (f.to_date(f.col('s1.delivery_date')).between(f.col('DOIC.start_date'), f.col('DOIC.end_date'))),
                  'left') \
            .join(imi_cost.alias('SOIC'), (f.col('SOIC.cost_type') == "OTHER_INCOME")
                  & (f.col('s1.prod_grp') == f.col('SOIC.prod_grp'))
                  & (f.col('s1.sector') == f.col('SOIC.sector'))
                  & (f.col('s1.country_mnmc') == f.col('SOIC.cty_mnmc'))
                  & (f.col('SOIC.airport').isNull())
                  & (f.col('SOIC.fuel_point').isNull())
                  & (f.col('SOIC.customer_number').isNull())
                  & (f.to_date(f.col('s1.delivery_date')).between(f.col('SOIC.start_date'), f.col('SOIC.end_date'))),
                  'left') \
            .filter(f.col('s1.country_mnmc').isin("AL", "CH", "CY", "GB", "HR", "IE")) \
            .select(f.col('s1.*'),
                    (((f.when(f.coalesce(f.col('scop.uom'), f.col('dcop.uom')) == "TONNES", f.col('s1.metric_tons'))
                       .when(f.coalesce(f.col('scop.uom'), f.col('dcop.uom')) == "US GALLON", f.col('s1.ugl'))
                       .when(f.coalesce(f.col('scop.uom'), f.col('dcop.uom')) == "CUBIC METERS", f.col('s1.m3'))
                       .when(f.coalesce(f.col('scop.uom'), f.col('dcop.uom')) == "LITRES", f.col('s1.litres'))
                       .otherwise(f.lit(None))) / f.col('s1.litres')) * f.coalesce(f.col('scop.cost_rate'),
                                                                                  f.col('dcop.cost_rate'))).alias(
                        'cop_cty'),
                    (((f.when(f.coalesce(f.col('soaf.uom'), f.col('doaf.uom')) == "TONNES", f.col('s1.metric_tons'))
                       .when(f.coalesce(f.col('soaf.uom'), f.col('doaf.uom')) == "US GALLON", f.col('s1.ugl'))
                       .when(f.coalesce(f.col('soaf.uom'), f.col('doaf.uom')) == "CUBIC METERS", f.col('s1.m3'))
                       .when(f.coalesce(f.col('soaf.uom'), f.col('doaf.uom')) == "LITRES", f.col('s1.litres'))
                       .otherwise(f.lit(None))) / f.col('s1.litres')) * f.coalesce(f.col('soaf.cost_rate'),
                                                                                  f.col('doaf.cost_rate'))).alias(
                        'oaf_cty'),
                    (((f.when(f.coalesce(f.col('soav.uom'), f.col('doav.uom')) == "TONNES", f.col('s1.metric_tons'))
                       .when(f.coalesce(f.col('soav.uom'), f.col('doav.uom')) == "US GALLON", f.col('s1.ugl'))
                       .when(f.coalesce(f.col('soav.uom'), f.col('doav.uom')) == "CUBIC METERS", f.col('s1.m3'))
                       .when(f.coalesce(f.col('soav.uom'), f.col('doav.uom')) == "LITRES", f.col('s1.litres'))
                       .otherwise(f.lit(None))) / f.col('s1.litres')) * f.coalesce(f.col('soav.cost_rate'),
                                                                                  f.col('doav.cost_rate'))).alias(
                        'oav_cty'),
                    (((f.when(f.coalesce(f.col('spaf.uom'), f.col('dpaf.uom')) == "TONNES", f.col('s1.metric_tons'))
                       .when(f.coalesce(f.col('spaf.uom'), f.col('dpaf.uom')) == "US GALLON", f.col('s1.ugl'))
                       .when(f.coalesce(f.col('spaf.uom'), f.col('dpaf.uom')) == "CUBIC METERS", f.col('s1.m3'))
                       .when(f.coalesce(f.col('spaf.uom'), f.col('dpaf.uom')) == "LITRES", f.col('s1.litres'))
                       .otherwise(f.lit(None))) / f.col('s1.litres')) * f.coalesce(f.col('spaf.cost_rate'),
                                                                                  f.col('dpaf.cost_rate'))).alias(
                        'paf_cty'),
                    (((f.when(f.coalesce(f.col('SPAV.uom'), f.col('dpav.uom')) == "TONNES", f.col('s1.metric_tons'))
                       .when(f.coalesce(f.col('SPAV.uom'), f.col('dpav.uom')) == "US GALLON", f.col('s1.ugl'))
                       .when(f.coalesce(f.col('SPAV.uom'), f.col('dpav.uom')) == "CUBIC METERS", f.col('s1.m3'))
                       .when(f.coalesce(f.col('SPAV.uom'), f.col('dpav.uom')) == "LITRES", f.col('s1.litres'))
                       .otherwise(f.lit(None))) / f.col('s1.litres')) * f.coalesce(f.col('SPAV.cost_rate'),
                                                                                  f.col('dpav.cost_rate'))).alias(
                        'pav_cty'),
                    (((f.when(s1.country_mnmc == "GB", f.lit(0).cast('double'))
                       .when(f.coalesce(f.col('SOIC.uom'), f.col('DOIC.uom')) == "TONNES", f.col('s1.metric_tons'))
                       .when(f.coalesce(f.col('SOIC.uom'), f.col('DOIC.uom')) == "US GALLON", f.col('s1.ugl'))
                       .when(f.coalesce(f.col('SOIC.uom'), f.col('DOIC.uom')) == "CUBIC METERS", f.col('s1.m3'))
                       .when(f.coalesce(f.col('SOIC.uom'), f.col('DOIC.uom')) == "LITRES", f.col('s1.litres'))
                       .otherwise(f.lit(None))) / f.col('s1.litres')) * f.coalesce(f.col('SOIC.cost_rate'),
                                                                                  f.col('DOIC.cost_rate'))
                     .alias('oic_cty')))

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
