# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz  Harvey     09-Apr-2021     Initial version
#  0.2              Tingting Wan    18-May-2021     Optimise & add change logs
# =================================================================================================
# Description   :- The aim of the code is to l3_l31_ext_adj_mena
#               into conform zone
# Author        :- Liz Harvey
# Date          :- 09-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        # new jfrog changes test
        print('jfrog changes test')
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.conform_database = args['source_database1']
        self.netapp_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']
        # report specific =============================================

        self.report_file = "l3_isp_ext_adj_mena"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):

        # read data from specific table argument passed(database, table)
        df_table_1 = self._get_table(self.netapp_database, 'l2_isp_ext_adj_ae').toDF()
        print("data count of table {}.{} is {}".format(self.netapp_database,
                                                       'l2_isp_ext_adj_ae',
                                                       df_table_1.count()))
        df_table_2 = self._get_table(self.netapp_database, 'l2_isp_ext_adj_bh').toDF()
        print("data count of table {}.{} is {}".format(self.netapp_database, 'l2_isp_ext_adj_bh',
                                                       df_table_2.count()))
        df_table_3 = self._get_table(self.conform_database, 'l41_isp_fact_sales_billing_cost_allocation_mena_s2a').toDF()
        print("data count of table {}.{} is {}".format(self.conform_database,
                                                       'l41_isp_fact_sales_billing_cost_allocation_mena_s2a',
                                                       df_table_3.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2, df_table_3)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign all input tables
        df_table_ae = args[0]
        df_table_bh = args[1]
        df_table_s2a = args[2]

        # df_table_ae --- l2_isp_ext_adj_ae
        # df_table_bh --- l2_isp_ext_adj_bh
        # df_table_s2a --- Layer_4.1_Datasets/l41_isp_fact_sales_billing_cost_allocation_mena_s2a

        # transformation of l2_isp_ext_adj_ae table
        df_table_AE = df_table_ae.filter(f.col('include') == 'Y') \
            .groupBy(f.col('airports').alias('airport_mnmc'),
                     (f.from_unixtime(f.unix_timestamp(f.col('start_date'), 'dd/MM/yyyy')).cast('date')).alias(
                         'start_date'),
                     (f.from_unixtime(f.unix_timestamp(f.col('end_date'), 'dd/MM/yyyy')).cast('date')).alias(
                         'end_date')) \
            .agg((f.sum(f.col('usd_ugl_rate').cast('double')) * (-1)).alias('usd_ugl_adj_rate')) \
            .select(f.lit('AE').alias('country_mnmc'),
                    f.col('airport_mnmc').alias('airport_mnmc'),
                    f.col('start_date'),
                    f.col('end_date'),
                    f.lit(0).cast('int').alias('ugl'),
                    f.lit(0).cast('double').alias('usd_adj_value'),
                    f.lit(0).cast('double').alias('airbp_value'),
                    f.lit(0).cast('double').alias('chevron_value'),
                    f.lit(0).cast('double').alias('bapco_value'),
                    f.col('usd_ugl_adj_rate'),
                    f.lit(0).cast('double').alias('usd_ugl_airbp_rate'),
                    f.lit(0).cast('double').alias('usd_ugl_chevron_rate'),
                    f.lit(0).cast('double').alias('usd_ugl_bapco_rate')
                    )

        # transformation of l3_isp_ext_adj_bh & l41_isp_fact_sales_billing_cost_allocation_mena_s2a

        # Create table A from l3_isp_ext_adj_bh
        df_table_A = df_table_bh.select(
            f.col('airports').alias('airport_mnmc'),
            f.col('end_date'),
            f.col('start_date'),
            f.col('usd_value').alias('usd_value'),
            f.when(f.col('ext_adj_desc') == 'AirBP Fixed Share (13%)', f.col('usd_value'))
                .otherwise(f.lit(0)).alias('airbp_value'),
            f.when(f.col('ext_adj_desc') == 'Chevron', f.col('usd_value'))
                .otherwise(f.lit(0)).alias('chevron_value'),
            f.when(f.col('ext_adj_desc') == 'BAPCO', f.col('usd_value'))
                .otherwise(f.lit(0)).alias('bapco_value'))

        # join table A and V
        df_table_A_V = df_table_A.alias('A').join(df_table_s2a.alias('V'),
                                                  (f.col('A.airport_mnmc') == f.col('V.airport_mnmc'))
                                                  & (f.col('V.start_of_month') == f.from_unixtime(
                                                      f.unix_timestamp(f.col('A.start_date'), 'dd/MM/yyyy')).cast(
                                                      'date'))
                                                  & (f.col('V.end_of_month') == f.from_unixtime(
                                                      f.unix_timestamp(f.col('A.end_date'), 'dd/MM/yyyy')).cast(
                                                      'date'))) \
            .filter((f.col('V.country_mnmc') == 'BH') & (f.col('V.prod_grp') == 'Default')) \
            .groupBy(f.col('A.airport_mnmc').alias('airport_mnmc'),
                     (f.from_unixtime(f.unix_timestamp(f.col('A.start_date'), 'dd/MM/yyyy')).cast('date')).alias(
                         'start_date'),
                     (f.from_unixtime(f.unix_timestamp(f.col('A.end_date'), 'dd/MM/yyyy')).cast('date')).alias(
                         'end_date'),
                     f.col('V.ugl').alias('ugl')) \
            .agg(f.sum((f.col('A.usd_value')).cast('double')).alias('usd_adj_value'),
                 f.sum((f.col('A.airbp_value')).cast('double')).alias('usd_airbp_value'),
                 f.sum((f.col('A.chevron_value')).cast('double')).alias('usd_chevron_value'),
                 f.sum((f.col('A.bapco_value')).cast('double')).alias('usd_bapco_value'),
                 (f.sum(((f.col('A.usd_value')).cast('double'))) / f.col('V.ugl')).alias('usd_ugl_adj_rate'),
                 (f.sum(((f.col('A.airbp_value')).cast('double'))) / f.col('V.ugl')).alias('usd_ugl_airbp_rate'),
                 (f.sum(((f.col('A.chevron_value')).cast('double'))) / f.col('V.ugl')).alias('usd_ugl_chevron_rate'),
                 (f.sum(((f.col('A.bapco_value')).cast('double'))) / f.col('V.ugl')).alias('usd_ugl_bapco_rate')) \
            .select(f.lit('BH').alias('country_mnmc'),
                    f.col('airport_mnmc'),
                    f.col('start_date'),
                    f.col('end_date'),
                    f.col('ugl'),
                    f.col('usd_adj_value'),
                    f.col('usd_airbp_value'),
                    f.col('usd_chevron_value'),
                    f.col('usd_bapco_value'),
                    f.col('usd_ugl_adj_rate'),
                    f.col('usd_ugl_airbp_rate'),
                    f.col('usd_ugl_chevron_rate'),
                    f.col('usd_ugl_bapco_rate'))

        # performs the unionAll of df_table_AE and df_table_A_V
        df_tfx_result = df_table_AE.unionAll(df_table_A_V)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()

