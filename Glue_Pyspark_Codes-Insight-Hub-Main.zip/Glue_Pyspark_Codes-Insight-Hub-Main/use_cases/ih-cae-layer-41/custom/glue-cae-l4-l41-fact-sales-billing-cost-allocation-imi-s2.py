# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    05-Feb-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_imi_s2
#                  into conform zone
# Author        :- Tingting Wan
# Date          :- 08-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_imi_s2"

        # print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
        #                                                                  self.destination_bucket))

    def execute(self):
        # generate input table list
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, 'l41_isp_fact_sales_billing_cost_allocation_s1').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l41_isp_fact_sales_billing_cost_allocation_s1',
        #                                                df_table_1.count()))
        df_table_2 = self._get_table(source_database, 'l3_isp_imi_cost_data_add_all').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_isp_imi_cost_data_add_all',
        #                                                df_table_2.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):

        # assign tables
        S = args[0]
        # IMI_COST - l3_isp_imi_cost_data_add_all
        IMI_COST = args[1].cache()

        # join and filter dataframes
        df_tfx_result = S.alias('S').join(IMI_COST.alias('DCOP'), (f.col('DCOP.cost_type') == "COP_RATE")
                                          & (f.col('S.prod_grp') == f.col('DCOP.prod_grp'))
                                          & (f.col('DCOP.sector') == "Default")
                                          & (f.col('S.country_mnmc') == f.col('DCOP.cty_mnmc'))
                                          & (f.col('DCOP.airport').isNull())
                                          & (f.col('DCOP.fuel_point').isNull())
                                          & (f.col('DCOP.customer_number').isNull())
                                          & (f.to_date(f.col('S.delivery_date')).between(f.col('DCOP.start_date'),
                                                                                         f.col('DCOP.end_date'))),
                                          'left') \
            .join(IMI_COST.alias('SCOP'), (f.col('SCOP.cost_type') == "COP_RATE")
                  & (f.col('S.prod_grp') == f.col('SCOP.prod_grp'))
                  & (f.col('SCOP.sector') == f.col('S.sector'))
                  & (f.col('S.country_mnmc') == f.col('SCOP.cty_mnmc'))
                  & (f.col('SCOP.airport').isNull())
                  & (f.col('SCOP.fuel_point').isNull())
                  & (f.col('SCOP.customer_number').isNull())
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('SCOP.start_date'), f.col('SCOP.end_date'))),
                  'left') \
            .join(IMI_COST.alias('DOAF'), (f.col('DOAF.cost_type') == "ONAIRFIELD_FXD")
                  & (f.col('S.prod_grp') == f.col('DOAF.prod_grp'))
                  & (f.col('DOAF.sector') == "Default")
                  & (f.col('S.country_mnmc') == f.col('DOAF.cty_mnmc'))
                  & (f.col('DOAF.airport').isNull())
                  & (f.col('DOAF.fuel_point').isNull())
                  & (f.col('DOAF.customer_number').isNull())
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('DOAF.start_date'), f.col('DOAF.end_date'))),
                  'left') \
            .join(IMI_COST.alias('SOAF'), (f.col('SOAF.cost_type') == "ONAIRFIELD_FXD")
                  & (f.col('S.prod_grp') == f.col('SOAF.prod_grp'))
                  & (f.col('S.sector') == f.col('SOAF.sector'))
                  & (f.col('S.country_mnmc') == f.col('SOAF.cty_mnmc'))
                  & (f.col('SOAF.airport').isNull())
                  & (f.col('SOAF.fuel_point').isNull())
                  & (f.col('SOAF.customer_number').isNull())
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('SOAF.start_date'), f.col('SOAF.end_date'))),
                  'left') \
            .join(IMI_COST.alias('DOAV'), (f.col('DOAV.cost_type') == "ONAIRFIELD_VAR")
                  & (f.col('S.prod_grp') == f.col('DOAV.prod_grp'))
                  & (f.col('DOAV.sector') == "Default")
                  & (f.col('S.country_mnmc') == f.col('DOAV.cty_mnmc'))
                  & (f.col('DOAV.airport').isNull())
                  & (f.col('DOAV.fuel_point').isNull())
                  & (f.col('DOAV.customer_number').isNull())
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('DOAV.start_date'), f.col('DOAV.end_date'))),
                  'left') \
            .join(IMI_COST.alias('SOAV'), (f.col('SOAV.cost_type') == "ONAIRFIELD_VAR")
                  & (f.col('S.prod_grp') == f.col('SOAV.prod_grp'))
                  & (f.col('S.sector') == f.col('SOAV.sector'))
                  & (f.col('S.country_mnmc') == f.col('SOAV.cty_mnmc'))
                  & (f.col('SOAV.airport').isNull())
                  & (f.col('SOAV.fuel_point').isNull())
                  & (f.col('SOAV.customer_number').isNull())
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('SOAV.start_date'), f.col('SOAV.end_date'))),
                  'left') \
            .join(IMI_COST.alias('DPAF'), (f.col('DPAF.cost_type') == "PREAIRFIELD_FXD")
                  & (f.col('S.prod_grp') == f.col('DPAF.prod_grp'))
                  & (f.col('DPAF.sector') == "Default")
                  & (f.col('S.country_mnmc') == f.col('DPAF.cty_mnmc'))
                  & (f.col('DPAF.airport').isNull())
                  & (f.col('DPAF.fuel_point').isNull())
                  & (f.col('DPAF.customer_number').isNull())
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('DPAF.start_date'), f.col('DPAF.end_date'))),
                  'left') \
            .join(IMI_COST.alias('SPAF'), (f.col('SPAF.cost_type') == "PREAIRFIELD_FXD")
                  & (f.col('S.prod_grp') == f.col('SPAF.prod_grp'))
                  & (f.col('S.sector') == f.col('SPAF.sector'))
                  & (f.col('S.country_mnmc') == f.col('SPAF.cty_mnmc'))
                  & (f.col('SPAF.airport').isNull())
                  & (f.col('SPAF.fuel_point').isNull())
                  & (f.col('SPAF.customer_number').isNull())
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('SPAF.start_date'), f.col('SPAF.end_date'))),
                  'left') \
            .join(IMI_COST.alias('DPAV'), (f.col('DPAV.cost_type') == "PREAIRFIELD_VAR")
                  & (f.col('S.prod_grp') == f.col('DPAV.prod_grp'))
                  & (f.col('DPAV.sector') == "Default")
                  & (f.col('S.country_mnmc') == f.col('DPAV.cty_mnmc'))
                  & (f.col('DPAV.airport').isNull())
                  & (f.col('DPAV.fuel_point').isNull())
                  & (f.col('DPAV.customer_number').isNull())
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('DPAV.start_date'), f.col('DPAV.end_date'))),
                  'left') \
            .join(IMI_COST.alias('SPAV'), (f.col('SPAV.cost_type') == "PREAIRFIELD_VAR")
                  & (f.col('S.prod_grp') == f.col('SPAV.prod_grp'))
                  & (f.col('S.sector') == f.col('SPAV.sector'))
                  & (f.col('S.country_mnmc') == f.col('SPAV.cty_mnmc'))
                  & (f.col('SPAV.airport').isNull())
                  & (f.col('SPAV.fuel_point').isNull())
                  & (f.col('SPAV.customer_number').isNull())
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('SPAV.start_date'), f.col('SPAV.end_date'))),
                  'left') \
            .join(IMI_COST.alias('DOIC'), (f.col('DOIC.cost_type') == "OTHER_INCOME")
                  & (f.col('S.prod_grp') == f.col('DOIC.prod_grp'))
                  & (f.col('DOIC.sector') == "Default")
                  & (f.col('S.country_mnmc') == f.col('DOIC.cty_mnmc'))
                  & (f.col('DOIC.airport').isNull())
                  & (f.col('DOIC.fuel_point').isNull())
                  & (f.col('DOIC.customer_number').isNull())
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('DOIC.start_date'), f.col('DOIC.end_date'))),
                  'left') \
            .join(IMI_COST.alias('SOIC'), (f.col('SOIC.cost_type') == "OTHER_INCOME")
                  & (f.col('S.prod_grp') == f.col('SOIC.prod_grp'))
                  & (f.col('S.sector') == f.col('SOIC.sector'))
                  & (f.col('S.country_mnmc') == f.col('SOIC.cty_mnmc'))
                  & (f.col('SOIC.airport').isNull())
                  & (f.col('SOIC.fuel_point').isNull())
                  & (f.col('SOIC.customer_number').isNull())
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('SOIC.start_date'), f.col('SOIC.end_date'))),
                  'left') \
            .filter(f.col('S.country_mnmc').isin("AL", "CH", "CY", "GB", "HR", "IE")) \
            .select(f.col('S.*'),
                    (((f.when(f.coalesce(f.col('SCOP.uom'), f.col('DCOP.uom')) == "TONNES", f.col('S.metric_tons'))
                       .when(f.coalesce(f.col('SCOP.uom'), f.col('DCOP.uom')) == "US GALLON", f.col('S.ugl'))
                       .when(f.coalesce(f.col('SCOP.uom'), f.col('DCOP.uom')) == "CUBIC METERS", f.col('S.m3'))
                       .when(f.coalesce(f.col('SCOP.uom'), f.col('DCOP.uom')) == "LITRES", f.col('S.litres'))
                       .otherwise(f.lit(None))) / f.col('S.litres')) * f.coalesce(f.col('SCOP.cost_rate'),
                                                                                  f.col('DCOP.cost_rate'))).alias(
                        'cop_cty'),
                    (((f.when(f.coalesce(f.col('SOAF.uom'), f.col('DOAF.uom')) == "TONNES", f.col('S.metric_tons'))
                       .when(f.coalesce(f.col('SOAF.uom'), f.col('DOAF.uom')) == "US GALLON", f.col('S.ugl'))
                       .when(f.coalesce(f.col('SOAF.uom'), f.col('DOAF.uom')) == "CUBIC METERS", f.col('S.m3'))
                       .when(f.coalesce(f.col('SOAF.uom'), f.col('DOAF.uom')) == "LITRES", f.col('S.litres'))
                       .otherwise(f.lit(None))) / f.col('S.litres')) * f.coalesce(f.col('SOAF.cost_rate'),
                                                                                  f.col('DOAF.cost_rate'))).alias(
                        'oaf_cty'),
                    (((f.when(f.coalesce(f.col('SOAV.uom'), f.col('DOAV.uom')) == "TONNES", f.col('S.metric_tons'))
                       .when(f.coalesce(f.col('SOAV.uom'), f.col('DOAV.uom')) == "US GALLON", f.col('S.ugl'))
                       .when(f.coalesce(f.col('SOAV.uom'), f.col('DOAV.uom')) == "CUBIC METERS", f.col('S.m3'))
                       .when(f.coalesce(f.col('SOAV.uom'), f.col('DOAV.uom')) == "LITRES", f.col('S.litres'))
                       .otherwise(f.lit(None))) / f.col('S.litres')) * f.coalesce(f.col('SOAV.cost_rate'),
                                                                                  f.col('DOAV.cost_rate'))).alias(
                        'oav_cty'),
                    (((f.when(f.coalesce(f.col('SPAF.uom'), f.col('DPAF.uom')) == "TONNES", f.col('S.metric_tons'))
                       .when(f.coalesce(f.col('SPAF.uom'), f.col('DPAF.uom')) == "US GALLON", f.col('S.ugl'))
                       .when(f.coalesce(f.col('SPAF.uom'), f.col('DPAF.uom')) == "CUBIC METERS", f.col('S.m3'))
                       .when(f.coalesce(f.col('SPAF.uom'), f.col('DPAF.uom')) == "LITRES", f.col('S.litres'))
                       .otherwise(f.lit(None))) / f.col('S.litres')) * f.coalesce(f.col('SPAF.cost_rate'),
                                                                                  f.col('DPAF.cost_rate'))).alias(
                        'paf_cty'),
                    (((f.when(f.coalesce(f.col('SPAV.uom'), f.col('DPAV.uom')) == "TONNES", f.col('S.metric_tons'))
                       .when(f.coalesce(f.col('SPAV.uom'), f.col('DPAV.uom')) == "US GALLON", f.col('S.ugl'))
                       .when(f.coalesce(f.col('SPAV.uom'), f.col('DPAV.uom')) == "CUBIC METERS", f.col('S.m3'))
                       .when(f.coalesce(f.col('SPAV.uom'), f.col('DPAV.uom')) == "LITRES", f.col('S.litres'))
                       .otherwise(f.lit(None))) / f.col('S.litres')) * f.coalesce(f.col('SPAV.cost_rate'),
                                                                                  f.col('DPAV.cost_rate'))).alias(
                        'pav_cty'),
                    (((f.when(S.country_mnmc == "GB", f.lit(0).cast('double'))
                       .when(f.coalesce(f.col('SOIC.uom'), f.col('DOIC.uom')) == "TONNES", f.col('S.metric_tons'))
                       .when(f.coalesce(f.col('SOIC.uom'), f.col('DOIC.uom')) == "US GALLON", f.col('S.ugl'))
                       .when(f.coalesce(f.col('SOIC.uom'), f.col('DOIC.uom')) == "CUBIC METERS", f.col('S.m3'))
                       .when(f.coalesce(f.col('SOIC.uom'), f.col('DOIC.uom')) == "LITRES", f.col('S.litres'))
                       .otherwise(f.lit(None))) / f.col('S.litres')) * f.coalesce(f.col('SOIC.cost_rate'),
                                                                                  f.col('DOIC.cost_rate'))).alias(
                        'oic_cty')

                    )



        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
