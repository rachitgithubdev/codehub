# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    10-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_mena_s3a
#                  into conform zone
# Author        :- Tingting Wan
# Date          :- 10-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from awsglue.job import Job
from functools import reduce


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l41_isp_fact_sales_billing_cost_allocation_s1',
                                 'l41_isp_fact_sales_billing_cost_allocation_mena_s2a',
                                 'l3_isp_cost_data_mena']
        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_mena_s3a"

        # print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
        #                                                                  self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table_1 = self._get_table(self.source_database, self.input_table_list[0]).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[0],
                                                       df_input_table_1.count()))
        df_input_table_2 = self._get_table(self.source_database, self.input_table_list[1]).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[1],
                                                       df_input_table_2.count()))
        df_input_table_3 = self._get_table(self.source_database, self.input_table_list[2]).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[2],
                                                       df_input_table_3.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_1, df_input_table_2, df_input_table_3)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign all input tables
        df_table_S = args[0]
        df_table_S2 = args[1]
        df_table_C = args[2]

        # transformation
        ## df_table_C -- l3_isp_cost_data_mena
        # create table COP
        df_table_COP = df_table_C.filter(
            (df_table_C.cost_type == 'COP')
            & df_table_C.airport.isNull()) \
            .groupBy(
            df_table_C.prod_grp,
            df_table_C.cty_mnmc,
            df_table_C.airport,
            df_table_C.start_date,
            df_table_C.end_date,
            f.lit('COP_RATE')
        ) \
            .agg(f.sum(df_table_C.cost).alias('cost'))

        df_table_COP = df_table_COP.select(
            df_table_COP.prod_grp,
            df_table_COP.cty_mnmc,
            df_table_COP.airport,
            df_table_COP.start_date,
            df_table_COP.end_date,
            f.lit('COP_RATE'),
            df_table_COP.cost,
        )

        # create table LAG
        df_table_LAG = df_table_C.filter(
            (df_table_C.cost_type == 'COP_LAG')
            & (df_table_C.prod_grp == 'Default')
            & df_table_C.airport.isNull()) \
            .groupBy(
            df_table_C.prod_grp,
            df_table_C.cty_mnmc,
            df_table_C.airport,
            df_table_C.start_date,
            df_table_C.end_date,
            df_table_C.cost_type,
        ) \
            .agg(f.sum(df_table_C.cost).alias('cost'))

        df_table_LAG = df_table_LAG.select(
            df_table_LAG.prod_grp,
            df_table_LAG.cty_mnmc,
            df_table_LAG.airport,
            df_table_LAG.start_date,
            df_table_LAG.end_date,
            df_table_LAG.cost_type,
            df_table_LAG.cost,
        )

        # create table OAF
        df_table_OAF = df_table_C.filter(
            (df_table_C.cost_type == 'OAF')
            & (df_table_C.prod_grp == 'Default')
            & df_table_C.airport.isNull()) \
            .groupBy(
            df_table_C.prod_grp,
            df_table_C.cty_mnmc,
            df_table_C.airport,
            df_table_C.start_date,
            df_table_C.end_date,
            df_table_C.cost_type,
        ) \
            .agg(f.sum(df_table_C.cost).alias('cost'))

        df_table_OAF = df_table_OAF.select(
            df_table_OAF.prod_grp,
            df_table_OAF.cty_mnmc,
            df_table_OAF.airport,
            df_table_OAF.start_date,
            df_table_OAF.end_date,
            df_table_OAF.cost_type,
            df_table_OAF.cost,
        )

        # create table OAV
        df_table_OAV = df_table_C.filter(
            (df_table_C.cost_type == 'OAV')
            & (df_table_C.prod_grp == 'Default')
            & df_table_C.airport.isNull()) \
            .groupBy(
            df_table_C.prod_grp,
            df_table_C.cty_mnmc,
            df_table_C.airport,
            df_table_C.start_date,
            df_table_C.end_date,
            df_table_C.cost_type,
        ) \
            .agg(f.sum(df_table_C.cost).alias('cost'))

        df_table_OAV = df_table_OAV.select(
            df_table_OAV.prod_grp,
            df_table_OAV.cty_mnmc,
            df_table_OAV.airport,
            df_table_OAV.start_date,
            df_table_OAV.end_date,
            df_table_OAV.cost_type,
            df_table_OAV.cost,
        )
        # create table PAF
        df_table_PAF = df_table_C.filter(
            (df_table_C.cost_type == 'PAF')
            & (df_table_C.prod_grp == 'Default')
            & df_table_C.airport.isNull()) \
            .groupBy(
            df_table_C.prod_grp,
            df_table_C.cty_mnmc,
            df_table_C.airport,
            df_table_C.start_date,
            df_table_C.end_date,
            df_table_C.cost_type,
        ) \
            .agg(f.sum(df_table_C.cost).alias('cost'))

        df_table_PAF = df_table_PAF.select(
            df_table_PAF.prod_grp,
            df_table_PAF.cty_mnmc,
            df_table_PAF.airport,
            df_table_PAF.start_date,
            df_table_PAF.end_date,
            df_table_PAF.cost_type,
            df_table_PAF.cost,
        )
        # create table PAV
        df_table_PAV = df_table_C.filter(
            (df_table_C.cost_type == 'PAV')
            & (df_table_C.prod_grp == 'Default')
            & df_table_C.airport.isNull()) \
            .groupBy(
            df_table_C.prod_grp,
            df_table_C.cty_mnmc,
            df_table_C.airport,
            df_table_C.start_date,
            df_table_C.end_date,
            df_table_C.cost_type,
        ) \
            .agg(f.sum(df_table_C.cost).alias('cost'))

        df_table_PAV = df_table_PAV.select(
            df_table_PAV.prod_grp,
            df_table_PAV.cty_mnmc,
            df_table_PAV.airport,
            df_table_PAV.start_date,
            df_table_PAV.end_date,
            df_table_PAV.cost_type,
            df_table_PAV.cost,
        )
        # create table OIC
        df_table_OIC = df_table_C.filter(
            (df_table_C.cost_type == 'OTHER_INCOME')
            & (df_table_C.prod_grp == 'Default')
            & df_table_C.airport.isNull()) \
            .groupBy(
            df_table_C.prod_grp,
            df_table_C.cty_mnmc,
            df_table_C.airport,
            df_table_C.start_date,
            df_table_C.end_date,
            df_table_C.cost_type,
        ) \
            .agg(f.sum(df_table_C.cost).alias('cost'))

        df_table_OIC = df_table_OIC.select(
            df_table_OIC.prod_grp,
            df_table_OIC.cty_mnmc,
            df_table_OIC.airport,
            df_table_OIC.start_date,
            df_table_OIC.end_date,
            df_table_OIC.cost_type,
            df_table_OIC.cost,
        )

        # table join and select
        df_tfx_result = df_table_S.alias('S') \
            .join(df_table_S2.alias('TOTVP'),
                  (f.col('S.country_mnmc') == f.col('TOTVP.country_mnmc'))
                  & (f.col('TOTVP.airport_mnmc') == 'Default')
                  & (f.col('S.prod_grp') == f.col('TOTVP.prod_grp'))
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('TOTVP.start_of_month'),
                                                                 f.col('TOTVP.end_of_month'))),
                  'left') \
            .join(df_table_S2.alias('TOTVC'),
                  (f.col('S.country_mnmc') == f.col('TOTVC.country_mnmc'))
                  & (f.col('TOTVC.airport_mnmc') == 'Default')
                  & (f.col('TOTVC.prod_grp') == 'Default')
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('TOTVC.start_of_month'),
                                                                 f.col('TOTVC.end_of_month'))),
                  'left') \
            .join(df_table_COP.alias('COP'),
                  (f.col('S.prod_grp') == f.col('COP.prod_grp'))
                  & (f.col('S.country_mnmc') == f.col('COP.cty_mnmc'))
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('COP.start_date'), f.col('COP.end_date'))),
                  'left') \
            .join(df_table_LAG.alias('LAG'),
                  (f.col('S.country_mnmc') == f.col('LAG.cty_mnmc'))
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('LAG.start_date'), f.col('LAG.end_date'))),
                  'left') \
            .join(df_table_OAF.alias('OAF'),
                  (f.col('S.country_mnmc') == f.col('OAF.cty_mnmc'))
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('OAF.start_date'), f.col('OAF.end_date'))),
                  'left') \
            .join(df_table_OAV.alias('OAV'),
                  (f.col('S.country_mnmc') == f.col('OAV.cty_mnmc'))
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('OAV.start_date'), f.col('OAV.end_date'))),
                  'left') \
            .join(df_table_PAF.alias('PAF'),
                  (f.col('S.country_mnmc') == f.col('PAF.cty_mnmc'))
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('PAF.start_date'), f.col('PAF.end_date'))),
                  'left') \
            .join(df_table_PAV.alias('PAV'),
                  (f.col('S.country_mnmc') == f.col('PAV.cty_mnmc'))
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('PAV.start_date'), f.col('PAV.end_date'))),
                  'left') \
            .join(df_table_OIC.alias('OIC'),
                  (f.col('S.country_mnmc') == f.col('OIC.cty_mnmc'))
                  & (f.to_date(f.col('S.delivery_date')).between(f.col('OIC.start_date'), f.col('OIC.end_date'))),
                  'left') \
            .filter(f.col('S.country_mnmc').isin('AE', 'BH', 'EG', 'IQ', 'JO', 'LB', 'QL', 'OM', 'SA', 'TN')) \
            .select(
            f.col('S.*'),
            f.coalesce(f.col('COP.cost') / f.col('TOTVP.ugl'), f.lit(0)).alias('cop_cty'),
            f.coalesce(f.col('LAG.cost') / f.col('TOTVC.ugl'), f.lit(0)).alias('lag_cty'),
            f.coalesce(f.col('OIC.cost') / f.col('TOTVC.ugl'), f.lit(0)).alias('oic_cty'),
            f.coalesce(f.col('OAF.cost') / f.col('TOTVC.ugl'), f.lit(0)).alias('oaf_cty'),
            f.coalesce(f.col('OAV.cost') / f.col('TOTVC.ugl'), f.lit(0)).alias('oav_cty'),
            f.coalesce(f.col('PAF.cost') / f.col('TOTVC.ugl'), f.lit(0)).alias('paf_cty'),
            f.coalesce(f.col('PAV.cost') / f.col('TOTVC.ugl'), f.lit(0)).alias('pav_cty')
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()

