# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    23-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_gr_s8
#                  into conform zone
# Author        :- Tingting Wan
# Date          :- 23-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l41_isp_fact_sales_billing_cost_allocation_gr_s7',
                                 'l3_isp_apc_gr']
        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_gr_s8"

        # print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
        #                                                                  self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table_1 = self._get_table(self.source_database, self.input_table_list[0]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[0],
        #                                                df_input_table_1.count()))
        df_input_table_2 = self._get_table(self.source_database, self.input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[1],
        #                                                df_input_table_2.count()))

        # apply transformation on the dataframe argument passed(dataframes)
        df_tfx_table = self._apply_tfx(df_input_table_1, df_input_table_2)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign all input tables
        df_table_S7 = args[0]
        df_table_C = args[1]

        # transformation
        ## df_table_C -- l31_isp_apc_gr
        # table join and select
        df_tfx_result = df_table_S7.alias('S') \
            .join(df_table_C.alias('C'),
                  (f.year(f.col('S.delivery_date')) == f.col('C.apc_year'))
                  & (f.col('S.prod_grp') == f.col('C.prod_grp'))
                  & (f.col('S.airport_cae') == f.col('C.airport'))
                  & (f.col('S.sector_cae') == f.col('C.sector_cae')),
                  'left') \
            .select(
            f.col('S.ref_id'),
            f.col('S.billing_document'),
            f.col('S.source_system'),
            f.col('S.billing_item'),
            f.col('S.country_mnmc'),
            f.col('S.sector'),
            f.col('S.sales_organisation'),
            f.col('S.prod_grp'),
            f.col('S.item_category'),
            f.col('S.material_number'),
            f.col('S.material_mnmc'),
            f.col('S.airport_id'),
            f.col('S.airport_mnmc'),
            f.col('S.airport_name'),
            f.col('S.customer_id'),
            f.col('S.customer_number'),
            f.col('S.customer_header'),
            f.col('S.customer_name'),
            f.col('S.fuel_point_mnmc'),
            f.col('S.fuel_point_name'),
            f.col('S.delivery_date'),
            f.col('S.billing_date'),
            f.col('S.m3'),
            f.col('S.ugl'),
            f.col('S.litres'),
            f.col('S.metric_tons'),
            f.col('S.document_currency'),
            f.col('S.local_currency'),
            f.col('S.exchange_rate'),
            f.col('S.net_value'),
            f.col('S.ile_exch_rate'),
            f.col('S.lcl_net_val'),
            f.col('S.lre_exch_rate'),
            f.col('S.usd_net_val'),
            f.col('S.rec_type'),
            f.col('S.sector_cae'),
            f.col('S.airport_cae'),
            f.col('S.lcl_adj_val'),
            f.col('S.lcl_cop_val'),
            f.col('S.lcl_lag_val'),
            (f.col('S.lcl_oic_val') + f.coalesce(
                f.col('C.oic_rate') * f.col('S.litres'),
                f.lit(0))).alias('lcl_oic_val'),
            (f.col('S.lcl_oaf_val') + f.coalesce(
                f.col('C.oaf_rate') * f.col('S.litres'),
                f.lit(0))).alias('lcl_oaf_val'),
            (f.col('S.lcl_oav_val') + f.coalesce(
                f.col('C.oav_rate') * f.col('S.litres'),
                f.lit(0))).alias('lcl_oav_val'),
            (f.col('S.lcl_paf_val') + f.coalesce(
                f.col('C.paf_rate') * f.col('S.litres'),
                f.lit(0))).alias('lcl_paf_val'),
            (f.col('S.lcl_pav_val') + f.coalesce(
                f.col('C.pav_rate') * f.col('S.litres'),
                f.lit(0))).alias('lcl_pav_val')

        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()

