# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    19-Apr-2021     Initial version
#  0.2              Tingting Wan    27-May-2021     Change log
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_gr_s3
#                  into conform zone
# Author        :- Tingting Wan
# Date          :- 19-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from awsglue.job import Job
from functools import reduce


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l41_isp_fact_sales_billing_cost_allocation_gr_s2',
                                 'l3_isp_cost_data_gr']
        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_gr_s3"

        # print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
        #                                                                  self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table_1 = self._get_table(self.source_database, self.input_table_list[0]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[0],
        #                                                df_input_table_1.count()))
        df_input_table_2 = self._get_table(self.source_database, self.input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[1],
        #                                                df_input_table_2.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_1, df_input_table_2)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign all input tables
        df_table_S2 = args[0].cache()
        df_table_C = args[1]

        # transformation
        ## df_table_C -- l31_isp_cost_data_gr
        # create table MC,MV,AC,AV
        df_table_MC = df_table_C.groupBy(
            f.col('rec_type'),
            f.col('customer_header'),
            f.upper(f.substring(f.col('customer_name'), 1, 4)).alias('customer_part_name'),
            f.col('prod_grp'),
            f.col('airport_mnmc'),
            f.col('end_date').alias('period')
        ) \
            .agg(f.sum(f.col('lcl_adj_val')).alias('lcl_adj_val'),
                 f.sum(f.col('lcl_cop_val')).alias('lcl_cop_val'),
                 f.sum(f.col('lcl_lag_val')).alias('lcl_lag_val')) \
            .select(
            f.col('rec_type'),
            f.col('customer_header'),
            f.col('customer_part_name'),
            f.col('prod_grp'),
            f.col('airport_mnmc'),
            f.col('period'),
            f.col('lcl_adj_val'),
            f.col('lcl_cop_val'),
            f.col('lcl_lag_val')
        )

        df_table_MV = df_table_S2.filter(
            (f.col('delivery_date') <= f.col('cop_last_loaded_date'))
            & f.col('item_category').isin('1', '3')) \
            .groupBy(
            f.col('rec_type'),
            f.col('customer_header'),
            f.upper(f.substring(f.col('customer_name'), 1, 4)).alias('customer_part_name'),
            f.col('prod_grp'),
            f.col('airport_cae'),
            f.last_day(f.col('delivery_date')).alias('period')
        ) \
            .agg(f.sum(f.col('litres')).alias('tot_vol')) \
            .select(
            f.col('rec_type'),
            f.col('customer_header'),
            f.col('customer_part_name'),
            f.col('prod_grp'),
            f.col('airport_cae'),
            f.col('period'),
            f.col('tot_vol')
        )
        # create table AC,AV
        df_table_AC = df_table_C.groupBy(
            f.col('rec_type'),
            f.col('customer_header'),
            f.upper(f.substring(f.col('customer_name'), 1, 4)).alias('customer_part_name'),
            f.col('prod_grp'),
            f.col('airport_mnmc'),
            f.year(f.col('start_date')).alias('del_year')
        ) \
            .agg(f.sum(f.col('lcl_adj_val')).alias('lcl_adj_val'),
                 f.sum(f.col('lcl_cop_val')).alias('lcl_cop_val'),
                 f.sum(f.col('lcl_lag_val')).alias('lcl_lag_val'),
                 f.sum(f.col('lcl_oic_val')).alias('lcl_oic_val'),
                 f.sum(f.col('lcl_oaf_val')).alias('lcl_oaf_val'),
                 f.sum(f.col('lcl_oav_val')).alias('lcl_oav_val'),
                 f.sum(f.col('lcl_paf_val')).alias('lcl_paf_val'),
                 f.sum(f.col('lcl_pav_val')).alias('lcl_pav_val')) \
            .select(
            f.col('rec_type'),
            f.col('customer_header'),
            f.col('customer_part_name'),
            f.col('prod_grp'),
            f.col('airport_mnmc'),
            f.col('del_year'),
            f.col('lcl_adj_val'),
            f.col('lcl_cop_val'),
            f.col('lcl_lag_val'),
            f.col('lcl_oic_val'),
            f.col('lcl_oaf_val'),
            f.col('lcl_oav_val'),
            f.col('lcl_paf_val'),
            f.col('lcl_pav_val')
        )
        df_table_AC.printSchema()
        df_table_AV = df_table_S2.filter(
            (f.col('delivery_date') <= f.col('cop_last_loaded_date'))
            & f.col('item_category').isin('1', '3')) \
            .groupBy(
            f.col('rec_type'),
            f.col('customer_header'),
            f.upper(f.substring(f.col('customer_name'), 1, 4)).alias('customer_part_name'),
            f.col('prod_grp'),
            f.col('airport_cae'),
            f.year(f.col('delivery_date')).alias('del_year')
        ) \
            .agg(f.sum(f.col('litres')).alias('tot_vol')) \
            .select(
            f.col('rec_type'),
            f.col('customer_header'),
            f.col('customer_part_name'),
            f.col('prod_grp'),
            f.col('airport_cae'),
            f.col('del_year'),
            f.col('tot_vol')
        )

        # table join and select
        df_union1 = df_table_S2.alias('S') \
            .join(df_table_MC.alias('MC'),
                  (f.col('S.rec_type') == f.col('MC.rec_type'))
                  & f.when(f.col('S.rec_type') == 'C',
                           f.col('S.customer_header') == f.col('MC.customer_header'))
                  .otherwise((f.upper(f.substring(f.col('S.customer_name'), 1, 4)) == f.col('MC.customer_part_name'))
                             & f.col('MC.customer_header').isNull())
                  & (f.col('S.prod_grp') == f.col('MC.prod_grp'))
                  & (f.col('S.airport_cae') == f.col('MC.airport_mnmc'))
                  & (f.last_day(f.col('S.delivery_date')) == f.col('MC.period')),
                  'left') \
            .join(df_table_MV.alias('MV'),
                  (f.col('S.rec_type') == f.col('MV.rec_type'))
                  & f.when(f.col('S.rec_type') == 'C',
                           f.col('S.customer_header') == f.col('MV.customer_header'))
                  .otherwise((f.upper(f.substring(f.col('S.customer_name'), 1, 4)) == f.col('MV.customer_part_name'))
                             & f.col('MV.customer_header').isNull())
                  & (f.col('S.prod_grp') == f.col('MV.prod_grp'))
                  & (f.col('S.airport_cae') == f.col('MV.airport_cae'))
                  & (f.last_day(f.col('S.delivery_date')) == f.col('MV.period')),
                  'left') \
            .join(df_table_AC.alias('AC'),
                  (f.col('S.rec_type') == f.col('AC.rec_type'))
                  & f.when(f.col('S.rec_type') == 'C',
                           f.col('S.customer_header') == f.col('AC.customer_header'))
                  .otherwise((f.upper(f.substring(f.col('S.customer_name'), 1, 4)) == f.col('AC.customer_part_name'))
                             & f.col('AC.customer_header').isNull())
                  & (f.col('S.prod_grp') == f.col('AC.prod_grp'))
                  & (f.col('S.airport_cae') == f.col('AC.airport_mnmc'))
                  & (f.year(f.col('S.delivery_date')) == f.col('AC.del_year')),
                  'left') \
            .join(df_table_AV.alias('AV'),
                  (f.col('S.rec_type') == f.col('AV.rec_type'))
                  & f.when(f.col('S.rec_type') == 'C',
                           f.col('S.customer_header') == f.col('AV.customer_header'))
                  .otherwise((f.upper(f.substring(f.col('S.customer_name'), 1, 4)) == f.col('AV.customer_part_name'))
                             & f.col('AV.customer_header').isNull())
                  & (f.col('S.prod_grp') == f.col('AV.prod_grp'))
                  & (f.col('S.airport_cae') == f.col('AV.airport_cae'))
                  & (f.year(f.col('S.delivery_date')) == f.col('AV.del_year')),
                  'left') \
            .select(
            f.col('S.*'),
            (f.coalesce(f.col('MC.lcl_adj_val'), f.lit(0)) * f.coalesce(f.col('S.litres') / f.col('MV.tot_vol'),
                                                                        f.lit(0))).alias(
                'lcl_adj_val'),
            (f.coalesce(f.col('MC.lcl_cop_val'), f.lit(0)) * f.coalesce(f.col('S.litres') / f.col('MV.tot_vol'),
                                                                        f.lit(0))).alias(
                'lcl_cop_val'),
            (f.coalesce(f.col('MC.lcl_lag_val'), f.lit(0)) * f.coalesce(f.col('S.litres') / f.col('MV.tot_vol'),
                                                                        f.lit(0))).alias(
                'lcl_lag_val'),
            (f.coalesce(f.col('AC.lcl_oic_val'), f.lit(0)) * f.coalesce(f.col('S.litres') / f.col('AV.tot_vol'),
                                                                        f.lit(0))).alias(
                'lcl_oic_val'),
            (f.coalesce(f.col('AC.lcl_oaf_val'), f.lit(0)) * f.coalesce(f.col('S.litres') / f.col('AV.tot_vol'),
                                                                        f.lit(0))).alias(
                'lcl_oaf_val'),
            (f.coalesce(f.col('AC.lcl_oav_val'), f.lit(0)) * f.coalesce(f.col('S.litres') / f.col('AV.tot_vol'),
                                                                        f.lit(0))).alias(
                'lcl_oav_val'),
            (f.coalesce(f.col('AC.lcl_paf_val'), f.lit(0)) * f.coalesce(f.col('S.litres') / f.col('AV.tot_vol'),
                                                                        f.lit(0))).alias(
                'lcl_paf_val'),
            (f.coalesce(f.col('AC.lcl_pav_val'), f.lit(0)) * f.coalesce(f.col('S.litres') / f.col('AV.tot_vol'),
                                                                        f.lit(0))).alias(
                'lcl_pav_val')
        )

        # join and filter dataframes
        df_union2 = df_table_S2.filter(f.col('delivery_date') > f.col('apc_last_loaded_date')) \
            .select(f.col('*'),
                    f.lit(0).cast('double').alias('lcl_adj_val'),
                    f.lit(0).cast('double').alias('lcl_cop_val'),
                    f.lit(0).cast('double').alias('lcl_lag_val'),
                    f.lit(0).cast('double').alias('lcl_oic_val'),
                    f.lit(0).cast('double').alias('lcl_oaf_val'),
                    f.lit(0).cast('double').alias('lcl_oav_val'),
                    f.lit(0).cast('double').alias('lcl_paf_val'),
                    f.lit(0).cast('double').alias('lcl_pav_val')
                    )

        # union All tables
        df_tfx_result = df_union1.unionAll(df_union2)
        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()

