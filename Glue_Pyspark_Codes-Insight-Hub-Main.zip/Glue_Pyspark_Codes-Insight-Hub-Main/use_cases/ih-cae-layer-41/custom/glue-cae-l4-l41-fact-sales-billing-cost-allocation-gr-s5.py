# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    20-Apr-2021     Initial version
#  0.2              Tingting Wan    28-May-2021     Change log
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_gr_s5
#                  into conform zone
# Author        :- Tingting Wan
# Date          :- 20-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from awsglue.job import Job
from functools import reduce


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l41_isp_fact_sales_billing_cost_allocation_gr_s4',
                                 'l3_isp_cost_data_gr']
        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_gr_s5"

        # print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
        #                                                                  self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table_1 = self._get_table(self.source_database, self.input_table_list[0]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[0],
        #                                                df_input_table_1.count()))
        df_input_table_2 = self._get_table(self.source_database, self.input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[1],
        #                                                df_input_table_2.count()))

        # apply transformation on the dataframe argument passed(dataframes)
        df_tfx_table = self._apply_tfx(df_input_table_1, df_input_table_2)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign all input tables
        df_table_S4 = args[0].cache()
        df_table_CST = args[1].filter(args[1].rec_type.isin('C', 'D', 'P')).cache()

        # transformation
        ## df_table_CST -- l31_isp_cost_data_gr -- REC_TYPE = 'C','D','P'
        # create table MC,MT
        df_table_MC = df_table_CST.groupBy(
            df_table_CST.airport_mnmc,
            df_table_CST.prod_grp,
            df_table_CST.end_date.alias('period')
        ) \
            .agg(f.sum(f.coalesce(df_table_CST.lcl_adj_val, f.lit(0))).alias('lcl_adj_cst'),
                 f.sum(f.coalesce(df_table_CST.lcl_cop_val, f.lit(0))).alias('lcl_cop_cst'),
                 f.sum(f.coalesce(df_table_CST.lcl_lag_val, f.lit(0))).alias('lcl_lag_cst')) \
            .select(
            f.col('airport_mnmc'),
            f.col('prod_grp'),
            f.col('period'),
            f.col('lcl_adj_cst'),
            f.col('lcl_cop_cst'),
            f.col('lcl_lag_cst')
        )

        # create table MT
        df_table_MT = df_table_S4.filter(f.col('delivery_date') <= f.col('apc_last_loaded_date')) \
            .groupBy(
            df_table_S4.airport_cae,
            df_table_S4.prod_grp,
            f.last_day(df_table_S4.delivery_date).alias('period')
        ) \
            .agg(f.sum(df_table_S4.litres).alias('litres_tot'),
                 f.sum(df_table_S4.lcl_adj_val).alias('lcl_adj_tot'),
                 f.sum(df_table_S4.lcl_cop_val).alias('lcl_cop_tot'),
                 f.sum(df_table_S4.lcl_lag_val).alias('lcl_lag_tot')
                 ) \
            .select(
            f.col('airport_cae'),
            f.col('prod_grp'),
            f.col('period'),
            f.col('litres_tot'),
            f.col('lcl_adj_tot'),
            f.col('lcl_cop_tot'),
            f.col('lcl_lag_tot')
        )
        # print("data count of df_table_T ", df_table_T.count())

        # create table AC,AT
        df_table_AC = df_table_CST.groupBy(
            df_table_CST.airport_mnmc,
            df_table_CST.prod_grp,
            f.year(f.col('start_date')).alias('del_year')
        ) \
            .agg(f.sum(f.coalesce(df_table_CST.lcl_oic_val, f.lit(0))).alias('lcl_oic_cst'),
                 f.sum(f.coalesce(df_table_CST.lcl_oaf_val, f.lit(0))).alias('lcl_oaf_cst'),
                 f.sum(f.coalesce(df_table_CST.lcl_oav_val, f.lit(0))).alias('lcl_oav_cst'),
                 f.sum(f.coalesce(df_table_CST.lcl_paf_val, f.lit(0))).alias('lcl_paf_cst'),
                 f.sum(f.coalesce(df_table_CST.lcl_pav_val, f.lit(0))).alias('lcl_pav_cst')) \
            .select(
            f.col('airport_mnmc'),
            f.col('prod_grp'),
            f.col('del_year'),
            f.col('lcl_oic_cst'),
            f.col('lcl_oaf_cst'),
            f.col('lcl_oav_cst'),
            f.col('lcl_paf_cst'),
            f.col('lcl_pav_cst')
        )

        # create table T
        df_table_AT = df_table_S4.filter(f.col('delivery_date') <= f.col('apc_last_loaded_date')) \
            .groupBy(
            df_table_S4.airport_cae,
            df_table_S4.prod_grp,
            f.year(f.col('delivery_date')).alias('del_year')
        ) \
            .agg(f.sum(df_table_S4.litres).alias('litres_tot'),
            f.sum(df_table_S4.lcl_oic_val).alias('lcl_oic_tot'),
                 f.sum(df_table_S4.lcl_oaf_val).alias('lcl_oaf_tot'),
                 f.sum(df_table_S4.lcl_oav_val).alias('lcl_oav_tot'),
                 f.sum(df_table_S4.lcl_paf_val).alias('lcl_paf_tot'),
                 f.sum(df_table_S4.lcl_pav_val).alias('lcl_pav_tot')
                 ) \
            .select(
            f.col('airport_cae'),
            f.col('prod_grp'),
            f.col('del_year'),
            f.col('litres_tot'),
            f.col('lcl_oic_tot'),
            f.col('lcl_oaf_tot'),
            f.col('lcl_oav_tot'),
            f.col('lcl_paf_tot'),
            f.col('lcl_pav_tot')
        )

        # table join and select
        df_union1 = df_table_S4.alias('S').filter(f.col('S.delivery_date') <= f.col('S.apc_last_loaded_date')) \
            .join(df_table_MC.alias('MC'),
                  (f.col('S.prod_grp') == f.col('MC.prod_grp'))
                  & (f.col('S.airport_cae') == f.col('MC.airport_mnmc'))
                  & (f.last_day(f.col('S.delivery_date')) == f.col('MC.period')),
                  'left') \
            .join(df_table_MT.alias('MT'),
                  (f.col('S.prod_grp') == f.col('MT.prod_grp'))
                  & (f.col('S.airport_cae') == f.col('MT.airport_cae'))
                  & (f.last_day(f.col('S.delivery_date')) == f.col('MT.period')),
                  'left') \
            .join(df_table_AC.alias('AC'),
                  (f.col('S.prod_grp') == f.col('AC.prod_grp'))
                  & (f.col('S.airport_cae') == f.col('AC.airport_mnmc'))
                  & (f.year(f.col('S.delivery_date')) == f.col('AC.del_year')),
                  'left') \
            .join(df_table_AT.alias('AT'),
                  (f.col('S.prod_grp') == f.col('AT.prod_grp'))
                  & (f.col('S.airport_cae') == f.col('AT.airport_cae'))
                  & (f.year(f.col('S.delivery_date')) == f.col('AT.del_year')),
                  'left') \
            .select(
            f.col('S.ref_id'),
            f.col('S.billing_document'),
            f.col('S.source_system'),
            f.col('S.billing_item'),
            f.col('S.country_mnmc'),
            f.col('S.sector'),
            f.col('S.sales_organisation'),
            f.col('S.prod_grp'),
            f.col('S.item_category'),
            f.col('S.material_number'),
            f.col('S.material_mnmc'),
            f.col('S.airport_id'),
            f.col('S.airport_mnmc'),
            f.col('S.airport_name'),
            f.col('S.customer_id'),
            f.col('S.customer_number'),
            f.col('S.customer_header'),
            f.col('S.customer_name'),
            f.col('S.fuel_point_mnmc'),
            f.col('S.fuel_point_name'),

            f.col('S.delivery_date'),
            f.col('S.billing_date'),
            f.col('S.apc_last_loaded_date'),
            f.col('S.m3'),
            f.col('S.ugl'),
            f.col('S.litres'),
            f.col('S.metric_tons'),
            f.col('S.document_currency'),
            f.col('S.local_currency'),

            f.col('S.exchange_rate'),
            f.col('S.net_value'),
            f.col('S.ile_exch_rate'),
            f.col('S.lcl_net_val'),
            f.col('S.lre_exch_rate'),
            f.col('S.usd_net_val'),
            f.col('S.rec_type'),
            f.col('S.sector_cae'),
            f.col('S.airport_cae'),
            (f.col('S.lcl_adj_val') + f.coalesce(
                (f.col('MC.lcl_adj_cst') - f.col('MT.lcl_adj_tot')) * (f.col('S.litres') / f.col('MT.litres_tot')),
                f.lit(0))).alias('lcl_adj_val'),
            (f.col('S.lcl_cop_val') + f.coalesce(
                (f.col('MC.lcl_cop_cst') - f.col('MT.lcl_cop_tot')) * (f.col('S.litres') / f.col('MT.litres_tot')),
                f.lit(0))).alias('lcl_cop_val'),
            (f.col('S.lcl_lag_val') + f.coalesce(
                (f.col('MC.lcl_lag_cst') - f.col('MT.lcl_lag_tot')) * (f.col('S.litres') / f.col('MT.litres_tot')),
                f.lit(0))).alias('lcl_lag_val'),
            (f.col('S.lcl_oic_val') + f.coalesce(
                (f.col('AC.lcl_oic_cst') - f.col('AT.lcl_oic_tot')) * (f.col('S.litres') / f.col('AT.litres_tot')),
                f.lit(0))).alias('lcl_oic_val'),
            (f.col('S.lcl_oaf_val') + f.coalesce(
                (f.col('AC.lcl_oaf_cst') - f.col('AT.lcl_oaf_tot')) * (f.col('S.litres') / f.col('AT.litres_tot')),
                f.lit(0))).alias('lcl_oaf_val'),
            (f.col('S.lcl_oav_val') + f.coalesce(
                (f.col('AC.lcl_oav_cst') - f.col('AT.lcl_oav_tot')) * (f.col('S.litres') / f.col('AT.litres_tot')),
                f.lit(0))).alias('lcl_oav_val'),
            (f.col('S.lcl_paf_val') + f.coalesce(
                (f.col('AC.lcl_paf_cst') - f.col('AT.lcl_paf_tot')) * (f.col('S.litres') / f.col('AT.litres_tot')),
                f.lit(0))).alias('lcl_paf_val'),
            (f.col('S.lcl_pav_val') + f.coalesce(
                (f.col('AC.lcl_pav_cst') - f.col('AT.lcl_pav_tot')) * (f.col('S.litres') / f.col('AT.litres_tot')),
                f.lit(0))).alias('lcl_pav_val')

        )
        # -- Future records - To be estimated records - Delivery_Date > Last_Loaded_Date
        df_union2 = df_table_S4.alias('S').filter(f.col('S.delivery_date') > f.col('S.apc_last_loaded_date')) \
            .select(
            f.col('S.ref_id'),
            f.col('S.billing_document'),
            f.col('S.source_system'),
            f.col('S.billing_item'),
            f.col('S.country_mnmc'),
            f.col('S.sector'),
            f.col('S.sales_organisation'),
            f.col('S.prod_grp'),
            f.col('S.item_category'),
            f.col('S.material_number'),
            f.col('S.material_mnmc'),
            f.col('S.airport_id'),
            f.col('S.airport_mnmc'),
            f.col('S.airport_name'),
            f.col('S.customer_id'),
            f.col('S.customer_number'),
            f.col('S.customer_header'),
            f.col('S.customer_name'),
            f.col('S.fuel_point_mnmc'),
            f.col('S.fuel_point_name'),

            f.col('S.delivery_date'),
            f.col('S.billing_date'),
            f.col('S.apc_last_loaded_date'),
            f.col('S.m3'),
            f.col('S.ugl'),
            f.col('S.litres'),
            f.col('S.metric_tons'),
            f.col('S.document_currency'),
            f.col('S.local_currency'),

            f.col('S.exchange_rate'),
            f.col('S.net_value'),
            f.col('S.ile_exch_rate'),
            f.col('S.lcl_net_val'),
            f.col('S.lre_exch_rate'),
            f.col('S.usd_net_val'),
            f.col('S.rec_type'),
            f.col('S.sector_cae'),
            f.col('S.airport_cae'),
            f.lit(0).cast('double').alias('lcl_adj_val'),
            f.lit(0).cast('double').alias('lcl_cop_val'),
            f.lit(0).cast('double').alias('lcl_lag_val'),
            f.lit(0).cast('double').alias('lcl_oic_val'),
            f.lit(0).cast('double').alias('lcl_oaf_val'),
            f.lit(0).cast('double').alias('lcl_oav_val'),
            f.lit(0).cast('double').alias('lcl_paf_val'),
            f.lit(0).cast('double').alias('lcl_pav_val')
        )
        # union All tables
        df_tfx_result = df_union1.unionAll(df_union2)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()

