# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz  Harvey     14-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to l4-l41-fact-sales-billing-cost-allocation-alro-s2
#               into conform zone
# Author        :- Liz Harvey
# Date          :- 14-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']
        # report specific =============================================

        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_alro_s2"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        # generate input table list
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, 'l3_isp_apc_alro_all').toDF()
        print("data count of table {}.{} is {}".format(source_database,
                                                       'l3_isp_apc_alro_all',
                                                       df_table_1.count()))
        df_table_2 = self._get_table(source_database, 'l41_isp_fact_sales_billing_cost_allocation_s1').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l41_isp_fact_sales_billing_cost_allocation_s1',
                                                       df_table_2.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_table_1, df_table_2):
        df_l41_gr = df_table_2.groupBy(
            f.col("country_mnmc").alias("country_mnmc"),
            f.col("airport_mnmc").alias("airport_mnmc"),
            f.to_date(f.concat(f.year(f.col("delivery_date")), f.lit("-"), f.month(f.col("delivery_date")),
                               f.lit("-01"))).alias("period")) \
            .agg(f.sum(f.col("litres")).alias("tot_vol")) \
            .filter(f.col("country_mnmc").isin("AL", "RO")) \
            .select(f.col("country_mnmc"),
                    f.col("airport_mnmc"),
                    f.col("period"),
                    f.col("tot_vol")
                    )

        df_tfx_result = df_l41_gr.alias("S").join(df_table_1.alias("C"),
                                                  (f.col("S.country_mnmc") == f.col("C.country_mnmc"))
                                                  & (f.col("S.airport_mnmc") == f.col("C.airport_mnmc"))
                                                  & (f.col("S.period") == f.col("C.period")), "right") \
            .select(f.col("C.country_mnmc"),
                    f.col("C.airport_mnmc"),
                    f.col("C.period").alias("start_of_month"),
                    (f.last_day(f.col("C.period"))).alias("end_of_month"),
                    (f.coalesce((f.col("C.oic") / f.col("S.tot_vol")), f.lit(0))).alias("oic_rate"),
                    (f.coalesce((f.col("C.paf") / f.col("S.tot_vol")), f.lit(0))).alias("paf_rate"),
                    (f.coalesce((f.col("C.pav") / f.col("S.tot_vol")), f.lit(0))).alias("pav_rate"),
                    (f.coalesce((f.col("C.oaf") / f.col("S.tot_vol")), f.lit(0))).alias("oaf_rate"),
                    (f.coalesce((f.col("C.oav") / f.col("S.tot_vol")), f.lit(0))).alias("oav_rate"),
                    (f.coalesce((f.col("C.cop") / f.col("S.tot_vol")), f.lit(0))).alias("cop_rate")
                    )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()

