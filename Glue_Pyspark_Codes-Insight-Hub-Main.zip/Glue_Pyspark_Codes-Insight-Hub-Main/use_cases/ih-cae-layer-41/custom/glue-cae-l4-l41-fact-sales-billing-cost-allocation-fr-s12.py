# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    19-Mar-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_fr_s12
#                  into conform zone
# Author        :- Tingting Wan
# Date          :- 19-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.confirm_database = args['source_database1']
        self.netapp_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l41_isp_fact_sales_billing_cost_allocation_s1',
                                 'l2_isp_location_decode_fr',
                                 'l2_isp_airport_los_decode_fr']
        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_fr_s12"


    def execute(self):

        # read data from country specific table argument passed(database, table)
        df_input_table_A = self._get_table(self.confirm_database, self.input_table_list[0]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[0],
        #                                                df_input_table_A.count()))

        df_input_table_B = self._get_table(self.netapp_database, self.input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(self.netapp_database, self.input_table_list[1],
        #                                                df_input_table_B.count()))
        df_input_table_C = self._get_table(self.netapp_database, self.input_table_list[2]).toDF()
        # print("data count of table {}.{} is {}".format(self.netapp_database, self.input_table_list[2],
        #                                                df_input_table_C.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_A, df_input_table_B, df_input_table_C)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):

        # convert all the columns alias to lower case
        df_input_table_S = args[0]
        df_input_table_C = args[1].select(
            [f.col(x).alias(x.lower()) for x in args[1].columns])
        df_input_table_L = args[2].select(
            [f.col(x).alias(x.lower()) for x in args[2].columns])

        # applying transformation
        df_tfx_result = df_input_table_S.alias('S')\
            .join(df_input_table_C.alias('C'),
                  (f.col('S.customer_number') == f.col('C.client_code')),'left') \
            .join(df_input_table_L.alias('L'),
                  (f.col('S.location_of_sale') == f.col('L.los_mnmc'))
                  & (f.length(f.col('S.airport_mnmc')) > 5), 'left') \
            .filter(f.col('S.country_mnmc') == 'FR') \
            .select(f.col('S.*'),
                    f.when(f.col('S.plant').isin('ISP_ESP0166_1660323864384', 'ISP_ESP0166_90750000058480',
                                                 'ISP_ESP0166_90750000058430', 'ISP_ESP0166_10077968010',
                                                 'ISP_ESP0166_10004294237', 'ISP_ESP0166_10000320238',
                                                 'ISP_ESP0166_10023188994', 'ISP_ESP0166_90750000058714',
                                                 'ISP_ESP0166_90750000043448', 'ISP_ESP0166_90750000058432',
                                                 'ISP_ESP0166_10000051711', 'ISP_ESP0166_90750000058722',
                                                 'ISP_ESP0166_90750000058495', 'ISP_ESP0166_90750000043446'),
                           f.when(f.col('S.location_of_sale') == '10BRIEJ-FR', f.lit('ISP_ESP0166_1660137543562'))
                           .when(f.col('S.location_of_sale') == '17STGNA-FR', f.lit('ISP_ESP0166_1660066843576'))
                           .when(f.col('S.location_of_sale') == '17STGNJ-FR', f.lit('ISP_ESP0166_1660066843576'))
                           .when(f.col('S.location_of_sale') == '22BMCS-FR', f.lit('ISP_ESP0166_1660322263544'))
                           .when(f.col('S.location_of_sale') == '30AVIGJ-FR', f.lit('ISP_ESP0166_5240000185606'))
                           .when(f.col('S.location_of_sale') == '31CUGNA-FR', f.lit('ISP_ESP0166_1660375568893'))
                           .when(f.col('S.location_of_sale') == '37BMCS-FR', f.lit('ISP_ESP0166_1660319370774'))
                           .when(f.col('S.location_of_sale') == '50GRANJ-FR', f.lit('ISP_ESP0166_5240000180896'))
                           .when(f.col('S.location_of_sale') == '56LANNB-FR', f.lit('ISP_ESP0166_1660388895114'))
                           .when(f.col('S.location_of_sale') == '65TARBE-FR', f.lit('ISP_ESP0166_1660388337393'))
                           .when(f.col('S.location_of_sale') == '66PERPI-FR', f.lit('ISP_ESP0166_1660388971118'))
                           .when(f.col('S.location_of_sale') == '76CAUDE-FR', f.lit('ISP_ESP0166_1660363992363'))
                           .when(f.col('S.location_of_sale') == '83CANET-FR', f.lit('ISP_ESP0166_5250004178874'))
                           .when(f.col('S.location_of_sale') == '83CANJU-FR', f.lit('ISP_ESP0166_1660388897666'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660330783329',
                                 f.lit('ISP_ESP0166_1660237496978'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660332298874', f.lit('ISP_ESP0166_CEQ_Bulk'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660032274905',
                                 f.lit('ISP_ESP0166_5240000181008'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250274386698',
                                 f.lit('ISP_ESP0166_1660066843576'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660032923741',
                                 f.lit('ISP_ESP0166_5240000181027'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660330808222',
                                 f.lit('ISP_ESP0166_5250004176698'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250271856521',
                                 f.lit('ISP_ESP0166_5240000181932'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660341708047',
                                 f.lit('ISP_ESP0166_1660341707704'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660296641016',
                                 f.lit('ISP_ESP0166_1660066843576'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660033059110',
                                 f.lit('ISP_ESP0166_5250004176698'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660030270797',
                                 f.lit('ISP_ESP0166_5240000180831'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250219647485',
                                 f.lit('ISP_ESP0166_5240000180839'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250219643359',
                                 f.lit('ISP_ESP0166_5240000180839'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660388342121',
                                 f.lit('ISP_ESP0166_1660388337393'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250287848779',
                                 f.lit('ISP_ESP0166_1660319370767'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660032333428',
                                 f.lit('ISP_ESP0166_5240000185606'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660319234711',
                                 f.lit('ISP_ESP0166_1660237496978'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250220065904',
                                 f.lit('ISP_ESP0166_1660137543562'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660032333499',
                                 f.lit('ISP_ESP0166_5240000181044'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660032135836',
                                 f.lit('ISP_ESP0166_5240000181940'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660038519481',
                                 f.lit('ISP_ESP0166_1660036457786'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660341708262',
                                 f.lit('ISP_ESP0166_1660341707704'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660032075638',
                                 f.lit('ISP_ESP0166_5240000180823'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250281829921',
                                 f.lit('ISP_ESP0166_5240000180839'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660224126394',
                                 f.lit('ISP_ESP0166_5250003947410'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660177085072',
                                 f.lit('ISP_ESP0166_1660176995378'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660275276869',
                                 f.lit('ISP_ESP0166_1660276278601'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660033057529',
                                 f.lit('ISP_ESP0166_5240000184227'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660344680126',
                                 f.lit('ISP_ESP0166_5240000180483'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660035423716',
                                 f.lit('ISP_ESP0166_5240000184036'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250231168235',
                                 f.lit('ISP_ESP0166_5250003947374'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660314911008',
                                 f.lit('ISP_ESP0166_1660314952544'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660332298895', f.lit('ISP_ESP0166_CEQ_Bulk'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660388897654',
                                 f.lit('ISP_ESP0166_1660388895114'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250231169030',
                                 f.lit('ISP_ESP0166_5250003947374'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660345175248',
                                 f.lit('ISP_ESP0166_5250007375897'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660032239543',
                                 f.lit('ISP_ESP0166_5240000180806'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660032277249',
                                 f.lit('ISP_ESP0166_5250007502902'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660271174651',
                                 f.lit('ISP_ESP0166_1660250627295'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_1660345173890',
                                 f.lit('ISP_ESP0166_1660108285943'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250215575641',
                                 f.lit('ISP_ESP0166_1660363992363'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250271811288',
                                 f.lit('ISP_ESP0166_5240000180839'))
                           .when(f.col('S.customer_id') == 'ISP_ESP0166_5250271887926',
                                 f.lit('ISP_ESP0166_5240000181932'))
                           .when(f.col('S.location_of_sale') == '31EDEIS-FR', f.lit('ISP_ESP0166_1660401063502'))
                           .when((f.col('S.plant') == 'ISP_ESP0166_1660323864384')
                                 & (f.year(f.col('S.delivery_date')) == 2020),
                                 f.lit('ISP_ESP0166_1660323864384'))
                           .when(f.col('S.customer_id').isin('ISP_ESP0166_1660081286690', 'ISP_ESP0166_1660162083904',
                                                             'ISP_ESP0166_1660148887823', 'ISP_ESP0166_1660162209642',
                                                             'ISP_ESP0166_1660192703521', 'ISP_ESP0166_1660271176093',
                                                             'ISP_ESP0166_1660323865215', 'ISP_ESP0166_1660364366084',
                                                             'ISP_ESP0166_1660364377561', 'ISP_ESP0166_1660388753977',
                                                             'ISP_ESP0166_1660388897722', 'ISP_ESP0166_1660391033051')
                                 & (f.col('S.material_mnmc') == 'JETA1'), f.lit('ISP_ESP0166_SEA'))
                           ).alias('airport_code1'),
                    f.when((f.length(f.col('S.airport_mnmc')) > 5)
                          & f.col('L.airport_code').isNotNull(),
                          f.col('L.airport_code'))
                    .when((f.length(f.col('S.airport_mnmc')) > 5)
                          & f.col('C.airport_code').isNotNull(),
                          f.col('C.airport_code'))
                    .when(((f.length(f.col('S.airport_mnmc')) > 5)
                          | ((f.col('S.airport_mnmc') == '76FF')
                          & (f.year(f.col('S.delivery_date')) == 2019)))
                          & f.col('C.airport_code').isNull()
                          & (f.col('S.sector') == 'Military') & (f.col('S.prod_grp') == '#JETS'),
                          f.lit('SEA'))
                    .when((f.length(f.col('S.airport_mnmc')) > 5)
                          & (f.col('S.customer_id') == 'ISP_ESP0166_5250271811288'),
                          f.lit('76BF'))
                    .when((f.length(f.col('S.airport_mnmc')) > 5)
                          & (f.col('S.customer_id') == 'ISP_ESP0166_5250271887926'),
                          f.lit('43AF'))
                    .when((f.length(f.col('S.airport_mnmc')) > 5)
                          & (f.col('S.location_of_sale') == '31EDEIS-FR'),
                          f.lit('31EF')).alias('airport_code')

                    )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
