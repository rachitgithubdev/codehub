# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      25-May-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_imi_s8
#                  into conform zone
# Author        :- Bakul Seth
# Date          :- 25-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = 'l41_isp_fact_sales_billing_cost_allocation_imi_s7'
        self.report_file = 'l41_isp_fact_sales_billing_cost_allocation_imi_s8'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):

        # read data from country specific table argument passed(database, table)
        print('reading data from source table')
        df_input = self._get_table(self.source_database, self.input_table).toDF()
        print('Schema of table {}.{} is '.format(self.source_database, self.input_table))
        df_input.printSchema()

        # apply transformation on the dataframe argument passed(dataframe)
        print('Applying transformations the source data')
        df_tfx_table = self._apply_tfx(df_input)
        print('Schema after transformation ', df_tfx_table.printSchema())

        # Write data to S3 bucket
        print('Writing final transformed data to s3 bucket')
        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table\
            .write.option('compression', 'snappy')\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(inp_table):

        inp_sum = inp_table.filter(inp_table.delivery_date <= inp_table.apc_last_loaded_date)\
            .groupBy(inp_table.airport_mnmc, f.year(inp_table.delivery_date).alias('del_year'))\
            .agg(f.sum(inp_table.lcl_oic_val).alias('lcl_oic_tot'), f.sum(inp_table.lcl_oaf_val).alias('lcl_oaf_tot'),
                 f.sum(inp_table.lcl_oav_val).alias('lcl_oav_tot'), f.sum(inp_table.lcl_paf_val).alias('lcl_paf_tot'),
                 f.sum(inp_table.lcl_pav_val).alias('lcl_pav_tot'), f.sum(inp_table.usd_oic_val).alias('usd_oic_tot'),
                 f.sum(inp_table.usd_oaf_val).alias('usd_oaf_tot'), f.sum(inp_table.usd_oav_val).alias('usd_oav_tot'),
                 f.sum(inp_table.usd_paf_val).alias('usd_paf_tot'), f.sum(inp_table.usd_pav_val).alias('usd_pav_tot'),
                 f.sum(inp_table.litres).alias('litres_tot'))\
            .select(inp_table.airport_mnmc, f.col('del_year'), f.col('lcl_oic_tot'), f.col('lcl_oaf_tot'),
                    f.col('lcl_oav_tot'), f.col('lcl_paf_tot'), f.col('lcl_pav_tot'),
                    f.col('usd_oic_tot'), f.col('usd_oaf_tot'), f.col('usd_oav_tot'), f.col('usd_paf_tot'),
                    f.col('usd_pav_tot'), f.col('litres_tot'))

        df_future = inp_table.filter((inp_table.country_mnmc.isin(['CY'])) &
                                     (inp_table.delivery_date > inp_table.apc_last_loaded_date))\
            .select(inp_table.ref_id, inp_table.billing_document, inp_table.source_system, inp_table.billing_item,
                    inp_table.country_mnmc, inp_table.sector, inp_table.prod_grp, inp_table.item_category,
                    inp_table.material_number, inp_table.material_mnmc, inp_table.airport_id, inp_table.airport_mnmc,
                    inp_table.airport_name, inp_table.customer_id, inp_table.customer_number, inp_table.customer_header,
                    inp_table.customer_name, inp_table.delivery_date, inp_table.litres, inp_table.ugl,
                    inp_table.billing_date, inp_table.document_currency, inp_table.local_currency,
                    inp_table.exchange_rate, inp_table.ile_exch_rate, inp_table.lre_exch_rate, inp_table.net_value,
                    inp_table.lcl_net_val, f.lit(0).cast('double').alias('lcl_adj_val'),
                    f.lit(0).cast('double').alias('lcl_cop_val'), f.lit(0).cast('double').alias('lcl_lag_val'),
                    f.lit(0).cast('double').alias('lcl_cso_val'), f.lit(0).cast('double').alias('lcl_oic_val'),
                    f.lit(0).cast('double').alias('lcl_oav_val'), f.lit(0).cast('double').alias('lcl_oaf_val'),
                    f.lit(0).cast('double').alias('lcl_pav_val'), f.lit(0).cast('double').alias('lcl_paf_val'),
                    inp_table.usd_net_val, f.lit(0).cast('double').alias('usd_adj_val'),
                    f.lit(0).cast('double').alias('usd_cop_val'), f.lit(0).cast('double').alias('usd_lag_val'),
                    f.lit(0).cast('double').alias('usd_cso_val'), f.lit(0).cast('double').alias('usd_oic_val'),
                    f.lit(0).cast('double').alias('usd_oav_val'), f.lit(0).cast('double').alias('usd_oaf_val'),
                    f.lit(0).cast('double').alias('usd_pav_val'), f.lit(0).cast('double').alias('usd_paf_val'),
                    f.lit(0).cast('double').alias('lcl_oic_mth'), f.lit(0).cast('double').alias('lcl_oav_mth'),
                    f.lit(0).cast('double').alias('lcl_oaf_mth'), f.lit(0).cast('double').alias('lcl_pav_mth'),
                    f.lit(0).cast('double').alias('lcl_paf_mth'), f.lit(0).cast('double').alias('usd_oic_mth'),
                    f.lit(0).cast('double').alias('usd_oav_mth'), f.lit(0).cast('double').alias('usd_oaf_mth'),
                    f.lit(0).cast('double').alias('usd_pav_mth'), f.lit(0).cast('double').alias('usd_paf_mth'))

        df_current = inp_table.alias('inp').filter((f.col('inp.country_mnmc').isin(['CY'])) &
                                                   (f.col('inp.delivery_date') <= f.col('inp.apc_last_loaded_date')))\
            .join(inp_sum.alias('sum'), ((f.col('inp.airport_mnmc') == f.col('sum.airport_mnmc')) &
                                         (f.year(f.col('inp.delivery_date')) == f.col('sum.del_year'))), 'left')\
            .select(f.col('inp.ref_id'), f.col('inp.billing_document'), f.col('inp.source_system'),
                    f.col('inp.billing_item'), f.col('inp.country_mnmc'), f.col('inp.sector'), f.col('inp.prod_grp'),
                    f.col('inp.item_category'), f.col('inp.material_number'), f.col('inp.material_mnmc'),
                    f.col('inp.airport_id'), f.col('inp.airport_mnmc'), f.col('inp.airport_name'),
                    f.col('inp.customer_id'), f.col('inp.customer_number'), f.col('inp.customer_header'),
                    f.col('inp.customer_name'), f.col('inp.delivery_date'), f.col('inp.litres'), f.col('inp.ugl'),
                    f.col('inp.billing_date'), f.col('inp.document_currency'), f.col('inp.local_currency'),
                    f.col('inp.exchange_rate'), f.col('inp.ile_exch_rate'), f.col('inp.lre_exch_rate'),
                    f.col('inp.net_value'), f.col('inp.lcl_net_val'), f.col('inp.lcl_adj_val'),
                    f.col('inp.lcl_cop_val'), f.col('inp.lcl_lag_val'), f.col('inp.lcl_cso_val'),
                    f.coalesce((f.col('sum.lcl_oic_tot') *
                                (f.col('inp.litres') / f.col('sum.litres_tot'))), f.lit(0)).alias('lcl_oic_val'),
                    f.coalesce((f.col('sum.lcl_oaf_tot') *
                                (f.col('inp.litres') / f.col('sum.litres_tot'))), f.lit(0)).alias('lcl_oaf_val'),
                    f.coalesce((f.col('sum.lcl_oav_tot') *
                                (f.col('inp.litres') / f.col('sum.litres_tot'))), f.lit(0)).alias('lcl_oav_val'),
                    f.coalesce((f.col('sum.lcl_paf_tot') *
                                (f.col('inp.litres') / f.col('sum.litres_tot'))), f.lit(0)).alias('lcl_paf_val'),
                    f.coalesce((f.col('sum.lcl_pav_tot') *
                                (f.col('inp.litres') / f.col('sum.litres_tot'))), f.lit(0)).alias('lcl_pav_val'),
                    f.col('inp.usd_net_val'), f.col('inp.usd_adj_val'), f.col('inp.usd_cop_val'),
                    f.col('inp.usd_lag_val'), f.col('inp.usd_cso_val'),
                    f.coalesce((f.col('sum.usd_oic_tot')
                                * (f.col('inp.litres') / f.col('sum.litres_tot'))), f.lit(0)).alias('usd_oic_val'),
                    f.coalesce((f.col('sum.usd_oaf_tot') *
                                (f.col('inp.litres') / f.col('sum.litres_tot'))), f.lit(0)).alias('usd_oaf_val'),
                    f.coalesce((f.col('sum.usd_oav_tot') *
                                (f.col('inp.litres') / f.col('sum.litres_tot'))), f.lit(0)).alias('usd_oav_val'),
                    f.coalesce((f.col('sum.usd_paf_tot') *
                                (f.col('inp.litres') / f.col('sum.litres_tot'))), f.lit(0)).alias('usd_paf_val'),
                    f.coalesce((f.col('sum.usd_pav_tot') *
                                (f.col('inp.litres') / f.col('sum.litres_tot'))), f.lit(0)).alias('usd_pav_val'),
                    f.col('inp.lcl_oic_val').alias('lcl_oic_mth'), f.col('inp.lcl_oaf_val').alias('lcl_oaf_mth'),
                    f.col('inp.lcl_oav_val').alias('lcl_oav_mth'), f.col('inp.lcl_paf_val').alias('lcl_paf_mth'),
                    f.col('inp.lcl_pav_val').alias('lcl_pav_mth'), f.col('inp.usd_oic_val').alias('usd_oic_mth'),
                    f.col('inp.usd_oaf_val').alias('usd_oaf_mth'), f.col('inp.usd_oav_val').alias('usd_oav_mth'),
                    f.col('inp.usd_paf_val').alias('usd_paf_mth'), f.col('inp.usd_pav_val').alias('usd_pav_mth'))

        df_tfx_result = df_current.union(df_future)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()

