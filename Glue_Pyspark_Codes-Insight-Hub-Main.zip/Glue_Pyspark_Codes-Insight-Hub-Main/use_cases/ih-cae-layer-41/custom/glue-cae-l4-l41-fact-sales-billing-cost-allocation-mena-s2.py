# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    09-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l41_isp_fact_sales_billing_cost_allocation_mena_s2a
#                  into conform zone
# Author        :- Tingting Wan
# Date          :- 09-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from awsglue.job import Job
from functools import reduce


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l41_isp_fact_sales_billing_cost_allocation_s1"
        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_mena_s2a"

        # print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
        #                                                                  self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_input_table.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table):
        # cache df_input_table
        df_input_table = df_input_table.cache()

        ## Country/Airport/Product Level for Airfield Costs + COP
        # Country Level for Airfield Costs
        df_Clvl_Aircosts = df_input_table.filter(
            df_input_table.country_mnmc.isin('AE', 'BH', 'EG', 'IQ', 'JO', 'LB', 'QL', 'OM', 'SA', 'TN')) \
            .groupBy(df_input_table.country_mnmc,
                     f.trunc(df_input_table.delivery_date, 'month').alias('start_of_month'),
                     (f.to_date(f.last_day(df_input_table.delivery_date))).alias('end_of_month')) \
            .agg(f.sum(df_input_table.ugl).alias('ugl')
                 ).select(
            f.col('country_mnmc'),
            f.lit('Default').alias('airport_mnmc'),
            f.lit('Default').alias('prod_grp'),
            f.col('start_of_month'),
            f.col('end_of_month'),
            f.col('ugl')
        )
        # print("df_Clvl_Aircosts", df_Clvl_Aircosts.count())

        # Country/Product Level for COP
        df_CPlvl_COP = df_input_table.filter(
            df_input_table.country_mnmc.isin('AE', 'BH', 'EG', 'IQ', 'JO', 'LB', 'QL', 'OM', 'SA', 'TN')
            & df_input_table.prod_grp.isin('#AVGAS', '#JETS')) \
            .groupBy(df_input_table.country_mnmc, df_input_table.prod_grp.alias('prod_grp'),
                     f.trunc(df_input_table.delivery_date, 'month').alias('start_of_month'),
                     (f.to_date(f.last_day(df_input_table.delivery_date))).alias('end_of_month')) \
            .agg(f.sum(df_input_table.ugl).alias('ugl')
                 ).select(
            f.col('country_mnmc'),
            f.lit('Default').alias('airport_mnmc'),
            f.col('prod_grp'),
            f.col('start_of_month'),
            f.col('end_of_month'),
            f.col('ugl')
        )
        # print("df_CPlvl_COP", df_CPlvl_COP.count())

        # Country/Airport Level for Airfield costs
        df_CAlvl_Aircosts = df_input_table.filter(
            df_input_table.country_mnmc.isin('AE', 'BH', 'EG', 'IQ', 'JO', 'LB', 'QL', 'OM', 'SA', 'TN')
            & (df_input_table.airport_mnmc.isin('AAN', 'AUH', 'AZI', 'DXB', 'AEMD', 'FJR', 'RKT', 'SHJ',
                                                'ALOI') == False)) \
            .groupBy(df_input_table.country_mnmc, df_input_table.airport_mnmc.alias('airport_mnmc'),
                     f.trunc(df_input_table.delivery_date, 'month').alias('start_of_month'),
                     (f.to_date(f.last_day(df_input_table.delivery_date))).alias('end_of_month')) \
            .agg(f.sum(df_input_table.ugl).alias('ugl')
                 ).select(
            f.col('country_mnmc'),
            f.col('airport_mnmc'),
            f.lit('Default').alias('prod_grp'),
            f.col('start_of_month'),
            f.col('end_of_month'),
            f.col('ugl')
        )
        # print("df_CAlvl_Aircosts", df_CAlvl_Aircosts.count())
        # Country/Airport/Product Level for COP
        df_CAPlvl_COP = df_input_table.filter(
            df_input_table.country_mnmc.isin('AE', 'BH', 'EG', 'IQ', 'JO', 'LB', 'QL', 'OM', 'SA', 'TN')
            & df_input_table.prod_grp.isin('#AVGAS', '#JETS')
            & (df_input_table.airport_mnmc.isin('AAN', 'AUH', 'AZI', 'DXB', 'FJR', 'AEMD', 'ALOI', 'RKT',
                                                'SHJ') == False)) \
            .groupBy(df_input_table.country_mnmc, df_input_table.airport_mnmc,
                     df_input_table.prod_grp.alias('prod_grp'),
                     f.trunc(df_input_table.delivery_date, 'month').alias('start_of_month'),
                     (f.to_date(f.last_day(df_input_table.delivery_date))).alias('end_of_month')) \
            .agg(f.sum(df_input_table.ugl).alias('ugl')
                 ).select(
            f.col('country_mnmc'),
            f.col('airport_mnmc'),
            f.col('prod_grp'),
            f.col('start_of_month'),
            f.col('end_of_month'),
            f.col('ugl')
        )
        # print("df_CAPlvl_COP", df_CAPlvl_COP.count())

        ## DXB - Dubai Airports
        # Country/Airport Level for Airfield costs - DXB - Dubai Airports
        df_CAlvl_Aircosts_DXB = df_input_table.filter(
            df_input_table.country_mnmc.isin('AE')
            & df_input_table.airport_mnmc.isin('DXB', 'AEMD')) \
            .groupBy(df_input_table.country_mnmc,
                     f.trunc(df_input_table.delivery_date, 'month').alias('start_of_month'),
                     (f.to_date(f.last_day(df_input_table.delivery_date))).alias('end_of_month')) \
            .agg(f.sum(df_input_table.ugl).alias('ugl')
                 ).select(
            f.col('country_mnmc'),
            f.lit('DXB').alias('airport_mnmc'),
            f.lit('Default').alias('prod_grp'),
            f.col('start_of_month'),
            f.col('end_of_month'),
            f.col('ugl')
        )
        # print("df_CAlvl_Aircosts_DXB", df_CAlvl_Aircosts_DXB.count())

        # Country/Airport/Product Level for COP - DXB - Dubai Airports
        df_CAPlvl_COP_DXB = df_input_table.filter(
            df_input_table.country_mnmc.isin('AE')
            & df_input_table.airport_mnmc.isin('DXB', 'AEMD')
            & df_input_table.prod_grp.isin('#AVGAS', '#JETS')) \
            .groupBy(df_input_table.country_mnmc, df_input_table.prod_grp.alias('prod_grp'),
                     f.trunc(df_input_table.delivery_date, 'month').alias('start_of_month'),
                     (f.to_date(f.last_day(df_input_table.delivery_date))).alias('end_of_month')) \
            .agg(f.sum(df_input_table.ugl).alias('ugl')
                 ).select(
            f.col('country_mnmc'),
            f.lit('DXB').alias('airport_mnmc'),
            f.col('prod_grp'),
            f.col('start_of_month'),
            f.col('end_of_month'),
            f.col('ugl')
        )
        # print("df_CAPlvl_COP_DXB", df_CAPlvl_COP_DXB.count())

        ## SHJ - Sharja Airports
        # Country/Airport Level for Airfield costs - SHJ - Sharja Airports
        df_CAlvl_Aircosts_SHJ = df_input_table.filter(
            df_input_table.country_mnmc.isin('AE')
            & df_input_table.airport_mnmc.isin('ALOI', 'SHJ')) \
            .groupBy(df_input_table.country_mnmc,
                     f.trunc(df_input_table.delivery_date, 'month').alias('start_of_month'),
                     (f.to_date(f.last_day(df_input_table.delivery_date))).alias('end_of_month')) \
            .agg(f.sum(df_input_table.ugl).alias('ugl')
                 ).select(
            f.col('country_mnmc'),
            f.lit('SHJ').alias('airport_mnmc'),
            f.lit('Default').alias('prod_grp'),
            f.col('start_of_month'),
            f.col('end_of_month'),
            f.col('ugl')
        )
        # print("df_CAlvl_Aircosts_SHJ", df_CAlvl_Aircosts_SHJ.count())

        # Country/Airport/Product Level for COP - SHJ - Sharja Airports
        df_CAPlvl_COP_SHJ = df_input_table.filter(
            df_input_table.country_mnmc.isin('AE')
            & df_input_table.airport_mnmc.isin('ALOI', 'SHJ')
            & df_input_table.prod_grp.isin('#AVGAS', '#JETS')) \
            .groupBy(df_input_table.country_mnmc, df_input_table.prod_grp.alias('prod_grp'),
                     f.trunc(df_input_table.delivery_date, 'month').alias('start_of_month'),
                     (f.to_date(f.last_day(df_input_table.delivery_date))).alias('end_of_month')) \
            .agg(f.sum(df_input_table.ugl).alias('ugl')
                 ).select(
            f.col('country_mnmc'),
            f.lit('SHJ').alias('airport_mnmc'),
            f.col('prod_grp'),
            f.col('start_of_month'),
            f.col('end_of_month'),
            f.col('ugl')
        )
        # print("df_CAPlvl_COP_SHJ", df_CAPlvl_COP_SHJ.count())

        ## ADNOC - Abu Dhabi Airports
        # Country/Airport Level for Airfield costs - ADNOC - Abu Dhabi Airports
        df_CAlvl_Aircosts_ADNOC = df_input_table.filter(
            df_input_table.country_mnmc.isin('AE')
            & df_input_table.airport_mnmc.isin('AAN', 'AUH', 'AZI', 'FJR', 'RKT')) \
            .groupBy(df_input_table.country_mnmc,
                     f.trunc(df_input_table.delivery_date, 'month').alias('start_of_month'),
                     (f.to_date(f.last_day(df_input_table.delivery_date))).alias('end_of_month')) \
            .agg(f.sum(df_input_table.ugl).alias('ugl')
                 ).select(
            f.col('country_mnmc'),
            f.lit('ADNOC').alias('airport_mnmc'),
            f.lit('Default').alias('prod_grp'),
            f.col('start_of_month'),
            f.col('end_of_month'),
            f.col('ugl')
        )
        # print("df_CAlvl_Aircosts_ADNOC", df_CAlvl_Aircosts_ADNOC.count())

        # Country/Airport/Product Level for COP - ADNOC - Abu Dhabi Airports
        df_CAPlvl_COP_ADNOC = df_input_table.filter(
            df_input_table.country_mnmc.isin('AE')
            & df_input_table.airport_mnmc.isin('AAN', 'AUH', 'AZI', 'FJR', 'RKT')
            & df_input_table.prod_grp.isin('#AVGAS', '#JETS')) \
            .groupBy(df_input_table.country_mnmc, df_input_table.prod_grp.alias('prod_grp'),
                     f.trunc(df_input_table.delivery_date, 'month').alias('start_of_month'),
                     (f.to_date(f.last_day(df_input_table.delivery_date))).alias('end_of_month')) \
            .agg(f.sum(df_input_table.ugl).alias('ugl')
                 ).select(
            f.col('country_mnmc'),
            f.lit('ADNOC').alias('airport_mnmc'),
            f.col('prod_grp'),
            f.col('start_of_month'),
            f.col('end_of_month'),
            f.col('ugl')
        )

        # print("df_CAPlvl_COP_ADNOC", df_CAPlvl_COP_ADNOC.count())

        # Union all the Dataframes and get the distinct values
        df_list = [df_Clvl_Aircosts, df_CPlvl_COP,
                   df_CAlvl_Aircosts, df_CAPlvl_COP,
                   df_CAlvl_Aircosts_DXB, df_CAPlvl_COP_DXB,
                   df_CAlvl_Aircosts_SHJ, df_CAPlvl_COP_SHJ,
                   df_CAlvl_Aircosts_ADNOC, df_CAPlvl_COP_ADNOC]

        # print('Union all the Dataframes and get the distinct values')
        df_tfx_result = reduce(DataFrame.unionAll, df_list).distinct()

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
