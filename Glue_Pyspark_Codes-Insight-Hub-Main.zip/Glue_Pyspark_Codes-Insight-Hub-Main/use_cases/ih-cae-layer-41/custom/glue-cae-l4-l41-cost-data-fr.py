# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    22-Mar-2021      Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l41_cost_data_fr into conform zone
# Author        :- Tingting Wan
# Date          :- 22-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql import DataFrame
from functools import reduce
import calendar


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.conform_database = args['source_database1']
        self.netapp_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l3_isp_cost_data_fr', 'l2_isp_man_adj_fr']
        self.report_file = "l41_cost_data_fr"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):

        # read data
        df_input_table = self._get_table(self.conform_database, self.input_table_list[0]).toDF()
        # print(
        #     "data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[0], df_input_table.count()))

        df_union_table = self._get_table(self.netapp_database, self.input_table_list[1]).toDF()
        # print(
        #     "data count of table {}.{} is {}".format(self.netapp_database, self.input_table_list[1], df_union_table.count()))

        tran_latest_dfs = []
        # Generate month wise inner table
        for month_idx in range(1, 13):
            # apply transformation on the dataframe argument passed(dataframe, month_idx)
            df_inner_table = self.apply_tfx_inner(df_input_table, month_idx)
            # Append each dataframe to list.
            tran_latest_dfs.append(df_inner_table)

        final_result_df = reduce(DataFrame.unionByName, tran_latest_dfs)
        # apply transformation on the main dataframe argument passed
        df_tfx_table = self._apply_tfx(final_result_df, df_union_table)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    def apply_tfx_inner(self, df_input_table, month_idx):

        # convert all the columns alias to lower case
        df_input_table = df_input_table.select([f.col(x).alias(x.lower()) for x in df_input_table.columns])
        month = calendar.month_abbr[month_idx].lower()

        # get cost_month string
        if month_idx <= 9:
            cost_month = '0' + str(month_idx)
        else:
            cost_month = str(month_idx)
        # print('cost_month', cost_month)

        # transformation
        df_tfx_result = df_input_table.select(
            df_input_table.cost_year.cast('int'),
            f.concat(df_input_table.cost_year.cast('int'), f.lit(cost_month)).cast('int').alias('cost_month'),
            df_input_table.cost_category,
            df_input_table.cost_sub_category,
            df_input_table.product,
            df_input_table.customer,
            df_input_table.sector,
            df_input_table.plant,
            f.col(month).alias('cost_value')
        )

        return df_tfx_result

    @staticmethod
    def _apply_tfx(df_inner_table, df_union_table):

        # convert all the columns alias to lower case
        df_union_table = df_union_table.select([f.col(x).alias(x.lower()) for x in df_union_table.columns])

        # transformation
        # creat outer table
        df_outer_table = df_inner_table.filter(
            df_inner_table.cost_category.isin('01.01 - Volumes', '02 - Turnover', '03 - COP', '05 - Airport Fees',
                                              '09 - Other Income', '10 - PreVAR', '11 - PreFIX', '14 - OnVAR',
                                              '15 - OnFIX')) \
            .groupBy(
            df_inner_table.cost_year,
            df_inner_table.cost_month,
            df_inner_table.cost_category,
            df_inner_table.cost_sub_category,
            df_inner_table.product,
            df_inner_table.plant
        ) \
            .agg(
            f.sum(df_inner_table.cost_value).alias('cost_value')
        ).select(
            f.col('cost_year').cast('int'),
            f.col('cost_month').cast('int'),
            f.col('cost_category'),
            f.col('cost_sub_category'),
            f.col('product'),
            f.col('plant'),
            f.col('cost_value')
        )

        # create union table
        df_union_table = df_union_table.select(
            df_union_table.cost_year.cast('int'),
            df_union_table.cost_month.cast('int'),
            f.lit('Manual Adjustment').alias('cost_category'),
            f.lit('Manual Adjustment').alias('cost_sub_category'),
            df_union_table.product,
            df_union_table.plant,
            df_union_table.cost_value
        )

        # union all outer and union tables
        df_tfx_result = df_outer_table.union(df_union_table)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
