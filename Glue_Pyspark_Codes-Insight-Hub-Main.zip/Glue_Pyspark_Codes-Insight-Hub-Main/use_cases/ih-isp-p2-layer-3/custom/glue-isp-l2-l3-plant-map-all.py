# ================================Revision History=================================================
# #
#  Change Version,  Change Author,         Change Date,    Change Component
#  0.1              Arvind Shrivastava    08-Mar-2021      Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_plant_map-all into conform zone. This is a pre-requisite for South-Africa and Mozambique cae glue job
# Author        :- Arvind Shrivastava
# Date          :- 08-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'country_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.netapp_database = args['source_database1']
        self.source_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l2_isp_plant_map_za', 'l2_isp_port_plant', 'l2_isp_loc_location','l2_isp_cust_acct','l2_isp_mtl_art_material']
        self.report_file = "l3_isp_plant_map_all"

        # generic variables  ===========================================
        self.country = 'za'
        self.country_database = args['country_database']

        # Create country and database map
        self.country_database_map = dict(map(lambda x: x.split('='), self.country_database.split(',')))

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):

        # generate input tables

        df_input_table_M = self._get_table(self.netapp_database, self.input_table_list[0]).toDF()
        print("data count of table {}.{} is {}".format(self.netapp_database, self.input_table_list[0],
                                                       df_input_table_M.count()))

        # get country database and table
        country = self.country
        country_database = self.source_database + "_" + self.country_database_map[country]
        country_table_list = [input_table + "_" + country for input_table in self.input_table_list[1:]]

        # read data from country specific table argument passed(database, table)
        df_input_table_A = self._get_table(country_database, country_table_list[0]).toDF()
        #print("data count of table {}.{} is {}".format(country_database, country_table_list[0], df_input_table_A.count()))
        #
        df_input_table_L = self._get_table(country_database, country_table_list[1]).toDF()
        #print("data count of table {}.{} is {}".format(country_database, country_table_list[1], df_input_table_L.count()))
        #
        df_input_table_C = self._get_table(country_database, country_table_list[2]).toDF()
        #print("data count of table {}.{} is {}".format(country_database, country_table_list[2], df_input_table_C.count()))
        #
        df_input_table_P = self._get_table(country_database, country_table_list[3]).toDF()
        #print("data count of table {}.{} is {}".format(country_database, country_table_list[3], df_input_table_P.count()))
        #

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_M, df_input_table_A, df_input_table_L, df_input_table_C, df_input_table_P)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):

        # convert all the columns alias to lower case
        df_input_table_M = args[0].select(
            [f.col(x).alias(x.lower()) for x in args[0].columns])
        df_input_table_A = args[1].select(
            [f.col(x).alias(x.lower()) for x in args[1].columns])
        df_input_table_L = args[2].select(
            [f.col(x).alias(x.lower()) for x in args[2].columns])
        df_input_table_C = args[3].select(
            [f.col(x).alias(x.lower()) for x in args[3].columns])
        df_input_table_P = args[4].select(
            [f.col(x).alias(x.lower()) for x in args[4].columns])


        # transformation logic for plant map all

        df_tfx_result = df_input_table_M.alias('M').join(df_input_table_A.alias('A'), f.col('A.mnmc') == f.col('M.airport'),'left') \
            .join(df_input_table_L.alias('L'), f.col('L.mnmc') == f.col('M.airport'),'left') \
            .join(df_input_table_C.alias('C'), f.col('C.global_acct_ref_num') == f.col('M.customer'), 'inner') \
            .join(df_input_table_P.alias('P'), f.col('P.mnmc') == f.col('M.product'), 'inner') \
            .select(
            f.concat(f.col('C.source_system'), f.lit('_'), f.col('C.id')).alias('cus_id'),
            f.col('M.customer').alias('cus_grn'),
            f.concat(f.col('P.source_system'), f.lit('_'), f.col('P.id')).alias('material_number'),
            f.col('M.product').alias('material_mnmc'),
            f.when((f.col('A.id').isNotNull()),(f.concat(f.col('A.source_system'), f.lit('_'), f.col('A.id'))))
                .when((f.col('L.id').isNotNull()),(f.concat(f.col('L.source_system'), f.lit('_'), f.col('L.id'))))
                .alias('plant_id'),
            f.col('M.airport').alias('plant_mnmc')
        )

        return df_tfx_result

if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
