# ================================Revision History=====================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      29-Apr-2021     Initial version
# =====================================================================================================
# Description   :- The aim of the code is to generate table l5_prot_summary
#                  into conform zone
# Author        :- Liz Harvey
# Date          :- 29-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ====================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l4_prot_fact_sales_billing', 'l4_prot_dim_customer',
                                 'l4_prot_dim_location']
        self.report_file = 'l5_prot_summary'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database,
                                                                         self.input_table_list,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table_1 = self._get_table(self.source_database, self.input_table_list[0]).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[0],
                                                       df_input_table_1.count()))
        df_input_table_2 = self._get_table(self.source_database, self.input_table_list[1]).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[1],
                                                       df_input_table_2.count()))
        df_input_table_3 = self._get_table(self.source_database, self.input_table_list[2]).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[2],
                                                       df_input_table_3.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_1, df_input_table_2, df_input_table_3)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table_1, df_input_table_2, df_input_table_3):
        w = Window.partitionBy(df_input_table_1.billing_document).orderBy(df_input_table_1.billing_document,
                                                                          df_input_table_1.sales_document,
                                                                          df_input_table_1.sales_document_item)

        df_tfx_result = df_input_table_1.alias("A").join(df_input_table_2.alias("B"),
                                                         f.col("A.soldto_party") == f.col("B.erp_id"), "left") \
            .join(df_input_table_3.alias("LOC"), f.col("A.plant") == f.col("LOC.plant"), "left") \
            .filter(f.col("A.f2_fimp") == "S") \
            .withColumn("billing_item", row_number().over(w)) \
            .select(f.col("A.delivery_method").alias("delivery_method"),
                    f.col("A.pricing_date").alias("pricing_date"),
                    f.col("A.billing_date").alias("billing_date"),
                    f.col("A.delivery_date").alias("delivery_date"),
                    f.col("B.customer_country").alias("customer_country"),
                    f.col("B.grn_header").alias("grn_header"),
                    f.col("B.customer_account_name").alias("customer_account_name"),
                    f.col("B.grn").alias("grn"),
                    f.col("LOC.location_manager").alias("account_manager"),
                    f.col("B.sector").alias("sector"),
                    f.lit("BRA").alias("source_system"),
                    f.col("A.sales_organisation").alias("sales_organisation"),
                    f.col("A.sales_document").alias("sales_document"),
                    f.col("A.reference_document").alias("delivery_number"),
                    f.col("A.material_number").alias("material_number"),
                    f.col("A.material_description").alias("material_description"),
                    f.col("A.local_material_description").alias("local_material_description"),
                    f.col("A.billing_document").alias("billing_document"),
                    f.col("billing_item").cast("string"),
                    f.col("A.local_currency").alias("local_currency"),
                    f.col("A.m3").alias("qty_in_m3"),
                    f.col("A.ugl").alias("qty_in_usg"),
                    f.col("A.litres").alias("qty_in_litres"),
                    f.col("A.net_value").alias("net_value"),
                    f.col("A.document_currency").alias("document_currency"),
                    f.col("A.flight_number").alias("flight_number"),
                    f.col("A.aircraft_registration").alias("aircraft_registration"),
                    f.col("A.ref_id").alias("cost_element_key"),
                    f.col("A.soldto_party").alias("trx_cust_key"),
                    f.col("B.erp_id").alias("dim_cust_key"),
                    (f.when(f.col("A.plant") == "CFB", "CFB")
                     .when(f.substring(f.col("A.soldto_party"), 1, 6) == "CGR068", "CFB")
                     .when(f.col("A.soldto_party") == 'CGM43601', 'CGB')
                     .when(f.col("A.soldto_party") == 'CGJ12201', 'CPR')
                     .when(f.col("A.soldto_party") == 'CGB04101', 'DAM')
                     .when(f.col("A.soldto_party") == 'CGP09601', 'DJD')
                     .when(f.col("A.soldto_party") == 'CGV22701', 'GYN')
                     .when(f.col("A.soldto_party") == 'CGC53501', 'IGU')
                     .when(f.col("A.soldto_party") == 'CGJ11901', 'JCR')
                     .when(f.col("A.soldto_party") == 'CGJ08001', 'MEA')
                     .when(f.col("A.soldto_party") == 'CGP10801', 'MGF')
                     .when(f.col("A.soldto_party") == 'CGJ10601', 'PLU')
                     .when(f.col("A.soldto_party") == 'CGJ10604', 'PLU')
                     .when(f.col("A.soldto_party") == 'CGP10301', 'RAO')
                     .when(f.col("A.soldto_party") == 'CGP11201', 'SP2')
                     .when(f.col("A.soldto_party") == 'CGJ09701', 'VIX')
                     .otherwise(f.col("A.plant"))).alias("trx_loc_key"),
                    f.col("a.material_number").alias("trx_pro_key"),
                    f.col("a.material_number").alias("dim_pro_key"),
                    f.col("a.payer").alias("payer"),
                    f.col("a.soldto_party").alias("soldto_party"),
                    (f.current_date()).alias("last_modified_date"),
                    f.col("b.customer_country").alias("billto_customer_country"),
                    f.col("b.grn_header").alias("billto_grn_header"),
                    f.col("b.customer_account_name").alias("billto_customer_account_name"),
                    f.col("b.grn").alias("billto_grn"),
                    f.col("loc.location_manager").alias("billto_account_manager"),
                    f.col("b.sector").alias("billto_sector"),
                    f.col("b.erp_id").alias("dim_billto_key"),
                    f.col("a.soldto_party").alias("trx_billto_key"),
                    f.col("b.customer_country").alias("payer_customer_country"),
                    f.col("b.grn_header").alias("payer_grn_header"),
                    f.col("b.customer_account_name").alias("payer_customer_account_name"),
                    f.col("b.grn").alias("payer_grn"),
                    f.col("loc.location_manager").alias("payer_account_manager"),
                    f.col("b.sector").alias("payer_sector"),
                    f.col("b.erp_id").alias("dim_payer_key"),
                    f.col("a.soldto_party").alias("trx_payer_key"))

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()



