# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    25-Mar-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to l4_prot_dim_customer into conform zone
# Author        :- Tingting Wan
# Date          :- 25-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l3_prot_sa1010_customers"
        self.report_file = "l4_prot_dim_customer"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_input_table.count()))

        # apply transformation on the dataframe argument passed(dataframe)
        df_tfx_table = self._apply_tfx(df_input_table)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table):

        # transformation
        df_tfx_result = df_input_table.select(
            df_input_table.a1_xgref.alias('grn'),
            f.substring(df_input_table.a1_xgref, 1, 5).alias('grn_header'),
            f.substring(df_input_table.a1_xgref, 6, 2).alias('grn_subaccount'),
            f.lit('BRA').alias('source_system'),
            f.concat(df_input_table.a1_cod, df_input_table.a1_loja).alias('erp_id'),
            f.concat(f.lit('BRA'),df_input_table.a1_cod, df_input_table.a1_loja).alias('ref_erp_id'),
            f.lit('').alias('isp_id'),
            f.lit('').alias('isp_sold_to'),
            f.lit('').alias('isp_bill_to'),
            f.lit('').alias('isp_payer'),
            f.lit('').alias('mdm_partner_id'),
            f.lit('').alias('sold_to_mdm_id'),
            f.lit('').alias('bill_to_mdm_id'),
            f.lit('').alias('payer_mdm_id'),
            df_input_table.a1_tipo.alias('customer_type'),
            df_input_table.a1_grptrib.alias('bra_customer_trans_type'),
            f.lit('').alias('subaccount_reason'),
            f.lit('').alias('duns_number'),
            f.lit('01').alias('sales_organisation'),
            f.lit('').alias('isp_work_group'),
            df_input_table.a1_cod.alias('customer_group'),
            df_input_table.a1_nome.alias('customer_account_name'),
            df_input_table.a1_pais.alias('customer_country_key'),
            f.lit('Brazil').alias('customer_country'),
            df_input_table.a1_end.alias('street'),
            df_input_table.a1_mun.alias('city'),
            df_input_table.a1_cep.alias('postal_code'),
            df_input_table.a1_est.alias('state'),
            f.lit('').alias('website'),
            df_input_table.a1_cgc.alias('vat_reg_no'),
            f.lit('').alias('division'),
            f.lit('').alias('distribution_channel'),
            f.lit('').alias('airline_code'),
            f.lit('').alias('collection_country'),
            f.when(df_input_table.a1_xcobint == 'S', f.lit('International'))
                .when(df_input_table.a1_xcobint == 'N', f.lit('Local')).alias('collection_int_local_ind'),
            df_input_table.a1_xmcob.alias('currency'),
            f.lit('').alias('account_manager'),
            f.when(df_input_table.a1_xsegm == 'CA',f.lit('Commercial Airlines'))
                .when(df_input_table.a1_xsegm == 'GA',f.lit('General Aviation'))
                .when(df_input_table.a1_xsegm == 'MIL',f.lit('Military'))
                .when(df_input_table.a1_xsegm == 'DOD',f.lit('Partner'))
                .otherwise(f.lit('NO_PARENT_SECTOR')).alias('sector'),
            df_input_table.a1_cod.alias('group'),
            f.lit('').alias('carrier'),
            f.lit('').alias('end_date_isp'),
            f.lit('').alias('end_date_sap'),
            df_input_table.a1_inscr.alias('bra_state_tax_number'),
            df_input_table.a1_inscrm.alias('bra_city_tax_number'),
            df_input_table.a1_cnae.alias('bra_economic_activity_code'),
            df_input_table.a1_xcliscc.alias('bra_stirling_card_ind'),
            df_input_table.a1_cond.alias('bra_payment_condition'),
            f.substring(df_input_table.a1_cond, 2, 2).alias('bra_payment_terms'),
            f.substring(df_input_table.a1_cond, 1, 1).alias('bra_invoice_frequency'),
            df_input_table.a1_sativ1.alias('bra_dodo_code'),
            f.lit('').alias('regional_account_manager'),
            f.date_format(f.current_timestamp(), 'yyyyMMddHHmmss').alias('infa_ext_dt')
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()
