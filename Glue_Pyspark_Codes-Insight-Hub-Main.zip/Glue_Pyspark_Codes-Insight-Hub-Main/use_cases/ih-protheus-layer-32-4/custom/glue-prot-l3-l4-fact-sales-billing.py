# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    25-Mar-2021     Initial version
#  0.2              Liz Harvey      14-May-2021     Change log
# =================================================================================================
# Description   :- The aim of the code is to l4_prot_fact_sales_billing into conform zone
# Author        :- Tingting Wan
# Date          :- 25-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================

        self.report_file = "l4_prot_fact_sales_billing"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        # generate input table list
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, 'l32_prot_fiscal_doc').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l32_prot_fiscal_doc',
                                                       df_table_1.count()))
        df_table_2 = self._get_table(source_database, 'l32_prot_finance_doc').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l32_prot_finance_doc',
                                                       df_table_2.count()))
        df_table_3 = self._get_table(source_database, 'l3_prot_sc5010_goods_issue_hdr').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l3_prot_sc5010_goods_issue_hdr',
                                                       df_table_3.count()))
        df_table_4 = self._get_table(source_database, 'l3_prot_zb0010_delivery_ticket').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l3_prot_zb0010_delivery_ticket',
                                                       df_table_4.count()))
        df_table_5 = self._get_table(source_database, 'l3_prot_sa1010_customers').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l3_prot_sa1010_customers',
                                                       df_table_5.count()))
        df_table_6 = self._get_table(source_database, 'l3_prot_zh1010_locations').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l3_prot_zh1010_locations',
                                                       df_table_6.count()))
        df_table_7 = self._get_table(source_database, 'l3_prot_sx5010_descriptions').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l3_prot_sx5010_descriptions',
                                                       df_table_7.count()))
        df_table_8 = self._get_table(source_database, 'l3_prot_sm2010_currency').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l3_prot_sm2010_currency',
                                                       df_table_8.count()))
        df_table_9 = self._get_table(source_database, 'l3_prot_sb1010_products').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l3_prot_sb1010_products',
                                                       df_table_9.count()))
        df_table_10 = self._get_table(source_database, 'l3_prot_sd1010_goods_received_itm').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l3_prot_sd1010_goods_received_itm',
                                                       df_table_10.count()))
        df_table_11 = self._get_table(source_database, 'l3_prot_se1010_finance_doc').toDF()
        print("data count of table {}.{} is {}".format(source_database, 'l3_prot_se1010_finance_doc',
                                                       df_table_11.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2, df_table_3, df_table_4, df_table_5, df_table_6,
                                       df_table_7, df_table_8, df_table_9, df_table_10, df_table_11)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign all input tables
        # L32
        df_l32_fiscal_doc = args[0]
        df_l32_finance_doc = args[1]
        # L3 -- table 1
        df_l3_sc5010_goods_issue_hdr = args[2]
        df_l3_zb0010_delivery_ticket = args[3]
        df_l3_sa1010_customers = args[4]
        df_l3_zh1010_locations = args[5]
        df_l3_sx5010_descriptions = args[6]
        df_l3_sm2010_currency = args[7]
        df_l3_sb1010_products = args[8]
        # L3 -- table2
        df_l3_sd1010_goods_received_itm = args[9]
        df_l3_se1010_finance_doc = args[10]

        # join and filter dataframes
        # create table 1
        df_table_1 = df_l32_fiscal_doc.join(df_l32_finance_doc,
                                            (df_l32_fiscal_doc.d2_filial == df_l32_finance_doc.nf_filorig)
                                            & (df_l32_fiscal_doc.d2_doc == df_l32_finance_doc.nf_num)
                                            & (df_l32_fiscal_doc.d2_cliente == df_l32_finance_doc.nf_cliente)
                                            & (df_l32_fiscal_doc.d2_loja == df_l32_finance_doc.nf_loja), 'inner') \
            .join(df_l3_sc5010_goods_issue_hdr,
                  (df_l3_sc5010_goods_issue_hdr.c5_filial == df_l32_fiscal_doc.d2_filial)
                  & (df_l3_sc5010_goods_issue_hdr.c5_nota == df_l32_fiscal_doc.d2_doc)
                  & (df_l3_sc5010_goods_issue_hdr.c5_cliente == df_l32_fiscal_doc.d2_cliente)
                  & (df_l3_sc5010_goods_issue_hdr.c5_lojacli == df_l32_fiscal_doc.d2_loja)
                  & (df_l3_sc5010_goods_issue_hdr.c5_num == df_l32_fiscal_doc.d2_pedido), 'left') \
            .join(df_l3_zb0010_delivery_ticket,
                  (df_l3_zb0010_delivery_ticket.zb0_filial == df_l32_fiscal_doc.d2_filial)
                  & (df_l3_zb0010_delivery_ticket.zb0_numce == df_l3_sc5010_goods_issue_hdr.c5_xnumce)
                  & (df_l32_fiscal_doc.d2_cliente == df_l3_zb0010_delivery_ticket.zb0_codcli)
                  & (df_l32_fiscal_doc.d2_loja == df_l3_zb0010_delivery_ticket.zb0_lojcli), 'left') \
            .join(df_l3_sa1010_customers,
                  (df_l3_sa1010_customers.a1_cod == df_l3_sc5010_goods_issue_hdr.c5_cliente)
                  & (df_l3_sa1010_customers.a1_loja == df_l3_sc5010_goods_issue_hdr.c5_lojacli), 'left') \
            .join(df_l3_zh1010_locations,
                  df_l32_fiscal_doc.d2_filial == df_l3_zh1010_locations.zh1_filial, 'left') \
            .join(df_l3_sx5010_descriptions,
                  (df_l3_sx5010_descriptions.x5_tabela == '05')
                  & (df_l3_sx5010_descriptions.x5_chave == df_l32_finance_doc.nf_tipo), 'left') \
            .join(df_l3_sm2010_currency,
                  f.coalesce(f.when(
                      (df_l3_zb0010_delivery_ticket.zb0_numce == '') | df_l3_zb0010_delivery_ticket.zb0_numce.isNull(),
                      df_l3_sc5010_goods_issue_hdr.c5_emissao)
                             .otherwise(df_l3_zb0010_delivery_ticket.zb0_dtemis),
                             df_l32_fiscal_doc.d2_emissao) == df_l3_sm2010_currency.m2_data, 'left') \
            .join(df_l3_sb1010_products, df_l32_fiscal_doc.d2_cod == df_l3_sb1010_products.b1_cod, 'left') \
            .filter(df_l32_fiscal_doc.d2_cod.isin('A08240N', 'A08601E', 'A08601N', '000210', 'A999999', 'P5000')
                    & (f.concat(f.date_format(df_l32_fiscal_doc.d2_emissao, 'YYYY'),
                                f.date_format(df_l32_fiscal_doc.d2_emissao, 'MM')).cast('int') > 201703)) \
            .select(
            df_l32_fiscal_doc.d2_filial,
            df_l32_finance_doc.nf_num.alias('billing_document'),
            f.concat(df_l32_finance_doc.nf_num, f.lit('_'), df_l32_fiscal_doc.d2_doc, f.lit('_'),
                     df_l32_fiscal_doc.d2_item, f.lit('_'), df_l3_zh1010_locations.zh1_iata, f.lit('_'),
                     (f.concat(df_l32_fiscal_doc.d2_cliente, df_l32_fiscal_doc.d2_loja))).alias('ref_id'),
            df_l32_finance_doc.nf_tipo.alias('billing_type'),
            df_l3_sx5010_descriptions.x5_desceng.alias('billing_type_desc'),
            f.lit('').alias('billing_category'),
            f.lit('').alias('billing_category_desc'),
            f.lit('').alias('sales_doc_category'),
            f.lit('').alias('sd_document_categ_desc'),
            f.when(df_l32_finance_doc.nf_moeda == 2, f.lit('USD')).otherwise(f.lit('BRL')).alias('document_currency'),
            f.lit('01').alias('sales_organisation'),
            f.lit('Air BP Brazil').alias('sales_organisation_desc'),
            f.lit('').alias('distribution_channel'),
            f.lit('').alias('distribution_channel_desc'),
            f.lit('').alias('pricing_procedure'),
            f.lit('').alias('pricing_procedure_desc'),
            f.lit('').alias('doc_condition_no'),
            f.lit('').alias('fk_doc_condition_no'),
            df_l3_sc5010_goods_issue_hdr.c5_xgranel.alias('shipping_condition'),
            f.when(df_l3_sc5010_goods_issue_hdr.c5_xgranel == 'S', f.lit('Bulk'))
                .when(df_l3_sc5010_goods_issue_hdr.c5_xgranel == 'N', f.lit('Into Plane')).alias(
                'shipping_condition_desc'),
            df_l32_fiscal_doc.d2_emissao.alias('billing_date'),
            f.date_format(df_l32_fiscal_doc.d2_emissao, 'MM').alias('posting_period'),
            f.date_format(df_l32_fiscal_doc.d2_emissao, 'YYYY').alias('fiscal_year'),
            f.lit('').alias('posting_status'),
            f.lit('').alias('exchange_rate_accntg'),
            df_l3_sa1010_customers.a1_cond.alias('terms_of_payment'),
            f.lit('01').alias('company_code'),
            df_l32_fiscal_doc.d2_total.alias('total_net_value'),
            f.lit('').alias('header_time'),
            df_l32_fiscal_doc.d2_emissao.alias('header_created_on'),
            f.lit('').alias('statistics_currency'),
            df_l3_sm2010_currency.m2_moeda2.alias('exchange_rate_type'),
            f.lit('Daily Rate').alias('exchange_rate_type_desc'),
            f.lit('AirBP').alias('division'),
            f.lit('AirBP').alias('division_desc'),
            f.lit('BRL').alias('local_currency'),
            f.lit('').alias('cred_data_exch_rate'),
            f.lit('').alias('logical_system'),
            f.lit('').alias('translation_date'),
            f.concat(df_l32_fiscal_doc.d2_doc, df_l32_fiscal_doc.d2_filial).alias('billing_item'),
            f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0))
                .otherwise(df_l32_fiscal_doc.d2_quant).alias('billed_quantity'),
            df_l32_fiscal_doc.d2_um.alias('sales_unit'),
            df_l32_fiscal_doc.d2_um.alias('base_unit_of_measure'),
            f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0))
                .otherwise(df_l32_fiscal_doc.d2_quant).alias('billing_qty_in_sku'),
            f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0))
                .otherwise(df_l32_fiscal_doc.d2_quant).alias('required_quantity'),
            f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0))
                .otherwise((df_l32_fiscal_doc.d2_quant * df_l32_fiscal_doc.d2_peso)).alias('net_weight'),
            f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0))
                .otherwise((df_l32_fiscal_doc.d2_quant * df_l32_fiscal_doc.d2_peso)).alias('gross_weight'),
            f.lit('KG').alias('weight_unit'),
            f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0))
                .otherwise(df_l32_fiscal_doc.d2_quant).alias('volume'),
            df_l32_fiscal_doc.d2_um.alias('volume_unit'),
            f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0))
                .otherwise(df_l32_fiscal_doc.d2_quant / 3.785411784).alias('ugl'),
            f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0))
                .otherwise(df_l32_fiscal_doc.d2_quant / 1000.0).alias('m3'),
            f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0))
                .otherwise((df_l32_fiscal_doc.d2_quant * df_l32_fiscal_doc.d2_peso) / 1000.0).alias('metric_tons'),
            f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0))
                .otherwise(df_l32_fiscal_doc.d2_quant).alias('litres'),
            f.when((df_l3_zb0010_delivery_ticket.zb0_numce == '') | df_l3_zb0010_delivery_ticket.zb0_numce.isNull(),
                   df_l3_sc5010_goods_issue_hdr.c5_emissao)
                .otherwise(df_l3_zb0010_delivery_ticket.zb0_dtemis).alias('pricing_date'),
            f.coalesce(
                f.when((df_l3_zb0010_delivery_ticket.zb0_numce == '') | df_l3_zb0010_delivery_ticket.zb0_numce.isNull(),
                       df_l3_sc5010_goods_issue_hdr.c5_emissao)
                    .otherwise(df_l3_zb0010_delivery_ticket.zb0_dtemis), df_l32_fiscal_doc.d2_emissao).alias(
                'delivery_date'),
            df_l3_sc5010_goods_issue_hdr.c5_txmoeda.alias('exchange_rate'),
            f.lit('').alias('average_exchange_rate'),
            f.coalesce(df_l3_sm2010_currency.m2_moeda2, f.lit(1)).alias('d_1_exchange_rate'),
            ((df_l32_fiscal_doc.d2_total - (
                    df_l32_fiscal_doc.d2_valicm + df_l32_fiscal_doc.d2_valimp5 + df_l32_fiscal_doc.d2_valimp6)) / f.coalesce(
                df_l3_sc5010_goods_issue_hdr.c5_txmoeda, f.lit(1))).alias('net_value_doc'),
            (df_l32_fiscal_doc.d2_total - (
                    df_l32_fiscal_doc.d2_valicm + df_l32_fiscal_doc.d2_valimp5 + df_l32_fiscal_doc.d2_valimp6)).alias(
                'net_value'),
            ((df_l32_fiscal_doc.d2_total - (
                    df_l32_fiscal_doc.d2_valicm + df_l32_fiscal_doc.d2_valimp5 + df_l32_fiscal_doc.d2_valimp6)) /
             (f.when((df_l32_finance_doc.nf_moeda == 2) & (df_l3_sc5010_goods_issue_hdr.c5_txmoeda > 2),
                     f.coalesce(df_l3_sc5010_goods_issue_hdr.c5_txmoeda,
                                f.coalesce(df_l3_sm2010_currency.m2_moeda2, f.lit(1))))
              .otherwise(f.coalesce(df_l3_sm2010_currency.m2_moeda2, f.lit(1))))).alias('net_value_gc'),
            (f.when((df_l32_finance_doc.nf_moeda == 2) & (df_l3_sc5010_goods_issue_hdr.c5_txmoeda > 2),
                    f.coalesce(df_l3_sc5010_goods_issue_hdr.c5_txmoeda,
                               f.coalesce(df_l3_sm2010_currency.m2_moeda2, f.lit(1))))
             .otherwise(f.coalesce(df_l3_sm2010_currency.m2_moeda2, f.lit(1)))).alias('gc_exchange_rate'),
            (df_l32_fiscal_doc.d2_total - (
                    df_l32_fiscal_doc.d2_valicm + df_l32_fiscal_doc.d2_valimp5 + df_l32_fiscal_doc.d2_valimp6)).alias(
                'net_value_lc'),
            df_l32_fiscal_doc.d2_valicm.alias('prot_tax_icms'),
            df_l32_fiscal_doc.d2_valimp5.alias('prot_tax_comfins'),
            df_l32_fiscal_doc.d2_valimp6.alias('prot_tax_pis'),
            df_l32_fiscal_doc.d2_total.alias('gross_value_lc'),
            (f.when((df_l3_zb0010_delivery_ticket.zb0_numce == '') | (df_l3_zb0010_delivery_ticket.zb0_numce.isNull()),
                    f.concat(df_l32_fiscal_doc.d2_doc, f.lit("-"), df_l32_fiscal_doc.d2_filial))
             .otherwise(f.concat(df_l3_zb0010_delivery_ticket.zb0_numce, f.lit("-"),
                                 df_l3_zb0010_delivery_ticket.zb0_filial))).alias("reference_document"),
            f.lit('').alias('reference_item'),
            f.lit('').alias('preceding_doc_categ'),
            df_l32_fiscal_doc.d2_doc.alias('sales_document'),
            df_l32_fiscal_doc.d2_item.alias('sales_document_item'),
            df_l32_fiscal_doc.d2_cod.alias('material_number'),
            f.concat(f.lit('BRA'), df_l32_fiscal_doc.d2_cod).alias('source_mat_no'),
            f.when(df_l32_fiscal_doc.d2_cod == 'A08240N', f.lit('AVGAS'))
                .when(df_l32_fiscal_doc.d2_cod == 'A08601E', f.lit('JET A-1'))
                .when(df_l32_fiscal_doc.d2_cod == 'A08601N', f.lit('JET A-1'))
                .when(df_l32_fiscal_doc.d2_cod == 'A999999', f.lit('Jet Defuelling Refuelling'))
                .when(df_l32_fiscal_doc.d2_cod == 'P5000', f.lit('Additives'))
                .when(df_l32_fiscal_doc.d2_cod == '000210', f.lit('Water Detector'))
                .otherwise(df_l3_sb1010_products.b1_desc).alias('material_description'),
            df_l3_sb1010_products.b1_desc.alias('local_material_description'),
            f.lit('').alias('item_category'),
            f.lit('').alias('shipping_point_receiving_pt'),
            df_l3_zh1010_locations.zh1_iata.alias('plant'),
            f.lit('BR').alias('country'),
            f.lit('').alias('sales_office'),
            f.lit('').alias('line_created_on'),
            f.lit('').alias('line_time'),
            f.lit('').alias('exchange_rate_stats'),
            f.lit('').alias('profit_centre'),
            f.lit('').alias('distchanorder'),
            df_l3_zb0010_delivery_ticket.zb0_numvoo.alias('flight_number'),
            df_l3_zb0010_delivery_ticket.zb0_tipaer.alias('aircraft_type_code'),
            df_l3_zb0010_delivery_ticket.zb0_prefix.alias('aircraft_registration'),
            df_l32_fiscal_doc.d2_um.alias('billing_unit'),
            f.lit('').alias('order_reason'),
            f.lit('').alias('price_group_order'),
            f.lit('').alias('ref_contractitm'),
            f.lit('').alias('pricing_time'),
            f.lit('').alias('contract_nr'),
            df_l3_zb0010_delivery_ticket.zb0_numce.alias('extern_bol_no'),
            df_l3_sc5010_goods_issue_hdr.c5_condpag.alias('inv_cycle_ind'),
            f.lit('').alias('met_event_type'),
            f.lit('').alias('price_list_ord'),
            f.lit('').alias('pc_type'),
            f.lit('').alias('ssr_pc_category'),
            f.lit('').alias('shp_type_stage'),
            f.lit('').alias('channel_of_trade'),
            f.lit('').alias('district'),
            f.lit('').alias('cons_assgn'),
            f.lit('').alias('contr_doc_type'),
            f.lit('').alias('standard_refinery'),
            f.lit('').alias('original_plant'),
            f.lit('').alias('standard_supply_loc'),
            df_l3_zb0010_delivery_ticket.zb0_cta.alias('vessel_name'),
            f.lit('').alias('term_type'),
            f.concat(df_l32_fiscal_doc.d2_cliente, df_l32_fiscal_doc.d2_loja).alias('shipto_party'),
            f.concat(df_l32_fiscal_doc.d2_cliente, df_l32_fiscal_doc.d2_loja).alias('billto_party'),
            f.concat(df_l32_fiscal_doc.d2_cliente, df_l32_fiscal_doc.d2_loja).alias('soldto_party'),
            f.concat(df_l32_fiscal_doc.d2_cliente, df_l32_fiscal_doc.d2_loja).alias('payer'),
            f.lit('').alias('destination_airport'),
            f.lit('').alias('final_destination_partner'),
            f.lit('').alias('parent_partner'),
            f.lit('').alias('vendor'),
            f.lit('').alias('sales_rep'),
            f.lit('').alias('agent_id'),
            df_l32_fiscal_doc.d2_emissao,
            df_l32_fiscal_doc.f2_fimp,
            f.current_timestamp().alias('infa_ext_dt'),
            f.when(
                (df_l3_sc5010_goods_issue_hdr.c5_xgranel == 'S') & df_l32_fiscal_doc.d2_cod.isin('A08240N', 'A08601E',
                                                                                                 'A08601N'),
                f.lit('Bulk'))
                .when(df_l32_fiscal_doc.d2_cod.isin('A08240N', 'A08601E', 'A08601N'), f.lit('Into Plane'))
                .otherwise(f.lit('NA')).alias('delivery_method')
        )
        # print('df_table_1', df_table_1.count())

        # create table 2
        df_sc5010_gihdr_new = df_l3_sc5010_goods_issue_hdr.select(f.col("c5_filial"),
                                                                  f.col("c5_nota"),
                                                                  f.col("c5_cliente"),
                                                                  f.col("c5_lojacli"),
                                                                  f.col("c5_xgranel")).distinct()

        df_table_2 = df_l3_sd1010_goods_received_itm \
            .join(df_l3_se1010_finance_doc,
                  (df_l3_sd1010_goods_received_itm.d1_filial == df_l3_se1010_finance_doc.e1_filorig)
                  & (df_l3_sd1010_goods_received_itm.d1_doc == df_l3_se1010_finance_doc.e1_num)
                  & (df_l3_sd1010_goods_received_itm.d1_fornece == df_l3_se1010_finance_doc.e1_cliente)
                  & (df_l3_sd1010_goods_received_itm.d1_loja == df_l3_se1010_finance_doc.e1_loja)
                  & (df_l3_se1010_finance_doc.e1_tipo == 'NCC'), 'inner') \
            .join(df_l3_sa1010_customers,
                  (df_l3_sa1010_customers.a1_cod == df_l3_se1010_finance_doc.e1_cliente)
                  & (df_l3_sa1010_customers.a1_loja == df_l3_se1010_finance_doc.e1_loja), 'left') \
            .join(df_l3_zh1010_locations,
                  df_l3_sd1010_goods_received_itm.d1_filial == df_l3_zh1010_locations.zh1_filial, 'left') \
            .join(df_l3_sx5010_descriptions,
                  (df_l3_sx5010_descriptions.x5_tabela == '05')
                  & (df_l3_sx5010_descriptions.x5_chave == df_l3_se1010_finance_doc.e1_tipo), 'left') \
            .join(df_l3_sm2010_currency,
                  f.coalesce(df_l3_sd1010_goods_received_itm.d1_emissao,
                             df_l3_se1010_finance_doc.e1_emissao) == df_l3_sm2010_currency.m2_data, 'left') \
            .join(df_l3_sb1010_products,
                  df_l3_sd1010_goods_received_itm.d1_cod == df_l3_sb1010_products.b1_cod,
                  'left') \
            .join(df_sc5010_gihdr_new, (df_sc5010_gihdr_new.c5_filial == df_l3_sd1010_goods_received_itm.d1_filial)
                  & (df_sc5010_gihdr_new.c5_nota == df_l3_sd1010_goods_received_itm.d1_nfori)
                  & (df_sc5010_gihdr_new.c5_cliente == df_l3_sd1010_goods_received_itm.d1_fornece)
                  & (df_sc5010_gihdr_new.c5_lojacli == df_l3_sd1010_goods_received_itm.d1_loja), "left") \
            .filter(
                (df_l3_sd1010_goods_received_itm.d1_cod.isin('A08240N', 'A08601E', 'A08601N', '000210', 'A999999', 'P5000'))
                & (f.concat(f.date_format(df_l3_sd1010_goods_received_itm.d1_emissao, 'YYYY'),
                            f.date_format(df_l3_sd1010_goods_received_itm.d1_emissao, 'MM')).cast('int') > 201703)
            ) \
            .select(
                df_l3_sd1010_goods_received_itm.d1_filial,
                df_l3_se1010_finance_doc.e1_num.alias('billing_document'),
                f.concat(df_l3_se1010_finance_doc.e1_num, f.lit('_'), df_l3_sd1010_goods_received_itm.d1_doc, f.lit('_'),
                         df_l3_sd1010_goods_received_itm.d1_item, f.lit('_'), df_l3_zh1010_locations.zh1_iata, f.lit('_'),
                         (f.concat(df_l3_se1010_finance_doc.e1_cliente, df_l3_se1010_finance_doc.e1_loja))).alias('ref_id'),
                df_l3_se1010_finance_doc.e1_tipo.alias('billing_type'),
                df_l3_sx5010_descriptions.x5_desceng.alias('billing_type_desc'),
                f.lit('').alias('billing_category'),
                f.lit('').alias('billing_category_desc'),
                f.lit('').alias('sales_doc_category'),
                f.lit('').alias('sd_document_categ_desc'),
                f.lit('BRL').alias('document_currency'),
                f.lit('01').alias('sales_organisation'),
                f.lit('Air BP Brazil').alias('sales_organisation_desc'),
                f.lit('').alias('distribution_channel'),
                f.lit('').alias('distribution_channel_desc'),
                f.lit('').alias('pricing_procedure'),
                f.lit('').alias('pricing_procedure_desc'),
                f.lit('').alias('doc_condition_no'),
                f.lit('').alias('fk_doc_condition_no'),
                f.lit('').alias('shipping_condition'),
                f.lit('').alias('shipping_condition_desc'),
                f.coalesce(df_l3_sd1010_goods_received_itm.d1_emissao, df_l3_se1010_finance_doc.e1_emissao).alias(
                    'billing_date'),
                f.date_format(f.coalesce(df_l3_sd1010_goods_received_itm.d1_emissao, df_l3_se1010_finance_doc.e1_emissao),
                              'MM').alias('posting_period'),
                f.date_format(f.coalesce(df_l3_sd1010_goods_received_itm.d1_emissao, df_l3_se1010_finance_doc.e1_emissao),
                              'YYYY').alias('fiscal_year'),
                f.lit('').alias('posting_status'),
                f.lit('').alias('exchange_rate_accntg'),
                df_l3_sa1010_customers.a1_cond.alias('terms_of_payment'),
                f.lit('01').alias('company_code'),
                df_l3_sd1010_goods_received_itm.d1_total.alias('total_net_value'),
                f.lit('').alias('header_time'),
                df_l3_se1010_finance_doc.e1_emissao.alias('header_created_on'),
                f.lit('').alias('statistics_currency'),
                df_l3_sm2010_currency.m2_moeda2.alias('exchange_rate_type'),
                f.lit('Daily Rate').alias('exchange_rate_type_desc'),
                f.lit('AirBP').alias('division'),
                f.lit('AirBP').alias('division_desc'),
                f.lit('BRL').alias('local_currency'),
                f.lit('').alias('cred_data_exch_rate'),
                f.lit('').alias('logical_system'),
                f.lit('').alias('translation_date'),
                f.concat(df_l3_sd1010_goods_received_itm.d1_doc, df_l3_sd1010_goods_received_itm.d1_filial,
                         df_l3_sd1010_goods_received_itm.d1_item).alias('billing_item'),
                f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0)).otherwise(
                    df_l3_sd1010_goods_received_itm.d1_quant * (-1)).alias('billed_quantity'),
                df_l3_sd1010_goods_received_itm.d1_um.alias('sales_unit'),
                df_l3_sd1010_goods_received_itm.d1_um.alias('base_unit_of_measure'),
                f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0)).otherwise(
                    df_l3_sd1010_goods_received_itm.d1_quant * (-1)).alias('billing_qty_in_sku'),
                f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0)).otherwise(
                    df_l3_sd1010_goods_received_itm.d1_quant * (-1)).alias('required_quantity'),
                f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0)).otherwise(
                    (df_l3_sd1010_goods_received_itm.d1_quant * (-1))).alias('net_weight'),
                f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0)).otherwise(
                    (df_l3_sd1010_goods_received_itm.d1_quant * (-1))).alias('gross_weight'),
                f.lit('KG').alias('weight_unit'),
                f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0)).otherwise(
                    df_l3_sd1010_goods_received_itm.d1_quant * (-1)).alias('volume'),
                df_l3_sd1010_goods_received_itm.d1_um.alias('volume_unit'),
                f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0)).otherwise(
                    (df_l3_sd1010_goods_received_itm.d1_quant * (-1)) / 3.785411784).alias('ugl'),
                f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0)).otherwise(
                    (df_l3_sd1010_goods_received_itm.d1_quant * (-1)) / 1000).alias('m3'),
                f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0)).otherwise(
                    (df_l3_sd1010_goods_received_itm.d1_quant * (-1)) / 1000).alias('metric_tons'),
                f.when(df_l3_sb1010_products.b1_cod.isin('P5000', 'A999999'), f.lit(0)).otherwise(
                    df_l3_sd1010_goods_received_itm.d1_quant * (-1)).alias('litres'),
                f.coalesce(df_l3_sd1010_goods_received_itm.d1_emissao, df_l3_se1010_finance_doc.e1_emissao).alias(
                    'pricing_date'),
                f.coalesce(df_l3_sd1010_goods_received_itm.d1_emissao, df_l3_se1010_finance_doc.e1_emissao).alias(
                    'delivery_date'),
                f.coalesce(df_l3_sm2010_currency.m2_moeda2, f.lit(1)).alias('exchange_rate'),
                f.lit('').alias('average_exchange_rate'),
                f.coalesce(df_l3_sm2010_currency.m2_moeda2, f.lit(1)).alias('d_1_exchange_rate'),
                ((df_l3_sd1010_goods_received_itm.d1_total - (
                        df_l3_sd1010_goods_received_itm.d1_valicm + df_l3_sd1010_goods_received_itm.d1_valimp5 +
                        df_l3_sd1010_goods_received_itm.d1_valimp6)) * (-1)).alias('net_value_doc'),
                ((df_l3_sd1010_goods_received_itm.d1_total - (
                        df_l3_sd1010_goods_received_itm.d1_valicm + df_l3_sd1010_goods_received_itm.d1_valimp5 +
                        df_l3_sd1010_goods_received_itm.d1_valimp6)) * (-1)).alias('net_value'),
                ((df_l3_sd1010_goods_received_itm.d1_total - (
                        df_l3_sd1010_goods_received_itm.d1_valicm + df_l3_sd1010_goods_received_itm.d1_valimp5 +
                        df_l3_sd1010_goods_received_itm.d1_valimp6)) * (-1)) /
                f.coalesce(df_l3_sm2010_currency.m2_moeda2, f.lit(1)).alias('net_value_gc'),
                f.coalesce(df_l3_sm2010_currency.m2_moeda2, f.lit(1)).alias('gc_exchange_rate'),
                ((df_l3_sd1010_goods_received_itm.d1_total - (
                        df_l3_sd1010_goods_received_itm.d1_valicm + df_l3_sd1010_goods_received_itm.d1_valimp5 +
                        df_l3_sd1010_goods_received_itm.d1_valimp6)) * (-1)).alias('net_value_lc'),
                (df_l3_sd1010_goods_received_itm.d1_valicm * (-1)).alias('prot_tax_icms'),
                (df_l3_sd1010_goods_received_itm.d1_valimp5 * (-1)).alias('prot_tax_comfins'),
                (df_l3_sd1010_goods_received_itm.d1_valimp6 * (-1)).alias('prot_tax_pis'),
                (df_l3_sd1010_goods_received_itm.d1_total * (-1)).alias('gross_value_lc'),
                f.lit('').alias('reference_document'),
                f.lit('').alias('reference_item'),
                f.lit('').alias('preceding_doc_categ'),
                df_l3_sd1010_goods_received_itm.d1_doc.alias('sales_document'),
                df_l3_sd1010_goods_received_itm.d1_item.alias('sales_document_item'),
                df_l3_sd1010_goods_received_itm.d1_cod.alias('material_number'),
                f.concat(f.lit('BRA'), df_l3_sd1010_goods_received_itm.d1_cod).alias('source_mat_no'),
                f.when(df_l3_sd1010_goods_received_itm.d1_cod == 'A08240N', f.lit('AVGAS'))
                .when(df_l3_sd1010_goods_received_itm.d1_cod == 'A08601E', f.lit('JET A-1'))
                .when(df_l3_sd1010_goods_received_itm.d1_cod == 'A08601N', f.lit('JET A-1'))
                .when(df_l3_sd1010_goods_received_itm.d1_cod == 'A999999', f.lit('Jet Defuelling Refuelling'))
                .when(df_l3_sd1010_goods_received_itm.d1_cod == 'P5000', f.lit('Additives'))
                .when(df_l3_sd1010_goods_received_itm.d1_cod == '000210', f.lit('Water Detector'))
                .otherwise(df_l3_sb1010_products.b1_desc).alias('material_description'),
                df_l3_sb1010_products.b1_desc.alias('local_material_description'),
                f.lit('').alias('item_category'),
                f.lit('').alias('shipping_point_receiving_pt'),
                df_l3_zh1010_locations.zh1_iata.alias('plant'),
                f.lit('BR').alias('country'),
                f.lit('').alias('sales_office'),
                f.lit('').alias('line_created_on'),
                f.lit('').alias('line_time'),
                f.lit('').alias('exchange_rate_stats'),
                f.lit('').alias('profit_centre'),
                f.lit('').alias('distchanorder'),
                f.lit('').alias('flight_number'),
                f.lit('').alias('aircraft_type_code'),
                f.lit('').alias('aircraft_registration'),
                df_l3_sd1010_goods_received_itm.d1_um.alias('billing_unit'),
                f.lit('').alias('order_reason'),
                f.lit('').alias('price_group_order'),
                f.lit('').alias('ref_contractitm'),
                f.lit('').alias('pricing_time'),
                f.lit('').alias('contract_nr'),
                f.lit('').alias('extern_bol_no'),
                f.lit('').alias('inv_cycle_ind'),
                f.lit('').alias('met_event_type'),
                f.lit('').alias('price_list_ord'),
                f.lit('').alias('pc_type'),
                f.lit('').alias('ssr_pc_category'),
                f.lit('').alias('shp_type_stage'),
                f.lit('').alias('channel_of_trade'),
                f.lit('').alias('district'),
                f.lit('').alias('cons_assgn'),
                f.lit('').alias('contr_doc_type'),
                f.lit('').alias('standard_refinery'),
                f.lit('').alias('original_plant'),
                f.lit('').alias('standard_supply_loc'),
                f.lit('').alias('vessel_name'),
                f.lit('').alias('term_type'),
                f.concat(df_l3_se1010_finance_doc.e1_cliente, df_l3_se1010_finance_doc.e1_loja).alias('shipto_party'),
                f.concat(df_l3_se1010_finance_doc.e1_cliente, df_l3_se1010_finance_doc.e1_loja).alias('billto_party'),
                f.concat(df_l3_se1010_finance_doc.e1_cliente, df_l3_se1010_finance_doc.e1_loja).alias('soldto_party'),
                f.concat(df_l3_se1010_finance_doc.e1_cliente, df_l3_se1010_finance_doc.e1_loja).alias('payer'),
                f.lit('').alias('destination_airport'),
                f.lit('').alias('final_destination_partner'),
                f.lit('').alias('parent_partner'),
                f.lit('').alias('vendor'),
                f.lit('').alias('sales_rep'),
                f.lit('').alias('agent_id'),
                df_l3_sd1010_goods_received_itm.d1_emissao,
                f.lit('S').alias('f2_fimp'),
                f.current_timestamp().alias('infa_ext_dt'),
                (f.when((df_l3_sc5010_goods_issue_hdr.c5_xgranel == 'S') & (
                    df_l3_sd1010_goods_received_itm.d1_cod.isin('A08240N', 'A08601E', 'A08601N')), "Bulk")
                 .when(df_l3_sd1010_goods_received_itm.d1_cod.isin('A08240N', 'A08601E', 'A08601N'), "Into Plane")
                 .otherwise("NA")).alias("delivery_method")
            )
        # print('df_table_2', df_table_2.count())

        # union all tables
        df_tfx_result = df_table_1.union(df_table_2)
        print("df_tfx_result", df_tfx_result.count())

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()
