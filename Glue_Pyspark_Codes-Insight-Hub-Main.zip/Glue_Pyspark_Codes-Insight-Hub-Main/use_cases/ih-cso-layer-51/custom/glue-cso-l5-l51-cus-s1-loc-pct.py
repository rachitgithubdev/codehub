# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      16-Jun-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-cso-l51-loc-pct &
#                  glue-cso-l51-cus-pct-s1 into conform zone
# Author        :- Liz Harvey
# Date          :- 16-Jun-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class CsoETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'netapp_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.netapp_database = args['netapp_database']
        self.destination_bucket = args['destination_bucket']
        self.environment = args['environment']

        # report specific =============================================
        self.input_tables = ['l3_cs_and_o_sov_loc_pct', 'l4_dim_location', 'l3_cs_and_o_sov', 'l3_cs_and_o_sov_cus_pct']
        self.report_file = 'l51_cs_and_o_loc_pct'
        self.report_file1 = 'l51_cs_and_o_cus_pct_s1'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}, {}.{}* and write it to {}'.format(self.source_database, self.netapp_database,
                                                                             self.input_tables,
                                                                             self.destination_bucket))

    def execute(self):
        # generate input table list
        source_database = self.source_database
        netapp_database = self.netapp_database
        input_tables = self.input_tables
        print("input table list is {}".format(input_tables))
        # read data from country specific table argument passed(database, table)
        print('Reading data from input table {}.{}'.format(self.netapp_database, self.input_tables[0]))
        df_cso = self._get_table(self.netapp_database, self.input_tables[0])

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[1]))
        df_dim_loc = self._get_table(self.source_database, self.input_tables[1])

        print('Reading data from input table {}.{}'.format(self.netapp_database, self.input_tables[2]))
        df_cso_sov = self._get_table(self.netapp_database, self.input_tables[2])

        print('Reading data from input table {}.{}'.format(self.netapp_database, self.input_tables[3]))
        df_cus_pct = self._get_table(self.netapp_database, self.input_tables[3])

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('applying the transformations')
        df_tfx_table = self._apply_tfx(df_cso, df_dim_loc, df_cso_sov, df_cus_pct)
        # print('schema after transformation ', df_tfx_table.printSchema())

        print('Writing loc-pct to s3')
        self.write_results(df_tfx_table[0], self.report_file)

        print('Writing cus-pct-s1 to s3')
        self.write_results(df_tfx_table[1], self.report_file1)

    def write_results(self, df_tfx_table, report_file):
        final_path = self.destination_bucket + '/' + report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        df_cso = args[0]
        df_dim_loc = args[1]
        df_cso_sov = args[2]
        df_cso_cus = args[3]

        tbl = df_cso.select(f.posexplode(
            f.split(f.repeat(f.lit("o"), f.months_between(f.current_date(), '2020-01-01')), "o"))).alias("add")

        print('Starting loc-pct job')
        loc_result = tbl.alias("add").join(df_cso.alias("dlp"),
                                           ((f.year(f.add_months('2020-01-01', tbl.pos)) * 100) +
                                           (f.month(f.add_months('2020-01-01', tbl.pos))).between(df_cso.start_month,
                                           (f.coalesce(df_cso.end_month, (f.from_unixtime(f.unix_timestamp(f.current_date(),'yyyyMM'))).cast(int))))) &
                                           (df_cso.src_of_val == 'Default')) \
            .join(df_cso_sov.alias("sov"), df_cso_sov.srv_of_val != df_cso.src_of_val) \
            .join(df_dim_loc.alias("loc"), (df_dim_loc.iata == df_cso.iata) &
                  (df_dim_loc.cs_and_o_supply_chain == df_cso.supply_chain) &
                  (df_dim_loc.cs_and_o_location_flag == 'Yes')) \
            .join(df_cso.alias("slp"), (((f.year(f.add_months('2020-01-01', tbl.pos)) * 100) +
                                         f.month(f.add_months('2020-01-01', tbl.pos))).between(f.col("slp.start_month"),
                                         (f.coalesce(f.col("dlp.end_month"), (f.from_unixtime(f.unix_timestamp(f.current_date(), 'yyyyMM'))).cast(int))))) &
                  (f.col("slp.src_of_val") == df_cso_sov.src_of_val) &
                  (f.col("slp.supply_chain") == f.col("dlp.supply_chain")) &
                  (df_cso.iata == f.col("dlp.iata"))) \
            .select(
            f.col("sov.src_of_val").alias("src_of_val"),
            (f.when(f.col("slp.src_of_val").isNull(), f.lit('d'))
             .otherwise(f.lit('s'))).alias("sov_ind"),
            f.col("dlp.supply_chain").alias("supply_chain"),
            f.col("loc.locationid").alias("sem_location_id"),
            f.col("loc.iata").alias("sem_iata"),
            f.col("loc.location_name").alias("sem_location_name"),
            (f.last_day(f.add_months('2020-01-01', tbl.pos))).alias("period"),
            f.col("dlp.pct").alias("dpct"),
            f.col("slp").pct.alias("spct"),
            (f.coalesce(f.col("slp.pct"), f.col("dlp.pct"))).alias("pct"))

        print('Starting cus-pct-s1 job')
        cus_tbl = df_dim_loc.groupBy(df_dim_loc.grn,
                                     df_dim_loc.grn_header,
                                     df_dim_loc.cc_grn,
                                     df_dim_loc.sales_organisation,
                                     df_dim_loc.customer_account_name,
                                     df_dim_loc.customer_country,
                                     df_dim_loc.sector,
                                     df_dim_loc.account_manager,
                                     df_dim_loc.payer_mdm_id,
                                     df_dim_loc.sold_to_mdm_id,
                                     df_dim_loc.isp_sold_to) \
            .agg(f.first(df_dim_loc.grn, True).alias("grn"),
                 f.first(df_dim_loc.grn_header, True).alias("grn_header"),
                 f.first(df_dim_loc.cc_grn, True).alias("cc_grn"),
                 f.first(df_dim_loc.sales_organisation, True).alias("sales_organisation"),
                 f.first(df_dim_loc.customer_country, True).alias("customer_country"),
                 f.first(df_dim_loc.sector, True).alias("sector"),
                 f.first(df_dim_loc.customer_account_name, True).alias("customer_account_name"),
                 f.first(df_dim_loc.account_manager, True).alias("account_manager"),
                 f.first(df_dim_loc.payer_mdm_id, True).alias("payer_mdm_id"),
                 f.first(df_dim_loc.sold_to_mdm_id, True).alias("sold_to_mdm_id"),
                 f.first(df_dim_loc.isp_sold_to, True).alias("isp_sold_to")) \
            .filter(df_dim_loc.grn.isNotNull(),
                    df_dim_loc.cc_grn.isNotNull(),
                    df_dim_loc.grn_header.isNotNull(),
                    df_dim_loc.sales_organisation.isNotNull(),
                    df_dim_loc.sector.isNotNull(),
                    df_dim_loc.account_manager.isNotNull()) \
            .select(df_dim_loc.grn,
                    df_dim_loc.grn_header,
                    df_dim_loc.cc_grn,
                    df_dim_loc.sales_organisation,
                    df_dim_loc.customer_country,
                    df_dim_loc.sector,
                    df_dim_loc.customer_account_name,
                    df_dim_loc.account_manager,
                    df_dim_loc.payer_mdm_id,
                    df_dim_loc.sold_to_mdm_id,
                    df_dim_loc.isp_sold_to)

        cus_pct_result = tbl.alias("add").join(df_cso_cus.alias("dcp"),
                                               (((f.year(f.add_months('2020-01-01', f.col("tbl.pos"))) * 100) +
                                                 f.month(f.add_months('2020-01-01', f.col("tbl.pos")))).between(
                                                   f.col("dcp.start_month"),
                                                   (f.coalesce(f.col("dcp.end_month"), (f.from_unixtime(
                                                       f.unix_timestamp(f.current_date(), 'yyyyMM'))).cast(int))))) &
                                               f.col("dcp.src_of_val") == 'Default') \
            .join(df_cso_sov.alias("sov"), f.col("sov.src_of_val") != f.col("dcp.src_of_val")) \
            .join(df_dim_loc.alias("loc"),
                  (f.col("loc.iata") == (f.when(f.col("dcp.iata") == '*ALL*', f.col("loc.iata"))
                                         .otherwise(f.col("dcp.iata")))) &
                  (f.col("loc.cs_and_o_supply_chain") == f.col("dcp.supply_chain")) &
                  (f.col("loc.cs_and_o_location_flag") == 'Yes')) \
            .join(cus_tbl.alias("cus"), (f.col("cus.grn") == f.col("dcp.grn")) & (
                f.col("cus.sales_organisation") == f.col("dcp.sales_organisation"))) \
            .join(df_cso_cus.alias("scp"), (((f.year(f.add_months('2020-01-01', tbl.pos)) * 100) +
                                             f.month(f.add_months('2020-01-01', tbl.pos))).between(f.col("dcp.start_month"),
                                             (f.coalesce(f.col("dcp.end_month"), (f.from_unixtime(f.unix_timestamp(f.current_date(), 'yyyyMM'))).cast(int)))))
                  & (f.col("scp.src_of_val") == f.col("sov.src_of_val"))
                  & (f.col("scp.supply_chain") == f.col("dcp.supply_chain"))
                  & (f.col("scp.iata") == f.col("dcp.iata"))
                  & (f.col("scp.grn") == f.col("dcp.grn"))
                  & (f.col("scp.sales_organisation") == f.col("dcp.sales_organisation")), 'left') \
            .select(f.col("sov.src_of_val").alias("src_of_val"),
                    f.when(f.col("scp.src_of_val").isNull(), f.lit('d'))
                    .otherwise(f.lit('s')).alias("sov_ind"),
                    f.col("dcp.supply_chain").alias("supply_chain"),
                    f.col("dcp.iata").alias("iata"),
                    f.col("loc.locationid").alias("sem_location_id"),
                    f.col("loc.iata").alias("sem_iata"),
                    f.col("loc.location_name").alias("sem_location_name"),
                    f.col("cus.customer_account_name"),
                    f.col("dcp.grn").alias("grn"),
                    f.col("dcp.sales_organisation").alias("sales_organisation"),
                    (f.last_day(f.add_months('2020-01-01', tbl.pos))).alias("period"),
                    f.col("dcp.pct").alias("dpct"),
                    f.col("scp.pct").alias("spct"),
                    (f.coalesce(f.col("scp.pct"), f.col("dcp.pct"))).alias("pct"))

        return [loc_result, cus_pct_result]


if __name__ == '__main__':
    trl = CsoETL()
    trl.execute()
