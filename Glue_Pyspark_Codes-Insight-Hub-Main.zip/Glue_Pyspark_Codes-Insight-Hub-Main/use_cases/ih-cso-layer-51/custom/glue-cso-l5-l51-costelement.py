# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      16-Jun-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-cso-l51-cus-costelement &
#                  glue-cso-l51-vol-costelement into conform zone
# Author        :- Liz Harvey
# Date          :- 16-Jun-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class CsoETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'netapp_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.netapp_database = args['netapp_database']
        self.destination_bucket = args['destination_bucket']
        self.environment = args['environment']

        # report specific =============================================
        self.input_tables = ['l51_cs_and_o_cus_pct',
                             'l51_cs_and_o_sov',
                             'l51_cs_and_o_loc_pct',
                             'l51_cs_and_o_values',
                             'l5_dim_waterfall_global',
                             'l4_dim_location',
                             'l51_cs_and_o_lc',
                             'l5_ytd_xrates_all',
                             'l51_summary']
        self.report_file = 'l51_cs_and_o_cus_costelement'
        self.report_file1 = 'l51_cs_and_o_vol_costelement'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}, {}.{}* and write it to {}'.format(self.source_database, self.netapp_database,
                                                                             self.input_tables,
                                                                             self.destination_bucket))

    def execute(self):
        # generate input table list
        source_database = self.source_database
        netapp_database = self.netapp_database
        input_tables = self.input_tables
        print("input table list is {}".format(input_tables))

        # read data from country specific table argument passed(database, table)
        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[0]))
        df_1 = self._get_table(self.source_database, self.input_tables[0])

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[1]))
        df_2 = self._get_table(self.source_database, self.input_tables[1])

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[2]))
        df_3 = self._get_table(self.source_database, self.input_tables[2])

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[3]))
        df_4 = self._get_table(self.source_database, self.input_tables[3])

        print('Reading data from input table {}.{}'.format(self.netapp_database, self.input_tables[4]))
        df_5 = self._get_table(self.netapp_database, self.input_tables[4])

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[5]))
        df_6 = self._get_table(self.source_database, self.input_tables[5])

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[6]))
        df_7 = self._get_table(self.source_database, self.input_tables[6])

        print('Reading data from input table {}.{}'.format(self.netapp_database, self.input_tables[7]))
        df_8 = self._get_table(self.netapp_database, self.input_tables[7])

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[8]))
        df_9 = self._get_table(self.source_database, self.input_tables[8])

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('applying the transformations')
        df_tfx_table = self._apply_tfx(df_1, df_2, df_3, df_4, df_5, df_6, df_7, df_8, df_9)
        # print('schema after transformation ', df_tfx_table.printSchema())

        print('Writing cus-costelement to s3 location')
        self.write_results(df_tfx_table[0], self.report_file)

        print('Writing vol-costelement to s3 location')
        self.write_results(df_tfx_table[1], self.report_file1)

    def write_results(self, df_tfx_table, report_file):
        final_path = self.destination_bucket + '/' + report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        cus_pct = args[0]
        sov = args[1]
        loc_pct = args[2]
        values = args[3]
        waterfall = args[4]
        dim_loc = args[5]
        lc = args[6]
        xrates = args[7]
        l51_sum = args[8]

        print('Starting cus-costelement job')
        cus_costelement = cus_pct.alias("cpt").join(sov, f.col("sov.src_of_val") == f.col("cpt.src_of_val")) \
            .join(loc_pct.alias("lpt"), (f.col("lpt.supply_chain") == f.col("cpt.supply_chain"))
                  & (f.col("lpt.sem_location_id") == f.col("cpt.sem_location_id"))
                  & (f.col("lpt.src_of_val") == f.col("cpt.src_of_val"))
                  & (f.col("lpt.period") == f.col("cpt.period"))) \
            .join(values.alias("val"), (f.col("val.src_of_val") == f.col("cpt.src_of_val"))
                  & (f.col("val.supply_chain") == f.col("cpt.supply_chain"))
                  & (f.col("val.period") == f.col("cpt.period"))
                  & (f.col("val.sov_value") != 0)) \
            .join(waterfall.alias("wfg"), f.trim(f.upper(f.col("sov.pricing_condition_l5"))) == f.trim(
                                                 f.upper(f.col("wfg.condition_type")))) \
            .join(dim_loc.alias("loc"), f.col("loc.locationid") == f.col("lpt.sem_location_id")) \
            .join(lc, f.col("lc.location_country") == f.col("loc.location_country")) \
            .join(xrates.alias("exrt"), (f.upper(f.col("exrt.from_cur_mnmc")) == 'USD')
                  & (f.col("exrt.to_cur_mnmc") == (f.when(f.col("lc.local_currency") == 'YTL', 'TRY')
                                                   .otherwise(f.col("lc.local_currency"))))
                  & (f.col("cpt.period").between(f.col("exrt.start_date"), f.col("exrt.end_date")))) \
            .filter(f.col("cpt.sov_ind") != 'I',
                    f.col("sov.lcp_ind") == 'Y') \
            .select(f.lit('CS&O').alias("source_system"),
                    f.col("wfg.hierarchy_level_5").alias("l5_hierarchy"),
                    f.col("wfg.hierarchy_level_4_key").alias("l4_hierarchy"),
                    f.col("wfg.hierarchy_level_3_key").alias("l3_hierarchy"),
                    f.col("wfg.hierarchy_level_2_key").alias("l2_hierarchy"),
                    f.col("wfg.hierarchy_level_1_key").alias("l1_hierarchy"),
                    (f.col("val.sov_value") * (f.col("lpt.pct") / 100) * (f.col("cpt.pct") / 100)).alias("value_usd"),
                    (f.col("val.sov_value") * (f.col("lpt.pct") / 100) * (f.col("cpt.pct") / 100) * f.col(
                        "exrt.ytd_exch_rate")).alias("value_lc"),
                    f.concat('cs&o_', f.col("lpt.sem_iata"), '_', f.col("cpt.grn"), '_',
                             f.col("cpt.sales_organisation"), '_',
                             f.col("cpt.period")).alias("cost_element_key"),
                    f.col("sov.pricing_condition_l5").alias("trx_wfh_key"),
                    (f.current_date()).alias("last_modified_date"),
                    f.col("cpt.grn"),
                    f.col("cpt.sales_organisation"),
                    f.col("cpt.period"),
                    f.col("cpt.sem_location_id"))

        print('Starting vol-costelement job')
        cpct1 = cus_pct.alias("C").join(l51_sum.alias("S"), f.col("S.grn") == f.col("C.grn")) \
            .filter(f.col("S.grn") == f.col("C.grn"),
                    f.last_day(f.col("S.delivery_date")) == f.col("C.period")) \
            .select(f.col("C.*"))

        vot = l51_sum.alias("S").join(dim_loc.alias("L"), f.col("S.sem_location_id") == f.col("L.locationid")) \
            .join(cpct1, f.col("S.grn") == f.col("cpct1.grn"), 'left_anti') \
            .groupBy(f.col("S.sem_location_id"),
                     f.last_day(f.col("S.delivery_date"))) \
            .agg(f.sum(f.col("S.qty_in_litres")).alias("tot_qty_in_litres")) \
            .filter(f.col("S.delivery_date") >= '2020-01-01',
                    f.col("S.cost_element_key").isNotNull(),
                    f.col("L.cs_and_o_location_flag") == 'Yes') \
            .select(f.col("S.sem_location_id"),
                    f.last_day(f.col("S.delivery_date")).alias("period"),
                    f.col("tot_qty_in_litres"))

        vat = cus_costelement.groupBy(f.col("sem_location_id"),
                                      f.col("trx_wfh_key"),
                                      f.col("period")) \
            .agg(f.sum(f.col("value_usd")).alias("tot_value_usd")) \
            .select(f.col("sem_location_id"),
                    f.col("trx_wfh_key"),
                    f.col("period"),
                    f.col("tot_value_usd"))

        cpct2 = cus_pct.alias("cus").join(l51_sum.alias("usm1"), f.col("usm1.grn") == f.col("cus.grn")) \
            .filter(f.col("usm.grn") == f.col("cus.grn"),
                    f.last_day(f.col("usm.delivery_date")) == f.col("cus.period")) \
            .select(f.col("C.*"))

        vol_costelement = l51_sum.alias("usm").join(dim_loc.alias("loc"),
                                                    f.col("usm.sem_location_id") == f.col("loc.locationid")) \
            .join(values.alias("val"), (f.col("loc.cs_and_o_supply_chain") == f.col("val.supply_chain")) &
                  (f.last_day(f.col("usm.delivery_date")) == f.col("val.period")) &
                  (f.col("val.sov_value") != 0)) \
            .join(sov, f.col("val.src_of_val") == f.col("sov.src_of_val")) \
            .join(f.col("loc_pct").alias("lpt"), (f.col("sov.src_of_val") == f.col("lpt.src_of_val")) &
                  (f.col("loc.locationid") == f.col("lpt.sem_location_id")) &
                  (f.last_day(f.col("lpt.period")) == f.last_day(f.col("usm.delivery_date"))), 'left') \
            .join(waterfall.alias("wfg"),
                  f.trim(f.upper(f.col("sov.pricing_condition_l5"))) == f.trim(f.upper(f.col("wfg.condition_type")))) \
            .join(vot, (f.col("usm.sem_location_id") == f.col("vot.sem_location_id")) &
                  (f.last_day(f.col("usm.delivery_date")) == f.col("vot.period"))) \
            .join(vat, (f.col("usm.sem_location_id") == f.col("vat.sem_location_id")) &
                  (f.col("sov.pricing_condition_l5") == f.col("vat.trx_wfh_key")) &
                  (f.last_day(f.col("usm.delivery_date")) == f.col("vat.period")), 'left') \
            .join(cpct2, f.col("usm.grn") == f.col("cpct2.grn"), 'left_anti') \
            .filter(f.last_day(f.col("usm.delivery_date")) >= '2020-01-01',
                    f.col("usm.cost_element_key").isNotNull(),
                    f.col("loc.cs_and_o_location_flag") == 'yes',
                    f.col("sov.lcp_ind") == 'y') \
            .select(f.col("usm.source_system"),
                    f.col("wfg.hierarchy_level_5").alias("l5_hierarchy"),
                    f.col("wfg.hierarchy_level_4_key").alias("l4_hierarchy"),
                    f.col("wfg.hierarchy_level_3_key").alias("l3_hierarchy"),
                    f.col("wfg.hierarchy_level_2_key").alias("l2_hierarchy"),
                    f.col("wfg.hierarchy_level_1_key").alias("l1_hierarchy"),
                    f.coalesce(((f.col("val.sov_value") * (f.col("lpt.pct") / 100)) - f.coalesce(
                        f.col("vat.tot_value_usd"), f.lit(0))) * (
                                       f.col("usm.qty_in_litres") / f.col("vot.tot_qty_in_litres")), f.lit(0)).alias(
                        "value_usd"),
                    f.coalesce(((f.col("val.sov_value") * (f.col("lpt.pct") / 100)) - f.coalesce(
                        f.col("vat.tot_value_usd"), f.lit(0))) * (
                                       f.col("usm.qty_in_litres") / f.col("vot.tot_qty_in_litres")) * (
                                           f.col("usm.gross_profit_lc") / f.col("usm.gross_profit_usd")),
                               f.lit(0)).alias("value_lc"),
                    f.col("usm.cost_element_key"),
                    f.col("sov.pricing_condition_l5").alias("trx_wfh_key"),
                    f.current_date().alias("last_modified_date"))

        return [cus_costelement, vol_costelement]


if __name__ == '__main__':
    trl = CsoETL()
    trl.execute()
