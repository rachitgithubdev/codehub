# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      15-Jun-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-cso-l51-cus-summary into conform zone
# Author        :- Liz Harvey
# Date          :- 15-Jun-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class CsoETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'netapp_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.netapp_database = args['netapp_database']
        self.destination_bucket = args['destination_bucket']
        self.environment = args['environment']

        # report specific =============================================
        self.input_tables = ['l51_CS_and_O_cus_costelement',
                             'l2_l5_dim_group_carrier',
                             'l4_dim_location',
                             'l51_CS_and_O_lc',
                             'l5_ytd_xrates_all',
                             'l4_dim_customer',
                             ]
        self.report_file = 'l51_cs_and_o_cus_summary'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}, {}.{}* and write it to {}'.format(self.source_database, self.netapp_database,
                                                                             self.input_tables,
                                                                             self.destination_bucket))

    def execute(self):
        # generate input table list
        source_database = self.source_database
        netapp_database = self.netapp_database
        input_tables = self.input_tables
        print("input table list is {}".format(input_tables))

        # read data from country specific table argument passed(database, table)
        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[0]))
        df_1 = self._get_table(self.source_database, self.input_tables)

        print('Reading data from input table {}.{}'.format(self.netapp_database, self.input_tables[1]))
        df_2 = self._get_table(self.netapp_database, self.input_tables)

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[2]))
        df_3 = self._get_table(self.source_database, self.input_tables)

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[3]))
        df_4 = self._get_table(self.source_database, self.input_tables)

        print('Reading data from input table {}.{}'.format(self.netapp_database, self.input_tables[4]))
        df_5 = self._get_table(self.netapp_database, self.input_tables)

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[5]))
        df_6 = self._get_table(self.source_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('applying the transformations')
        df_tfx_table = self._apply_tfx(df_1, df_2, df_3, df_4, df_5, df_6)
        # print('schema after transformation ', df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        cce = args[0]
        sfdc = args[1]
        loc = args[2]
        lc = args[3]
        exrt = args[4]
        dim_cus = args[5]

        cus = dim_cus.groupBy(f.col("grn"),
                              f.col("grn_header"),
                              f.col("cc_grn"),
                              f.col("sales_organisation"),
                              f.col("customer_account_name"),
                              f.col("customer_country"),
                              f.col("sector"),
                              f.col("account_manager"),
                              f.col("payer_mdm_id"),
                              f.col("sold_to_mdm_id"),
                              f.col("isp_sold_to")) \
            .filter(f.col("grn").isNotNull(),
                    f.col("cc_grn").isNotNull(),
                    f.col("grn_header").isNotNull(),
                    f.col("sales_organisation").isNotNull(),
                    f.col("sector").isNotNull(),
                    f.col("account_manager").isNotNull()) \
            .select(f.first(f.col("grn"), True).alias("grn"),
                    f.first(f.col("grn_header"), True).alias("grn_header"),
                    f.first(f.col("cc_grn"), True).alias("cc_grn"),
                    f.first(f.col("sales_organisation"), True).alias("sales_organisation"),
                    f.first(f.col("customer_country"), True).alias("customer_country"),
                    f.first(f.col("sector"), True).alias("sector"),
                    f.first(f.col("customer_account_name"), True).alias("customer_account_name"),
                    f.first(f.col("account_manager"), True).alias("account_manager"),
                    f.first(f.col("payer_mdm_id"), True).alias("payer_mdm_id"),
                    f.first(f.col("sold_to_mdm_id"), True).alias("sold_to_mdm_id"),
                    f.first(f.col("isp_sold_to"), True).alias("isp_sold_to"))

        df_tfx_result = cce.join(sfdc, f.col("cce.grn") == f.col("sfdc.GRN"), 'left') \
            .join(loc, f.col("loc.locationid") == f.col("cce.sem_location_id")) \
            .join(lc, f.col("lc.location_country") == f.col("loc.location_country")) \
            .join(exrt, (f.col("exrt.from_cur_mnmc") == 'usd') &
                  (f.col("exrt.to_cur_mnmc") == f.when(f.col("lc.local_currency") == 'ytl', 'try')
                   .otherwise(f.col("lc.local_currency"))) &
                  (f.col("cce.period").between(f.col("exrt.start_date"), f.col("exrt.end_date")))) \
            .join(cus, (f.col("cus.grn") == f.col("cce.grn"))
                  & (f.col("cus.sales_organisation") == f.col("cce.sales_organisation"))) \
            .groupBy(cce.period,
                     cus.customer_country,
                     cus.grn_header,
                     cus.customer_account_name,
                     cus.grn,
                     cus.cc_grn,
                     cus.account_manager,
                     cus.sector,
                     cus.sales_organisation,
                     lc.local_currency,
                     cce.cost_element_key,
                     cus.isp_sold_to,
                     cus.payer_mdm_id,
                     cus.sold_to_mdm_id,
                     f.current_date(),
                     sfdc.market_space,
                     sfdc.carrier,
                     sfdc.account_holder,
                     sfdc.group,
                     sfdc.customer_type,
                     sfdc.customer_segment,
                     sfdc.rsm,
                     cce.sem_location_id) \
            .agg(f.sum(cce.value_usd).alias("net_value")) \
            .select(cce.period.alias("pricing_date"),
                    cce.period.alias("billing_date"),
                    cce.period.alias("delivery_date"),
                    cus.customer_country,
                    cus.grn_header,
                    cus.customer_account_name,
                    cus.cc_grn,
                    cus.grn,
                    cus.account_manager,
                    cus.sector,
                    f.lit('CS&O').alias("source_system"),
                    cus.sales_organisation,
                    f.lit('CS&O').alias("sales_document"),
                    f.lit('CS&O').alias("delivery_number"),
                    f.lit('CS&O').alias("material_number"),
                    f.lit('CS&O').alias("material_description"),
                    f.lit('CS&O').alias("local_material_description"),
                    f.lit('CS&O').alias("billing_document"),
                    f.lit('CS&O').alias("billing_item"),
                    lc.local_currency.alias("local_currency"),
                    f.lit(0).cast('DoubleType').alias("qty_in_m3"),
                    f.lit(0).cast('DoubleType').alias("qty_in_usg"),
                    f.lit(0).cast('DoubleType').alias("qty_in_litres"),
                    f.col("net_value"),
                    f.lit("USD").alias("document_currency"),
                    f.lit('').cast('string').alias("flight_number"),
                    f.lit('').cast('string').alias("aircraft_registration"),
                    f.lit('N').alias("intercompany_flag"),
                    cus.payer_mdm_id.alias("payer"),
                    cus.sold_to_mdm_id.alias("soldto_party"),
                    f.lit('').cast('string').alias("costing_country"),
                    f.current_date().alias("last_modified_date"),
                    sfdc.market_space.alias("market_space"),
                    sfdc.carrier.alias("carrier"),
                    sfdc.account_holder.alias("sf_account_manager"),
                    sfdc.group.alias("group"),
                    sfdc.customer_type.alias("customer_type"),
                    sfdc.customer_segment.alias("customer_segment"),
                    sfdc.rsm.alias("regional_sales_manager"),
                    f.lit('NA').alias("delivery_method"),
                    cce.cost_element_key,
                    cus.isp_sold_to.alias("trx_cust_key"),
                    cus.isp_sold_to.alias("dim_cust_key"),
                    cce.sem_location_id.alias("trx_loc_key"),
                    f.lit('CS&O').alias("trx_pro_key"),
                    f.lit('CS&O').alias("dim_pro_key"),
                    cce.sem_location_id)

        return df_tfx_result


if __name__ == '__main__':
    trl = CsoETL()
    trl.execute()
