# == == == == == == == == == == == == == == == =Revision History == == == == == == == == == == == == == == == == == ==
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      14-Jun-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-cso-l51-sov into conform zone
# Author        :- Liz Harvey
# Date          :- 14-Jun-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class CsoETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'netapp_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.netapp_database = args['netapp_database']
        self.destination_bucket = args['destination_bucket']
        self.environment = args['environment']

        # report specific =============================================
        self.input_tables = ['l3_cs_and_o_sov', 'l51_summary', 'l4_dim_location', 'l51_cs_and_o_loc_pct',
                             'l51_cs_and_o_cus_pct_s1']
        self.report_file = 'l51_cs_and_o_sov'
        self.report_file1 = 'l51_cs_and_o_lc'
        self.report_file2 = 'l51_cs_and_o_cus_pct'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.netapp_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        print('Reading data from input tabled {}.{}'.format(self.netapp_database, self.input_tables[0]))
        df_1 = self._get_table(self.netapp_database, self.input_tables[0])

        print('Reading data from input tabled {}.{}'.format(self.source_database, self.input_tables[1]))
        df_2 = self._get_table(self.source_database, self.input_tables[1])

        print('Reading data from input tabled {}.{}'.format(self.source_database, self.input_tables[2]))
        df_3 = self._get_table(self.source_database, self.input_tables[2])

        print('Reading data from input tabled {}.{}'.format(self.source_database, self.input_tables[3]))
        df_4 = self._get_table(self.source_database, self.input_tables[3])

        print('Reading data from input tabled {}.{}'.format(self.source_database, self.input_tables[4]))
        df_5 = self._get_table(self.source_database, self.input_tables[4])

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('applying the transformations')
        df_tfx_table = self._apply_tfx(df_1, df_2, df_3, df_4, df_5)
        # print('schema after transformation ', df_tfx_table.printSchema())

        # write final result to required destination
        print('Write sov job to s3')
        self.write_results(df_tfx_table[0], self.report_file)

        print('Write lc job to s3')
        self.write_results(df_tfx_table[1], self.report_file1)

        print('Write cus pct job to s3')
        self.write_results(df_tfx_table[2], self.report_file2)

    def write_results(self, target_dataset, report_file):
        final_path = self.destination_bucket + '/' + report_file
        print('final_path', final_path)
        target_dataset \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        l3_sov = args[0]
        df_l51_sum = args[1]
        df_dim_loc = args[2]
        df_loc = args[3]
        df_cus = args[4]

        sov_result = l3_sov.select(l3_sov.src_of_val.alias("src_of_val"),
                                   l3_sov.pricing_condition_l5.alias("pricing_condition_l5"),
                                   l3_sov.ep2.alias("ep2_ind"),
                                   l3_sov.lcp.alias("lcp_ind")
                                   )

        m = df_l51_sum.alias("S").join(df_dim_loc.alias("L"), f.col("S.sem_location_id") == f.col("L.locationid")) \
            .groupBy(f.col("L.location_country")) \
            .agg(f.max(f.col("S.delivery_date")).alias("max_delivery_date")) \
            .select(f.col("L.location_country"), f.col("max_delivery_date"))

        lc_result = df_l51_sum.alias("S").join(df_dim_loc.alias("L"), f.col("L.locationid") == f.col("S.sem_location_id")) \
            .join(m, (m.location_country == f.col("L.location_country")) & (m.max_delivery_date == f.col("S.delivery_date"))) \
            .select(f.col("L.location_country"),
                    f.col("S.local_currency")).distinct()

        join_tbl = df_cus.groupBy(df_cus.supply_chain,
                                  df_cus.src_of_val,
                                  df_cus.sem_location_id,
                                  df_cus.period) \
            .agg(f.sum(df_cus.pct).alias("tot_pct")) \
            .select(df_cus.supply_chain,
                    df_cus.src_of_val,
                    df_cus.sem_location_id,
                    df_cus.period,
                    df_cus.tot_pct)

        df_joined = df_loc.alias("loc").join(join_tbl.alias("tot"), (f.col("loc.supply_chain") == f.col("tot.supply_chain"))
                                             & (f.col("loc.src_of_val") == f.col("tot.src_of_val"))
                                             & (f.col("loc.sem_location_id") == f.col("tot.sem_location_id"))
                                             & (f.col("loc.period") == f.col("tot.period")), 'left') \
            .filter(100 - f.coalesce(f.col("tot.tot_pct"), f.lit(0)) > 0) \
            .select(f.col("loc.src_of_val"),
                    f.lit('I').alias("sov_ind"),
                    f.col("loc.supply_chain"),
                    f.lit('').alias("iata"),
                    f.col("loc.sem_location_id"),
                    f.col("loc.sem_iata"),
                    f.col("loc.sem_location_name"),
                    f.lit('Into Plane').alias("customer_account_name"),
                    f.lit('').alias("grn"),
                    f.lit('').alias("sales_organisation"),
                    f.col("loc.period"),
                    f.lit(0).alias("dpct"),
                    f.lit(0).alias("spct"),
                    (100 - f.coalesce(f.col("tot.tot_pct"), f.lit(0))).alias("pct"))

        cus_pct_result = df_cus.unionAll(df_joined)

        return [sov_result, lc_result, cus_pct_result]


if __name__ == '__main__':
    trl = CsoETL()
    trl.execute()

