# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Hasan Chaudhary 27-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-pre-l3-l31-salesbenchmark.py into conform zone
# Author        :- Hasan Chaudhary
# Date          :- 27-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l3_pre_zcas_bmca_benchmark_adj', 'l3_pre_vbrp_billing_items',
                                 'l3_pre_lipso2_delivery_addl_qty', 'l3_pre_exchange_rates'
                                 ]
        self.report_file = "l31_pre_sales_benchmark"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # generate input table list
        source_database = self.source_database
        input_table_list = self.input_table_list
        print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        df_zcas = self._get_table(source_database, input_table_list[0]).toDF()
        # print("data count of table {}.{} is {}".format(source_database, input_table_list[0],
        #                                               df_zcas.count()))
        df_vbrp = self._get_table(source_database, input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(source_database, input_table_list[1],
        #                                               df_vbrp.count()))
        df_lipso2 = self._get_table(source_database, input_table_list[2]).toDF()
        # print("data count of table {}.{} is {}".format(source_database, input_table_list[2],
        #                                               df_lipso2.count()))
        df_rate = self._get_table(source_database, input_table_list[3]).toDF()
        # print("data count of table {}.{} is {}".format(source_database, input_table_list[3],
        #                                               df_rate.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_zcas, df_vbrp, df_lipso2, df_rate)
        #print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # MAIN LOGIC FOR SALES BENCHMARK CALCULATION  - Read data
        df_zcas = args[0].filter(args[0].fkdat >= '2021-02-15')
        df_vbrp = args[1]
        df_lipso2 = args[2].filter(args[2].msehi == 'M15') \
            .select(args[2].vbeln, args[2].posnr, args[2].adqntp).distinct()
        df_rate = args[3]

        df_benchmark = df_zcas.join(df_vbrp, (df_zcas.vbeln == df_vbrp.vbeln) & (df_zcas.posnr == df_vbrp.posnr),
                                    'left') \
            .join(df_lipso2, (df_vbrp.vgbel == df_lipso2.vbeln) & (df_vbrp.vgpos == df_lipso2.posnr), 'left') \
            .select(df_zcas.fkart, df_zcas.vbtyp, df_zcas.alt_bm_pp, df_zcas.exchange_rate,
                    df_zcas.vkorg, df_zcas.spart, df_zcas.vtweg, df_zcas.matnr,
                    df_zcas.vbeln, df_zcas.posnr, df_zcas.cogs, df_zcas.bm_pp,
                    df_zcas.bm_pp_c, df_zcas.waers, df_zcas.zzavcurr, df_zcas.fkdat, df_zcas.datefrom,
                    df_zcas.dateto, df_zcas.yf51_avg, df_zcas.yf51_curr, df_zcas.yf51_ddate, df_zcas.zex_off_rate_type,
                    df_vbrp.vgbel, df_vbrp.vgpos, df_lipso2.adqntp,
                    (((df_zcas.yf51_ddate) - (df_zcas.yf51_avg)) * df_lipso2.adqntp).alias('amount_yf51'))
        #print("data count of table is {}".format(df_benchmark.count()))
        df_benchmark_a = df_benchmark.join(df_rate,
                                           (df_benchmark.yf51_curr == df_rate.fcurr) & (
                                                   df_rate.tcurr == df_benchmark.waers) &
                                           (df_rate.kurst == df_benchmark.zex_off_rate_type) & (
                                                   df_rate.gdatu == df_benchmark.fkdat),
                                           'inner') \
            .select(df_rate.ukurs.alias('local_curr'), df_benchmark.vbeln.alias('vbeln_a'),
                    df_benchmark.posnr.alias('posnr_a'))
        #print("data count of table is {}".format(df_benchmark_a.count()))
        df_benchmark_b = df_benchmark.join(df_rate,
                                           (df_benchmark.yf51_curr == df_rate.fcurr) & (df_rate.tcurr == 'USD') & (
                                                   df_rate.gdatu == df_benchmark.fkdat) & (df_rate.kurst == 'M'),
                                           'inner') \
            .select(df_rate.ukurs.alias('global_curr'), df_benchmark.vbeln.alias('vbeln_b'),
                    df_benchmark.posnr.alias('posnr_b'))
        #print("data count of table is {}".format(df_benchmark_b.count()))
        df_benchmark_c = df_benchmark.join(df_rate,
                                           (df_rate.tcurr == 'EUR') & (df_rate.fcurr == df_benchmark.waers) &
                                           (df_rate.kurst == df_benchmark.zex_off_rate_type) & (
                                                   df_rate.gdatu == df_benchmark.fkdat),
                                           'inner') \
            .select(df_rate.ukurs.alias('ukurs_5_eur'), df_benchmark.vbeln.alias('vbeln_c'),
                    df_benchmark.posnr.alias('posnr_c'))
        #print("data count of table is {}".format(df_benchmark_c.count()))
        df_benchmark_d = df_benchmark.join(df_rate,
                                           (df_rate.fcurr == 'USD') & (df_rate.tcurr == 'EUR') &
                                           (df_rate.kurst == df_benchmark.zex_off_rate_type) & (
                                                   df_rate.gdatu == df_benchmark.fkdat),
                                           'inner') \
            .select(df_rate.ukurs.alias('ukurs_usdeur'), df_benchmark.vbeln.alias('vbeln_d'),
                    df_benchmark.posnr.alias('posnr_d'))
        #print("data count of table is {}".format(df_benchmark_d.count()))
        df_tfx_result = df_benchmark.join(df_benchmark_a,
                                          (df_benchmark.vbeln == df_benchmark_a.vbeln_a) & (
                                                  df_benchmark.posnr == df_benchmark_a.posnr_a),
                                          'left') \
            .join(df_benchmark_b,
                  (df_benchmark.vbeln == df_benchmark_b.vbeln_b) & (df_benchmark.posnr == df_benchmark_b.posnr_b),
                  'left') \
            .join(df_benchmark_c,
                  (df_benchmark.vbeln == df_benchmark_c.vbeln_c) & (df_benchmark.posnr == df_benchmark_c.posnr_c),
                  'left') \
            .join(df_benchmark_d,
                  (df_benchmark.vbeln == df_benchmark_d.vbeln_d) & (df_benchmark.posnr == df_benchmark_d.posnr_d),
                  'left') \
            .select(df_benchmark.fkart, df_benchmark.vbtyp, df_benchmark.alt_bm_pp, df_benchmark.exchange_rate,
                    df_benchmark.vkorg,
                    df_benchmark.spart, df_benchmark.vtweg, df_benchmark.matnr, df_benchmark.vbeln, df_benchmark.posnr,
                    df_benchmark.cogs,
                    df_benchmark.bm_pp, df_benchmark.bm_pp_c, df_benchmark.waers, df_benchmark.zzavcurr,
                    df_benchmark.fkdat, df_benchmark.datefrom,
                    df_benchmark.dateto, df_benchmark.yf51_avg, df_benchmark.yf51_curr, df_benchmark.yf51_ddate,
                    df_benchmark.zex_off_rate_type,
                    df_benchmark.vgbel.alias('reference_document'), df_benchmark.vgpos.alias('reference_item'),
                    df_benchmark.amount_yf51,
                    df_benchmark_c.ukurs_5_eur, df_benchmark_d.ukurs_usdeur,
                    df_benchmark_a.local_curr, df_benchmark_b.global_curr,
                    f.when((df_benchmark.zex_off_rate_type == f.lit('ECB')) & (
                            df_benchmark.waers.isin(['EUR', 'HUF']) == False),
                           (df_benchmark.amount_yf51 * (df_benchmark_c.ukurs_5_eur * f.lit(-1)) *
                            (f.lit(1) / df_benchmark_d.ukurs_usdeur * f.lit(-1))).cast('double'))
                    .when((df_benchmark.yf51_curr == df_benchmark.waers), df_benchmark.amount_yf51)
                    .otherwise((df_benchmark.amount_yf51 * (f.lit(1) / (df_benchmark_a.local_curr * f.lit(-1))))).alias(
                        'amount_lc'),
                    f.when(df_benchmark.yf51_curr == 'USD', df_benchmark.amount_yf51)
                    .when(df_benchmark.yf51_curr == 'MXN', df_benchmark.amount_yf51 * df_benchmark_b.global_curr)
                    .otherwise(df_benchmark.amount_yf51 * (1 / (df_benchmark_b.global_curr * -1))).alias('amount_gc')
                    )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
