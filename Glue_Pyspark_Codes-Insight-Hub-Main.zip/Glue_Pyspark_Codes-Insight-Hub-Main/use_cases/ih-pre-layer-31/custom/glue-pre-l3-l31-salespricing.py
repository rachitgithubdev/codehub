# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Hasan Chaudhary 8-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-pre-l3-l31-salespricing.py into conform zone
# Author        :- Hasan Chaudhary
# Date          :- 8-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l3_pre_vbrp_billing_items', 'l3_pre_vbrk_billing_header',
                                 'l3_pre_zsds_cond_exch_rate_indicator', 'l3_pre_konv_pricing_conditions',
                                 'l3_pre_exchange_rates'
                                 ]
        self.report_file = "l31_pre_sales_pricing"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # generate input table list
        source_database = self.source_database
        input_table_list = self.input_table_list
        print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        df_vbrp = self._get_table(source_database, input_table_list[0]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[0],
        #                                               df_vbrp.count()))
        df_vbrk = self._get_table(source_database, input_table_list[1]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[1],
        #                                               df_vbrk.count()))
        df_zsds = self._get_table(source_database, input_table_list[2]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[2],
        #                                               df_zsds.count()))
        df_konv = self._get_table(source_database, input_table_list[3]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[3],
        #                                               df_konv.count()))
        df_rate = self._get_table(source_database, input_table_list[4]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[4],
        #                                               df_rate.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_vbrp, df_vbrk, df_zsds, df_konv, df_rate)
        #print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # MAIN LOGIC FOR SALES BILLING CALCULATION  - Read data
        df_vbrp = args[0]
        df_vbrk = args[1]
        df_zsds = args[2].groupBy(args[2].kschl).agg(
            f.max(args[2].zzdexrt).alias('zzdexrt'))
        df_konv = args[3]
        df_rate = args[4].filter((args[4].kurst == 'M') & (args[4].tcurr == 'USD'))

        df_zsds = df_zsds.groupBy('kschl').agg(
            f.max('zzdexrt').alias('zzdexrt'))

        df_zsds = df_zsds.select(df_zsds.kschl, df_zsds.zzdexrt)

        df_konv = df_vbrp.join(df_vbrk, df_vbrp.vbeln == df_vbrk.vbeln, 'inner') \
            .join(df_konv, (df_vbrk.knumv == df_konv.knumv) & (df_vbrp.posnr == df_konv.kposn),
                  'inner') \
            .join(df_zsds, df_konv.kschl == df_zsds.kschl, 'left') \
            .join(df_rate, (df_vbrk.fkdat == df_rate.gdatu) & (
                df_vbrk.cmwae == df_rate.fcurr),
                  'left') \
            .select(df_vbrk.vbeln.alias('vbeln_vbrk'), df_vbrk.vbtyp, df_vbrk.waerk, df_vbrk.cmwae,
                    df_vbrk.knumv.alias('knumv_vbrk'), df_vbrk.fkdat,
                    df_vbrp.vbeln.alias('vbeln_vbrp'), df_vbrp.posnr,
                    f.when(df_vbrp.kursk.isNull(), f.lit(0)).otherwise(df_vbrp.kursk).alias('kursk'),
                    f.when(df_vbrp.zzavgcurrdocloc.isNull(), f.lit(0)).otherwise(df_vbrp.zzavgcurrdocloc).alias(
                        'zzavgcurrdocloc'),
                    f.when(df_vbrp.zzdminus1rate.isNull(), f.lit(0)).otherwise(df_vbrp.zzdminus1rate).alias(
                        'zzdminus1rate'),
                    f.when(df_vbrp.zzexchrate_wf.isNull(), f.lit(0)).otherwise(df_vbrp.zzexchrate_wf).alias(
                        'zzexchrate_wf'),
                    df_konv.knumv.alias('knumv_konv'), df_konv.kposn,
                    df_konv.kschl.alias('kschl_konv'), df_konv.kntyp,
                    f.when((df_vbrk.vbtyp == 'N') | (df_vbrk.vbtyp == 'O') | (df_vbrk.vbtyp == '6'),
                           df_konv.kwert * (-1)).otherwise(df_konv.kwert).alias('kwert'),
                    df_konv.stunr,
                    df_konv.zaehk, df_konv.kappl, df_konv.kawrt, df_konv.kbetr, df_konv.waers, df_konv.kkurs,
                    df_zsds.kschl.alias('kschl_zsds'), df_zsds.zzdexrt,
                    df_rate.kurst, df_rate.fcurr, df_rate.tcurr,
                    df_rate.gdatu, df_rate.ukurs)

        df_konv = df_konv.select('vbeln_vbrk', 'vbtyp', 'waerk', 'cmwae', 'knumv_vbrk', 'fkdat', 'vbeln_vbrp', 'posnr',
                                 'kursk', 'zzavgcurrdocloc', 'zzdminus1rate', 'zzexchrate_wf', 'knumv_konv', 'kposn',
                                 'kschl_konv', 'kntyp',
                                 'kwert', 'stunr', 'zaehk', 'kappl', 'kawrt', 'kbetr', 'waers', 'kkurs', 'kschl_zsds',
                                 'zzdexrt',
                                 'kurst', 'fcurr', 'tcurr', 'gdatu', 'ukurs',
                                 f.when(df_konv.cmwae == f.lit('HUF'), df_konv.kwert * 100).otherwise(
                                     df_konv.kwert).alias('var_amount_huf')
                                 )
        df_konv = df_konv.select('vbeln_vbrk', 'vbtyp', 'waerk', 'cmwae', 'knumv_vbrk', 'fkdat', 'vbeln_vbrp', 'posnr',
                                 'kursk', 'zzavgcurrdocloc', 'zzdminus1rate', 'zzexchrate_wf', 'knumv_konv', 'kposn',
                                 'kschl_konv', 'kntyp',
                                 'kwert', 'stunr', 'zaehk', 'kappl', 'kawrt', 'kbetr', 'waers', 'kkurs', 'kschl_zsds',
                                 'zzdexrt',
                                 'kurst', 'fcurr', 'tcurr', 'gdatu', 'ukurs',
                                 'var_amount_huf',
                                 f.when(df_konv.zzdexrt == f.lit('A'),
                                        f.when(df_konv.zzavgcurrdocloc > f.lit(0),
                                               df_konv.kwert * df_konv.zzavgcurrdocloc)
                                        .when(df_konv.zzavgcurrdocloc < f.lit(0),
                                              (df_konv.kwert / df_konv.zzavgcurrdocloc) * (-1))
                                        .when(df_konv.zzavgcurrdocloc == f.lit(0),
                                              f.when(df_konv.kursk > f.lit(0), df_konv.kwert * df_konv.kursk)
                                              .when(df_konv.kursk < f.lit(0), (df_konv.kwert / df_konv.kursk) * (-1))
                                              .otherwise(df_konv.kwert)
                                              )
                                        )
                                 .when(df_konv.zzdexrt == f.lit('B'),
                                       f.when(df_konv.zzdminus1rate > f.lit(0), df_konv.kwert * df_konv.zzdminus1rate)
                                       .when(df_konv.zzdminus1rate < f.lit(0),
                                             (df_konv.kwert / df_konv.zzdminus1rate) * (-1))
                                       .when(df_konv.zzdminus1rate == f.lit(0),
                                             f.when(df_konv.kursk > f.lit(0), df_konv.kwert * df_konv.kursk)
                                             .when(df_konv.kursk < f.lit(0), (df_konv.kwert / df_konv.kursk) * (-1))
                                             .otherwise(df_konv.kwert)
                                             )
                                       )
                                 .when(df_konv.zzdexrt == f.lit('C'),
                                       f.when(df_konv.zzexchrate_wf > f.lit(0), df_konv.kwert * df_konv.zzexchrate_wf)
                                       .when(df_konv.zzexchrate_wf < f.lit(0),
                                             (df_konv.kwert / df_konv.zzexchrate_wf) * (-1))
                                       .when(df_konv.zzexchrate_wf == f.lit(0),
                                             f.when(df_konv.kursk > f.lit(0), df_konv.kwert * df_konv.kursk)
                                             .when(df_konv.kursk < f.lit(0), (df_konv.kwert / df_konv.kursk) * (-1))
                                             .otherwise(df_konv.kwert)
                                             )
                                       ).alias('var_amount_lc'))

        # exp_USD_AND_USD

        df_konv1 = df_konv.filter((df_konv.cmwae == 'USD') & (df_konv.waerk == 'USD')) \
            .select(df_konv.vbeln_vbrk, df_konv.waerk, df_konv.cmwae, df_konv.knumv_vbrk, df_konv.fkdat,
                    df_konv.vbeln_vbrp, df_konv.posnr, df_konv.kursk, df_konv.zzavgcurrdocloc, df_konv.zzdminus1rate,
                    df_konv.zzexchrate_wf,
                    df_konv.knumv_konv, df_konv.kposn, df_konv.kschl_konv, df_konv.kntyp, df_konv.kwert,
                    df_konv.stunr, df_konv.zaehk, df_konv.kappl, df_konv.kawrt, df_konv.kbetr, df_konv.waers,
                    df_konv.kkurs, df_konv.kschl_zsds,
                    df_konv.zzdexrt, df_konv.kurst, df_konv.fcurr, df_konv.tcurr, df_konv.gdatu,
                    df_konv.ukurs,
                    df_konv.var_amount_huf,
                    df_konv.var_amount_lc,
                    df_konv.cmwae,
                    df_konv.waerk,
                    f.when(df_konv.kntyp == '9', df_konv.kwert * (-1)).otherwise(df_konv.kwert).alias(
                        'amount_lc'),
                    f.when(df_konv.kntyp == '9', df_konv.kwert * (-1)).otherwise(df_konv.kwert).alias(
                        'amount_gc')
                    )

        #print("data count of table is {}".format(df_konv1.count()))
        # exp_NOT_USD_AND_NOT_USD_SAME

        df_konv2 = df_konv.filter(
            ((df_konv.cmwae != 'USD') & (df_konv.waerk != 'USD')) & (df_konv.cmwae == df_konv.waerk)) \
            .select(df_konv.vbeln_vbrk, df_konv.waerk, df_konv.cmwae, df_konv.knumv_vbrk, df_konv.fkdat,
                    df_konv.vbeln_vbrp, df_konv.posnr, df_konv.kursk, df_konv.zzavgcurrdocloc, df_konv.zzdminus1rate,
                    df_konv.zzexchrate_wf,
                    df_konv.knumv_konv, df_konv.kposn, df_konv.kschl_konv, df_konv.kntyp, df_konv.kwert,
                    df_konv.stunr, df_konv.zaehk, df_konv.kappl, df_konv.kawrt, df_konv.kbetr, df_konv.waers,
                    df_konv.kkurs, df_konv.kschl_zsds,
                    df_konv.zzdexrt, df_konv.kurst, df_konv.fcurr, df_konv.tcurr, df_konv.gdatu,
                    df_konv.ukurs,
                    df_konv.var_amount_huf,
                    df_konv.var_amount_lc,
                    df_konv.cmwae,
                    df_konv.waerk,
                    f.when(df_konv.kntyp == '9', df_konv.var_amount_huf * (-1)).otherwise(df_konv.var_amount_huf).alias(
                        'amount_lc'),
                    f.when(df_konv.ukurs < f.lit(0),
                           f.when(df_konv.kntyp == '9', (df_konv.var_amount_huf / df_konv.ukurs) * -1 * -1).otherwise(
                               (df_konv.var_amount_huf / df_konv.ukurs) * -1))
                    .otherwise(f.when(df_konv.kntyp == '9', (df_konv.var_amount_huf * df_konv.ukurs) * -1).otherwise(
                        df_konv.var_amount_huf * df_konv.ukurs))
                    .alias('amount_gc')
                    )

        #print("data count of table is {}".format(df_konv2.count()))
        # exp_USD_AND_NOT_USD

        df_konv3 = df_konv.filter(((df_konv.cmwae != 'USD') | (df_konv.cmwae.isNull()))& (df_konv.waerk == 'USD')) \
            .select(df_konv.vbeln_vbrk, df_konv.waerk, df_konv.cmwae, df_konv.knumv_vbrk, df_konv.fkdat,
                    df_konv.vbeln_vbrp, df_konv.posnr, df_konv.kursk, df_konv.zzavgcurrdocloc, df_konv.zzdminus1rate,
                    df_konv.zzexchrate_wf,
                    df_konv.knumv_konv, df_konv.kposn, df_konv.kschl_konv, df_konv.kntyp, df_konv.kwert,
                    df_konv.stunr, df_konv.zaehk, df_konv.kappl, df_konv.kawrt, df_konv.kbetr, df_konv.waers,
                    df_konv.kkurs, df_konv.kschl_zsds,
                    df_konv.zzdexrt, df_konv.kurst, df_konv.fcurr, df_konv.tcurr, df_konv.gdatu,
                    df_konv.ukurs,
                    df_konv.var_amount_huf,
                    df_konv.var_amount_lc,
                    df_konv.cmwae,
                    df_konv.waerk,
                    f.when(df_konv.kntyp == '9', df_konv.var_amount_lc * (-1)).otherwise(df_konv.var_amount_lc).alias(
                        'amount_lc'),
                    f.when(df_konv.kntyp == '9', df_konv.kwert * (-1)).otherwise(df_konv.kwert).alias(
                        'amount_gc')
                    )

        #print("data count of table is {}".format(df_konv3.count()))
        # exp_NOT_USD_AND_USD

        df_konv4 = df_konv.filter(((df_konv.cmwae == 'USD') | (df_konv.cmwae.isNull())) & (df_konv.waerk != 'USD')) \
            .select(df_konv.vbeln_vbrk, df_konv.waerk, df_konv.cmwae, df_konv.knumv_vbrk, df_konv.fkdat,
                    df_konv.vbeln_vbrp, df_konv.posnr, df_konv.kursk, df_konv.zzavgcurrdocloc, df_konv.zzdminus1rate,
                    df_konv.zzexchrate_wf,
                    df_konv.knumv_konv, df_konv.kposn, df_konv.kschl_konv, df_konv.kntyp, df_konv.kwert,
                    df_konv.stunr, df_konv.zaehk, df_konv.kappl, df_konv.kawrt, df_konv.kbetr, df_konv.waers,
                    df_konv.kkurs, df_konv.kschl_zsds,
                    df_konv.zzdexrt, df_konv.kurst, df_konv.fcurr, df_konv.tcurr, df_konv.gdatu,
                    df_konv.ukurs,
                    df_konv.var_amount_huf,
                    df_konv.var_amount_lc,
                    df_konv.cmwae,
                    df_konv.waerk,
                    f.when(df_konv.kntyp == '9', df_konv.var_amount_lc * (-1)).otherwise(df_konv.var_amount_lc).alias(
                        'amount_lc'),
                    f.when(df_konv.kntyp == '9', df_konv.var_amount_lc * (-1)).otherwise(df_konv.var_amount_lc).alias(
                        'amount_gc')
                    )

        #print("data count of table is {}".format(df_konv4.count()))
        # exp_NOT_USD_AND_NOT_USD_NOT_SAME

        df_konv5 = df_konv.filter(
            ((df_konv.cmwae != 'USD') & (df_konv.waerk != 'USD')) & (df_konv.cmwae != df_konv.waerk)) \
            .select(df_konv.vbeln_vbrk, df_konv.waerk, df_konv.cmwae, df_konv.knumv_vbrk, df_konv.fkdat,
                    df_konv.vbeln_vbrp, df_konv.posnr, df_konv.kursk, df_konv.zzavgcurrdocloc, df_konv.zzdminus1rate,
                    df_konv.zzexchrate_wf,
                    df_konv.knumv_konv, df_konv.kposn, df_konv.kschl_konv, df_konv.kntyp, df_konv.kwert,
                    df_konv.stunr, df_konv.zaehk, df_konv.kappl, df_konv.kawrt, df_konv.kbetr, df_konv.waers,
                    df_konv.kkurs, df_konv.kschl_zsds,
                    df_konv.zzdexrt, df_konv.kurst, df_konv.fcurr, df_konv.tcurr, df_konv.gdatu,
                    df_konv.ukurs,
                    df_konv.var_amount_huf,
                    df_konv.var_amount_lc,
                    df_konv.cmwae,
                    df_konv.waerk,
                    f.when(df_konv.kntyp == '9', df_konv.var_amount_lc * (-1)).otherwise(df_konv.var_amount_lc).alias(
                        'amount_lc'),
                    f.when(df_konv.ukurs < f.lit(0),
                           f.when(df_konv.kntyp == '9', (df_konv.var_amount_lc / df_konv.ukurs) * -1 * -1).otherwise(
                               (df_konv.var_amount_lc / df_konv.ukurs) * -1))
                    .otherwise(f.when(df_konv.kntyp == '9', (df_konv.var_amount_lc * df_konv.ukurs) * -1).otherwise(
                        df_konv.var_amount_lc * df_konv.ukurs))
                    .alias('amount_gc')
                    )

        #print("data count of table is {}".format(df_konv5.count()))

        df_konv = reduce(DataFrame.union, [df_konv1, df_konv2, df_konv3, df_konv4, df_konv5])

        df_tfx_result = df_konv.select(df_konv.knumv_konv.alias('knumv_doc_condition_no'),
                                       df_konv.kposn.alias('kposn_itemno'),
                                       df_konv.kschl_konv.alias('kschl_condition_type'),
                                       df_konv.kntyp.alias('kntyp_condition_category'),
                                       df_konv.kwert.alias('kwert_condition_value'),
                                       df_konv.stunr.alias('stunr_step_number'),
                                       df_konv.zaehk.alias('zaehk_counter'), df_konv.kappl.alias('kappl_application'),
                                       df_konv.kawrt.alias('kawrt_condition_base_value'),
                                       df_konv.kbetr.alias('kbetr_condition_rate'),
                                       df_konv.waers.alias('waers_currency'),
                                       df_konv.kkurs.alias('kkurs_condexchange_rate'),
                                       # df_konv.cmwae,
                                       # df_konv.waerk,
                                       # df_konv.var_amount_huf,
                                       # df_konv.var_amount_lc,
                                       f.when(df_konv.amount_lc.isNull(), f.lit(0)).otherwise(df_konv.amount_lc).alias(
                                           'amount_lc'),
                                       f.when(df_konv.amount_gc.isNull(), f.lit(0)).otherwise(df_konv.amount_gc).alias(
                                           'amount_gc'))

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
