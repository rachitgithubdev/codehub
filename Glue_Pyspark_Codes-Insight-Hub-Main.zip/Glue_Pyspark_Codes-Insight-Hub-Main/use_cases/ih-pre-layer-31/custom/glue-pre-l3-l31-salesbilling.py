# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Hasan Chaudhary 11-Mar-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-pre-l3-l31-salesbilling.py into conform zone
# Author        :- Hasan Chaudhary
# Date          :- 11-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.functions import upper
from pyspark.sql.functions import col
from pyspark.sql.functions import when
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l3_pre_vbrp_billing_items', 'l3_pre_vbrk_billing_header',
                                 'l3_pre_vbpa_sales_partners', 'l3_pre_lipso2_delivery_addl_qty',
                                 'l3_pre_makt_material_descriptions', 'l3_pre_marm_material_uom',
                                 'l3_pre_vbak_sales_doc_header'
                                 ]
        self.report_file = "l31_pre_sales_billing"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # generate input table list
        source_database = self.source_database
        input_table_list = self.input_table_list
        print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        df_vbrp = self._get_table(source_database, input_table_list[0]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[0],
        #                                               df_vbrp.count()))
        df_vbrk = self._get_table(source_database, input_table_list[1]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[1],
        #                                               df_vbrk.count()))
        df_vbpa = self._get_table(source_database, input_table_list[2]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[2],
        #                                               df_vbpa.count()))
        df_lipso2 = self._get_table(source_database, input_table_list[3]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[3],
        #                                               df_lipso2.count()))
        df_makt = self._get_table(source_database, input_table_list[4]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[4],
        #                                               df_makt.count()))
        df_marm = self._get_table(source_database, input_table_list[5]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[5],
        #                                               df_marm.count()))
        df_vbak = self._get_table(source_database, input_table_list[6]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[6],
        #                                               df_vbak.count()))
        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_vbrp, df_vbrk, df_vbpa, df_lipso2, df_makt, df_marm, df_vbak)
        #print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # LOGIC FOR MARM - Read data
        df_vbrp_marm = args[0].select(args[0].vbeln.alias('A_vbeln'), args[0].posnr.alias('A_posnr'),
                                      args[0].meins.alias('A_meins'), args[0].fklmg.alias('A_fklmg'),
                                      args[0].matnr.alias('A_matnr'))
        df_marm = args[5].select(args[5].matnr.alias('B_matnr'), args[5].meinh.alias('B_meinh'),
                                 args[5].umrez.alias('B_umrez'), args[5].umren.alias('B_umren'))
        df_marm1 = args[5].select(args[5].matnr.alias('C_matnr'), args[5].meinh.alias('C_meinh'),
                                  args[5].umrez.alias('C_umrez'), args[5].umren.alias('C_umren'))
        df_marm2 = args[5].select(args[5].matnr.alias('D_matnr'), args[5].meinh.alias('D_meinh'),
                                  args[5].umrez.alias('D_umrez'), args[5].umren.alias('D_umren'))
        df_marm3 = args[5].select(args[5].matnr.alias('E_matnr'), args[5].meinh.alias('E_meinh'),
                                  args[5].umrez.alias('E_umrez'), args[5].umren.alias('E_umren'))
        df_marm4 = args[5].select(args[5].matnr.alias('F_matnr'), args[5].meinh.alias('F_meinh'),
                                  args[5].umrez.alias('F_umrez'), args[5].umren.alias('F_umren'))

        joined_df = df_vbrp_marm.join(
            df_marm, (col("A_matnr") == col("B_matnr")) &
                     (col("A_meins") == col("B_meinh")),
            'inner'
        )
        # join vbrp with marm on second condition
        joined_df = joined_df.join(
            df_marm1, (col("A_matnr") == col("C_matnr")) &
                      (upper(col("C_meinh")) == "TO"),
            'left'
        )
        # join vbrp with marm on third condition
        joined_df = joined_df.join(
            df_marm2, (col("A_matnr") == col("D_matnr")) &
                      (upper(col("D_meinh")) == "M3"),
            'left'
        )
        # join vbrp with marm on fourth condition
        joined_df = joined_df.join(
            df_marm3, (col("A_matnr") == col("E_matnr")) &
                      (upper(col("E_meinh")) == "L"),
            'left'
        )
        # join vbrp with marm on fourth condition
        joined_df = joined_df.join(
            df_marm4, (col("A_matnr") == col("F_matnr")) &
                      (upper(col("F_meinh")) == "UGL"),
            'left'
        )

        df_marm = joined_df.select(
            joined_df.A_vbeln.alias('vbeln'),
            joined_df.A_posnr.alias('posnr'),
            joined_df.A_meins.alias('meins'),
            joined_df.A_fklmg.alias('fklmg'),
            joined_df.A_matnr.alias('matnr'),
            ((joined_df.A_fklmg * (joined_df.B_umrez.cast('decimal') / joined_df.B_umren.cast('decimal'))) / (
                    joined_df.C_umrez.cast('decimal') / joined_df.C_umren.cast('decimal'))).alias('zzqty_to_marm'),
            ((joined_df.A_fklmg * (joined_df.B_umrez.cast('decimal') / joined_df.B_umren.cast('decimal'))) / (
                    joined_df.D_umrez.cast('decimal') / joined_df.D_umren.cast('decimal'))).alias('zzqty_m3_marm'),
            ((joined_df.A_fklmg * (joined_df.B_umrez.cast('decimal') / joined_df.B_umren.cast('decimal'))) / (
                    joined_df.E_umrez.cast('decimal') / joined_df.E_umren.cast('decimal'))).alias('zzqty_l_marm'),
            ((joined_df.A_fklmg * (joined_df.B_umrez.cast('decimal') / joined_df.B_umren.cast('decimal'))) / (
                    joined_df.F_umrez.cast('decimal') / joined_df.F_umren.cast('decimal'))).alias('zzqty_ugl_marm'))

        # LOGIC FOR LIPSO2 - Read data
        df_lipso2 = args[3]
        # add group-by columns
        # new line
        df_lipso2 = df_lipso2.withColumn("group_by_L",
                                         when(df_lipso2.msehi == "L", df_lipso2.adqntp).otherwise(f.lit(0)))
        df_lipso2 = df_lipso2.withColumn("group_by_TO",
                                         when(df_lipso2.msehi == "TO", df_lipso2.adqntp).otherwise(f.lit(0)))
        df_lipso2 = df_lipso2.withColumn("group_by_M3",
                                         when(df_lipso2.msehi == "M3", df_lipso2.adqntp).otherwise(f.lit(0)))
        df_lipso2 = df_lipso2.withColumn("group_by_UGL",
                                         when(df_lipso2.msehi == "UGL", df_lipso2.adqntp).otherwise(f.lit(0)))

        # group-by function
        df_lipso2 = df_lipso2.groupBy('vbeln', 'posnr').agg(
            f.max('group_by_L').alias('zzqty_l_lipso'),
            f.max('group_by_TO').alias('zzqty_to_lipso'),
            f.max('group_by_M3').alias('zzqty_m3_lipso'),
            f.max('group_by_UGL').alias('zzqty_ugl_lipso'))

        df_lipso2 = df_lipso2.select('vbeln', 'posnr', 'zzqty_l_lipso', 'zzqty_to_lipso', 'zzqty_m3_lipso',
                                         'zzqty_ugl_lipso')

        # LOGIC FOR VBPA - Read data
        df_vbpa1 = args[2]
        df_vbpa2 = args[2]
        df_vbpa1_vbrp = args[0]
        df_vbpa2_vbrp = args[0]

        df_vbpa1 = df_vbpa1.withColumn("kunnr_customer_billto",
                                       when(df_vbpa1.parvw == "RE", df_vbpa1.kunnr).otherwise('00')) \
            .withColumn("kunnr_customer_soldto", when(df_vbpa1.parvw == "AG", df_vbpa1.kunnr).otherwise('00')) \
            .withColumn("kunnr_customer_payer", when(df_vbpa1.parvw == "RG", df_vbpa1.kunnr).otherwise('00')) \
            .withColumn("kunnr_customer_final_dest_partner",
                        when(df_vbpa1.parvw == "ZG", df_vbpa1.kunnr).otherwise('00')) \
            .withColumn("kunnr_customer_parent_partner", when(df_vbpa1.parvw == "1D", df_vbpa1.kunnr).otherwise('00')) \
            .withColumn("kunnr_customer_sales_rep", when(df_vbpa1.parvw == "ZR", df_vbpa1.kunnr).otherwise('00')) \
            .withColumn("kunnr_customer_agent_id", when(df_vbpa1.parvw == "ZF", df_vbpa1.kunnr).otherwise('00')) \
            .groupBy('vbeln', 'posnr').agg(
            f.max('kunnr_customer_billto').alias('kunnr_customer_billto'),
            f.max('kunnr_customer_soldto').alias('kunnr_customer_soldto'),
            f.max('kunnr_customer_payer').alias('kunnr_customer_payer'),
            f.max('kunnr_customer_final_dest_partner').alias('kunnr_customer_final_dest_partner'),
            f.max('kunnr_customer_parent_partner').alias('kunnr_customer_parent_partner'),
            f.max('kunnr_customer_sales_rep').alias('kunnr_customer_sales_rep'),
            f.max('kunnr_customer_agent_id').alias('kunnr_customer_agent_id')) \
            .join(df_vbpa1_vbrp, df_vbpa1.vbeln == df_vbpa1_vbrp.vbeln, 'leftouter') \
            .filter(df_vbpa1.posnr == 0) \
            .select(df_vbpa1.vbeln.alias('vbpa1_vbeln'), df_vbpa1.posnr.alias('vbpa1_posnr'), 'kunnr_customer_billto',
                    'kunnr_customer_soldto',
                    'kunnr_customer_payer', 'kunnr_customer_final_dest_partner',
                    'kunnr_customer_parent_partner', 'kunnr_customer_sales_rep', 'kunnr_customer_agent_id',
                    df_vbpa1_vbrp.vbeln.alias('vbpa1_vbrp_vbeln'), df_vbpa1_vbrp.posnr.alias('vbpa1_vbrp_posnr'))

        df_vbpa2 = df_vbpa2.withColumn("kunnr_customer_shipto",
                                       when(df_vbpa2.parvw == "WE", df_vbpa2.kunnr).otherwise('00')) \
            .withColumn("kunnr_customer_dest_airport", when(df_vbpa2.parvw == "ZD", df_vbpa2.kunnr).otherwise('00')) \
            .withColumn("kunnr_customer_vendor", when(df_vbpa2.parvw == "LF", df_vbpa2.kunnr).otherwise('00')) \
            .groupBy('vbeln', 'posnr').agg(
            f.max('kunnr_customer_shipto').alias('kunnr_customer_shipto'),
            f.max('kunnr_customer_dest_airport').alias('kunnr_customer_dest_airport'),
            f.max('kunnr_customer_vendor').alias('kunnr_customer_vendor')) \
            .join(df_vbpa2_vbrp, (df_vbpa2.vbeln == df_vbpa2_vbrp.vbeln) & (df_vbpa2.posnr == df_vbpa2_vbrp.posnr),
                  'leftouter') \
            .withColumn("vbeln_calculated",
                        when(df_vbpa2.vbeln.isNull(), df_vbpa2_vbrp.vbeln).otherwise(df_vbpa2.vbeln)) \
            .select(df_vbpa2.vbeln.alias('vbpa2_vbeln'), df_vbpa2.posnr.alias('vbpa2_posnr'),
                    'kunnr_customer_shipto',
                    'kunnr_customer_dest_airport', 'kunnr_customer_vendor', 'vbeln_calculated',
                    df_vbpa2_vbrp.vbeln.alias('vbpa2_vbrp_vbeln'), df_vbpa2_vbrp.posnr.alias('vbpa2_vbrp_posnr'))

        df_vbpa = df_vbpa1.join(df_vbpa2, df_vbpa1.vbpa1_vbeln == df_vbpa2.vbeln_calculated, 'inner') \
            .orderBy([df_vbpa2.vbpa2_posnr, df_vbpa1.vbpa1_vbrp_posnr], descending=True) \
            .select('vbpa1_vbeln', 'vbpa1_posnr', 'kunnr_customer_billto', 'kunnr_customer_soldto',
                    'kunnr_customer_payer', 'kunnr_customer_final_dest_partner',
                    'kunnr_customer_parent_partner', 'kunnr_customer_sales_rep', 'kunnr_customer_agent_id',
                    'vbpa1_vbrp_vbeln', 'vbpa1_vbrp_posnr',
                    df_vbpa2.vbeln_calculated.alias('vbpa2_vbeln'), 'vbpa2_posnr', 'kunnr_customer_shipto',
                    'kunnr_customer_dest_airport', 'kunnr_customer_vendor', 'vbpa2_vbrp_vbeln', 'vbpa2_vbrp_posnr')

        windowSpec = Window.partitionBy(df_vbpa.vbpa2_vbeln, df_vbpa.vbpa1_vbrp_posnr).orderBy(df_vbpa.vbpa2_vbeln)

        df_vbpa = df_vbpa.select(df_vbpa.vbpa2_vbeln, df_vbpa.vbpa1_vbrp_posnr, f.when(
            (df_vbpa.vbpa2_posnr == f.lag(df_vbpa.vbpa1_vbrp_posnr, 0).over(windowSpec)) |
            ((df_vbpa.vbpa2_vbrp_posnr == 10) & (df_vbpa.vbpa2_posnr == 10)), df_vbpa.kunnr_customer_billto)
                                 .otherwise(df_vbpa.kunnr_customer_billto).alias('kunnr_customer_billto'), f.when(
            (df_vbpa.vbpa2_posnr == f.lag(df_vbpa.vbpa1_vbrp_posnr, 0).over(windowSpec)) |
            ((df_vbpa.vbpa2_vbrp_posnr == 10) & (df_vbpa.vbpa2_posnr == 10)), df_vbpa.kunnr_customer_soldto)
                                 .otherwise(df_vbpa.kunnr_customer_soldto).alias('kunnr_customer_soldto'), f.when(
            (df_vbpa.vbpa2_posnr == f.lag(df_vbpa.vbpa1_vbrp_posnr, 0).over(windowSpec)) |
            ((df_vbpa.vbpa2_vbrp_posnr == 10) & (df_vbpa.vbpa2_posnr == 10)), df_vbpa.kunnr_customer_payer)
                                 .otherwise(df_vbpa.kunnr_customer_payer).alias('kunnr_customer_payer'), f.when(
            (df_vbpa.vbpa2_posnr == f.lag(df_vbpa.vbpa1_vbrp_posnr, 0).over(windowSpec)) |
            ((df_vbpa.vbpa2_vbrp_posnr == 10) & (df_vbpa.vbpa2_posnr == 10)), df_vbpa.kunnr_customer_final_dest_partner)
                                 .otherwise(f.lit('NULL')).alias('kunnr_customer_final_dest_partner'), f.when(
            (df_vbpa.vbpa2_posnr == f.lag(df_vbpa.vbpa1_vbrp_posnr, 0).over(windowSpec)) |
            ((df_vbpa.vbpa2_vbrp_posnr == 10) & (df_vbpa.vbpa2_posnr == 10)), df_vbpa.kunnr_customer_parent_partner)
                                 .otherwise(f.lit('NULL')).alias('kunnr_customer_parent_partner'), f.when(
            (df_vbpa.vbpa2_posnr == f.lag(df_vbpa.vbpa1_vbrp_posnr, 0).over(windowSpec)) |
            ((df_vbpa.vbpa2_vbrp_posnr == 10) & (df_vbpa.vbpa2_posnr == 10)), df_vbpa.kunnr_customer_sales_rep)
                                 .otherwise(df_vbpa.kunnr_customer_sales_rep).alias('kunnr_customer_sales_rep'), f.when(
            (df_vbpa.vbpa2_posnr == f.lag(df_vbpa.vbpa1_vbrp_posnr, 0).over(windowSpec)) |
            ((df_vbpa.vbpa2_vbrp_posnr == 10) & (df_vbpa.vbpa2_posnr == 10)), df_vbpa.kunnr_customer_agent_id)
                                 .otherwise(f.lit('NULL')).alias('kunnr_customer_agent_id'), f.when(
            (df_vbpa.vbpa2_posnr == f.lag(df_vbpa.vbpa1_vbrp_posnr, 0).over(windowSpec)) |
            ((df_vbpa.vbpa2_vbrp_posnr == 10) & (df_vbpa.vbpa2_posnr == 10)), df_vbpa.kunnr_customer_shipto)
                                 .otherwise(df_vbpa.kunnr_customer_shipto).alias('kunnr_customer_shipto'), f.when(
            (df_vbpa.vbpa2_posnr == f.lag(df_vbpa.vbpa1_vbrp_posnr, 0).over(windowSpec)) |
            ((df_vbpa.vbpa2_vbrp_posnr == 10) & (df_vbpa.vbpa2_posnr == 10)), df_vbpa.kunnr_customer_dest_airport)
                                 .otherwise(f.lit('00')).alias('kunnr_customer_dest_airport'), f.when(
            (df_vbpa.vbpa2_posnr == f.lag(df_vbpa.vbpa1_vbrp_posnr, 0).over(windowSpec)) |
            ((df_vbpa.vbpa2_vbrp_posnr == 10) & (df_vbpa.vbpa2_posnr == 10)), df_vbpa.kunnr_customer_vendor)
                                 .otherwise(f.lit('NULL')).alias('kunnr_customer_vendor')) \
            .groupBy('vbpa2_vbeln', 'vbpa1_vbrp_posnr').agg(
            f.max('kunnr_customer_billto').alias('kunnr_customer_billto'),
            f.max('kunnr_customer_soldto').alias('kunnr_customer_soldto'),
            f.max('kunnr_customer_payer').alias('kunnr_customer_payer'),
            f.max('kunnr_customer_final_dest_partner').alias('kunnr_customer_final_dest_partner'),
            f.max('kunnr_customer_parent_partner').alias('kunnr_customer_parent_partner'),
			f.when(f.max('kunnr_customer_sales_rep') == '00', 'NULL')
                .otherwise(f.max('kunnr_customer_sales_rep'))
                .alias('kunnr_customer_sales_rep'),
            f.max('kunnr_customer_agent_id').alias('kunnr_customer_agent_id'),
            f.max('kunnr_customer_shipto').alias('kunnr_customer_shipto'),
            f.when(f.max('kunnr_customer_dest_airport') == '00', 'NULL')
                .otherwise(f.max('kunnr_customer_dest_airport'))
                .alias('kunnr_customer_dest_airport'),
            f.max('kunnr_customer_vendor').alias('kunnr_customer_vendor')) \
            .select('vbpa2_vbeln', 'vbpa1_vbrp_posnr', 'kunnr_customer_billto',
                    'kunnr_customer_soldto',
                    'kunnr_customer_payer', 'kunnr_customer_final_dest_partner', 'kunnr_customer_parent_partner',
                    'kunnr_customer_sales_rep', 'kunnr_customer_agent_id', 'kunnr_customer_shipto',
                    'kunnr_customer_dest_airport', 'kunnr_customer_vendor')

        # MAIN LOGIC FOR SALES BILLING CALCULATION  - Read data
        df_vbrk = args[1]
        df_makt = args[4]
        df_vbrp = args[0]
        df_vbak = args[6]
        df_sales_billing = df_vbrp.join(df_makt, df_vbrp.matnr == df_makt.matnr, 'left') \
            .join(df_vbrk, df_vbrp.vbeln == df_vbrk.vbeln, 'inner') \
            .join(df_vbpa, (df_vbrp.vbeln == df_vbpa.vbpa2_vbeln) & (df_vbrp.posnr == df_vbpa.vbpa1_vbrp_posnr),
                  'inner') \
            .join(df_lipso2, (df_lipso2.vbeln == df_vbrp.vgbel) & (df_lipso2.posnr == df_vbrp.vgpos), 'left') \
            .join(df_marm, (df_vbrp.vbeln == df_marm.vbeln) & (df_vbrp.posnr == df_marm.posnr), 'left') \
            .join(df_vbak, df_vbak.vbeln == df_vbrp.aubel , 'left') \
            .select(df_vbrk.vbeln, df_vbrk.fkart, df_vbrk.fktyp, df_vbrk.vbtyp, df_vbrk.waerk, df_vbrk.vkorg,
                    df_vbrk.vtweg, df_vbrk.kalsm, df_vbrk.knumv, df_vbrk.vsbed, df_vbrk.fkdat, df_vbrk.rfbsk,
                    df_vbrk.kurrf, df_vbrk.zterm, df_vbrk.bukrs, df_vbrk.netwr.alias('netwr_vbrk'),
                    df_vbrk.erzet.alias('erzet_vbrk'), df_vbrk.erdat.alias('erdat_vbrk'),
                    df_vbrk.kunrg, df_vbrk.kunag, df_vbrk.stwae, df_vbrk.kurst, df_vbrk.spart, df_vbrk.cmwae,
                    df_vbrk.cmkuf, df_vbrk.logsys, df_vbrk.kurrf_dat, df_vbrk.fksto, df_vbrk.sfakn,df_vbak.vbeln.alias('vbeln_vbak'),df_vbak.auart,
                    # df_vbrp.vbeln,
                    df_vbrp.posnr,
                    f.when((df_vbrp.posar) == 'A', 0)
                    .when(((df_vbrk.vbtyp == 'N')) | ((df_vbrk.vbtyp == 'O')) | (
                        (df_vbrk.vbtyp == '6')), df_vbrp.fkimg * (-1))
                    .otherwise(df_vbrp.fkimg).alias('fkimg'),
                    df_vbrp.vrkme, df_vbrp.meins,
                    f.when((df_vbrp.posar) == 'A', 0)
                    .when(((df_vbrk.vbtyp == 'N')) | ((df_vbrk.vbtyp == 'O')) | (
                        (df_vbrk.vbtyp == '6')), df_vbrp.fklmg * (-1))
                    .otherwise(df_vbrp.fklmg).alias('fklmg'),
                    f.when((df_vbrp.posar) == 'A', 0)
                    .when(((df_vbrk.vbtyp == 'N')) | ((df_vbrk.vbtyp == 'O')) | (
                        (df_vbrk.vbtyp == '6')), df_vbrp.lmeng * (-1))
                    .otherwise(df_vbrp.lmeng).alias('lmeng'),
                    f.when((df_vbrp.posar) == 'A', 0)
                    .when(((df_vbrk.vbtyp == 'N')) | ((df_vbrk.vbtyp == 'O')) | (
                        (df_vbrk.vbtyp == '6')), df_vbrp.ntgew * (-1))
                    .otherwise(df_vbrp.ntgew).alias('ntgew'),
                    f.when((df_vbrp.posar) == 'A', 0)
                    .when(((df_vbrk.vbtyp == 'N')) | ((df_vbrk.vbtyp == 'O')) | (
                        (df_vbrk.vbtyp == '6')), df_vbrp.brgew * (-1))
                    .otherwise(df_vbrp.brgew).alias('brgew'),
                    df_vbrp.gewei,
                    f.when((df_vbrp.posar) == 'A', 0)
                    .when(((df_vbrk.vbtyp == 'N')) | ((df_vbrk.vbtyp == 'O')) | (
                        (df_vbrk.vbtyp == '6')), df_vbrp.volum * (-1))
                    .otherwise(df_vbrp.volum).alias('volum'),
                    df_vbrp.voleh,
                    df_vbrp.prsdt, df_vbrp.kursk,
                    f.when((df_vbrp.posar) == 'A', 0)
                    .when(((df_vbrk.vbtyp == 'N')) | ((df_vbrk.vbtyp == 'O')) | (
                        (df_vbrk.vbtyp == '6')), df_vbrp.netwr * (-1))
                    .otherwise(df_vbrp.netwr).alias('netwr'),
                    df_vbrp.vgbel, df_vbrp.vgpos, df_vbrp.vgtyp,
                    df_vbrp.aubel, df_vbrp.aupos, df_vbrp.matnr, df_vbrp.pstyv, df_vbrp.vstel,
                    df_vbrp.werks, df_vbrp.aland, df_vbrp.vkbur, df_vbrp.spara, df_vbrp.erdat, df_vbrp.erzet,
                    df_vbrp.stcur, df_vbrp.prctr, df_vbrp.konda_auft, df_vbrp.pltyp_auft, df_vbrp.vtweg_auft,
                    df_vbrp.augru_auft, df_vbrp.oid_extbol, df_vbrp.oicontnr, df_vbrp.oic_kmpos, df_vbrp.oic_time,
                    df_vbrp.oiinvcyc9, df_vbrp.zzsup_loc, df_vbrp.zzimport_reg, df_vbrp.zzvesselname,
                    df_vbrp.zztermtype, df_vbrp.zzflnum, df_vbrp.zzairctycd, df_vbrp.zztailno, df_vbrp.zzcontract_type,
                    df_vbrp.zzorigplant, df_vbrp.vsart, df_vbrp.zzbillunit, df_vbrp.ssr_ccins, df_vbrp.ssr_cctyp,
                    df_vbrp.zsds_chot, df_vbrp.zzconsass, df_vbrp.zz_distric, df_vbrp.oircmetrev,
                    df_vbrp.zzavgcurrdocloc, df_vbrp.zzdminus1rate, df_vbrp.posar, df_vbrp.shkzg, df_vbrp.autyp,
                    df_vbrp.zzexchrate_wf,
                    df_makt.maktx,
                    # df_vbpa.vbpa2_vbeln, df_vbpa.vbpa1_vbrp_posnr,
                    df_vbpa.kunnr_customer_billto, df_vbpa.kunnr_customer_soldto, df_vbpa.kunnr_customer_payer,
                    df_vbpa.kunnr_customer_final_dest_partner, df_vbpa.kunnr_customer_parent_partner,
                    df_vbpa.kunnr_customer_sales_rep, df_vbpa.kunnr_customer_agent_id, df_vbpa.kunnr_customer_shipto,
                    df_vbpa.kunnr_customer_dest_airport, df_vbpa.kunnr_customer_vendor,

                    df_lipso2.vbeln.alias('vbeln_lipso2'), df_lipso2.posnr.alias('posnr_lipso2'),
                    df_lipso2.zzqty_l_lipso.alias('zzqty_l_lipso'), df_lipso2.zzqty_to_lipso.alias('zzqty_to_lipso'),
                    df_lipso2.zzqty_m3_lipso.alias('zzqty_m3_lipso'),
                    df_lipso2.zzqty_ugl_lipso.alias('zzqty_ugl_lipso'),

                    df_marm.vbeln.alias('vbeln_marm'), df_marm.posnr.alias('posnr_marm'),
                    df_marm.meins.alias('meins_marm'), df_marm.fklmg.alias('fklmg_marm'),
                    df_marm.matnr.alias('matnr_marm'), df_marm.zzqty_to_marm.alias('zzqty_to_marm'),
                    df_marm.zzqty_m3_marm.alias('zzqty_m3_marm'), df_marm.zzqty_l_marm.alias('zzqty_l_marm'),
                    df_marm.zzqty_ugl_marm.alias('zzqty_ugl_marm'),

                    f.when(df_lipso2.zzqty_l_lipso == f.lit(0), df_marm.zzqty_l_marm)
					 .when(df_lipso2.zzqty_l_lipso.isNull(), df_marm.zzqty_l_marm).otherwise(
                        df_lipso2.zzqty_l_lipso).alias('zzqty_l'),
                    f.when(df_lipso2.zzqty_to_lipso == f.lit(0), df_marm.zzqty_to_marm)
					 .when(df_lipso2.zzqty_to_lipso.isNull(), df_marm.zzqty_to_marm).otherwise(
                        df_lipso2.zzqty_to_lipso).alias('zzqty_to'),
                    f.when(df_lipso2.zzqty_m3_lipso == f.lit(0), df_marm.zzqty_m3_marm)
					 .when(df_lipso2.zzqty_m3_lipso.isNull(), df_marm.zzqty_m3_marm).otherwise(
                        df_lipso2.zzqty_m3_lipso).alias('zzqty_m3'),
                    f.when(df_lipso2.zzqty_ugl_lipso == f.lit(0), df_marm.zzqty_ugl_marm)
					 .when(df_lipso2.zzqty_ugl_lipso.isNull(), df_marm.zzqty_ugl_marm).otherwise(
                        df_lipso2.zzqty_ugl_lipso).alias('zzqty_ugl')
                    )

        df_tfx_result = df_sales_billing.select(df_sales_billing.vbeln.alias('vbeln_billing_doc'),
                                                df_sales_billing.fkart.alias('fkart_billing_type'),
                                                df_sales_billing.fktyp.alias('fktyp_billingcategory'),
                                                df_sales_billing.vbtyp.alias('vbtyp_document_cat'),
                                                df_sales_billing.waerk.alias('waerk_doc_currency'),
                                                df_sales_billing.vkorg.alias('vkorg_sales_org'),
                                                df_sales_billing.vtweg.alias('vtweg_distr_channel'),
                                                df_sales_billing.kalsm.alias('kalsm_pric_procedure'),
                                                df_sales_billing.knumv.alias('knumv_doc_condition'),
                                                df_sales_billing.vsbed.alias('vsbed_shipping_cond'),
                                                df_sales_billing.fkdat.alias('fkdat_billing_date'),
                                                df_sales_billing.rfbsk.alias('rfbsk_posting_status'),
                                                df_sales_billing.kurrf.alias('kurrf_exchrate_acct'),
                                                df_sales_billing.zterm.alias('zterm_payt_terms'),
                                                df_sales_billing.bukrs.alias('bukrs_company_code'),
                                                df_sales_billing.netwr_vbrk.alias('netwr_net_value_vbrk'),
                                                df_sales_billing.erzet_vbrk.alias('erzet_time_vbrk'),
                                                df_sales_billing.erdat_vbrk.alias('erdat_created_on_vbrk'),
                                                df_sales_billing.stwae.alias('stwae_stats_currency'),
                                                df_sales_billing.kurst.alias('kurst_exch_rate_type'),
                                                df_sales_billing.spart.alias('spart_division'),
                                                df_sales_billing.cmwae.alias('cmwae_currency'),
                                                df_sales_billing.cmkuf.alias('cmkuf_exchange_rate'),
                                                df_sales_billing.logsys.alias('logsys_logical_system'),
                                                df_sales_billing.kurrf_dat.alias('kurrf_dat_translatn_date'),
                                                df_sales_billing.posnr.alias('posnr_item'),
                                                df_sales_billing.fkimg.alias('fkimg_billed_qty'),
                                                df_sales_billing.vrkme.alias('vrkme_sales_unit'),
                                                df_sales_billing.meins.alias('meins_base_unit'),
                                                df_sales_billing.fklmg.alias('fklmg_billqty_in_sku'),
                                                df_sales_billing.lmeng.alias('lmeng_required_qty'),
                                                df_sales_billing.ntgew.alias('ntgew_net_weight'),
                                                df_sales_billing.brgew.alias('brgew_gross_weight'),
                                                df_sales_billing.gewei.alias('gewei_weight_unit'),
                                                df_sales_billing.volum.alias('volum_volume'),
                                                df_sales_billing.voleh.alias('voleh_volume_unit'),
                                                df_sales_billing.prsdt.alias('prsdt_pricing_date'),
                                                df_sales_billing.kursk.alias('kursk_exchange_rate'),
                                                df_sales_billing.netwr.alias('netwr_net_value_vbrp'),
                                                df_sales_billing.vgbel.alias('vgbel_reference_doc'),
                                                df_sales_billing.vgpos.alias('vgpos_reference_item'),
                                                df_sales_billing.vgtyp.alias('vgtyp_precdoccateg'),
                                                df_sales_billing.aubel.alias('aubel_sales_document'),
                                                df_sales_billing.aupos.alias('aupos_item'),
                                                df_sales_billing.matnr.alias('matnr_material'),
                                                df_sales_billing.pstyv.alias('pstyv_item_category'),
                                                df_sales_billing.vstel.alias('vstel_shipping_point'),
                                                df_sales_billing.werks.alias('werks_plant'),
                                                df_sales_billing.aland.alias('aland_country'),
                                                df_sales_billing.vkbur.alias('vkbur_sales_office'),
                                                df_sales_billing.erdat.alias('erdat_created_on_vbrp'),
                                                df_sales_billing.erzet.alias('erzet_time_vbrp'),
                                                df_sales_billing.stcur.alias('stcur_exchrate_stats'),
                                                df_sales_billing.prctr.alias('prctr_profit_center'),
                                                df_sales_billing.konda_auft.alias('konda_auft_pricegrouporder'),
                                                df_sales_billing.pltyp_auft.alias('pltyp_auft_price_list_ord'),
                                                df_sales_billing.augru_auft.alias('augru_auft_order_reason'),
                                                df_sales_billing.oid_extbol.alias('oid_extbol_externbol_no'),
                                                df_sales_billing.oicontnr.alias('oicontnr_contractnr'),
                                                df_sales_billing.oic_kmpos.alias('oic_kmpos_refcontractitm'),
                                                df_sales_billing.oic_time.alias('oic_time_time'),
                                                df_sales_billing.oiinvcyc9.alias('oiinvcyc9_invcycle_ind'),
                                                df_sales_billing.zzsup_loc.alias('zzsup_loc_standard_supply_loc'),
                                                df_sales_billing.zzimport_reg.alias('zzimport_reg_standard_refinery'),
                                                df_sales_billing.zzvesselname.alias('zzvesselname_vessel_name'),
                                                df_sales_billing.zztermtype.alias('zztermtype_pros_term_type'),
                                                df_sales_billing.zzflnum.alias('zzflnum_flight_number'),
                                                df_sales_billing.zzairctycd.alias('zzairctycd_aircraft_tycode'),
                                                df_sales_billing.zztailno.alias('zztailno_aircraft_reg'),
                                                df_sales_billing.zzcontract_type.alias(
                                                    'zzcontract_type_contr_doc_type'),
                                                df_sales_billing.zzorigplant.alias('zzorigplant_orignal_plant'),
                                                df_sales_billing.vsart.alias('vsart_shptype_stage'),
                                                df_sales_billing.zzbillunit.alias('zzbillunit_billing_unit'),
                                                df_sales_billing.ssr_ccins.alias('ssr_ccins_pc_type'),
                                                df_sales_billing.ssr_cctyp.alias('ssr_cctyp_ssr_pc_category'),
                                                df_sales_billing.zsds_chot.alias('zsds_chot_channel_of_trade'),
                                                df_sales_billing.zzconsass.alias('zzconsass_cons_assgn'),
                                                df_sales_billing.zz_distric.alias('zz_distric_district'),
                                                df_sales_billing.oircmetrev.alias('oircmetrev_met_event_type'),
                                                df_sales_billing.zzavgcurrdocloc.alias(
                                                    'zzavgcurrdocloc_average_exchange_rat'),
                                                df_sales_billing.zzdminus1rate.alias('zzdminus1rate_d_1_exc_rate'),
                                                f.when((df_sales_billing.posar) == 'A', 0)
                                                .when((df_vbrk.vbtyp == 'N') | (df_vbrk.vbtyp == 'O') | (
                                                        df_vbrk.vbtyp == '6'),
                                                      df_sales_billing.zzqty_to * (-1)).otherwise(
                                                    df_sales_billing.zzqty_to).alias('zzqty_to'),
                                                f.when((df_sales_billing.posar) == 'A', 0)
                                                .when(((df_vbrk.vbtyp) == 'N') | ((df_vbrk.vbtyp) == 'O') | (
                                                        (df_vbrk.vbtyp) == '6'),
                                                      df_sales_billing.zzqty_l * (-1)).otherwise(
                                                    df_sales_billing.zzqty_l).alias('zzqty_l'),
                                                f.when((df_sales_billing.posar) == 'A', 0)
                                                .when(((df_vbrk.vbtyp) == 'N') | ((df_vbrk.vbtyp) == 'O') | (
                                                        (df_vbrk.vbtyp) == '6'),
                                                      df_sales_billing.zzqty_ugl * (-1)).otherwise(
                                                    df_sales_billing.zzqty_ugl).alias('zzqty_ugl'),
                                                f.when((df_sales_billing.posar) == 'A', 0)
                                                .when(((df_vbrk.vbtyp) == 'N') | ((df_vbrk.vbtyp) == 'O') | (
                                                        (df_vbrk.vbtyp) == '6'),
                                                      df_sales_billing.zzqty_m3 * (-1)).otherwise(
                                                    df_sales_billing.zzqty_m3).alias('zzqty_m3'),
                                                df_sales_billing.kunnr_customer_shipto.alias('kunnr_customer_shipto'),
                                                df_sales_billing.kunnr_customer_billto.alias('kunnr_customer_billto'),
                                                df_sales_billing.kunnr_customer_soldto.alias('kunnr_customer_soldto'),
                                                df_sales_billing.kunnr_customer_payer.alias('kunnr_customer_payer'),
                                                df_sales_billing.kunnr_customer_dest_airport.alias(
                                                    'kunnr_customer_dest_airport'),
                                                df_sales_billing.kunnr_customer_final_dest_partner.alias(
                                                    'kunnr_customer_final_dest_partner'),
                                                df_sales_billing.kunnr_customer_parent_partner.alias(
                                                    'kunnr_customer_parent_partner'),
                                                df_sales_billing.kunnr_customer_vendor.alias('kunnr_customer_vendor'),
                                                df_sales_billing.kunnr_customer_sales_rep.alias(
                                                    'kunnr_customer_sales_rep'),
                                                df_sales_billing.kunnr_customer_agent_id.alias(
                                                    'kunnr_customer_agent_id'),
                                                df_sales_billing.fksto.alias('fksto_cancelled'),
                                                df_sales_billing.sfakn.alias('sfakn_cancelled_bill_doc'),
                                                df_sales_billing.autyp.alias('autyp_sd_document_category'),
                                                df_sales_billing.posar.alias('posar_item_type'),
                                                df_sales_billing.shkzg.alias('shkzg_returns_item'),
                                                df_sales_billing.maktx.alias('maktx_material_description'),
                                                df_sales_billing.zzexchrate_wf.alias('zzexchrate_wf_c_exchange_rate'),
                                                df_sales_billing.auart.alias('auart_delivery_method'),
                                                df_sales_billing.vbeln_lipso2, df_sales_billing.posnr_lipso2, df_sales_billing.zzqty_l_lipso,
                                                df_sales_billing.zzqty_to_lipso, df_sales_billing.zzqty_m3_lipso, df_sales_billing.zzqty_ugl_lipso,
                                                df_sales_billing.vbeln_marm, df_sales_billing.posnr_marm, df_sales_billing.meins_marm, df_sales_billing.fklmg_marm,
                                                df_sales_billing.matnr_marm, df_sales_billing.zzqty_to_marm, df_sales_billing.zzqty_m3_marm,
                                                df_sales_billing.zzqty_l_marm, df_sales_billing.zzqty_ugl_marm)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
