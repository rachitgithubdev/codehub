# testing the Deployment of Glue job using different branch
# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      11-Mar-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to create tender tcurr_extracts layer 3.1 table in
#                  conform zone
# Author        :- Bakul Seth
# Date          :- 11-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from datetime import date, timedelta, datetime
from dateutil.relativedelta import relativedelta
from pyspark.sql import Window
from pyspark.sql.types import *


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 11')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'currency_list',
                                   'back_year',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = 'l3_pre_tcurr_exrates'
        self.report_file = 'l31_pre_exchange_rates'

        # hardcoded as of now need to be parameterized
        self.curr_list = ['CUP', 'GMD', 'RUB', 'VES', 'BYN', 'BDT', 'UYU', 'MGA', 'DKK', 'CNY', 'XAF', 'ZAR', 'MNT',
                          'SLL', 'YER', 'LSL', 'ISK', 'KES', 'PEN', 'CVE', 'DZD', 'BRL', 'HTG', 'AUD', 'LAK', 'CHF',
                          'SYP', 'IRR', 'LBP', 'LKR', 'XCD', 'ETB', 'PLN', 'NOK', 'BMD', 'UGX', 'AMD', 'MXN', 'SCR',
                          'BGN', 'USD', 'RSD', 'NZD', 'TRY', 'MRU', 'HNL', 'DJF', 'SDG', 'ERN', 'AWG', 'MUR', 'LRD',
                          'HUF', 'DOP', 'ZMW', 'GIP', 'XDR', 'MZN', 'PAB', 'SGD', 'CDF', 'KGS', 'BAM', 'ANG', 'SOS',
                          'RWF', 'MAD', 'AFN', 'UAH', 'BND', 'PYG', 'BOB', 'KHR', 'TOP', 'TJS', 'XOF', 'KMF', 'AOA',
                          'MYR', 'TZS', 'MWK', 'JOD', 'BHD', 'SEK', 'IDR', 'RON', 'JPY', 'VUV', 'MKD', 'BSD', 'EUR',
                          'MDL', 'INR', 'VND', 'ARS', 'SRD', 'GTQ', 'BWP', 'MVR', 'ILS', 'HRK', 'GHS', 'NIO', 'LYD',
                          'TND', 'JMD', 'HKD', 'CAD', 'TTD', 'SVC', 'EGP', 'CLP', 'NAD', 'MOP', 'GNF', 'QAR', 'GBP',
                          'BZD', 'THB', 'CZK', 'BBD', 'PKR', 'KZT', 'GYD', 'SZL', 'SBD', 'KRW', 'MMK', 'TWD', 'UZS',
                          'PGK', 'ALL', 'OMR', 'KPW', 'AED', 'PHP', 'AZN', 'SAR', 'BIF', 'IQD', 'NPR', 'WST', 'XPF',
                          'KWD', 'COP', 'STN', 'KYD', 'FJD', 'NGN', 'CRC', 'GEL', 'BTN']
        self.back_year = int(args['back_year'])
        self.curr_type = ['ECB', 'RBA', 'M', 'CBIS', 'ANZB', 'CBM']
        self._spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        # empty dataframe
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # read data from tcurr table from Layer 3 argument passed(database, table, emptyDataframe)
        df_tcurr = self._get_table(self.source_database, self.input_table, final_result_df).toDF().cache()
        print('data count of table {}.{} is {}'.format(self.source_database, self.input_table, df_tcurr.printSchema()))

        end_date = date.today()
        start_date = end_date.replace(day=1) - relativedelta(years=1)

        # read data from tcurr table from Layer 3 argument passed(database, table, emptyDataframe)
        df_tcurr31 = self._get_table(self.source_database, self.report_file, final_result_df).toDF()
        if not bool(df_tcurr31.head(1)):
            start_date = df_tcurr.select(f.min(df_tcurr.gdatu).alias('gdatu')).collect()[0].asDict()['gdatu']
            print('This is first run running the JOB from beginning', start_date)

        # creating currency dataframe from the passed value
        df_currency = self._spark.createDataFrame(self.curr_list, StringType()) \
            .withColumnRenamed('value', 'curr').cache()

        # date dataframe and list till current date
        date_array = list((start_date + timedelta(days=i)).strftime('%Y-%m-%d') for i in
                          range((end_date - start_date).days + 1))
        df_date = self._spark.createDataFrame(date_array, StringType()). \
            select(f.col('value').alias('curr_date').cast('date')).cache()

        # create currency type dataframe
        df_curr_type = self._spark.createDataFrame(self.curr_type, StringType()) \
            .withColumnRenamed('value', 'curr_type').cache()

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_tcurr, df_currency, df_date, df_curr_type)
        print('data count after transformation ', df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option('compression', 'snappy').partitionBy('year_month') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name, empty_df):
        print('reading data from {}.{}'.format(source_database, table_name))
        error_flag = False
        try:
            empty_df = self._gc.create_dynamic_frame.from_catalog(
                database=source_database,
                table_name=table_name,
                transformation_ctx='target_table')
        except:
            error_flag = True
            print("Oops!", sys.exc_info()[0], "occurred.")

        return empty_df

    @staticmethod
    def _apply_tfx(input_table, currency, date_df, curre_type_df):
        # cross join of date and currency
        date_cure_df = date_df.crossJoin(currency).cache()
        print('date_cure_df done', date_cure_df.count())
        date_cure_type_df = date_cure_df.crossJoin(curre_type_df).cache()
        print('date_cure_df done', date_cure_type_df.count())

        # filter the input table for given currency type
        df_filtered = input_table.filter(input_table.kurst.isin(['ECB', 'RBA', 'M', 'CBIS', 'ANZB', 'CBM']))
        print('df_fillered', df_filtered.count())
        df_non_filtered = input_table.filter(input_table.kurst.isin(['ECB', 'RBA', 'M', 'CBIS', 'ANZB', 'CBM']) == False)
        print('df_non_filtered', df_non_filtered.count())

        # join the current table with l2 table
        df_joined = date_cure_type_df.join(df_filtered, (date_cure_type_df.curr_date == df_filtered.gdatu) &
                                           (date_cure_type_df.curr == df_filtered.fcurr) &
                                           (date_cure_type_df.curr_type == df_filtered.kurst), 'left')
        print('df_joined done', df_joined.count(), df_joined.printSchema())

        # apply window function to populate missing value
        window = Window.partitionBy(df_joined.curr, df_joined.curr_type).orderBy(df_joined.curr_date)

        df_tfx_result = df_joined.\
            select(df_joined.curr_date,  df_joined.curr, df_joined.curr_type, df_joined.kurst, df_joined.fcurr,
                   df_joined.tcurr, df_joined.gdatu, df_joined.ukurs,
                   f.last(df_joined.kurst, ignorenulls=True).over(window).alias('kurst_1'),
                   f.last(df_joined.fcurr, ignorenulls=True).over(window).alias('fcurr_1'),
                   f.last(df_joined.tcurr, ignorenulls=True).over(window).alias('tcurr_1'),
                   f.last(df_joined.ukurs, ignorenulls=True).over(window).alias('updated_col'),
                   f.last(df_joined.gdatu, ignorenulls=True).over(window).alias('gdatu_updated'),
                   f.substring(df_joined.curr_date, 1, 7).alias('year_month'))
        print('df_tfx_result window done')

        df_tfx_result1 = df_tfx_result.\
            select(df_tfx_result.kurst_1.alias('kurst'), df_tfx_result.fcurr_1.alias('fcurr'),
                   df_tfx_result.tcurr_1.alias('tcurr'), df_tfx_result.curr_date.alias('gdatu'),
                   df_tfx_result.updated_col.alias('ukurs'), df_tfx_result.year_month)
        print('selected all the required columns')

        # remove rows with null values and duplicates
        df_tfx_result1 = df_tfx_result1.na.drop(subset=["kurst", "fcurr", "tcurr", "ukurs"]).distinct()
        # df_tfx_result1 = df_tfx_result1.na.drop(subset=[df_tfx_result1.kurst, df_tfx_result1.fcurr,
        #                                                df_tfx_result1.tcurr, df_tfx_result1.ukurs]).distinct()

        # df_tfx_result1.filter((df_tfx_result1.kurst == 'ANZB') & (df_tfx_result1.fcurr == 'EUR')).show()

        df_temp = df_tfx_result1.groupBy('kurst', 'fcurr', 'tcurr', 'gdatu', 'ukurs', 'year_month')\
            .count().filter("count > 1")
        df_temp.show()

        print(df_tfx_result1.count())

        print('df_tfx_result_distinct', df_tfx_result1.distinct().count())

        # add addition month year column to non filtered data
        df_non_filltered = df_non_filtered.withColumn('year_month', f.substring(df_non_filtered.gdatu, 1, 7))

        # union filtered and non-filtered data
        df_tfx_result_final = df_tfx_result1.unionAll(df_non_filltered)

        print('df_tfx_result', df_tfx_result_final.count())

        return df_tfx_result_final


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
