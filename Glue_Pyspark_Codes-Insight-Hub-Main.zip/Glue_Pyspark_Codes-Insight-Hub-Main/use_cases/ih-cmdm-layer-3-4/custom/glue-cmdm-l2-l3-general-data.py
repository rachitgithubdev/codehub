# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    15-Jan-2021     Initial version
#  0.2              Tingting Wan    06-May-2021     Implement change logs
# =================================================================================================
# Description   :- The aim of the code is to generate l3_cust_mdm_general_data into conform zone
# Author        :- Tingting Wan
# Date          :- 18-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpCMDMETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "general_data"
        self.report_file = "l3_cust_mdm_general_data"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        print("Schema of table {}.{} is {}".format(self.source_database, self.input_table,
                                                   df_input_table.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table)
        print("Schema after transformation ", df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table\
            .write.option("compression", "snappy")\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    def _apply_tfx(self, df_input_table):

        # convert all the columns alias to lower case
        print('converting all the columns to lower case')
        df_input_table = df_input_table.select([f.col(x).alias(x.lower()) for x in df_input_table.columns])\
            .withColumn('infa_ext_dt', f.date_format(f.col('creation_date'), 'yyyyMMddHHmmss'))
        df_input_table.createOrReplaceTempView('general_data')

        # transformation
        print('Applying the transformations')
        df_final_result = self._spark.sql('''SELECT DISTINCT mdm_partner_id, sold_to_mdm_id, bill_to_mdm_id, 
        payer_mdm_id, erp_id, 'mdm_customer' as source_system, concat('mdm_customer_', erp_id) as ref_erp_id,
        isp_id, isp_cab_id, isp_invoice_point_id, isp_cust_account_id, work_group_isp_value, 
        work_group_sales_area_country, work_group_isp_agreement_value, work_group_sap_value, global_reference_number, 
        main_global_reference_number, subaccount_global_reference_number, customer_type_name, 
        customer_account_group_name, subaccount_reason_reason, name_1, street_1, country_of_origin_name, 
        country_of_origin_country_key, city, postal_code, vat_registration_number, customer_legal_group_name, 
        alliance_name, end_date_isp, end_date, infa_ext_dt FROM general_data where ((infa_ext_dt = 
        (Select max(infa_ext_dt) from general_data where mdm_partner_id not like '99%')) or mdm_partner_id like '99%')
        ''')

        return df_final_result


if __name__ == '__main__':
    trl = LcpCMDMETL()
    trl.execute()
