# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    14-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-cmdm-l3-l4-dim-customer into conform zone
# Author        :- Tingting Wan
# Date          :- 18-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpCMDMETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l3_cust_mdm_general_data', 'l3_cust_mdm_sales_area', 'l3_cust_mdm_company_codes']
        self.report_file = "l4_dim_customer"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
                                                                         self.destination_bucket))

    def execute(self):
        # generate input table list
        source_database = self.source_database
        input_table_list = self.input_table_list
        # print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        df_table_A = self._get_table(source_database, input_table_list[0]).toDF()
        print("Schema of table {}.{} is {}".format(source_database, input_table_list[0],
                                                   df_table_A.printSchema()))
        df_table_B = self._get_table(source_database, input_table_list[1]).toDF()
        print("Schema of table {}.{} is {}".format(source_database, input_table_list[1],
                                                   df_table_B.printSchema()))
        df_table_C = self._get_table(source_database, input_table_list[2]).toDF()
        print("Schema of table {}.{} is {}".format(source_database, input_table_list[2],
                                                   df_table_C.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_A, df_table_B, df_table_C)
        print("Schema after transformation ", df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table\
            .write.option("compression", "snappy")\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):

        # convert all the columns alias to lower case
        df_input_table_gd = args[0]
        df_input_table_sa = args[1]
        df_input_table_cc = args[2]

        # join dataframes
        df_tfx_result = df_input_table_gd.join(df_input_table_sa,
                                               df_input_table_gd.mdm_partner_id == df_input_table_sa.mdm_partner_id,
                                               'inner') \
            .join(df_input_table_cc, df_input_table_gd.mdm_partner_id == df_input_table_cc.mdm_partner_id, 'inner') \
            .select(df_input_table_gd.mdm_partner_id.alias('mdm_partner_id'),
                    df_input_table_gd.sold_to_mdm_id.alias('sold_to_mdm_id'),
                    df_input_table_gd.bill_to_mdm_id.alias('bill_to_mdm_id'),
                    df_input_table_gd.payer_mdm_id.alias('payer_mdm_id'),
                    df_input_table_gd.erp_id.alias('erp_id'),
                    df_input_table_gd.source_system.alias('source_system'),
                    df_input_table_gd.ref_erp_id.alias('ref_erp_id'),
                    df_input_table_gd.isp_id.alias('isp_id'),
                    df_input_table_gd.isp_cab_id.alias('isp_sold_to'),
                    df_input_table_gd.isp_invoice_point_id.alias('isp_bill_to'),
                    df_input_table_gd.isp_cust_account_id.alias('isp_payer'),
                    df_input_table_gd.work_group_isp_value.alias('isp_work_group'),
                    df_input_table_gd.work_group_sales_area_country.alias('country_work_group'),
                    df_input_table_gd.work_group_isp_agreement_value.alias('isp_agreement_work_group'),
                    df_input_table_gd.work_group_sap_value.alias('sap_work_group'),
                    df_input_table_cc.global_reference_number.alias('cc_grn'),
                    df_input_table_gd.global_reference_number.alias('grn_header'),
                    df_input_table_gd.main_global_reference_number.alias('grn'),
                    df_input_table_gd.subaccount_global_reference_number.alias('grn_subaccount'),
                    df_input_table_gd.customer_type_name.alias('customer_type'),
                    df_input_table_gd.customer_account_group_name.alias('customer_group'),
                    df_input_table_gd.subaccount_reason_reason.alias('subaccount_reason'),
                    df_input_table_gd.name_1.alias('customer_account_name'),
                    df_input_table_gd.street_1.alias('street'),
                    df_input_table_gd.country_of_origin_name.alias('customer_country'),
                    df_input_table_gd.country_of_origin_country_key.alias('customer_country_key'),
                    df_input_table_gd.city.alias('city'),
                    df_input_table_gd.postal_code.alias('postal_code'),
                    df_input_table_gd.vat_registration_number.alias('vat_reg_no'),
                    df_input_table_gd.customer_legal_group_name.alias('customer_legal_group_name'),
                    df_input_table_gd.alliance_name.alias('alliance_name'),
                    df_input_table_gd.end_date_isp.alias('end_date_isp'),
                    df_input_table_gd.end_date.alias('end_date'),
                    df_input_table_sa.sales_organization.alias('sales_organisation'),
                    df_input_table_sa.division.alias('division'),
                    df_input_table_sa.distribution_channel.alias('distribution_channel'),
                    df_input_table_sa.account_holder.alias(
                        'account_manager'),
                    df_input_table_sa.airline_code.alias('airline_code'),
                    df_input_table_sa.collection_country.alias('collection_country'),
                    df_input_table_sa.currency.alias('currency'),
                    df_input_table_sa.customer_group_0.alias('sector'),
                    f.when(df_input_table_sa.customer_group_3 == f.lit('AKG'), f.lit('Key Global'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('AKR'), f.lit('Key Regional'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('AGL'), f.lit('Global'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('ARG'), f.lit('Regional'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('ACR'), f.lit('CA Reseller'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('ABU'), f.lit('Bulk Only'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('ABE'), f.lit('Bulk and Equipment'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('ASC'), f.lit('Sterling Card'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('AFC'), f.lit('Flight Card'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('APC'), f.lit('Into Plane Contracted'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('AGR'), f.lit('GA Reseller'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('AMI'), f.lit('Military'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('ATD'), f.lit('Trader'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('AGO'), f.lit('Government'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('AOC'), f.lit('Oil Company'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('ABA'), f.lit('Bank'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('ACS'), f.lit('CSO'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('ASH'), f.lit('Storage and Handling'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('AIC'), f.lit('BP Intra-company Sale'))
                    .when(df_input_table_sa.customer_group_3 == f.lit('GDI'), f.lit('Distributor'))
                    .otherwise(df_input_table_sa.customer_group_3).alias('segment'),
                    f.lit(' ').alias('group'),
                    f.lit(' ').alias('carrier'),
                    df_input_table_sa.price_group.alias('price_group'),
                    df_input_table_sa.price_list.alias('price_list'),
                    df_input_table_sa.paper_switch_off.alias('paper_switch_off'),
                    df_input_table_sa.print_flag_old.alias('print_flag_old'),
                    df_input_table_sa.print_flag.alias('print_flag'),
                    df_input_table_sa.edi_flag.alias('edi_flag'),
                    df_input_table_sa.ebill_flag.alias('ebill_flag'),
                    df_input_table_sa.ebill_for_syndication_old.alias('ebill_for_syndication_old'),
                    df_input_table_sa.ebill_for_syndication.alias('ebill_for_syndication'),
                    df_input_table_sa.terms_of_payment.alias('terms_of_payment'),
                    df_input_table_sa.invoice_frequency.alias('invoice_frequency'),
                    df_input_table_sa.print_location.alias('print_location'))
        # print("df_tfx_result", df_tfx_result.count())

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCMDMETL()
    trl.execute()
