# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    15-Jan-2021     Initial version
#  0.2              Tingting Wan    10-May-2021     Implement change logs
# =================================================================================================
# Description   :- The aim of the code is to generate l3_cust_mdm_sales_area into conform zone
# Author        :- Tingting Wan
# Date          :- 18-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpCMDMETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database1']
        self.confirm_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['sales_area', 'l3_cust_mdm_general_data']
        self.report_file = "l3_cust_mdm_sales_area"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table_1 = self._get_table(self.source_database, self.input_table_list[0]).toDF()
        print("Schema of table {}.{} is {}".format(self.source_database, self.input_table_list[0],
                                                   df_input_table_1.printSchema()))
        df_input_table_2 = self._get_table(self.confirm_database, self.input_table_list[1]).toDF()
        print("Schema of table {}.{} is {}".format(self.confirm_database, self.input_table_list[1],
                                                   df_input_table_2.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_1, df_input_table_2)
        print("Schema after transformation ", df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    def _apply_tfx(self, df_input_table_1, df_input_table_2):
        # convert all the columns alias to lower case
        print('converting all the columns to lower case')
        area = df_input_table_1.select([f.col(x).alias(x.lower()) for x in df_input_table_1.columns])\
            .withColumn('infa_ext_dt', f.date_format(f.col('creation_date'), 'yyyyMMddHHmmss'))
        area.createOrReplaceTempView('area')

        # create table C -- select from l3_cust_mdm_sales_area
        general_data = df_input_table_2
        general_data.createOrReplaceTempView('general_data')

        # transformation
        print('Applying the transformation')
        df_final_result = self._spark.sql(''' SELECT area.mdm_partner_id, area.sales_organization, 
        area.sales_area_division as division, area.sales_area_distribution_channel as distribution_channel, 
        area.account_holder, area.airline_code, area.collection_country_qual as collection_country, 
        area.currency_qual as currency, area.customer_group_0_qual as customer_group_0, 
        area.customer_group_3_qual as customer_group_3, area.price_group_qual as price_group, 
        area.price_list_qual as price_list, area.paper_switch_off_qual as paper_switch_off, 
        area.print_flag_old_qual as print_flag_old, area.print_flag_qual as print_flag, area.edi_flag_qual as edi_flag, 
        area.ebill_flag_qual as ebill_flag, area.e_bill_for_syndication_old_qual as ebill_for_syndication_old, 
        area.e_bill_for_syndication_qual as ebill_for_syndication, area.terms_of_payment_qual as terms_of_payment, 
        area.invoice_frequency_qual as invoice_frequency, area.print_location_qual as print_location ,area.infa_ext_dt 
        FROM area AS area, general_data AS general_data, 
        (Select mdm_partner_id, max(infa_ext_dt) as infa_ext_dt from area group by mdm_partner_id) AS area1 where 
        area.mdm_partner_id = general_data.mdm_partner_id and area.mdm_partner_id = area1.mdm_partner_id and 
        area.infa_ext_dt = area1.infa_ext_dt''')

        return df_final_result


if __name__ == '__main__':
    trl = LcpCMDMETL()
    trl.execute()
