# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    15-Dec-2020     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-smr-l3-l4-location-mapping-isp into conform zone
# Author        :- Bakul Seth
# Date          :- 15-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpSmrETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l31_location_mapping"
        self.report_file = "l4_location_mapping_isp"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
        #                                                                  self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        print("schema of table {}.{} is {}".format(self.source_database, self.input_table,
                                                   df_input_table.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table)
        print("schema after transformation ", df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table\
            .write.option("compression", "snappy")\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table):

        # applying transformation
        print('Applying the transformations')
        final_result_df = df_input_table.groupBy(df_input_table.locationid, df_input_table.isp_mapping).count() \
            .filter(df_input_table.isp_mapping.isNotNull()) \
            .select(df_input_table.locationid.alias('location_id'),
                    df_input_table.isp_mapping
                    )

        return final_result_df


if __name__ == '__main__':
    trl = LcpSmrETL()
    trl.execute()


