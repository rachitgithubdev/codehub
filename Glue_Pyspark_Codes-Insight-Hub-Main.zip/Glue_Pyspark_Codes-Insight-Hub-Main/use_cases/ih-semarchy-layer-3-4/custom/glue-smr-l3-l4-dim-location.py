# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      08-May-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate generate l4_dim_location into conform zone
# Author        :- Bakul Seth
# Date          :- 08-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpSmrETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l31_location_master_data', 'l31_ca_ga_location_manager']
        self.report_file = 'l4_dim_location'

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # generate input table list
        print('input table list is {}'.format(self.input_table_list))
        # read data from country specific table argument passed(database, table)
        print('Reading data from source')
        df_master_date = self._get_table(self.source_database, self.input_table_list[0]).toDF()
        print('Schema of table {}.{} is {}'.format(self.source_database, self.input_table_list[0],
                                                   df_master_date.printSchema()))
        df_loc_manager = self._get_table(self.source_database, self.input_table_list[1]).toDF()
        print('Schema of table {}.{} is {}'.format(self.source_database, self.input_table_list[1],
                                                   df_loc_manager.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('Applying transformation')
        df_tfx_table = self._apply_tfx(df_master_date, df_loc_manager)
        print('Schema after transformation ', df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table\
            .write.option('compression', 'snappy')\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # Preparing dataframe from the argument
        print('Preparing dataframe from the argument')
        master_data = args[0]
        loc_manager = args[1]

        # applying transformation
        print('Applying the transformation')
        df_tfx_result = master_data.join(loc_manager, master_data.locationid == loc_manager.locationid, 'left') \
            .groupBy(master_data.locationid, master_data.business, master_data.pu, master_data.cluster,
                     master_data.reporting_country, master_data.location_country, master_data.region,
                     master_data.location_name, master_data.iata, master_data.icao, master_data.iso_code_2,
                     master_data.iso_code_3, loc_manager.ca_location_manager, loc_manager.ga_location_manager,
                     master_data.aftn, master_data.elevation, master_data.fuel, master_data.latitude,
                     master_data.longitude, master_data.length, master_data.width, master_data.lighting,
                     master_data.location_city, master_data.location_subdivision, master_data.location_type,
                     master_data.operator, master_data.pcn, master_data.sita, master_data.surface,
                     master_data.type, master_data.cs_and_o_location_flag, master_data.cs_and_o_supply_chain).count() \
            .select(master_data.locationid, master_data.business, master_data.pu, master_data.cluster,
                    master_data.reporting_country, master_data.location_country, master_data.region,
                    master_data.location_name, master_data.iata, master_data.icao, master_data.iso_code_2,
                    master_data.iso_code_3, loc_manager.ca_location_manager, loc_manager.ga_location_manager,
                    master_data.aftn, master_data.elevation, master_data.fuel, master_data.latitude,
                    master_data.longitude, master_data.length, master_data.width, master_data.lighting,
                    master_data.location_city, master_data.location_subdivision, master_data.location_type,
                    master_data.operator, master_data.pcn, master_data.sita, master_data.surface,
                    master_data.type, master_data.cs_and_o_location_flag, master_data.cs_and_o_supply_chain,
                    f.when(master_data.locationid.isin(['11513', '11582', '11540', '11521', '11639', '11602', '11675',
                                                        '11760', '11087', '11141', '11774', '11777', '11784', '11314',
                                                        '11779', '11775', '11751', '11411', '11137', '11253', '11677',
                                                        '11051', '11489', '11667', '11345', '11400', '11341']),
                           f.when(f.upper(master_data.iata).isin(['ARN', 'CPH', 'KEF']), f.lit('AIR_NORDIC'))
                           .when(f.upper(master_data.iata).isin(['AMS', 'ANR', 'BRU', 'LGG', 'LUX', 'FRA', 'CDG', 'ORY',
                                                                 'ZRH']), f.lit('AIR_RNCE'))
                           .when(f.upper(master_data.iata).isin(['DXB', 'SHJ']), f.lit('AIR_ME'))
                           .when(f.upper(master_data.iata).isin(['LGW', 'LHR', 'MAN', 'STN']), f.lit('AIR_UKIRE'))
                           .when(f.upper(master_data.iata).isin(['JNB', 'LOS']), f.lit('AIR_AFRICA'))
                           .when(f.upper(master_data.iata).isin(['BNE', 'MEL', 'PER', 'SYD']), f.lit('AIR_AUS'))
                           .when(f.upper(master_data.iata).isin(['ORD', 'JFK', 'SEA']), f.lit('AIR_US'))
                           .otherwise(f.concat(f.lit('EP2 Unmapped = '), master_data.iata)))
                    .otherwise(f.lit(None)).alias('ep2_organisation'))

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpSmrETL()
    trl.execute()

