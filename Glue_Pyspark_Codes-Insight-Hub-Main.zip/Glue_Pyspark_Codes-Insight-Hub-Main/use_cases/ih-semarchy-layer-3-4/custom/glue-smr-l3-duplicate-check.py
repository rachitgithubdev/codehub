# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      08-May-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-smr-l2-l3-location-master-data into conform zone
# Author        :- Bakul Seth
# Date          :- 08-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import datetime
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpSmrETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = 'conform_main_aviation'
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = 'l3_location_master_data'
        self.dup_warning_check = 'l3_location_duplicates_check_warnings'
        self.dup_check = 'l3_location_duplicates_check'
        self.dup_build_warning = 'l3_location_build_warnings'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        print('Reading data from source')
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        print('schema of table {}.{} is {}'.format(self.source_database, self.input_table,
                                                   df_input_table.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('Applying transformations for duplicate check and duplicate warning')
        df_tfx_table = self._apply_tfx(df_input_table)

        # writing the data to final s3 path for layer 3
        print('Writing the data to duplicate check warning L3')
        self.write_results(self.dup_warning_check, df_tfx_table[1])

        # Check if duplicates are there, abort the JOB else write data to duplicate check table
        print('Check if duplicate count is greater than 0')
        if df_tfx_table[0].count() > 0:
            print('Error: Duplicate count is greater than zero hence data is not being refreshed updating the details '
                  'in build warning table')
            print('Read date from duplicate check table')
            df_dup_check = self._get_table(self.source_database, self.dup_check).toDF()
            print('schema of table {}.{} is {}'.format(self.source_database, self.dup_check,
                                                       df_input_table.printSchema()))

            print('perform build warning process')
            df_build_warning = self._apply_build_warning(df_dup_check, df_input_table, df_tfx_table[1])
            print('Schema after build check warning : ', df_build_warning.printSchema())

            # writing the data to final s3 path for layer 3
            print('Writing the data to duplicate check warning L3')
            self.write_results(self.dup_build_warning, df_build_warning)

        else:
            print('Duplicate count is 0 hence writing the data to duplicate check table')
            self.write_results(self.dup_check, df_tfx_table[2])

    def write_results(self, report_file, df_tfx_table):
        final_path = self.destination_bucket + '/' + report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_inp):

        # Applying the transformation
        df_inp.cache()
        print(df_inp.count())
        print('Applying the transformation for both managers')
        managers = df_inp.filter(df_inp.defaultdeliverypoint == f.lit('BOTH'))\
            .select(df_inp.locationid, df_inp.cacontact, df_inp.gacontact).distinct().cache()
        managers.printSchema()

        print('Applying the transformation for ca_managers')
        ca_manager = df_inp.filter(df_inp.defaultdeliverypoint == f.lit('CA')) \
            .select(df_inp.locationid, df_inp.cacontact).distinct()
        ca_manager.printSchema()

        print('Applying the transformation for ga_managers')
        ga_manager = df_inp.filter(df_inp.defaultdeliverypoint == f.lit('GA')) \
            .select(df_inp.locationid, df_inp.gacontact).distinct()
        ga_manager.printSchema()

        print('Join CA manager and GA managers data')
        both_managers = ca_manager.join(ga_manager, ca_manager.locationid == ga_manager.locationid)\
            .drop(ga_manager.locationid).distinct()
        both_managers.printSchema()

        print('Union CA an GA data with both_managers')
        managers_all = managers.unionByName(both_managers)
        managers_all.printSchema()

        print('Concat CA and GA contact number in new column both_sector')
        managers_caga = managers_all.withColumn('both_sectors',
                                                f.concat(f.coalesce(f.col('cacontact'), f.lit('*NULL*')),
                                                         f.coalesce(f.col('gacontact'), f.lit('*NULL*'))))
        managers_caga.printSchema()

        print('Calculate the count of location ID')
        managers_id = managers_caga.groupBy(managers_caga.locationid)\
            .agg(f.count(managers_caga.both_sectors).alias('row_count'))
        managers_id.printSchema()

        print('Filter the data where count is greater than 1')
        dup_managers = managers_id.filter(managers_id.row_count > f.lit(1))
        dup_managers.printSchema()

        print('Get rows from input table, where only duplicate data exists')
        duplicate_check_warning = df_inp.join(dup_managers, df_inp.locationid == dup_managers.locationid)\
            .select(df_inp['*'])
        duplicate_check_warning.printSchema()

        print('Add timestamp column to the input table')
        duplicate_check = df_inp.withColumn('last_foundry_update', f.lit(f.current_timestamp())).cache()
        duplicate_check.printSchema()

        return [dup_managers, duplicate_check_warning, duplicate_check]

    @staticmethod
    def _apply_build_warning(dup_check, master_data, dup_warning):
        # Starting the build warning process
        hours_allowed = 15
        minimum_location_count = 2000

        print('get the last update timestamp from duplicate check table')
        last_upd = dup_check.select(dup_check.last_foundry_update).distinct()
        last_upd_date = dup_check.select(dup_check.last_foundry_update).collect()[0].asDict()['last_foundry_update']

        time_now = datetime.datetime.now()
        print('current timestamp', time_now)

        # in the datetime library: Monday = 0, Sunday = 6 - note this is different from pyspark functions
        day_of_week = time_now.weekday()
        print('day_of_week', day_of_week)

        if day_of_week == 6:  # Sunday
            hours_allowed = hours_allowed + 24
        elif day_of_week == 0:  # Monday
            hours_allowed = hours_allowed + 48

        # We do not expect the data to be updated over the weekend
        time_diff = (time_now - last_upd_date)
        print('time_diff', time_diff)
        hours_old = time_diff.total_seconds() / 3600
        print('hours_old', hours_old)
        location_count = master_data.count()

        last_upd = last_upd.withColumn('hours_old', f.round(f.lit(hours_old), 0))
        last_upd = last_upd.withColumn('hours_allowed', f.lit(hours_allowed))
        last_upd = last_upd.withColumn('location_count', f.lit(location_count))

        #  Check reasons for build being out of date
        print('hours_old :', hours_old, 'hours_allowed :', hours_allowed)
        if hours_old > hours_allowed:
            print('Data in source is out of date')

            #  1) There are not enough rows in the incoming data
            if location_count <= minimum_location_count:
                print('Insufficient rows in source data')
                last_upd = last_upd.withColumn('warning_message',
                                               f.lit('There are not enough rows - check for Semarchy load issues'))
            else:
                # 2) There are duplicate records in duplicate check warning
                if dup_warning.count() > 0:
                    print('There are duplicate records in duplicate check warning')
                    last_upd = last_upd.withColumn('warning_message',
                                                   f.lit('Duplicates in Semarchy load - see separate report'))
                else:
                    print('Location master out-of-date, check for build failures or suspended schedule')
                    last_upd = last_upd.withColumn('warning_message', f.lit(
                        'Location master out-of-date, check for build failures or suspended schedule?'))

        else:
            print('Up to date data no issues')
            last_upd = last_upd.withColumn('warning_message', f.lit(''))
            last_upd = last_upd.where('1=0')  # remove rows from table as data is up to date enough

        duplicate_check_warning = last_upd.withColumn('warning_date', f.lit(time_now))

        return  duplicate_check_warning


if __name__ == '__main__':
    trl = LcpSmrETL()
    trl.execute()
