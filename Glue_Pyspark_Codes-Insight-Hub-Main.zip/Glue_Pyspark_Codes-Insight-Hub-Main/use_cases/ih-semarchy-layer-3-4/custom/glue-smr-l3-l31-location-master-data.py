# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      08-May-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-smr-l2-l3-location-master-data into conform zone
# Author        :- Bakul Seth
# Date          :- 08-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpSmrETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l3_location_duplicates_check"
        self.report_file = "l31_location_master_data"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        print('Reading data from source')
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        print("schema of table {}.{} is {}".format(self.source_database, self.input_table,
                                                   df_input_table.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('Applying transformations')
        df_tfx_table = self._apply_tfx(df_input_table)

        # writing the data to final s3 path for layer 3
        print('Writing the data in layer3')
        self.write_results(self.report_file, df_tfx_table)

    def write_results(self, report_file, df_tfx_table):
        final_path = self.destination_bucket + '/' + report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_inp):

        print('Applying the transformation for l31')
        final_result = df_inp \
            .groupBy(df_inp.locationid, df_inp.business, df_inp.performanceunit, df_inp.cluster,
                     df_inp.reportingcountryname, df_inp.name, df_inp.regionname, df_inp.locationname, df_inp.iata,
                     df_inp.icao, df_inp.isocode2, df_inp.isocode3, df_inp.aftn, df_inp.elevation, df_inp.fuel,
                     df_inp.latitude, df_inp.longitude, df_inp.length, df_inp.width, df_inp.lighting,
                     df_inp.locationcity, df_inp.locationsubdivision, df_inp.locationtype, df_inp.operator, df_inp.pcn,
                     df_inp.sita, df_inp.surface, df_inp.type, df_inp.avgas, df_inp.deliverymethod,
                     df_inp.fuelavailableoutofhours, df_inp.fuelprovider, df_inp.jetadditive, df_inp.jetfuel,
                     df_inp.jp8, df_inp.operationtype, df_inp.sterlingcardaccepted, df_inp.unleadedavgas,
                     df_inp.bpinternalcodelocdb, df_inp.defaultdeliverypoint, df_inp.csoindicator,
                     df_inp.supplychain).count() \
            .filter(df_inp.locationid.isNotNull()) \
            .select(df_inp.locationid.alias('locationid'), df_inp.business.alias('business'),
                    df_inp.performanceunit.alias('pu'), df_inp.cluster.alias('cluster'),
                    df_inp.reportingcountryname.alias('reporting_country'),
                    df_inp.name.alias('location_country'), df_inp.regionname.alias('region'),
                    df_inp.locationname.alias('location_name'), df_inp.iata.alias('iata'),
                    df_inp.icao.alias('icao'), df_inp.isocode2.alias('iso_code_2'),
                    df_inp.isocode3.alias('iso_code_3'), df_inp.aftn.alias('aftn'),
                    df_inp.elevation.alias('elevation'), df_inp.fuel.alias('fuel'),
                    df_inp.latitude.alias('latitude'), df_inp.longitude.alias('longitude'),
                    df_inp.length.alias('length'), df_inp.width.alias('width'),
                    df_inp.lighting.alias('lighting'), df_inp.locationcity.alias('location_city'),
                    df_inp.locationsubdivision.alias('location_subdivision'),
                    df_inp.locationtype.alias('location_type'), df_inp.operator.alias('operator'),
                    df_inp.pcn.alias('pcn'), df_inp.sita.alias('sita'),
                    df_inp.surface.alias('surface'), df_inp.type.alias('type'),
                    df_inp.avgas.alias('avgas'), df_inp.deliverymethod.alias('delivery_method'),
                    df_inp.fuelavailableoutofhours.alias('fuel_avail_out_of_hours'),
                    df_inp.fuelprovider.alias('fuel_provider'),
                    df_inp.jetadditive.alias('jet_additive'), df_inp.jetfuel.alias('jetfuel'),
                    df_inp.jp8.alias('jp8'), df_inp.operationtype.alias('operation_type'),
                    df_inp.sterlingcardaccepted.alias('sterling_card_accepted'),
                    df_inp.unleadedavgas.alias('unleaded_avgas'),
                    df_inp.bpinternalcodelocdb.alias('bp_internal_code_loc_db'),
                    df_inp.defaultdeliverypoint.alias('defaultdeliverypoint'),
                    df_inp.csoindicator.alias('cs_and_o_location_flag'),
                    df_inp.supplychain.alias('cs_and_o_supply_chain'))

        return final_result


if __name__ == '__main__':
    trl = LcpSmrETL()
    trl.execute()
