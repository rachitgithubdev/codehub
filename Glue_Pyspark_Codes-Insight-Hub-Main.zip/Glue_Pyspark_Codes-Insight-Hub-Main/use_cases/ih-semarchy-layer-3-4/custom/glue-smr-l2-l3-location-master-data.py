# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      08-May-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-smr-l2-l3-location-master-data into conform zone
# Author        :- Bakul Seth
# Date          :- 08-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpSmrETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_location_master_data"
        self.report_file = "l3_location_master_data"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        print('Reading data from source')
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        print("schema of table {}.{} is {}".format(self.source_database, self.input_table,
                                                   df_input_table.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('Applying transformations')
        df_tfx_table = self._apply_tfx(df_input_table)

        # writing the data to final s3 path for layer 3
        print('Writing the data in layer3')
        self.write_results(self.report_file, df_tfx_table)

    def write_results(self, report_file, df_tfx_table):
        final_path = self.destination_bucket + '/' + report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_inp):
        # convert all the columns alias to lower case
        df_inp = df_inp.select([f.col(x).alias(x.lower()) for x in df_inp.columns])

        # Applying the transformation
        print('Applying the transformation for l3')
        final_result_df1 = df_inp.select(
            df_inp.countryid, df_inp.business, df_inp.cluster, df_inp.isocode2, df_inp.isocode3, df_inp.isoname,
            df_inp.name, df_inp.performanceunit, df_inp.regionid, df_inp.regionname, df_inp.reportingcountryname,
            df_inp.key_semarchy_token_file_data, df_inp.fkey_semarchy_token_file_data, df_inp.locationid,
            df_inp.countryid1, df_inp.aftn, df_inp.airportid, df_inp.bplocation, df_inp.designatedinternational,
            df_inp.elevation, df_inp.fuel, df_inp.iata, df_inp.icao, df_inp.lastmodifieddate, df_inp.latitude,
            df_inp.length, df_inp.lighting, df_inp.locationcity, df_inp.locationcountry, df_inp.locationname,
            df_inp.locationsubdivision, df_inp.locationtype, df_inp.longitude, df_inp.mdmlocationidentifier,
            df_inp.nonairportid, df_inp.operator, df_inp.pcn, df_inp.sita, df_inp.slotsrequired, df_inp.surface,
            df_inp.towerhours, df_inp.type, df_inp.width, df_inp.key_location, df_inp.fkey_location,
            df_inp.fuelproviderid, df_inp.locationid1, df_inp.avgas, df_inp.deliverymethod,
            df_inp.fuelavailableoutofhours, df_inp.fuelprovider, df_inp.jetadditive, df_inp.jetfuel, df_inp.jp8,
            df_inp.operationtype, df_inp.operatorrefuelunlavgas, df_inp.operatorrefuellingavgas,
            df_inp.operatorrefuellingjet, df_inp.sterlingcardaccepted, df_inp.unleadedavgas, df_inp.deliverypointid,
            df_inp.bpinternalcodelocdb, df_inp.dealerid, df_inp.defaultdeliverypoint, df_inp.defaultmeasure,
            df_inp.defaultproductdescription, df_inp.deliverypointname, df_inp.deliverypointstatus,
            df_inp.deliverypointuid, df_inp.duty, df_inp.expirydate, df_inp.fuelprice, df_inp.globalreferencenumber,
            df_inp.lastapprovaldate, df_inp.mdmdpidentifier, df_inp.mdmlocationidentifier1, df_inp.publishdate,
            df_inp.servicelevelprovided, df_inp.soluslocation, df_inp.unitofmeasure, df_inp.vat, df_inp.cacontact,
            df_inp.capriceindex, df_inp.defaultcurrencyname, df_inp.defaultproductdesc, df_inp.defaultproductname,
            df_inp.gacontact, df_inp.gapriceindex, df_inp.locationmanager, df_inp.key_deliverypoint,
            df_inp.mdm_dp_identifier, df_inp.csoindicator, df_inp.supplychain)

        return final_result_df1


if __name__ == '__main__':
    trl = LcpSmrETL()
    trl.execute()
