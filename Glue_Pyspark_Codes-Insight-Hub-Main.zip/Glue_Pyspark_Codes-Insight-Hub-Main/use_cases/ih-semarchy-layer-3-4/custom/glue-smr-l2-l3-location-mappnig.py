# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      11-May-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_location_mapping and l31_location_mapping
#                  into conform zone
# Author        :- Liz Harvey
# Date          :- 11-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpSmrETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_location_mapping"
        self.report_file = "semarchy_layer_3/l3_location_mapping"
        self.report_file1 = "semarchy_layer_3.1/l31_location_mapping"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        print("Schema of table {}.{} is {}".format(self.source_database, self.input_table,
                                                   df_input_table.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('Applying the transformations on the table')
        df_tfx_table = self._apply_tfx(df_input_table)

        print('Writing L3 details to the s3 location')
        self.write_results(df_tfx_table[0], self.report_file)

        print('Writing L31 details to the s3 location')
        self.write_results(df_tfx_table[1], self.report_file1)

    def write_results(self, df_tfx_table, report_file):
        final_path = self.destination_bucket + '/' + report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table):

        # convert all the columns alias to lower case
        print('converting all the column alias to lower case')
        df_input_table = df_input_table.select([f.col(x).alias(x.lower()) for x in df_input_table.columns])

        # applying transformation
        print('Starting the l3 transformations')
        final_result_df1 = df_input_table.select(f.col("ukms_mapping_id").alias("ukms_mapping_id"),
                                                 f.col("fromsystem").alias("fromsystem"),
                                                 f.col("fromvalue").alias("fromvalue"),
                                                 f.col("tosystem").alias("tosystem"),
                                                 f.col("toobject").alias("toobject"),
                                                 f.col("tovalue").alias("tovalue"),
                                                 f.col("ispfromsystem").alias("ispfromsystem"),
                                                 f.col("isp_refid").alias("isp_refid"),
                                                 f.col("ispfromvalue").alias("ispfromvalue"),
                                                 f.col("protheusfromsystem").alias("protheusfromsystem"),
                                                 f.col("protheusfromvalue").alias("protheusfromvalue"),
                                                 f.col("pr4fromsystem").alias("pr4fromsystem"),
                                                 f.col("pr4fromvalue").alias("pr4fromvalue"),
                                                 f.col("sunfromsystem").alias("sunfromsystem"),
                                                 f.col("sunfromvalue").alias("sunfromvalue"),
                                                 f.col("mdmdpidentifier").alias("mdmdpidentifier"),
                                                 f.col("locationid").alias("locationid"),
                                                 f.col("deliverypointid").alias("deliverypointid"),
                                                 f.col("publisherid_dpid_erpmap").alias("publisherid_dpid_erpmap"),
                                                 f.col("sourceid_dpid_erpmap").alias("sourceid_dpid_erpmap")
                                                 )
        final_result_df1.printSchema()

        print('starting the l31 transformations')
        final_result_df2 = final_result_df1.filter((f.col("toobject") == "PLANT") | (f.col("toobject").isNull())) \
                                            .groupBy(f.col("locationid").alias("locationid"),
                                                     f.col("tovalue").alias("pre_mapping"), 
                                                     f.col("ispfromvalue").alias("isp_from_value"),
                                                    (f.trim(f.substring(f.col("isp_refid"), 13, 14))).alias("isp_mapping"),
                                                    f.col("protheusfromvalue").alias("pro_mapping"),
                                                    f.col("sunfromvalue").alias("sun_mapping"),
                                                    f.col("pr4fromvalue").alias("pr4_mapping"),
                                                    (f.substring(f.regexp_replace(f.regexp_replace(
                                                        f.regexp_replace((f.current_timestamp().cast("string")), ' ', ''), '-',
                                                        ''), ':', ''), 1, 14)).alias("infa_ext_dt")).count() \
                                            .select(f.col("locationid"),
                                                    f.col("pre_mapping"),
                                                    f.col("isp_from_value"),
                                                    f.col("isp_mapping"),
                                                    f.col("pro_mapping"),
                                                    f.col("sun_mapping"),
                                                    f.col("pr4_mapping"),
                                                    f.col("infa_ext_dt"))
                                            
        final_result_df2.printSchema()

        return [final_result_df1, final_result_df2]


if __name__ == '__main__':
    trl = LcpSmrETL()
    trl.execute()


