# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      11-May-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l31_ca_ga_location_manager into conform zone
# Author        :- Liz Harvey
# Date          :- 11-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as f


class LcpSmrETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 11')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = 'conform_main_aviation'
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = 'l3_location_duplicates_check'
        self.report_file = 'l31_ca_ga_location_manager'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        print('Schema of table {}.{} is {}'.format(self.source_database, self.input_table,
                                                   df_input_table.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table)
        print('Schema count after transformation ', df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table):
        # convert all the columns alias to lower case
        print('Applying the transformations')
        df_x = df_input_table.filter(f.col('defaultdeliverypoint') == 'BOTH') \
            .select(f.col('locationid').alias('locationid'),
                    f.col('cacontact').alias('ca_location_manager'),
                    f.col('gacontact').alias('ga_location_manager'))

        df_x_1 = df_x.select(f.col('locationid'),
                             f.col('ca_location_manager'),
                             f.col('ga_location_manager')
                             )

        df_y_ca = df_input_table.filter(f.col('defaultdeliverypoint') == 'CA') \
            .select(f.col('locationid').alias('locationid'),
                    f.col('cacontact').alias('ca_location_manager'))

        df_y_ga = df_input_table.filter(f.col('defaultdeliverypoint') == 'GA') \
            .select(f.col('locationid').alias('locationid'),
                    f.col('gacontact').alias('ga_location_manager'))

        df_y_joined = df_y_ca.alias('ca').join(df_y_ga.alias('ga'), f.col('ca.locationid') == f.col('ga.locationid')) \
            .select((f.when(~(f.col('ca.locationid').isNull()), f.col('ca.locationid'))
                     .otherwise(f.col('ca.locationid'))).alias('locationid'),
                    f.col('ca_location_manager'),
                    f.col('ga_location_manager')
                    )

        df_y_1 = df_y_joined.select(f.col('locationid').alias('locationid'),
                                    f.col('ca_location_manager').alias('ca_location_manager'),
                                    f.col('ga_location_manager').alias('ga_location_manager'))

        df_tfx_result = df_x_1.union(df_y_1)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpSmrETL()
    trl.execute()
