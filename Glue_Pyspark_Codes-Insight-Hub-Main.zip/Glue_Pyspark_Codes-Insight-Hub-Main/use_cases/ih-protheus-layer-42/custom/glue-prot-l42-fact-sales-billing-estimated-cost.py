# ================================Revision History=====================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      19-Apr-2021     Initial version
# =====================================================================================================
# Description   :- The aim of the code is to generate table l42_prot_fact_sales_billing_estimated_cost
#                   into conform zone
# Author        :- Bakul Seth
# Date          :- 19-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ====================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_tables = ['l42_prot_fact_sales_billing_cost_allocation', 'l42_prot_dim_cost_loaded_date']
        self.report_file = 'l42_prot_fact_sales_billing_estimated_cost'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):

        # read data from country specific table argument passed(database, table)
        print('Reading data from input tabled {}.{}'.format(self.source_database,  self.input_tables))
        df_input_table = self._get_table(self.source_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table)
        print('Schema after transformation ')
        df_tfx_table.printSchema()

        print('Writing the results to desired location')
        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name[0]))
        cost_allocation = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[0],
                                                                     transformation_ctx='target_table').toDF()
        print('Data read from {}.{} is complete schema for the table is '.format(source_database, table_name[0]))
        cost_allocation.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[1]))
        cost_date = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[1],
                                                               transformation_ctx='target_table').toDF()
        print('Data read from {}.{} is complete schema for the table is '.format(source_database, table_name[1]))
        cost_date.printSchema()

        return [cost_allocation, cost_date]

    @staticmethod
    def _apply_tfx(df_input):

        # preparing dataframe
        df_allocation = df_input[0]

        df_date = df_input[1]

        # applying the transformations on the dataframe
        print('Applying the transformations now')
        df_tfx = df_allocation.crossJoin(df_date)\
            .filter((df_allocation.prod_grp.isin(['#AVGAS', '#JETS'])) &
                    (df_allocation.period.between(f.date_add(f.add_months(f.last_day(f.coalesce(
                        df_date.last_loaded_date, f.add_months(f.trunc(f.current_date(), 'MM'), -2))), -6), 1),
                        (f.last_day(f.coalesce(df_date.last_loaded_date, f.add_months(f.trunc(f.current_date(), 'MM'),
                                                                                      -2)))))))\
            .groupBy(df_allocation.country_mnmc, df_allocation.prod_grp, df_allocation.cae_plant,
                     df_date.last_loaded_date,
                     f.date_add(f.add_months(f.last_day(f.coalesce(df_date.last_loaded_date,
                                                                   f.add_months(f.trunc(f.current_date(), 'MM'), -2))),
                                             -6), 1),
                     f.last_day(f.coalesce(df_date.last_loaded_date, f.add_months(f.trunc(f.current_date(), 'MM'),
                                                                                  -2))))\
            .agg((f.sum(df_allocation.usd_adj_val) /
                  (f.months_between(f.last_day(f.coalesce(df_date.last_loaded_date,
                                                          f.add_months(f.trunc(f.current_date(), 'MM'), -2))),
                                    f.date_add(f.add_months(f.last_day(
                                        f.coalesce(df_date.last_loaded_date, f.add_months(f.trunc(
                                            f.current_date(), 'MM'), -2))), -6), 1)))).alias('usd_adj_val'),
                 f.when(f.sum(df_allocation.usd_net_val) == f.lit(0), f.lit(0).cast('double'))
                 .otherwise(f.sum(df_allocation.usd_cop_val) / f.sum(df_allocation.usd_net_val)).alias('pct_cop_rate'),
                 (f.sum(df_allocation.usd_oic_val) /
                  f.months_between(f.last_day(f.coalesce(df_date.last_loaded_date,
                                                         f.add_months(f.trunc(f.current_date(), 'MM'), -2))),
                                   f.date_add(f.add_months(f.last_day(
                                       f.coalesce(df_date.last_loaded_date,
                                                  f.add_months(f.trunc(f.current_date(), 'MM'), -2))), -6), 1)))
                 .alias('usd_oic_val'),
                 (f.sum(df_allocation.usd_oaf_val) /
                  f.months_between(f.last_day(f.coalesce(df_date.last_loaded_date,
                                                         f.add_months(f.trunc(f.current_date(), 'MM'), -2))),
                                   f.date_add(f.add_months(f.last_day(
                                       f.coalesce(df_date.last_loaded_date,
                                                  f.add_months(f.trunc(f.current_date(), 'MM'), -2))), -6), 1)))
                 .alias('usd_oaf_val'),
                 f.when(f.sum(df_allocation.litres) == f.lit(0), f.lit(0).cast('double'))
                 .otherwise(f.sum(df_allocation.usd_oav_val) / f.sum(df_allocation.litres)).alias('usd_oav_rate'),
                 (f.sum(df_allocation.usd_paf_val) /
                 f.months_between(f.last_day(f.coalesce(df_date.last_loaded_date,
                                                        f.add_months(f.trunc(f.current_date(), 'MM'), -2))),
                                  f.date_add(f.add_months(f.last_day(
                                      f.coalesce(df_date.last_loaded_date,
                                                 f.add_months(f.trunc(f.current_date(), 'MM'), -2))), -6), 1)))
                 .alias('usd_paf_val'),
                 f.when(f.sum(df_allocation.litres) == f.lit(0), f.lit(0).cast('double'))
                 .otherwise(f.sum(df_allocation.usd_pav_val) / f.sum(df_allocation.litres)).alias('usd_pav_rate'))

        df_tfx_result = df_tfx\
            .select(df_tfx.country_mnmc, df_tfx.prod_grp, df_tfx.cae_plant, df_tfx.last_loaded_date,
                    f.date_add(f.add_months(f.last_day(f.coalesce(
                        df_date.last_loaded_date, f.add_months(f.trunc(f.current_date(), 'MM'), -2))), -6), 1)
                    .alias('start_date'),
                    f.last_day(f.coalesce(df_date.last_loaded_date, f.add_months(f.trunc(f.current_date(), 'MM'), -2)))
                    .alias('end_date'), df_tfx.usd_adj_val, df_tfx.pct_cop_rate, df_tfx.usd_oic_val, df_tfx.usd_oaf_val,
                    df_tfx.usd_oav_rate, df_tfx.usd_paf_val, df_tfx.usd_pav_rate)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()
