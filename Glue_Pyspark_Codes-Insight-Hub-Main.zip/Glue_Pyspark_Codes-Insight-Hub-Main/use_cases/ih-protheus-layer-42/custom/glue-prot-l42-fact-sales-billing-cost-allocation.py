# ================================Revision History=====================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      19-Apr-2021     Initial version
# =====================================================================================================
# Description   :- The aim of the code is to generate table l42_prot_fact_sales_billing_cost_allocation
#                   into conform zone
# Author        :- Bakul Seth
# Date          :- 19-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ====================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = 'l41_prot_fact_sales_billing_cost_allocation_br_s5'
        self.report_file = 'l42_prot_fact_sales_billing_cost_allocation'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):

        # read data from country specific table argument passed(database, table)
        print('Reading data from input tabled {}.{}'.format(self.source_database,  self.input_table))
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        print('Data read complete schema of table is')
        df_input_table.printSchema()

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table)
        print('Schema after transformation ')
        df_tfx_table.printSchema()

        print('Writing the results to desired location')
        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table')
        return table

    @staticmethod
    def _apply_tfx(df_input):
        # applying the transformations on the dataframe
        print('Applying the transformations now')
        df_tfx_result = df_input\
            .select(df_input.ref_id, df_input.sales_document, df_input.billing_document, df_input.billing_item,
                    df_input.sales_organisation, df_input.country_mnmc, df_input.sector, df_input.prod_grp,
                    df_input.item_category, df_input.material_number, df_input.plant_id, df_input.plant,
                    df_input.plant_name, df_input.cae_plant, df_input.customer_id, df_input.customer_name,
                    df_input.delivery_date, df_input.d2_emissao, df_input.billing_date, df_input.period,
                    df_input.litres, df_input.ugl, df_input.document_currency, df_input.local_currency,
                    df_input.exchange_rate_type, df_input.exchange_rate, df_input.ile_exch_rate,
                    df_input.ire_exch_rate, df_input.lre_exch_rate, df_input.net_value, df_input.lcl_net_val,
                    df_input.lcl_man_val, df_input.lcl_tmp_val, df_input.lcl_apf_val, df_input.lcl_icm_val,
                    df_input.lcl_adj_val, df_input.lcl_cop_sys_val, df_input.lcl_cosa_val, df_input.lcl_cop_val,
                    df_input.lcl_lag_val, df_input.lcl_oic_val, df_input.lcl_oaf_val, df_input.lcl_oav_val,
                    df_input.lcl_paf_val, df_input.lcl_pav_val, df_input.usd_net_val, df_input.usd_adj_val,
                    df_input.usd_cop_val, df_input.usd_lag_val, df_input.usd_oic_val, df_input.usd_oaf_val,
                    df_input.usd_oav_val, df_input.usd_paf_val, df_input.usd_pav_val)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()
