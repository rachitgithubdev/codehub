# ================================Revision History=====================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      19-Apr-2021     Initial version
# =====================================================================================================
# Description   :- The aim of the code is to generate table l42_prot_fact_sales_pricing_conditions
#                   into conform zone
# Author        :- Bakul Seth
# Date          :- 19-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ====================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_tables = ['l42_prot_fact_sales_billing_cost_allocation_final',
                             'l42_prot_dim_pricing_conditions']
        self.report_file = 'l42_prot_fact_sales_pricing_conditions'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):

        # read data from country specific table argument passed(database, table)
        print('Reading data from input tabled {}.{}'.format(self.source_database,  self.input_tables))
        df_input_table = self._get_table(self.source_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table)
        print('Schema after transformation ')
        df_tfx_table.printSchema()

        print('Writing the results to desired location')
        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name[0]))
        cost_allocation = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[0],
                                                                     transformation_ctx='target_table').toDF()
        print('Data read from {}.{} is complete schema for the table is '.format(source_database, table_name[0]))
        cost_allocation.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[1]))
        pricing_cond = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[1],
                                                                  transformation_ctx='target_table').toDF()
        print('Data read from {}.{} is complete schema for the table is '.format(source_database, table_name[1]))
        pricing_cond.printSchema()

        return [cost_allocation, pricing_cond]

    def _apply_tfx(self, df_input):

        # preparing dataframe
        df_allocation = df_input[0]
        df_allocation.createOrReplaceTempView('allocation')

        df_price_cond = df_input[1]
        df_price_cond.createOrReplaceTempView('price_cond')

        # applying the transformations on the dataframe
        print('Applying the transformations now')
        df_tfx1 = df_allocation\
            .join(df_price_cond, (df_allocation.material_number == df_price_cond.material_number), 'left')\
            .select(f.lit('BRA').alias('source_system'), f.lit(None).cast('string').alias('doc_condition_no'),
                    df_allocation.ref_id, df_allocation.billing_item.alias('item_no'),
                    f.lit(0).cast('integer').alias('step_number'), f.lit(0).cast('integer').alias('counter'),
                    f.lit(None).cast('string').alias('application'),
                    df_allocation.item_category.alias('condition_category'),
                    f.when(df_price_cond.pricing_condition.isNotNull(), df_price_cond.pricing_condition)
                    .otherwise(f.lit('XXXX')).alias('condition_type'),
                    f.lit(0).cast('double').alias('condition_base_value'),
                    f.lit(0).cast('double').alias('condition_rate'), df_allocation.local_currency,
                    df_allocation.exchange_rate.alias('cond_exchange_rate'),
                    df_allocation.net_value.alias('condition_value'),
                    df_allocation.lcl_net_val.alias('condition_value_lc'),
                    df_allocation.usd_net_val.alias('condition_value_gc'))
        df_tfx1.printSchema()

        print('Calculating ADJ data')
        df_tfx2 = self._spark.sql('''SELECT 'BRA' AS source_system, CAST((NULL) AS STRING) AS doc_condition_no,
        ref_id AS ref_id, billing_item AS item_no, CAST((0) AS INT) AS step_number, CAST((0) AS INT) AS counter, 
        CAST((NULL) AS STRING) AS application, item_category AS condition_category,
        (SELECT pricing_condition FROM price_cond WHERE cost_column = "ADJ_VAL") AS condition_type,
        CAST((0) AS DOUBLE) AS condition_base_value, CAST((0) AS DOUBLE) AS condition_rate, 
        local_currency AS local_currency, exchange_rate AS cond_exchange_rate, net_value AS condition_value,
        CAST((lcl_adj_val) AS DOUBLE) AS condition_value_lc, CAST((usd_adj_val) AS DOUBLE) AS condition_value_gc 
        FROM allocation''')
        df_tfx2.printSchema()

        print('Calculating COP data')
        df_tfx3 = self._spark.sql('''SELECT 'BRA' AS source_system, CAST((NULL) AS STRING) AS doc_condition_no,
        ref_id AS ref_id, billing_item AS item_no, CAST((0) AS INT) AS step_number, CAST((0) AS INT) AS counter, 
        CAST((NULL) AS STRING) AS application, item_category AS condition_category,
        (SELECT pricing_condition FROM price_cond WHERE cost_column = "COP_VAL") AS condition_type,
        CAST((0) AS DOUBLE) AS condition_base_value, CAST((0) AS DOUBLE) AS condition_rate, 
        local_currency AS local_currency, exchange_rate AS cond_exchange_rate, net_value AS condition_value,
        CAST((lcl_cop_val*-1) AS DOUBLE) AS condition_value_lc, 
        CAST((usd_cop_val*-1) AS DOUBLE) AS condition_value_gc FROM allocation''')
        df_tfx3.printSchema()

        print('Calculating LAG data')
        df_tfx4 = self._spark.sql('''SELECT 'BRA' AS source_system, CAST((NULL) AS STRING) AS doc_condition_no,
        ref_id AS ref_id, billing_item AS item_no, CAST((0) AS INT) AS step_number, CAST((0) AS INT) AS counter, 
        CAST((NULL) AS STRING) AS application, item_category AS condition_category,
        (SELECT pricing_condition FROM price_cond WHERE cost_column = "LAG_VAL") AS condition_type, 
        CAST((0) AS DOUBLE) AS condition_base_value, CAST((0) AS DOUBLE) AS condition_rate, 
        local_currency AS local_currency, exchange_rate AS cond_exchange_rate, net_value AS condition_value,
        CAST((lcl_lag_val*-1) AS DOUBLE) AS condition_value_lc, 
        CAST((usd_lag_val*-1) AS DOUBLE) AS condition_value_gc FROM allocation''')
        df_tfx4.printSchema()

        print('Calculating OIC data')
        df_tfx5 = self._spark.sql('''SELECT 'BRA' AS source_system, CAST((NULL) AS STRING) AS doc_condition_no,
        ref_id AS ref_id, billing_item AS item_no, CAST((0) AS INT) AS step_number, CAST((0) AS INT) AS counter, 
        CAST((NULL) AS STRING) AS application, item_category AS condition_category,
        (SELECT pricing_condition FROM price_cond WHERE cost_column = "OIC_VAL") AS condition_type, 
        CAST((0) AS DOUBLE) AS condition_base_value, CAST((0) AS DOUBLE) AS condition_rate, 
        local_currency AS local_currency, exchange_rate AS cond_exchange_rate, net_value AS condition_value,
        CAST((lcl_oic_val) AS DOUBLE) AS condition_value_lc, 
        CAST((usd_oic_val) AS DOUBLE) AS condition_value_gc FROM allocation''')
        df_tfx5.printSchema()

        print('Calculating OAF data')
        df_tfx6 = self._spark.sql('''SELECT 'BRA' AS source_system, CAST((NULL) AS STRING) AS doc_condition_no,
        ref_id AS ref_id, billing_item AS item_no, CAST((0) AS INT) AS step_number, CAST((0) AS INT) AS counter, 
        CAST((NULL) AS STRING) AS application, item_category AS condition_category,
        (SELECT pricing_condition FROM price_cond WHERE cost_column = "OAF_VAL") AS condition_type, 
        CAST((0) AS DOUBLE) AS condition_base_value, CAST((0) AS DOUBLE) AS condition_rate, 
        local_currency AS local_currency, exchange_rate AS cond_exchange_rate, net_value AS condition_value,
        CAST((lcl_oaf_val*-1) AS DOUBLE) AS condition_value_lc, 
        CAST((usd_oaf_val*-1) AS DOUBLE) AS condition_value_gc FROM allocation''')
        df_tfx6.printSchema()

        print('Calculating OAV data')
        df_tfx7 = self._spark.sql('''SELECT 'BRA' AS source_system, CAST((NULL) AS STRING) AS doc_condition_no,
        ref_id AS ref_id, billing_item AS item_no, CAST((0) AS INT) AS step_number, CAST((0) AS INT) AS counter,
        CAST((NULL) AS STRING) AS application, item_category AS condition_category,
        (SELECT pricing_condition FROM price_cond WHERE cost_column = "OAV_VAL") AS condition_type, 
        CAST((0) AS DOUBLE) AS condition_base_value, CAST((0) AS DOUBLE) AS condition_rate, 
        local_currency AS local_currency, exchange_rate AS cond_exchange_rate, net_value AS condition_value,
        CAST((lcl_oav_val*-1) AS DOUBLE) AS condition_value_lc, 
        CAST((usd_oav_val*-1) AS DOUBLE) AS condition_value_gc FROM allocation''')
        df_tfx7.printSchema()

        print('Calculating PAF data')
        df_tfx8 = self._spark.sql('''SELECT 'BRA' AS source_system, CAST((NULL) AS STRING) AS doc_condition_no,
        ref_id AS ref_id, billing_item AS item_no, CAST((0) AS INT) AS step_number, CAST((0) AS INT) AS counter,
        CAST((NULL) AS STRING) AS application, item_category AS condition_category,
        (SELECT pricing_condition FROM price_cond WHERE cost_column = "PAF_VAL") AS condition_type, 
        CAST((0) AS DOUBLE) AS condition_base_value, CAST((0) AS DOUBLE) AS condition_rate, 
        local_currency AS local_currency, exchange_rate AS cond_exchange_rate, net_value AS condition_value,
        CAST((lcl_paf_val*-1) AS DOUBLE) AS condition_value_lc, 
        CAST((usd_paf_val*-1) AS DOUBLE) AS condition_value_gc FROM allocation''')
        df_tfx8.printSchema()

        print('Calculating PAV data')
        df_tfx9 = self._spark.sql('''SELECT 'BRA' AS source_system, CAST((NULL) AS STRING) AS doc_condition_no,
        ref_id AS ref_id, billing_item AS item_no, CAST((0) AS INT) AS step_number, CAST((0) AS INT) AS counter,
        CAST((NULL) AS STRING) AS application, item_category AS condition_category,
        (SELECT pricing_condition FROM price_cond WHERE cost_column = "PAV_VAL") AS condition_type, 
        CAST((0) AS DOUBLE) AS condition_base_value, CAST((0) AS DOUBLE) AS condition_rate, 
        local_currency AS local_currency, exchange_rate AS cond_exchange_rate, net_value AS condition_value,
        CAST((lcl_pav_val*-1) AS DOUBLE) AS condition_value_lc, 
        CAST((usd_pav_val*-1) AS DOUBLE) AS condition_value_gc FROM allocation''')
        df_tfx9.printSchema()

        df_list = [df_tfx1, df_tfx2, df_tfx3, df_tfx4, df_tfx5, df_tfx6, df_tfx7, df_tfx8, df_tfx9]

        print('Union all the Dataframes and get the distinct values')
        df_tfx_result = reduce(DataFrame.unionAll, df_list).distinct()

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()
