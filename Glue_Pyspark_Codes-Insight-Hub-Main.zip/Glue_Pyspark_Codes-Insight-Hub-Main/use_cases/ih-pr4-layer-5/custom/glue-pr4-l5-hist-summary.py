# ================================Revision History=====================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      04-May-2021     Initial version
# =====================================================================================================
# Description   :- The aim of the code is to generate table l5_pr4_summary
#                  into conform zone
# Author        :- Liz Harvey
# Date          :- 04-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ====================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
import sys


class LcpPr4ETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database1 = args['source_database1']
        self.source_database2 = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l4_pr4_fact_sales_billing', 'l2_pr4_us_dim_customer']
        self.report_file = 'l5_pr4_summary'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database1,
                                                                         self.source_database2,
                                                                         self.input_table_list,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table_1 = self._get_table(self.source_database1, self.input_table_list[0]).toDF()
        print("Schema of table {}.{} is {}".format(self.source_database1, self.input_table_list[0],
                                                   df_input_table_1.printSchema()))
        df_input_table_2 = self._get_table(self.source_database2, self.input_table_list[1]).toDF()
        print("Schema of table {}.{} is {}".format(self.source_database2, self.input_table_list[1],
                                                   df_input_table_2.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_1, df_input_table_2)
        print("Schema after transformation ", df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table_1, df_input_table_2):
        df_t1_1 = df_input_table_1.withColumn("max", f.lit(1))
        w = Window.partitionBy(f.col("max"))
        df_t1_2 = df_t1_1.withColumn("last_modified_date", f.max(f.col("billing_date")).over(w))

        df_tfx_result = df_t1_2.alias("A").join(df_input_table_2.alias("B"),
                                                f.col("A.sold_to_party") == f.col("B.erp_id"), "left") \
            .select(
            f.concat(f.substring(f.col("A.month_id").cast("string"), 1, 4), f.lit("-"),
                     f.substring(f.col("A.Month_Id").cast("string"), 5, 2)).cast(DateType()).alias("pricing_date"),
            f.col("A.billing_date").alias("billing_date"),
            f.col("A.delivery_date").alias("delivery_date"),
            f.col("A.name").alias("airport_name"),
            f.col("B.customer_country").alias("customer_country"),
            f.col("B.grn_header").alias("grn_header"),
            f.col("B.customer_account_name").alias("customer_account_name"),
            f.col("B.grn").alias("grn"),
            f.col("B.account_manager").alias("account_manager"),
            (f.when(f.col("B.sector") == "EXPORT", "Export")
             .otherwise(f.col("B.sector"))).alias("sector"),
            f.col("B.customer_country").alias("billto_customer_country"),
            f.col("B.grn_header").alias("billto_grn_header"),
            f.col("B.customer_account_name").alias("billto_customer_account_name"),
            f.col("B.grn").alias("billto_grn"),
            f.col("B.account_manager").alias("billto_account_manager"),
            (f.when(f.col("B.sector") == "EXPORT", "Export")
             .otherwise(f.col("B.sector"))).alias("billto_sector"),
            f.col("B.customer_country").alias("payer_customer_country"),
            f.col("B.grn_header").alias("payer_grn_header"),
            f.col("B.customer_account_name").alias("payer_customer_account_name"),
            f.col("B.grn").alias("payer_grn"),
            f.col("B.account_manager").alias("payer_account_manager"),
            (f.when(f.col("B.sector") == "EXPORT", "Export")
             .otherwise(f.col("B.sector"))).alias("payer_sector"),
            f.lit("pr4_hist").alias("source_system"),
            f.col("A.sales_organization").alias("sales_organisation"),
            f.col("A.sales_document").alias("sales_document"),
            f.col("A.delivery_num").alias("delivery_number"),
            f.col("A.material").alias("material_number"),
            f.col("A.material_description").alias("local_material_description"),
            f.col("A.material_description").alias("material_description"),
            f.col("A.billing_document").alias("billing_document"),
            f.col("A.billing_item").alias("billing_item"),
            f.col("A.local_currency").alias("local_currency"),
            f.col("A.m3").alias("qty_in_m3"),
            f.col("A.ugl").alias("qty_in_usg"),
            (f.col("A.m3") * 1000).alias("qty_in_litres"),
            f.col("A.local_currency").alias("document_currency"),
            f.col("A.flightnum").alias("flight_number"),
            f.col("A.aircraftreg").alias("aircraft_registration"),
            f.col("A.ref_id").alias("cost_element_key"),
            f.col("A.last_modified_date").alias("last_modified_date"),
            f.col("A.sold_to_party").alias("trx_cust_key"),
            f.col("B.erp_id").alias("DIM_CUST_KEY"),
            f.col("A.sold_to_party").alias("TRX_BILLTO_KEY"),
            f.col("B.erp_id").alias("DIM_BILLTO_KEY"),
            f.col("A.sold_to_party").alias("TRX_PAYER_KEY"),
            f.col("B.erp_id").alias("DIM_PAYER_KEY"),
            f.col("A.iata_code_bo").alias("TRX_LOC_KEY"),
            f.col("A.material").alias("TRX_PRO_KEY"),
            f.col("A.material").alias("DIM_PRO_KEY"),
            f.col("A.ib_global_cust_ref").alias("payer"),
            f.col("A.sold_to_party").alias("soldto_party"),
            (f.when(f.col("A.MOT").isin(["Refueler Truck", "Hydrant"]), "Into Plane")
             .when(f.col("A.MOT").isin(["Truck", "Pipeline", "In-Tank Transfer"]), "Bulk")
             .when(f.col("A.MOT").isNull(), "NA")
             .otherwise("NA")).alias("delivery_method")
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPr4ETL()
    trl.execute()
