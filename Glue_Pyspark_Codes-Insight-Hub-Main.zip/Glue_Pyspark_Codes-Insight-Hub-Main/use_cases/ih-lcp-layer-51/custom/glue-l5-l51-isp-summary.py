# ================================Revision History============================================
# #
#  Change Version,  Change Author   , Change Date , Change Component, Change Description
#  0.1              Bakul Seth                      Initial version
#  0.2              Liz Harvey        05-May-2021   Protheus & PR4
#  0.3              Liz Harvey        13-May-2021   SUN
#  0.4              Hasan Chaudhary   31-May-2021   PRE
# 0.5               Liz Harvey        08-June-2021  Change control
# ============================================================================================
# Description :- The aim of the code is to generate l51_summary into conform zone
# Author :-  Bakul Seth
# Date :- 16-Dec-2020
# Version :-  0.1
# AWS component used :- S3 and Glue
# ===========================================================================================


import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class LcpL51ETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database1']
        self.netapp_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l5_isp_summary', 'l2_l5_dim_group_carrier', 'l5_prot_summary',
                                 'l5_pr4_summary', 'l4_location_mapping_pr4', 'l5_sun_summary', 'l5_pre_summary',
                                 'l4_location_mapping_isp', 'l4_location_mapping_pro', 'l4_location_mapping_sun',
                                 'l4_location_mapping_pre']
        self.report_file = "l51_summary"

        # print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and {}.{}* write it to {}'.format(self.source_database,
        #                                                                         self.input_table_list[0],
        #                                                                         self.netapp_database,
        #                                                                         self.input_table_list[1],
        #                                                                         self.destination_bucket))

    def execute(self):
        # generate input table list
        source_database = self.source_database
        netapp_database = self.netapp_database
        input_table_list = self.input_table_list
        # print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        df_input_table_A = self._get_table(source_database, input_table_list[0]).toDF()
        df_input_table_B = self._get_table(netapp_database, input_table_list[1]).toDF()
        df_input_table_C = self._get_table(source_database, input_table_list[2]).toDF()
        df_input_table_D = self._get_table(source_database, input_table_list[3]).toDF()
        df_input_table_E = self._get_table(source_database, input_table_list[4]).toDF()
        df_input_table_F = self._get_table(source_database, input_table_list[5]).toDF()
        df_input_table_G = self._get_table(source_database, input_table_list[6]).toDF()
        df_input_table_H = self._get_table(source_database, input_table_list[7]).toDF()
        df_input_table_I = self._get_table(source_database, input_table_list[8]).toDF()
        df_input_table_J = self._get_table(source_database, input_table_list[9]).toDF()
        df_input_table_K = self._get_table(source_database, input_table_list[10]).toDF()

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_A, df_input_table_B, df_input_table_C, df_input_table_D,
                                       df_input_table_E, df_input_table_F, df_input_table_G, df_input_table_H,
                                       df_input_table_I, df_input_table_J, df_input_table_K)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # convert all the columns alias to lower case
        final_result_df = args[0].select(
            [f.col(x).alias(x.lower()) for x in args[0].columns])
        group_carrier_df = args[1].select(
            [f.col(x).alias(x.lower()) for x in args[1].columns])
        prot_summary_df = args[2].select(
            [f.col(x).alias(x.lower()) for x in args[2].columns])
        pr4_summary_df = args[3].select(
            [f.col(x).alias(x.lower()) for x in args[3].columns])
        pr4_location_df = args[4].select(
            [f.col(x).alias(x.lower()) for x in args[4].columns])
        sun_summary_df = args[5].select(
            [f.col(x).alias(x.lower()) for x in args[5].columns])
        pre_summary_df = args[6].select(
            [f.col(x).alias(x.lower()) for x in args[6].columns])
        isp_location_df = args[7].select(
            [f.col(x).alias(x.lower()) for x in args[7].columns])
        prot_location_df = args[8].select(
            [f.col(x).alias(x.lower()) for x in args[8].columns])
        sun_location_df = args[9].select(
            [f.col(x).alias(x.lower()) for x in args[9].columns])
        pre_location_df = args[10].select(
            [f.col(x).alias(x.lower()) for x in args[10].columns])

        # applying transformation
        df_isp_union = final_result_df.join(group_carrier_df, final_result_df.grn == group_carrier_df.grn, 'left') \
            .join(isp_location_df, f.split(final_result_df.trx_loc_key, "_")[2]
                  == isp_location_df.isp_mapping, 'left') \
            .select(
            final_result_df.pricing_date.alias('pricing_date'), final_result_df.billing_date.alias('billing_date'),
            final_result_df.delivery_date.alias('delivery_date'),
            f.when(final_result_df.customer_country == f.lit('AL'), f.lit('Albania'))
                .when(final_result_df.customer_country == f.lit('Brit.Virgin Is.'), f.lit('BRITISH VIRGIN ISLANDS'))
                .when(final_result_df.customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                .when(final_result_df.customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                .when(final_result_df.customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                .when(final_result_df.customer_country == f.lit('French Polynes.'), f.lit('French Polynesia'))
                .when(final_result_df.customer_country == f.lit('IT'), f.lit('Italy'))
                .when(final_result_df.customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                .when(final_result_df.customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                .when(final_result_df.customer_country == f.lit('Republic Of Korea'), f.lit('South Korea'))
                .when(final_result_df.customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'), f.lit('South Korea'))
                .when(final_result_df.customer_country == f.lit('RO'), f.lit('Romania'))
                .when(final_result_df.customer_country == f.lit('Russian Federation'), f.lit('RUSSIA'))
                .when(final_result_df.customer_country == f.lit('Utd.Arab Emir.'), f.lit('United Arab Emirates'))
                .when(final_result_df.customer_country == f.lit('United States'), f.lit('USA'))
                .when(final_result_df.customer_country == f.lit('Usa'), f.lit('USA'))
                .otherwise(final_result_df.customer_country).alias('customer_country'),
            final_result_df.grn_header.alias('grn_header'),
            final_result_df.customer_account_name.alias('customer_account_name'),
            final_result_df.cc_grn.alias('cc_grn'), final_result_df.grn.alias('grn'),
            final_result_df.account_manager.alias('account_manager'), final_result_df.sector.alias('sector'),
            final_result_df.customer_segment.alias('customer_segment'),
            final_result_df.source_system.alias('source_system'),
            final_result_df.sales_organisation.alias('sales_organisation'),
            final_result_df.sales_document.alias('sales_document'),
            final_result_df.delivery_number.alias('delivery_number'),
            final_result_df.material_number.alias('material_number'),
            final_result_df.material_description.alias('material_description'),
            final_result_df.local_material_description.alias('local_material_description'),
            final_result_df.billing_document.alias('billing_document'),
            final_result_df.billing_item.alias('billing_item'),
            final_result_df.local_currency.alias('local_currency'),
            f.coalesce(final_result_df.qty_in_m3, f.lit(0)).alias('qty_in_m3'),
            f.coalesce(final_result_df.qty_in_usg, f.lit(0)).alias('qty_in_usg'),
            f.coalesce(final_result_df.qty_in_litres, f.lit(0)).alias('qty_in_litres'),
            f.coalesce(final_result_df.net_value, f.lit(0)).alias('net_value'),
            final_result_df.document_currency.alias('document_currency'),
            final_result_df.flight_number.alias('flight_number'),
            final_result_df.aircraft_registration.alias('aircraft_registration'),
            final_result_df.cost_element_key.alias('cost_element_key'),
            final_result_df.trx_cust_key.alias('trx_cust_key'),
            final_result_df.dim_cust_key.alias('dim_cust_key'),
            final_result_df.trx_loc_key.alias('trx_loc_key'),
            final_result_df.trx_pro_key.alias('trx_pro_key'),
            final_result_df.dim_pro_key.alias('dim_pro_key'),
            f.when(final_result_df.customer_account_name.isin(
                f.lit('BP Aviation A/S'), f.lit('BP AVIATION A/S'), f.lit('BP INTERNATIONAL LIMITED UPSTREAM HO'),
                f.lit('BP PRODUCTS NORTH AMERICA INC'), f.lit('BP Products North America Inc')) |
                   (f.substring(final_result_df.customer_account_name, 1, 12).isin(f.lit('BP EUROPA SE'),
                                                                                   f.lit('BP Europa SE'))) |
                   (f.substring(final_result_df.customer_account_name, 1, 14) == f.lit('AIR BP LIMITED')) |
                   (f.substring(final_result_df.customer_account_name, 1, 13).isin(f.lit('BP OIL ESPANA'),
                                                                                   f.lit('BP Oil Espana'))) |
                   (f.substring(final_result_df.customer_account_name, 1, 16).isin(f.lit('Air BP Sweden AB'),
                                                                                   f.lit('AIR BP SWEDEN AB'))) |
                   (f.substring(final_result_df.customer_account_name, 1, 9).isin(f.lit('BP France'),
                                                                                  f.lit('BP FRANCE'))) |
                   final_result_df.soldto_party.isin('0010023709', '0012154140', '0012164165', '0010023732',
                                                     '0010023650',
                                                     '0010012647', '0010023743', '0030099390', '0012244440'),
                   f.lit('Y')).otherwise('N').alias('intercompany_flag'),
            final_result_df.payer.alias('payer'), final_result_df.soldto_party.alias('soldto_party'),
            final_result_df.costing_country.alias('costing_country'),
            final_result_df.last_modified_date.alias('last_modified_date'),
            group_carrier_df.market_space.alias('Market_Space'), group_carrier_df.carrier.alias('carrier'),
            group_carrier_df.account_holder.alias('SF_Account_Manager'), group_carrier_df.group.alias('group'),
            group_carrier_df.customer_type.alias('Customer_Type'),
            group_carrier_df.customer_segment.alias('Marketing_Segment'),
            group_carrier_df.rsm.alias('Regional_Sales_Manager'),
            final_result_df.delivery_method.alias('delivery_method'),
            isp_location_df.location_id.alias("sem_location_id"),
            (f.when(final_result_df.billto_customer_country.isNull(),
                    f.when(final_result_df.customer_country == f.lit('AL'), f.lit('Albania'))
                    .when(final_result_df.customer_country == f.lit('Brit.Virgin Is.'), f.lit('BRITISH VIRGIN ISLANDS'))
                    .when(final_result_df.customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                    .when(final_result_df.customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                    .when(final_result_df.customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                    .when(final_result_df.customer_country == f.lit('French Polynes.'), f.lit('French Polynesia'))
                    .when(final_result_df.customer_country == f.lit('IT'), f.lit('Italy'))
                    .when(final_result_df.customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                    .when(final_result_df.customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                    .when(final_result_df.customer_country == f.lit('Republic Of Korea'), f.lit('South Korea'))
                    .when(final_result_df.customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'), f.lit('South Korea'))
                    .when(final_result_df.customer_country == f.lit('RO'), f.lit('Romania'))
                    .when(final_result_df.customer_country == f.lit('Russian Federation'), f.lit('RUSSIA'))
                    .when(final_result_df.customer_country == f.lit('Utd.Arab Emir.'), f.lit('United Arab Emirates'))
                    .when(final_result_df.customer_country == f.lit('United States'), f.lit('USA'))
                    .when(final_result_df.customer_country == f.lit('Usa'), f.lit('USA'))
                    .otherwise(final_result_df.customer_country))
             .otherwise(f.when(final_result_df.billto_customer_country == f.lit('AL'), f.lit('Albania'))
                        .when(final_result_df.billto_customer_country == f.lit('Brit.Virgin Is.'),
                              f.lit('BRITISH VIRGIN ISLANDS'))
                        .when(final_result_df.billto_customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                        .when(final_result_df.billto_customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                        .when(final_result_df.billto_customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                        .when(final_result_df.billto_customer_country == f.lit('French Polynes.'),
                              f.lit('French Polynesia'))
                        .when(final_result_df.billto_customer_country == f.lit('IT'), f.lit('Italy'))
                        .when(final_result_df.billto_customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                        .when(final_result_df.billto_customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                        .when(final_result_df.billto_customer_country == f.lit('Republic Of Korea'),
                              f.lit('South Korea'))
                        .when(final_result_df.billto_customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'),
                              f.lit('South Korea'))
                        .when(final_result_df.billto_customer_country == f.lit('RO'), f.lit('Romania'))
                        .when(final_result_df.billto_customer_country == f.lit('Russian Federation'),
                              f.lit('RUSSIA'))
                        .when(final_result_df.billto_customer_country == f.lit('Utd.Arab Emir.'),
                              f.lit('United Arab Emirates'))
                        .when(final_result_df.billto_customer_country == f.lit('United States'), f.lit('USA'))
                        .when(final_result_df.billto_customer_country == f.lit('Usa'), f.lit('USA'))
                        .otherwise(final_result_df.billto_customer_country))).alias("billto_customer_country"),
            (f.when(final_result_df.billto_grn_header.isNull(), final_result_df.grn_header)
             .otherwise(final_result_df.billto_grn_header)).alias("billto_grn_header"),
            (f.when(final_result_df.billto_customer_account_name.isNull(), final_result_df.customer_account_name)
             .otherwise(final_result_df.billto_customer_account_name)).alias("billto_customer_account_name"),
            (f.when(final_result_df.billto_grn.isNull(), final_result_df.grn)
             .otherwise(final_result_df.billto_grn)).alias("billto_grn"),
            (f.when(final_result_df.billto_cc_grn.isNull(), final_result_df.cc_grn)
             .otherwise(final_result_df.billto_cc_grn)).alias("billto_cc_grn"),
            (f.when(final_result_df.billto_account_manager.isNull(), final_result_df.account_manager)
             .otherwise(final_result_df.billto_account_manager)).alias("billto_account_manager"),
            (f.when(final_result_df.billto_sector.isNull(), final_result_df.sector)
             .otherwise(final_result_df.billto_sector)).alias("billto_sector"),
            (f.when(final_result_df.payer_customer_country.isNull(),
                    f.when(final_result_df.customer_country == f.lit('AL'), f.lit('Albania'))
                    .when(final_result_df.customer_country == f.lit('Brit.Virgin Is.'), f.lit('BRITISH VIRGIN ISLANDS'))
                    .when(final_result_df.customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                    .when(final_result_df.customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                    .when(final_result_df.customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                    .when(final_result_df.customer_country == f.lit('French Polynes.'), f.lit('French Polynesia'))
                    .when(final_result_df.customer_country == f.lit('IT'), f.lit('Italy'))
                    .when(final_result_df.customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                    .when(final_result_df.customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                    .when(final_result_df.customer_country == f.lit('Republic Of Korea'), f.lit('South Korea'))
                    .when(final_result_df.customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'), f.lit('South Korea'))
                    .when(final_result_df.customer_country == f.lit('RO'), f.lit('Romania'))
                    .when(final_result_df.customer_country == f.lit('Russian Federation'), f.lit('RUSSIA'))
                    .when(final_result_df.customer_country == f.lit('Utd.Arab Emir.'), f.lit('United Arab Emirates'))
                    .when(final_result_df.customer_country == f.lit('United States'), f.lit('USA'))
                    .when(final_result_df.customer_country == f.lit('Usa'), f.lit('USA'))
                    .otherwise(final_result_df.customer_country))
             .otherwise(f.when(final_result_df.payer_customer_country == f.lit('AL'), f.lit('Albania'))
                        .when(final_result_df.payer_customer_country == f.lit('Brit.Virgin Is.'),
                              f.lit('BRITISH VIRGIN ISLANDS'))
                        .when(final_result_df.payer_customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                        .when(final_result_df.payer_customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                        .when(final_result_df.payer_customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                        .when(final_result_df.payer_customer_country == f.lit('French Polynes.'),
                              f.lit('French Polynesia'))
                        .when(final_result_df.payer_customer_country == f.lit('IT'), f.lit('Italy'))
                        .when(final_result_df.payer_customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                        .when(final_result_df.payer_customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                        .when(final_result_df.payer_customer_country == f.lit('Republic Of Korea'),
                              f.lit('South Korea'))
                        .when(final_result_df.payer_customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'),
                              f.lit('South Korea'))
                        .when(final_result_df.payer_customer_country == f.lit('RO'), f.lit('Romania'))
                        .when(final_result_df.payer_customer_country == f.lit('Russian Federation'),
                              f.lit('RUSSIA'))
                        .when(final_result_df.payer_customer_country == f.lit('Utd.Arab Emir.'),
                              f.lit('United Arab Emirates'))
                        .when(final_result_df.payer_customer_country == f.lit('United States'), f.lit('USA'))
                        .when(final_result_df.payer_customer_country == f.lit('Usa'), f.lit('USA'))
                        .otherwise(final_result_df.payer_customer_country))).alias("payer_customer_country"),
            (f.when(final_result_df.payer_grn_header.isNull(), final_result_df.grn_header)
             .otherwise(final_result_df.payer_grn_header)).alias("payer_grn_header"),
            (f.when(final_result_df.payer_customer_account_name.isNull(), final_result_df.customer_account_name)
             .otherwise(final_result_df.payer_customer_account_name)).alias("payer_customer_account_name"),
            (f.when(final_result_df.payer_grn.isNull(), final_result_df.grn)
             .otherwise(final_result_df.payer_grn)).alias("payer_grn"),
            (f.when(final_result_df.payer_cc_grn.isNull(), final_result_df.grn)
             .otherwise(final_result_df.payer_cc_grn)).alias("payer_cc_grn"),
            (f.when(final_result_df.payer_account_manager.isNull(), final_result_df.account_manager)
             .otherwise(final_result_df.payer_account_manager)).alias("payer_account_manager"),
            (f.when(final_result_df.payer_sector.isNull(), final_result_df.sector)
             .otherwise(final_result_df.payer_sector)).alias("payer_sector"),
            (f.when(final_result_df.trx_billto_key.isNull(), final_result_df.trx_cust_key)
             .otherwise(final_result_df.trx_billto_key)).alias("trx_billto_key"),
            (f.when(final_result_df.dim_billto_key.isNull(), final_result_df.dim_cust_key)
             .otherwise(final_result_df.dim_billto_key)).alias("dim_billto_key"),
            (f.when(final_result_df.trx_payer_key.isNull(), final_result_df.trx_cust_key)
             .otherwise(final_result_df.trx_payer_key)).alias("trx_payer_key"),
            (f.when(final_result_df.dim_payer_key.isNull(), final_result_df.dim_cust_key)
             .otherwise(final_result_df.dim_payer_key)).alias("dim_payer_key")
        )

        # Liz - Protheus union =====================================================================
        df_prot_union = prot_summary_df.alias("prot").join(group_carrier_df.alias("sfdc"),
                                                           f.col("prot.grn") == f.col("sfdc.grn"), "left") \
            .join(prot_location_df, prot_summary_df.trx_loc_key == prot_location_df.pro_mapping,
                  'left') \
            .select(f.col("prot.pricing_date").alias("pricing_date"),
                    f.col("prot.billing_date").alias("billing_date"),
                    f.col("prot.delivery_date").alias("delivery_date"),
                    (f.when(f.col("prot.customer_country") == 'AL', 'Albania')
                     .when(f.col("prot.customer_country") == 'Brit.Virgin Is.', 'BRITISH VIRGIN ISLANDS')
                     .when(f.col("prot.customer_country") == 'Brunei Daruss.', 'BRUNEI')
                     .when(f.col("prot.customer_country") == 'CZECH', 'Czech Republic')
                     .when(f.col("prot.customer_country") == 'Czechia', 'Czech Republic')
                     .when(f.col("prot.customer_country") == 'French Polynes.', 'French Polynesia')
                     .when(f.col("prot.customer_country") == 'IT', 'Italy')
                     .when(f.col("prot.customer_country") == 'KAZAKSTAN', 'Kazakhstan')
                     .when(f.col("prot.customer_country") == 'LEBANON AIR BP', 'Lebanon')
                     .when(f.col("prot.customer_country") == 'Republic Of Korea', 'South Korea')
                     .when(f.col("prot.customer_country") == 'REPUBLIC OF KOREA (SOUTH)', 'South Korea')
                     .when(f.col("prot.customer_country") == 'RO', 'Romania')
                     .when(f.col("prot.customer_country") == 'Russian Federation', 'RUSSIA')
                     .when(f.col("prot.customer_country") == 'Utd.Arab Emir.', 'United Arab Emirates')
                     .when(f.col("prot.customer_country") == 'United States', 'USA')
                     .when(f.col("prot.customer_country") == 'Usa', 'USA')
                     .otherwise(f.col("prot.customer_country"))).alias("customer_country"),
                    f.col("prot.grn_header").alias("AS grn_header"),
                    f.col("prot.customer_account_name").alias("customer_account_name"),
                    f.col("prot.grn_header").alias("cc_grn"),
                    f.col("prot.grn").alias("grn"),
                    f.col("prot.account_manager").alias("account_manager"),
                    f.col("prot.sector").alias("sector"),
                    f.lit('NA').alias("customer_segment"),
                    f.col("prot.source_system").alias("source_system"),
                    f.col("prot.sales_organisation").alias("sales_organisation"),
                    f.col("prot.sales_document").alias("sales_document"),
                    f.col("prot.delivery_number").alias("delivery_number"),
                    f.col("prot.material_number").alias("material_number"),
                    f.col("prot.material_description").alias("material_description"),
                    f.col("prot.local_material_description").alias("local_material_description"),
                    f.col("prot.billing_document").alias("billing_document"),
                    f.col("prot.billing_item").alias("billing_item"),
                    f.col("prot.local_currency").alias("local_currency"),
                    (f.coalesce(f.col("prot.qty_in_m3"), f.lit(0))).alias("qty_in_m3"),
                    (f.coalesce(f.col("prot.qty_in_usg"), f.lit(0))).alias("qty_in_usg"),
                    (f.coalesce(f.col("prot.qty_in_litres"), f.lit(0))).alias("qty_in_litres"),
                    (f.coalesce(f.col("prot.net_value"), f.lit(0))).alias("net_value"),
                    f.col("prot.document_currency").alias("document_currency"),
                    f.col("prot.flight_number").alias("flight_number"),
                    f.col("prot.aircraft_registration").alias("aircraft_registration"),
                    f.col("prot.cost_element_key").alias("cost_element_key"),
                    f.col("prot.trx_cust_key").alias("TRX_CUST_KEY"),
                    f.col("prot.dim_cust_key").alias("DIM_CUST_KEY"),
                    f.col("prot.trx_loc_key").alias("TRX_LOC_KEY"),
                    f.col("prot.trx_pro_key").alias("TRX_PRO_KEY"),
                    f.col("prot.dim_pro_key").alias("DIM_PRO_KEY"),
                    f.lit("N").alias("intercompany_flag"),
                    f.col("prot.payer").alias("payer"),
                    f.col("prot.soldto_party").alias("soldto_party"),
                    f.lit(None).cast("string").alias("costing_country"),
                    f.col("prot.last_modified_date").alias("last_modified_date"),
                    f.col("sfdc.Market_Space").alias("Market_Space"),
                    f.col("sfdc.Carrier").alias("Carrier"),
                    f.col("sfdc.Account_Holder").alias("SF_Account_Manager"),
                    f.col("sfdc.Group").alias("Group"),
                    f.col("sfdc.Customer_Type").alias("Customer_Type"),
                    f.col("sfdc.Customer_Segment").alias("marketing_segment"),
                    f.col("sfdc.RSM").alias("Regional_Sales_Manager"),
                    f.col("prot.delivery_method").alias("delivery_method"),
                    f.col("location_id").alias("sem_location_id"),
                    (f.when(prot_summary_df.billto_customer_country.isNull(),
                            f.when(prot_summary_df.customer_country == f.lit('AL'), f.lit('Albania'))
                            .when(prot_summary_df.customer_country == f.lit('Brit.Virgin Is.'),
                                  f.lit('BRITISH VIRGIN ISLANDS'))
                            .when(prot_summary_df.customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                            .when(prot_summary_df.customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                            .when(prot_summary_df.customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                            .when(prot_summary_df.customer_country == f.lit('French Polynes.'),
                                  f.lit('French Polynesia'))
                            .when(prot_summary_df.customer_country == f.lit('IT'), f.lit('Italy'))
                            .when(prot_summary_df.customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                            .when(prot_summary_df.customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                            .when(prot_summary_df.customer_country == f.lit('Republic Of Korea'), f.lit('South Korea'))
                            .when(prot_summary_df.customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'),
                                  f.lit('South Korea'))
                            .when(prot_summary_df.customer_country == f.lit('RO'), f.lit('Romania'))
                            .when(prot_summary_df.customer_country == f.lit('Russian Federation'), f.lit('RUSSIA'))
                            .when(prot_summary_df.customer_country == f.lit('Utd.Arab Emir.'),
                                  f.lit('United Arab Emirates'))
                            .when(prot_summary_df.customer_country == f.lit('United States'), f.lit('USA'))
                            .when(prot_summary_df.customer_country == f.lit('Usa'), f.lit('USA'))
                            .otherwise(prot_summary_df.customer_country))
                     .otherwise(f.when(prot_summary_df.billto_customer_country == f.lit('AL'), f.lit('Albania'))
                                .when(prot_summary_df.billto_customer_country == f.lit('Brit.Virgin Is.'),
                                      f.lit('BRITISH VIRGIN ISLANDS'))
                                .when(prot_summary_df.billto_customer_country == f.lit('Brunei Daruss.'),
                                      f.lit('BRUNEI'))
                                .when(prot_summary_df.billto_customer_country == f.lit('CZECH'),
                                      f.lit('Czech Republic'))
                                .when(prot_summary_df.billto_customer_country == f.lit('Czechia'),
                                      f.lit('Czech Republic'))
                                .when(prot_summary_df.billto_customer_country == f.lit('French Polynes.'),
                                      f.lit('French Polynesia'))
                                .when(prot_summary_df.billto_customer_country == f.lit('IT'), f.lit('Italy'))
                                .when(prot_summary_df.billto_customer_country == f.lit('KAZAKSTAN'),
                                      f.lit('Kazakhstan'))
                                .when(prot_summary_df.billto_customer_country == f.lit('LEBANON AIR BP'),
                                      f.lit('Lebanon'))
                                .when(prot_summary_df.billto_customer_country == f.lit('Republic Of Korea'),
                                      f.lit('South Korea'))
                                .when(prot_summary_df.billto_customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'),
                                      f.lit('South Korea'))
                                .when(prot_summary_df.billto_customer_country == f.lit('RO'), f.lit('Romania'))
                                .when(prot_summary_df.billto_customer_country == f.lit('Russian Federation'),
                                      f.lit('RUSSIA'))
                                .when(prot_summary_df.billto_customer_country == f.lit('Utd.Arab Emir.'),
                                      f.lit('United Arab Emirates'))
                                .when(prot_summary_df.billto_customer_country == f.lit('United States'), f.lit('USA'))
                                .when(prot_summary_df.billto_customer_country == f.lit('Usa'), f.lit('USA'))
                                .otherwise(prot_summary_df.billto_customer_country))).alias("billto_customer_country"),
                    (f.when(prot_summary_df.billto_grn_header.isNull(), prot_summary_df.grn_header)
                     .otherwise(prot_summary_df.billto_grn_header)).alias("billto_grn_header"),
                    (f.when(prot_summary_df.billto_customer_account_name.isNull(),
                            prot_summary_df.customer_account_name)
                     .otherwise(prot_summary_df.billto_customer_account_name)).alias("billto_customer_account_name"),
                    (f.when(prot_summary_df.billto_grn.isNull(), prot_summary_df.grn)
                     .otherwise(prot_summary_df.billto_grn)).alias("billto_grn"),
                    f.col("prot.grn_header").alias("billto_cc_grn"),
                    (f.when(prot_summary_df.billto_account_manager.isNull(), prot_summary_df.account_manager)
                     .otherwise(prot_summary_df.billto_account_manager)).alias("billto_account_manager"),
                    (f.when(prot_summary_df.billto_sector.isNull(), prot_summary_df.sector)
                     .otherwise(prot_summary_df.billto_sector)).alias("billto_sector"),
                    (f.when(prot_summary_df.payer_customer_country.isNull(),
                            f.when(prot_summary_df.customer_country == f.lit('AL'), f.lit('Albania'))
                            .when(prot_summary_df.customer_country == f.lit('Brit.Virgin Is.'),
                                  f.lit('BRITISH VIRGIN ISLANDS'))
                            .when(prot_summary_df.customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                            .when(prot_summary_df.customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                            .when(prot_summary_df.customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                            .when(prot_summary_df.customer_country == f.lit('French Polynes.'),
                                  f.lit('French Polynesia'))
                            .when(prot_summary_df.customer_country == f.lit('IT'), f.lit('Italy'))
                            .when(prot_summary_df.customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                            .when(prot_summary_df.customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                            .when(prot_summary_df.customer_country == f.lit('Republic Of Korea'), f.lit('South Korea'))
                            .when(prot_summary_df.customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'),
                                  f.lit('South Korea'))
                            .when(prot_summary_df.customer_country == f.lit('RO'), f.lit('Romania'))
                            .when(prot_summary_df.customer_country == f.lit('Russian Federation'), f.lit('RUSSIA'))
                            .when(prot_summary_df.customer_country == f.lit('Utd.Arab Emir.'),
                                  f.lit('United Arab Emirates'))
                            .when(prot_summary_df.customer_country == f.lit('United States'), f.lit('USA'))
                            .when(prot_summary_df.customer_country == f.lit('Usa'), f.lit('USA'))
                            .otherwise(prot_summary_df.customer_country))
                     .otherwise(f.when(prot_summary_df.payer_customer_country == f.lit('AL'), f.lit('Albania'))
                                .when(prot_summary_df.payer_customer_country == f.lit('Brit.Virgin Is.'),
                                      f.lit('BRITISH VIRGIN ISLANDS'))
                                .when(prot_summary_df.payer_customer_country == f.lit('Brunei Daruss.'),
                                      f.lit('BRUNEI'))
                                .when(prot_summary_df.payer_customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                                .when(prot_summary_df.payer_customer_country == f.lit('Czechia'),
                                      f.lit('Czech Republic'))
                                .when(prot_summary_df.payer_customer_country == f.lit('French Polynes.'),
                                      f.lit('French Polynesia'))
                                .when(prot_summary_df.payer_customer_country == f.lit('IT'), f.lit('Italy'))
                                .when(prot_summary_df.payer_customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                                .when(prot_summary_df.payer_customer_country == f.lit('LEBANON AIR BP'),
                                      f.lit('Lebanon'))
                                .when(prot_summary_df.payer_customer_country == f.lit('Republic Of Korea'),
                                      f.lit('South Korea'))
                                .when(prot_summary_df.payer_customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'),
                                      f.lit('South Korea'))
                                .when(prot_summary_df.payer_customer_country == f.lit('RO'), f.lit('Romania'))
                                .when(prot_summary_df.payer_customer_country == f.lit('Russian Federation'),
                                      f.lit('RUSSIA'))
                                .when(prot_summary_df.payer_customer_country == f.lit('Utd.Arab Emir.'),
                                      f.lit('United Arab Emirates'))
                                .when(prot_summary_df.payer_customer_country == f.lit('United States'), f.lit('USA'))
                                .when(prot_summary_df.payer_customer_country == f.lit('Usa'), f.lit('USA'))
                                .otherwise(prot_summary_df.payer_customer_country))).alias("payer_customer_country"),
                    (f.when(prot_summary_df.payer_grn_header.isNull(), prot_summary_df.grn_header)
                     .otherwise(prot_summary_df.payer_grn_header)).alias("payer_grn_header"),
                    (f.when(prot_summary_df.payer_customer_account_name.isNull(), prot_summary_df.customer_account_name)
                     .otherwise(prot_summary_df.payer_customer_account_name)).alias("payer_customer_account_name"),
                    (f.when(prot_summary_df.payer_grn.isNull(), prot_summary_df.grn)
                     .otherwise(prot_summary_df.payer_grn)).alias("payer_grn"),
                    prot_summary_df.grn.alias("payer_cc_grn"),
                    (f.when(prot_summary_df.payer_account_manager.isNull(), prot_summary_df.account_manager)
                     .otherwise(prot_summary_df.payer_account_manager)).alias("payer_account_manager"),
                    (f.when(prot_summary_df.payer_sector.isNull(), prot_summary_df.sector)
                     .otherwise(prot_summary_df.payer_sector)).alias("payer_sector"),
                    (f.when(prot_summary_df.trx_billto_key.isNull(), prot_summary_df.trx_cust_key)
                     .otherwise(prot_summary_df.trx_billto_key)).alias("trx_billto_key"),
                    (f.when(prot_summary_df.dim_billto_key.isNull(), prot_summary_df.dim_cust_key)
                     .otherwise(prot_summary_df.dim_billto_key)).alias("dim_billto_key"),
                    (f.when(prot_summary_df.trx_payer_key.isNull(), prot_summary_df.trx_cust_key)
                     .otherwise(prot_summary_df.trx_payer_key)).alias("trx_payer_key"),
                    (f.when(prot_summary_df.dim_payer_key.isNull(), prot_summary_df.dim_cust_key)
                     .otherwise(prot_summary_df.dim_payer_key)).alias("dim_payer_key")
                    )

        # Liz - PR4 union ===========================================================================================
        df_w_nv = pr4_summary_df.withColumn("net_value", f.lit(0))

        df_pr4_union = df_w_nv.alias("pr4").join(group_carrier_df.alias("sfdc"),
                                                 f.col("pr4.grn") == f.col("sfdc.grn"), "left") \
            .join(pr4_location_df.alias("lmp"), f.col("pr4.trx_loc_key") == f.col("lmp.pr4_mapping"), "left") \
            .select(
            f.col("pr4.pricing_date").alias("pricing_date"),
            f.col("pr4.billing_date").alias("billing_date"),
            f.col("pr4.delivery_date").alias("delivery_date"),
            (f.when(f.col("pr4.customer_country") == 'AL', 'Albania')
             .when(f.col("pr4.customer_country") == 'Brit.Virgin Is.', 'BRITISH VIRGIN ISLANDS')
             .when(f.col("pr4.customer_country") == 'Brunei Daruss.', 'BRUNEI')
             .when(f.col("pr4.customer_country") == 'CZECH', 'Czech Republic')
             .when(f.col("pr4.customer_country") == 'Czechia', 'Czech Republic')
             .when(f.col("pr4.customer_country") == 'French Polynes.', 'French Polynesia')
             .when(f.col("pr4.customer_country") == 'IT', 'Italy')
             .when(f.col("pr4.customer_country") == 'KAZAKSTAN', 'Kazakhstan')
             .when(f.col("pr4.customer_country") == 'LEBANON AIR BP', 'Lebanon')
             .when(f.col("pr4.customer_country") == 'Republic Of Korea', 'South Korea')
             .when(f.col("pr4.customer_country") == 'REPUBLIC OF KOREA (SOUTH)', 'South Korea')
             .when(f.col("pr4.customer_country") == 'RO', 'Romania')
             .when(f.col("pr4.customer_country") == 'Russian Federation', 'RUSSIA')
             .when(f.col("pr4.customer_country") == 'Utd.Arab Emir.', 'United Arab Emirates')
             .when(f.col("pr4.customer_country") == 'United States', 'USA')
             .when(f.col("pr4.customer_country") == 'Usa', 'USA')
             .otherwise(f.col("pr4.customer_country"))).alias("customer_country"),
            f.col("pr4.grn_header").alias("grn_header"),
            f.col("pr4.customer_account_name").alias("customer_account_name"),
            f.col("pr4.grn_header").alias("cc_grn"),
            f.col("pr4.grn").alias("grn"),
            f.col("pr4.account_manager").alias("account_manager"),
            f.col("pr4.sector").alias("sector"),
            f.lit('NA').alias("customer_segment"),
            (f.when(f.col("pr4.source_system") == "pr4_hist", "PR4")
             .otherwise(f.col("pr4.source_system"))).alias("source_system"),
            f.col("pr4.sales_organisation").alias("sales_organisation"),
            f.col("pr4.sales_document").alias("sales_document"),
            f.col("pr4.delivery_number").alias("delivery_number"),
            f.col("pr4.material_number").alias("material_number"),
            f.col("pr4.material_description").alias("material_description"),
            f.col("pr4.local_material_description").alias("local_material_description"),
            f.col("pr4.billing_document").alias("billing_document"),
            f.col("pr4.billing_item").alias("billing_item"),
            f.col("pr4.local_currency").alias("local_currency"),
            f.coalesce(f.col("pr4.qty_in_m3"), f.lit(0)).alias("qty_in_m3"),
            f.coalesce(f.col("pr4.qty_in_usg"), f.lit(0)).alias("qty_in_usg"),
            f.coalesce(f.col("pr4.qty_in_litres"), f.lit(0)).alias("qty_in_litres"),
            f.coalesce(f.col("pr4.net_value"), f.lit(0)).alias("net_value"),
            f.col("pr4.document_currency").alias("document_currency"),
            f.col("pr4.flight_number").alias("flight_number"),
            f.col("pr4.aircraft_registration").alias("aircraft_registration"),
            f.col("pr4.cost_element_key").alias("cost_element_key"),
            f.col("pr4.trx_cust_key").alias("trx_cust_key"),
            f.col("pr4.dim_cust_key").alias("dim_cust_key"),
            f.col("pr4.trx_loc_key").alias("trx_loc_key"),
            f.col("pr4.trx_pro_key").alias("trx_pro_key"),
            f.col("pr4.dim_pro_key").alias("dim_pro_key"),
            f.lit('N').alias("intercompany_flag"),
            f.col("pr4.payer").alias("payer"),
            f.col("pr4.soldto_party").alias("soldto_party"),
            f.lit(None).cast("string").alias("costing_country"),
            f.col("pr4.last_modified_date").alias("last_modified_date"),
            f.col("sfdc.Market_Space").alias("Market_Space"),
            f.col("sfdc.Carrier").alias("Carrier"),
            f.col("sfdc.Account_Holder").alias("SF_Account_Manager"),
            f.col("sfdc.Group").alias("Group"),
            f.col("sfdc.Customer_Type").alias("Customer_Type"),
            f.col("sfdc.Customer_Segment").alias("Marketing_Segment"),
            f.col("sfdc.RSM").alias("Regional_Sales_Manager"),
            f.col("pr4.delivery_method").alias("delivery_method"),
            f.col("lmp.locationid").alias("sem_location_id"),
            (f.when(f.col("billto_customer_country").isNull(),
                    (f.when(f.col("customer_country") == 'AL', 'Albania')
                     .when(f.col("customer_country") == 'Brit.Virgin Is.', 'BRITISH VIRGIN ISLANDS')
                     .when(f.col("customer_country") == 'Brunei Daruss.', 'BRUNEI')
                     .when(f.col("customer_country") == 'CZECH', 'Czech Republic')
                     .when(f.col("customer_country") == 'Czechia', 'Czech Republic')
                     .when(f.col("customer_country") == 'French Polynes.', 'French Polynesia')
                     .when(f.col("customer_country") == 'IT', 'Italy')
                     .when(f.col("customer_country") == 'KAZAKSTAN', 'Kazakhstan')
                     .when(f.col("customer_country") == 'LEBANON AIR BP', 'Lebanon')
                     .when(f.col("customer_country") == 'Republic Of Korea', 'South Korea')
                     .when(f.col("customer_country") == 'REPUBLIC OF KOREA (SOUTH)', 'South Korea')
                     .when(f.col("customer_country") == 'RO', 'Romania')
                     .when(f.col("customer_country") == 'Russian Federation', 'RUSSIA')
                     .when(f.col("customer_country") == 'Utd.Arab Emir.', 'United Arab Emirates')
                     .when(f.col("customer_country") == 'United States', 'USA')
                     .when(f.col("customer_country") == 'Usa', 'USA')
                     .otherwise(f.col("customer_country"))))
                .otherwise(
                (f.when(f.col("billto_customer_country") == 'AL', 'Albania')
                 .when(f.col("billto_customer_country") == 'Brit.Virgin Is.', 'BRITISH VIRGIN ISLANDS')
                 .when(f.col("billto_customer_country") == 'Brunei Daruss.', 'BRUNEI')
                 .when(f.col("billto_customer_country") == 'CZECH', 'Czech Republic')
                 .when(f.col("billto_customer_country") == 'Czechia', 'Czech Republic')
                 .when(f.col("billto_customer_country") == 'French Polynes.', 'French Polynesia')
                 .when(f.col("billto_customer_country") == 'IT', 'Italy')
                 .when(f.col("billto_customer_country") == 'KAZAKSTAN', 'Kazakhstan')
                 .when(f.col("billto_customer_country") == 'LEBANON AIR BP', 'Lebanon')
                 .when(f.col("billto_customer_country") == 'Republic Of Korea', 'South Korea')
                 .when(f.col("billto_customer_country") == 'REPUBLIC OF KOREA (SOUTH)', 'South Korea')
                 .when(f.col("billto_customer_country") == 'RO', 'Romania')
                 .when(f.col("billto_customer_country") == 'Russian Federation', 'RUSSIA')
                 .when(f.col("billto_customer_country") == 'Utd.Arab Emir.', 'United Arab Emirates')
                 .when(f.col("billto_customer_country") == 'United States', 'USA')
                 .when(f.col("billto_customer_country") == 'Usa', 'USA')
                 .otherwise(f.col("billto_customer_country"))))).alias("billto_customer_country"),
            (f.when(f.col("billto_grn_header").isNull(), f.col("grn_header"))
             .otherwise(f.col("billto_grn_header"))).alias("billto_grn_header"),
            (f.when(f.col("billto_customer_account_name").isNull(), f.col("customer_account_name"))
             .otherwise(f.col("billto_customer_account_name"))).alias("billto_customer_account_name"),
            (f.when(f.col("billto_grn").isNull(), f.col("pr4.grn"))
             .otherwise(f.col("billto_grn"))).alias("billto_grn"),
            f.col("grn_header").alias("billto_cc_grn"),
            (f.when(f.col("billto_account_manager").isNull(), f.col("account_manager"))
             .otherwise(f.col("billto_account_manager"))).alias("billto_account_manager"),
            (f.when(f.col("billto_sector").isNull(), f.col("sector"))
             .otherwise(f.col("billto_sector"))).alias("billto_sector"),
            (f.when(f.col("payer_customer_country").isNull(),
                    (f.when(f.col("customer_country") == 'AL', 'Albania')
                     .when(f.col("customer_country") == 'Brit.Virgin Is.', 'BRITISH VIRGIN ISLANDS')
                     .when(f.col("customer_country") == 'Brunei Daruss.', 'BRUNEI')
                     .when(f.col("customer_country") == 'CZECH', 'Czech Republic')
                     .when(f.col("customer_country") == 'Czechia', 'Czech Republic')
                     .when(f.col("customer_country") == 'French Polynes.', 'French Polynesia')
                     .when(f.col("customer_country") == 'IT', 'Italy')
                     .when(f.col("customer_country") == 'KAZAKSTAN', 'Kazakhstan')
                     .when(f.col("customer_country") == 'LEBANON AIR BP', 'Lebanon')
                     .when(f.col("customer_country") == 'Republic Of Korea', 'South Korea')
                     .when(f.col("customer_country") == 'REPUBLIC OF KOREA (SOUTH)', 'South Korea')
                     .when(f.col("customer_country") == 'RO', 'Romania')
                     .when(f.col("customer_country") == 'Russian Federation', 'RUSSIA')
                     .when(f.col("customer_country") == 'Utd.Arab Emir.', 'United Arab Emirates')
                     .when(f.col("customer_country") == 'United States', 'USA')
                     .when(f.col("customer_country") == 'Usa', 'USA')
                     .otherwise(f.col("customer_country"))))
                .otherwise(
                f.when(f.col("payer_customer_country") == 'AL', 'Albania')
                    .when(f.col("payer_customer_country") == 'Brit.Virgin Is.', 'BRITISH VIRGIN ISLANDS')
                    .when(f.col("payer_customer_country") == 'Brunei Daruss.', 'BRUNEI')
                    .when(f.col("payer_customer_country") == 'CZECH', 'Czech Republic')
                    .when(f.col("payer_customer_country") == 'Czechia', 'Czech Republic')
                    .when(f.col("payer_customer_country") == 'French Polynes.', 'French Polynesia')
                    .when(f.col("payer_customer_country") == 'IT', 'Italy')
                    .when(f.col("payer_customer_country") == 'KAZAKSTAN', 'Kazakhstan')
                    .when(f.col("payer_customer_country") == 'LEBANON AIR BP', 'Lebanon')
                    .when(f.col("payer_customer_country") == 'Republic Of Korea', 'South Korea')
                    .when(f.col("payer_customer_country") == 'REPUBLIC OF KOREA (SOUTH)', 'South Korea')
                    .when(f.col("payer_customer_country") == 'RO', 'Romania')
                    .when(f.col("payer_customer_country") == 'Russian Federation', 'RUSSIA')
                    .when(f.col("payer_customer_country") == 'Utd.Arab Emir.', 'United Arab Emirates')
                    .when(f.col("payer_customer_country") == 'United States', 'USA')
                    .when(f.col("payer_customer_country") == 'Usa', 'USA')
                    .otherwise(f.col("payer_customer_country")))).alias("payer_customer_country"),
            (f.when(f.col("payer_grn_header").isNull(), f.col("grn_header"))
             .otherwise(f.col("payer_grn_header"))).alias("payer_grn_header"),
            (f.when(f.col("payer_customer_account_name").isNull(), f.col("customer_account_name"))
             .otherwise(f.col("payer_customer_account_name"))).alias("payer_customer_account_name"),
            (f.when(f.col("payer_grn").isNull(), f.col("pr4.grn"))
             .otherwise(f.col("payer_grn"))).alias("payer_grn"),
            f.col("pr4.grn").alias("payer_cc_grn"),
            (f.when(f.col("payer_account_manager").isNull(), f.col("account_manager"))
             .otherwise(f.col("payer_account_manager"))).alias("payer_account_manager"),
            (f.when(f.col("payer_sector").isNull(), f.col("sector"))
             .otherwise(f.col("payer_sector"))).alias("payer_sector"),
            (f.when(f.col("trx_billto_key").isNull(), f.col("trx_cust_key"))
             .otherwise(f.col("trx_billto_key"))).alias("trx_billto_key"),
            (f.when(f.col("dim_billto_key").isNull(), f.col("dim_cust_key"))
             .otherwise(f.col("dim_billto_key"))).alias("dim_billto_key"),
            (f.when(f.col("trx_payer_key").isNull(), f.col("trx_cust_key"))
             .otherwise(f.col("trx_payer_key"))).alias("trx_payer_key"),
            (f.when(f.col("dim_payer_key").isNull(), f.col("dim_cust_key"))
             .otherwise(f.col("dim_payer_key"))).alias("dim_payer_key"))

        df_sun_union = sun_summary_df.alias("sun").join(group_carrier_df.alias("sfdc"),
                                                        f.col("sun.grn") == f.col("sfdc.grn"), "left") \
                                     .join(sun_location_df, (f.split(sun_summary_df.trx_loc_key, "_")[0]
                                           == sun_location_df.sun_mapping) &
                                           (f.split(sun_summary_df.trx_loc_key, "_")[1]
                                            == sun_location_df.iso_code2), "left"
                                           ) \
            .select(f.col("sun.pricing_date").alias("pricing_date"),
                    f.col("sun.billing_date").alias("billing_date"),
                    f.col("sun.delivery_date").alias("delivery_date"),
                    (f.when(f.col("sun.customer_country") == 'AL', 'Albania')
                     .when(f.col("sun.customer_country") == 'Brit.Virgin Is.', 'BRITISH VIRGIN ISLANDS')
                     .when(f.col("sun.customer_country") == 'Brunei Daruss.', 'BRUNEI')
                     .when(f.col("sun.customer_country") == 'CZECH', 'Czech Republic')
                     .when(f.col("sun.customer_country") == 'Czechia', 'Czech Republic')
                     .when(f.col("sun.customer_country") == 'French Polynes.', 'French Polynesia')
                     .when(f.col("sun.customer_country") == 'IT', 'Italy')
                     .when(f.col("sun.customer_country") == 'KAZAKSTAN', 'Kazakhstan')
                     .when(f.col("sun.customer_country") == 'LEBANON AIR BP', 'Lebanon')
                     .when(f.col("sun.customer_country") == 'Republic Of Korea', 'South Korea')
                     .when(f.col("sun.customer_country") == 'REPUBLIC OF KOREA (SOUTH)', 'South Korea')
                     .when(f.col("sun.customer_country") == 'RO', 'Romania')
                     .when(f.col("sun.customer_country") == 'Russian Federation', 'RUSSIA')
                     .when(f.col("sun.customer_country") == 'Utd.Arab Emir.', 'United Arab Emirates')
                     .when(f.col("sun.customer_country") == 'United States', 'USA')
                     .when(f.col("sun.customer_country") == 'Usa', 'USA')
                     .otherwise(f.col("sun.customer_country"))).alias("customer_country"),
                    f.col("sun.grn_header").alias("AS grn_header"),
                    f.col("sun.customer_account_name").alias("customer_account_name"),
                    f.col("sun.grn_header").alias("cc_grn"),
                    f.col("sun.grn").alias("grn"),
                    f.col("sun.account_manager").alias("account_manager"),
                    f.col("sun.sector").alias("sector"),
                    f.lit('NA').alias("customer_segment"),
                    f.col("sun.source_system").alias("source_system"),
                    f.col("sun.sales_organisation").alias("sales_organisation"),
                    f.col("sun.sales_document").alias("sales_document"),
                    f.col("sun.delivery_number").alias("delivery_number"),
                    f.col("sun.material_number").alias("material_number"),
                    f.col("sun.material_description").alias("material_description"),
                    f.col("sun.local_material_description").alias("local_material_description"),
                    f.col("sun.billing_document").alias("billing_document"),
                    f.col("sun.billing_item").alias("billing_item"),
                    f.col("sun.local_currency").alias("local_currency"),
                    (f.coalesce(f.col("sun.qty_in_m3"), f.lit(0))).alias("qty_in_m3"),
                    (f.coalesce(f.col("sun.qty_in_usg"), f.lit(0))).alias("qty_in_usg"),
                    (f.coalesce(f.col("sun.qty_in_litres"), f.lit(0))).alias("qty_in_litres"),
                    (f.coalesce(f.col("sun.net_value"), f.lit(0))).alias("net_value"),
                    f.col("sun.document_currency").alias("document_currency"),
                    f.col("sun.flight_number").alias("flight_number"),
                    f.col("sun.aircraft_registration").alias("aircraft_registration"),
                    f.col("sun.cost_element_key").alias("cost_element_key"),
                    f.col("sun.trx_cust_key").alias("TRX_CUST_KEY"),
                    f.col("sun.dim_cust_key").alias("DIM_CUST_KEY"),
                    f.col("sun.trx_loc_key").alias("TRX_LOC_KEY"),
                    f.col("sun.trx_pro_key").alias("TRX_PRO_KEY"),
                    f.col("sun.dim_pro_key").alias("DIM_PRO_KEY"),
                    f.lit("N").alias("intercompany_flag"),
                    f.col("sun.payer").alias("payer"),
                    f.col("sun.soldto_party").alias("soldto_party"),
                    f.col("costing_country").alias("costing_country"),
                    f.col("sun.last_modified_date").alias("last_modified_date"),
                    f.col("sfdc.Market_Space").alias("Market_Space"),
                    f.col("sfdc.Carrier").alias("Carrier"),
                    f.col("sfdc.Account_Holder").alias("SF_Account_Manager"),
                    f.col("sfdc.Group").alias("Group"),
                    f.col("sfdc.Customer_Type").alias("Customer_Type"),
                    f.col("sfdc.Customer_Segment").alias("Marketing_Segment"),
                    f.col("sfdc.RSM").alias("Regional_Sales_Manager"),
                    f.col("sun.delivery_method").alias("delivery_method"),
                    f.col("location_id").alias("sem_location_id"),
                    (f.when(f.col("billto_customer_country").isNull(),
                            (f.when(f.col("customer_country") == 'AL', 'Albania')
                             .when(f.col("customer_country") == 'Brit.Virgin Is.', 'BRITISH VIRGIN ISLANDS')
                             .when(f.col("customer_country") == 'Brunei Daruss.', 'BRUNEI')
                             .when(f.col("customer_country") == 'CZECH', 'Czech Republic')
                             .when(f.col("customer_country") == 'Czechia', 'Czech Republic')
                             .when(f.col("customer_country") == 'French Polynes.', 'French Polynesia')
                             .when(f.col("customer_country") == 'IT', 'Italy')
                             .when(f.col("customer_country") == 'KAZAKSTAN', 'Kazakhstan')
                             .when(f.col("customer_country") == 'LEBANON AIR BP', 'Lebanon')
                             .when(f.col("customer_country") == 'Republic Of Korea', 'South Korea')
                             .when(f.col("customer_country") == 'REPUBLIC OF KOREA (SOUTH)', 'South Korea')
                             .when(f.col("customer_country") == 'RO', 'Romania')
                             .when(f.col("customer_country") == 'Russian Federation', 'RUSSIA')
                             .when(f.col("customer_country") == 'Utd.Arab Emir.', 'United Arab Emirates')
                             .when(f.col("customer_country") == 'United States', 'USA')
                             .when(f.col("customer_country") == 'Usa', 'USA')
                             .otherwise(f.col("customer_country"))))
                        .otherwise(
                        (f.when(f.col("billto_customer_country") == 'AL', 'Albania')
                         .when(f.col("billto_customer_country") == 'Brit.Virgin Is.', 'BRITISH VIRGIN ISLANDS')
                         .when(f.col("billto_customer_country") == 'Brunei Daruss.', 'BRUNEI')
                         .when(f.col("billto_customer_country") == 'CZECH', 'Czech Republic')
                         .when(f.col("billto_customer_country") == 'Czechia', 'Czech Republic')
                         .when(f.col("billto_customer_country") == 'French Polynes.', 'French Polynesia')
                         .when(f.col("billto_customer_country") == 'IT', 'Italy')
                         .when(f.col("billto_customer_country") == 'KAZAKSTAN', 'Kazakhstan')
                         .when(f.col("billto_customer_country") == 'LEBANON AIR BP', 'Lebanon')
                         .when(f.col("billto_customer_country") == 'Republic Of Korea', 'South Korea')
                         .when(f.col("billto_customer_country") == 'REPUBLIC OF KOREA (SOUTH)', 'South Korea')
                         .when(f.col("billto_customer_country") == 'RO', 'Romania')
                         .when(f.col("billto_customer_country") == 'Russian Federation', 'RUSSIA')
                         .when(f.col("billto_customer_country") == 'Utd.Arab Emir.', 'United Arab Emirates')
                         .when(f.col("billto_customer_country") == 'United States', 'USA')
                         .when(f.col("billto_customer_country") == 'Usa', 'USA')
                         .otherwise(f.col("billto_customer_country"))))).alias("billto_customer_country"),
                    (f.when(f.col("billto_grn_header").isNull(), f.col("grn_header"))
                     .otherwise(f.col("billto_grn_header"))).alias("billto_grn_header"),
                    (f.when(f.col("billto_customer_account_name").isNull(), f.col("customer_account_name"))
                     .otherwise(f.col("billto_customer_account_name"))).alias("billto_customer_account_name"),
                    (f.when(f.col("billto_grn").isNull(), f.col("sun.grn"))
                     .otherwise(f.col("billto_grn"))).alias("billto_grn"),
                    f.col("grn_header").alias("billto_cc_grn"),
                    (f.when(f.col("billto_account_manager").isNull(), f.col("account_manager"))
                     .otherwise(f.col("billto_account_manager"))).alias("billto_account_manager"),
                    (f.when(f.col("billto_sector").isNull(), f.col("sector"))
                     .otherwise(f.col("billto_sector"))).alias("billto_sector"),
                    (f.when(f.col("payer_customer_country").isNull(),
                            (f.when(f.col("customer_country") == 'AL', 'Albania')
                             .when(f.col("customer_country") == 'Brit.Virgin Is.', 'BRITISH VIRGIN ISLANDS')
                             .when(f.col("customer_country") == 'Brunei Daruss.', 'BRUNEI')
                             .when(f.col("customer_country") == 'CZECH', 'Czech Republic')
                             .when(f.col("customer_country") == 'Czechia', 'Czech Republic')
                             .when(f.col("customer_country") == 'French Polynes.', 'French Polynesia')
                             .when(f.col("customer_country") == 'IT', 'Italy')
                             .when(f.col("customer_country") == 'KAZAKSTAN', 'Kazakhstan')
                             .when(f.col("customer_country") == 'LEBANON AIR BP', 'Lebanon')
                             .when(f.col("customer_country") == 'Republic Of Korea', 'South Korea')
                             .when(f.col("customer_country") == 'REPUBLIC OF KOREA (SOUTH)', 'South Korea')
                             .when(f.col("customer_country") == 'RO', 'Romania')
                             .when(f.col("customer_country") == 'Russian Federation', 'RUSSIA')
                             .when(f.col("customer_country") == 'Utd.Arab Emir.', 'United Arab Emirates')
                             .when(f.col("customer_country") == 'United States', 'USA')
                             .when(f.col("customer_country") == 'Usa', 'USA')
                             .otherwise(f.col("customer_country"))))
                        .otherwise(
                        f.when(f.col("payer_customer_country") == 'AL', 'Albania')
                            .when(f.col("payer_customer_country") == 'Brit.Virgin Is.', 'BRITISH VIRGIN ISLANDS')
                            .when(f.col("payer_customer_country") == 'Brunei Daruss.', 'BRUNEI')
                            .when(f.col("payer_customer_country") == 'CZECH', 'Czech Republic')
                            .when(f.col("payer_customer_country") == 'Czechia', 'Czech Republic')
                            .when(f.col("payer_customer_country") == 'French Polynes.', 'French Polynesia')
                            .when(f.col("payer_customer_country") == 'IT', 'Italy')
                            .when(f.col("payer_customer_country") == 'KAZAKSTAN', 'Kazakhstan')
                            .when(f.col("payer_customer_country") == 'LEBANON AIR BP', 'Lebanon')
                            .when(f.col("payer_customer_country") == 'Republic Of Korea', 'South Korea')
                            .when(f.col("payer_customer_country") == 'REPUBLIC OF KOREA (SOUTH)', 'South Korea')
                            .when(f.col("payer_customer_country") == 'RO', 'Romania')
                            .when(f.col("payer_customer_country") == 'Russian Federation', 'RUSSIA')
                            .when(f.col("payer_customer_country") == 'Utd.Arab Emir.', 'United Arab Emirates')
                            .when(f.col("payer_customer_country") == 'United States', 'USA')
                            .when(f.col("payer_customer_country") == 'Usa', 'USA')
                            .otherwise(f.col("payer_customer_country")))).alias("payer_customer_country"),
                    (f.when(f.col("payer_grn_header").isNull(), f.col("grn_header"))
                     .otherwise(f.col("payer_grn_header"))).alias("payer_grn_header"),
                    (f.when(f.col("payer_customer_account_name").isNull(), f.col("customer_account_name"))
                     .otherwise(f.col("payer_customer_account_name"))).alias("payer_customer_account_name"),
                    (f.when(f.col("payer_grn").isNull(), f.col("sun.grn"))
                     .otherwise(f.col("payer_grn"))).alias("payer_grn"),
                    f.col("sun.grn").alias("payer_cc_grn"),
                    (f.when(f.col("payer_account_manager").isNull(), f.col("account_manager"))
                     .otherwise(f.col("payer_account_manager"))).alias("payer_account_manager"),
                    (f.when(f.col("payer_sector").isNull(), f.col("sector"))
                     .otherwise(f.col("payer_sector"))).alias("payer_sector"),
                    (f.when(f.col("trx_billto_key").isNull(), f.col("trx_cust_key"))
                     .otherwise(f.col("trx_billto_key"))).alias("trx_billto_key"),
                    (f.when(f.col("dim_billto_key").isNull(), f.col("dim_cust_key"))
                     .otherwise(f.col("dim_billto_key"))).alias("dim_billto_key"),
                    (f.when(f.col("trx_payer_key").isNull(), f.col("trx_cust_key"))
                     .otherwise(f.col("trx_payer_key"))).alias("trx_payer_key"),
                    (f.when(f.col("dim_payer_key").isNull(), f.col("dim_cust_key"))
                     .otherwise(f.col("dim_payer_key"))).alias("dim_payer_key")
                    )

        df_pre_union = pre_summary_df.join(group_carrier_df, pre_summary_df.grn == group_carrier_df.grn, 'left') \
                                     .join(pre_location_df, pre_summary_df.trx_loc_key == pre_location_df.pre_mapping,
                                           "left") \
            .select(
            pre_summary_df.pricing_date.alias('pricing_date'), pre_summary_df.billing_date.alias('billing_date'),
            pre_summary_df.delivery_date.alias('delivery_date'),
            f.when(pre_summary_df.customer_country == f.lit('AL'), f.lit('Albania'))
                .when(pre_summary_df.customer_country == f.lit('Brit.Virgin Is.'), f.lit('BRITISH VIRGIN ISLANDS'))
                .when(pre_summary_df.customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                .when(pre_summary_df.customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                .when(pre_summary_df.customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                .when(pre_summary_df.customer_country == f.lit('French Polynes.'), f.lit('French Polynesia'))
                .when(pre_summary_df.customer_country == f.lit('IT'), f.lit('Italy'))
                .when(pre_summary_df.customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                .when(pre_summary_df.customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                .when(pre_summary_df.customer_country == f.lit('Republic Of Korea'), f.lit('South Korea'))
                .when(pre_summary_df.customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'), f.lit('South Korea'))
                .when(pre_summary_df.customer_country == f.lit('RO'), f.lit('Romania'))
                .when(pre_summary_df.customer_country == f.lit('Russian Federation'), f.lit('RUSSIA'))
                .when(pre_summary_df.customer_country == f.lit('Utd.Arab Emir.'), f.lit('United Arab Emirates'))
                .when(pre_summary_df.customer_country == f.lit('United States'), f.lit('USA'))
                .when(pre_summary_df.customer_country == f.lit('Usa'), f.lit('USA'))
                .otherwise(pre_summary_df.customer_country).alias('customer_country'),
            pre_summary_df.grn_header.alias('grn_header'),
            pre_summary_df.customer_account_name.alias('customer_account_name'),
            pre_summary_df.cc_grn.alias('cc_grn'), pre_summary_df.grn.alias('grn'),
            pre_summary_df.account_manager.alias('account_manager'), pre_summary_df.sector.alias('sector'),
            pre_summary_df.customer_segment.alias('customer_segment'),
            pre_summary_df.source_system.alias('source_system'),
            pre_summary_df.sales_organisation.alias('sales_organisation'),
            pre_summary_df.sales_document.alias('sales_document'),
            pre_summary_df.delivery_number.alias('delivery_number'),
            pre_summary_df.material_number.alias('material_number'),
            pre_summary_df.material_description.alias('material_description'),
            pre_summary_df.local_material_description.alias('local_material_description'),
            pre_summary_df.billing_document.alias('billing_document'),
            pre_summary_df.billing_item.alias('billing_item'),
            pre_summary_df.local_currency.alias('local_currency'),
            f.coalesce(pre_summary_df.qty_in_m3, f.lit(0)).alias('qty_in_m3'),
            f.coalesce(pre_summary_df.qty_in_ugl, f.lit(0)).alias('qty_in_usg'),
            f.coalesce(pre_summary_df.qty_in_litres, f.lit(0)).alias('qty_in_litres'),
            f.coalesce(pre_summary_df.net_value, f.lit(0)).alias('net_value'),
            pre_summary_df.document_currency.alias('document_currency'),
            pre_summary_df.flight_number.alias('flight_number'),
            pre_summary_df.aircraft_registration.alias('aircraft_registration'),
            pre_summary_df.cost_element_key.alias('cost_element_key'),
            pre_summary_df.trx_cust_key.alias('trx_cust_key'),
            pre_summary_df.dim_cust_key.alias('dim_cust_key'),
            pre_summary_df.trx_loc_key.alias('trx_loc_key'),
            pre_summary_df.trx_pro_key.alias('trx_pro_key'),
            pre_summary_df.dim_pro_key.alias('dim_pro_key'),
            f.when(pre_summary_df.customer_account_name.isin(
                f.lit('BP Aviation A/S'), f.lit('BP AVIATION A/S'), f.lit('BP INTERNATIONAL LIMITED UPSTREAM HO'),
                f.lit('BP PRODUCTS NORTH AMERICA INC'), f.lit('BP Products North America Inc')) |
                   (f.substring(pre_summary_df.customer_account_name, 1, 12).isin(f.lit('BP EUROPA SE'),
                                                                                  f.lit('BP Europa SE'))) |
                   (f.substring(pre_summary_df.customer_account_name, 1, 14) == f.lit('AIR BP LIMITED')) |
                   (f.substring(pre_summary_df.customer_account_name, 1, 13).isin(f.lit('BP OIL ESPANA'),
                                                                                  f.lit('BP Oil Espana'))) |
                   (f.substring(pre_summary_df.customer_account_name, 1, 16).isin(f.lit('Air BP Sweden AB'),
                                                                                  f.lit('AIR BP SWEDEN AB'))) |
                   (f.substring(pre_summary_df.customer_account_name, 1, 9).isin(f.lit('BP France'),
                                                                                 f.lit('BP FRANCE'))) |
                   pre_summary_df.soldto_party.isin('0010023709', '0012154140', '0012164165', '0010023732',
                                                    '0010023650',
                                                    '0010012647', '0010023743', '0030099390', '0012244440'),
                   f.lit('Y')).otherwise('N').alias('intercompany_flag'),
            pre_summary_df.payer.alias('payer'), pre_summary_df.soldto_party.alias('soldto_party'),
            f.lit('NULL').alias('costing_country'),
            pre_summary_df.last_modified_date.alias('last_modified_date'),
            group_carrier_df.market_space.alias('Market_Space'), group_carrier_df.carrier.alias('carrier'),
            group_carrier_df.account_holder.alias('SF_Account_Manager'), group_carrier_df.group.alias('group'),
            group_carrier_df.customer_type.alias('Customer_Type'),
            group_carrier_df.customer_segment.alias('Marketing_Segment'),
            group_carrier_df.rsm.alias('Regional_Sales_Manager'),
            pre_summary_df.delivery_method.alias('delivery_method'),
            pre_location_df.location_id.alias("sem_location_id"),
            (f.when(pre_summary_df.billto_customer_country.isNull(),
                    f.when(pre_summary_df.customer_country == f.lit('AL'), f.lit('Albania'))
                    .when(pre_summary_df.customer_country == f.lit('Brit.Virgin Is.'), f.lit('BRITISH VIRGIN ISLANDS'))
                    .when(pre_summary_df.customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                    .when(pre_summary_df.customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                    .when(pre_summary_df.customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                    .when(pre_summary_df.customer_country == f.lit('French Polynes.'), f.lit('French Polynesia'))
                    .when(pre_summary_df.customer_country == f.lit('IT'), f.lit('Italy'))
                    .when(pre_summary_df.customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                    .when(pre_summary_df.customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                    .when(pre_summary_df.customer_country == f.lit('Republic Of Korea'), f.lit('South Korea'))
                    .when(pre_summary_df.customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'), f.lit('South Korea'))
                    .when(pre_summary_df.customer_country == f.lit('RO'), f.lit('Romania'))
                    .when(pre_summary_df.customer_country == f.lit('Russian Federation'), f.lit('RUSSIA'))
                    .when(pre_summary_df.customer_country == f.lit('Utd.Arab Emir.'), f.lit('United Arab Emirates'))
                    .when(pre_summary_df.customer_country == f.lit('United States'), f.lit('USA'))
                    .when(pre_summary_df.customer_country == f.lit('Usa'), f.lit('USA'))
                    .otherwise(pre_summary_df.customer_country))
             .otherwise(f.when(pre_summary_df.billto_customer_country == f.lit('AL'), f.lit('Albania'))
                        .when(pre_summary_df.billto_customer_country == f.lit('Brit.Virgin Is.'),
                              f.lit('BRITISH VIRGIN ISLANDS'))
                        .when(pre_summary_df.billto_customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                        .when(pre_summary_df.billto_customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                        .when(pre_summary_df.billto_customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                        .when(pre_summary_df.billto_customer_country == f.lit('French Polynes.'),
                              f.lit('French Polynesia'))
                        .when(pre_summary_df.billto_customer_country == f.lit('IT'), f.lit('Italy'))
                        .when(pre_summary_df.billto_customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                        .when(pre_summary_df.billto_customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                        .when(pre_summary_df.billto_customer_country == f.lit('Republic Of Korea'),
                              f.lit('South Korea'))
                        .when(pre_summary_df.billto_customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'),
                              f.lit('South Korea'))
                        .when(pre_summary_df.billto_customer_country == f.lit('RO'), f.lit('Romania'))
                        .when(pre_summary_df.billto_customer_country == f.lit('Russian Federation'),
                              f.lit('RUSSIA'))
                        .when(pre_summary_df.billto_customer_country == f.lit('Utd.Arab Emir.'),
                              f.lit('United Arab Emirates'))
                        .when(pre_summary_df.billto_customer_country == f.lit('United States'), f.lit('USA'))
                        .when(pre_summary_df.billto_customer_country == f.lit('Usa'), f.lit('USA'))
                        .otherwise(pre_summary_df.billto_customer_country))).alias("billto_customer_country"),
            (f.when(pre_summary_df.billto_grn_header.isNull(), pre_summary_df.grn_header)
             .otherwise(pre_summary_df.billto_grn_header)).alias("billto_grn_header"),
            (f.when(pre_summary_df.billto_customer_account_name.isNull(), pre_summary_df.customer_account_name)
             .otherwise(pre_summary_df.billto_customer_account_name)).alias("billto_customer_account_name"),
            (f.when(pre_summary_df.billto_grn.isNull(), pre_summary_df.grn)
             .otherwise(pre_summary_df.billto_grn)).alias("billto_grn"),
            (f.when(pre_summary_df.billto_cc_grn.isNull(), pre_summary_df.cc_grn)
             .otherwise(pre_summary_df.billto_cc_grn)).alias("billto_cc_grn"),
            (f.when(pre_summary_df.billto_account_manager.isNull(), pre_summary_df.account_manager)
             .otherwise(pre_summary_df.billto_account_manager)).alias("billto_account_manager"),
            (f.when(pre_summary_df.billto_sector.isNull(), pre_summary_df.sector)
             .otherwise(pre_summary_df.billto_sector)).alias("billto_sector"),
            (f.when(pre_summary_df.payer_customer_country.isNull(),
                    f.when(pre_summary_df.customer_country == f.lit('AL'), f.lit('Albania'))
                    .when(pre_summary_df.customer_country == f.lit('Brit.Virgin Is.'), f.lit('BRITISH VIRGIN ISLANDS'))
                    .when(pre_summary_df.customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                    .when(pre_summary_df.customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                    .when(pre_summary_df.customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                    .when(pre_summary_df.customer_country == f.lit('French Polynes.'), f.lit('French Polynesia'))
                    .when(pre_summary_df.customer_country == f.lit('IT'), f.lit('Italy'))
                    .when(pre_summary_df.customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                    .when(pre_summary_df.customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                    .when(pre_summary_df.customer_country == f.lit('Republic Of Korea'), f.lit('South Korea'))
                    .when(pre_summary_df.customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'), f.lit('South Korea'))
                    .when(pre_summary_df.customer_country == f.lit('RO'), f.lit('Romania'))
                    .when(pre_summary_df.customer_country == f.lit('Russian Federation'), f.lit('RUSSIA'))
                    .when(pre_summary_df.customer_country == f.lit('Utd.Arab Emir.'), f.lit('United Arab Emirates'))
                    .when(pre_summary_df.customer_country == f.lit('United States'), f.lit('USA'))
                    .when(pre_summary_df.customer_country == f.lit('Usa'), f.lit('USA'))
                    .otherwise(pre_summary_df.customer_country))
             .otherwise(f.when(pre_summary_df.payer_customer_country == f.lit('AL'), f.lit('Albania'))
                        .when(pre_summary_df.payer_customer_country == f.lit('Brit.Virgin Is.'),
                              f.lit('BRITISH VIRGIN ISLANDS'))
                        .when(pre_summary_df.payer_customer_country == f.lit('Brunei Daruss.'), f.lit('BRUNEI'))
                        .when(pre_summary_df.payer_customer_country == f.lit('CZECH'), f.lit('Czech Republic'))
                        .when(pre_summary_df.payer_customer_country == f.lit('Czechia'), f.lit('Czech Republic'))
                        .when(pre_summary_df.payer_customer_country == f.lit('French Polynes.'),
                              f.lit('French Polynesia'))
                        .when(pre_summary_df.payer_customer_country == f.lit('IT'), f.lit('Italy'))
                        .when(pre_summary_df.payer_customer_country == f.lit('KAZAKSTAN'), f.lit('Kazakhstan'))
                        .when(pre_summary_df.payer_customer_country == f.lit('LEBANON AIR BP'), f.lit('Lebanon'))
                        .when(pre_summary_df.payer_customer_country == f.lit('Republic Of Korea'),
                              f.lit('South Korea'))
                        .when(pre_summary_df.payer_customer_country == f.lit('REPUBLIC OF KOREA (SOUTH)'),
                              f.lit('South Korea'))
                        .when(pre_summary_df.payer_customer_country == f.lit('RO'), f.lit('Romania'))
                        .when(pre_summary_df.payer_customer_country == f.lit('Russian Federation'),
                              f.lit('RUSSIA'))
                        .when(pre_summary_df.payer_customer_country == f.lit('Utd.Arab Emir.'),
                              f.lit('United Arab Emirates'))
                        .when(pre_summary_df.payer_customer_country == f.lit('United States'), f.lit('USA'))
                        .when(pre_summary_df.payer_customer_country == f.lit('Usa'), f.lit('USA'))
                        .otherwise(pre_summary_df.payer_customer_country))).alias("payer_customer_country"),
            (f.when(pre_summary_df.payer_grn_header.isNull(), pre_summary_df.grn_header)
             .otherwise(pre_summary_df.payer_grn_header)).alias("payer_grn_header"),
            (f.when(pre_summary_df.payer_customer_account_name.isNull(), pre_summary_df.customer_account_name)
             .otherwise(pre_summary_df.payer_customer_account_name)).alias("payer_customer_account_name"),
            (f.when(pre_summary_df.payer_grn.isNull(), pre_summary_df.grn)
             .otherwise(pre_summary_df.payer_grn)).alias("payer_grn"),
            (f.when(pre_summary_df.payer_cc_grn.isNull(), pre_summary_df.grn)
             .otherwise(pre_summary_df.payer_cc_grn)).alias("payer_cc_grn"),
            (f.when(pre_summary_df.payer_account_manager.isNull(), pre_summary_df.account_manager)
             .otherwise(pre_summary_df.payer_account_manager)).alias("payer_account_manager"),
            (f.when(pre_summary_df.payer_sector.isNull(), pre_summary_df.sector)
             .otherwise(pre_summary_df.payer_sector)).alias("payer_sector"),
            (f.when(pre_summary_df.trx_billto_key.isNull(), pre_summary_df.trx_cust_key)
             .otherwise(pre_summary_df.trx_billto_key)).alias("trx_billto_key"),
            (f.when(pre_summary_df.dim_billto_key.isNull(), pre_summary_df.dim_cust_key)
             .otherwise(pre_summary_df.dim_billto_key)).alias("dim_billto_key"),
            (f.when(pre_summary_df.trx_payer_key.isNull(), pre_summary_df.trx_cust_key)
             .otherwise(pre_summary_df.trx_payer_key)).alias("trx_payer_key"),
            (f.when(pre_summary_df.dim_payer_key.isNull(), pre_summary_df.dim_cust_key)
             .otherwise(pre_summary_df.dim_payer_key)).alias("dim_payer_key")
        )

        dfs = [df_isp_union, df_prot_union, df_pr4_union, df_sun_union, df_pre_union]
        df_tfx_result = reduce(DataFrame.unionAll, dfs)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpL51ETL()
    trl.execute()
