# ================================Revision History============================================
# #
#  Change Version,  Change Author   , Change Date , Change Component, Change Description
#  0.1              Liz Harvey        06-May-2021   
#  0.4              Hasan Chaudhary   31-May-2021   PRE
# ============================================================================================
# Description :- The aim of the code is to generate l51_costelement into conform zone
# Author :-  Liz Harvey
# Date :- 06-May-2021
# Version :-  0.1
# AWS component used :- S3 and Glue
# ===========================================================================================


import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame



class LcpL51ETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l5_prot_costelement', 'l5_pr4_costelement', 'l5_isp_costelement', 'l5_pre_costelement']
        self.report_file = "l51_costelement"

        # print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and {}.{}* write it to {}'.format(self.source_database,
        #                                                                         self.input_table_list[0],
        #                                                                         self.netapp_database,
        #                                                                         self.input_table_list[1],
        #                                                                         self.destination_bucket))

    def execute(self):
        # generate input table list
        source_database = self.source_database
        input_table_list = self.input_table_list
        # print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        df_input_table_A = self._get_table(source_database, input_table_list[0]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[0],
        #                                               df_input_table_A.count()))

        df_input_table_B = self._get_table(source_database, input_table_list[1]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[1],
        #                                               df_input_table_B.count()))
        
        df_input_table_C = self._get_table(source_database, input_table_list[2]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[2],
        #                                               df_input_table_C.count()))

        df_input_table_D = self._get_table(source_database, input_table_list[3]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[3],
        #                                               df_input_table_D.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_A, df_input_table_B, df_input_table_C, df_input_table_D)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)


    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table_A, df_input_table_B, df_input_table_C, df_input_table_D):
        df_prot_union = df_input_table_A.select(
                            f.lit("BRA").alias("source_system"),
                            f.col("l5_hierarchy").alias("l5_hierarchy"),
                            f.col("l4_hierarchy").alias("l4_hierarchy"),
                            f.col("l3_hierarchy").alias("l3_hierarchy"),
                            f.col("l2_hierarchy").alias("l2_hierarchy"),
                            f.col("l1_hierarchy").alias("l1_hierarchy"),
                            f.coalesce(f.col("value_usd"), f.lit(0)).alias("value_usd"),
                            f.coalesce(f.col("value_lc"), f.lit(0)).alias("value_lc"),
                            f.col("cost_element_key").alias("cost_element_key"),
                            f.col("trx_wfh_key").alias("trx_wfh_key"),
                            f.col("last_modified_date").alias("last_modified_date"))
                            
        df_pr4_union = df_input_table_B.select(
                            f.lit("PR4_HIST").alias("source_system"),
                            f.col("l5_hierarchy").alias("l5_hierarchy"),
                            f.col("l4_hierarchy").alias("l4_hierarchy"),
                            f.col("l3_hierarchy").alias("l3_hierarchy"),
                            f.col("l2_hierarchy").alias("l2_hierarchy"),
                            f.col("l1_hierarchy").alias("l1_hierarchy"),
                            f.coalesce(f.col("value_usd"), f.lit(0)).alias("value_usd"),
                            f.coalesce(f.col("value_lc"), f.lit(0)).alias("value_lc"),
                            f.col("cost_element_key").alias("cost_element_key"),
                            f.col("trx_wfh_key").alias("trx_wfh_key"),
                            f.col("last_modified_date").alias("last_modified_date"))
                            
        df_sun_union = df_input_table_C.select(
                            (f.when(f.substring(f.col("cost_element_key"), 1, 3) == "SUN", "SUN")
                             .otherwise("ISP")).alias("source_system"),
                            f.col("l5_hierarchy").alias("l5_hierarchy"),
                            f.col("l4_hierarchy").alias("l4_hierarchy"),
                            f.col("l3_hierarchy").alias("l3_hierarchy"),
                            f.col("l2_hierarchy").alias("l2_hierarchy"),
                            f.col("l1_hierarchy").alias("l1_hierarchy"),
                            f.coalesce(f.col("value_usd"), f.lit(0)).alias("value_usd"),
                            f.coalesce(f.col("value_lc"), f.lit(0)).alias("value_lc"),
                            f.col("cost_element_key").alias("cost_element_key"),
                            f.col("trx_wfh_key").alias("trx_wfh_key"),
                            f.col("last_modified_date").alias("last_modified_date"))

        df_pre_union = df_input_table_D.select(
                            f.lit("PRE").alias("source_system"),
                            f.col("l5_hierarchy").alias("l5_hierarchy"),
                            f.col("l4_hierarchy").alias("l4_hierarchy"),
                            f.col("l3_hierarchy").alias("l3_hierarchy"),
                            f.col("l2_hierarchy").alias("l2_hierarchy"),
                            f.col("l1_hierarchy").alias("l1_hierarchy"),
                            f.coalesce(f.col("value_usd"), f.lit(0)).alias("value_usd"),
                            f.coalesce(f.col("value_lc"), f.lit(0)).alias("value_lc"),
                            f.col("cost_element_key").alias("cost_element_key"),
                            f.col("trx_wfh_key").alias("trx_wfh_key"),
                            f.col("last_modified_date").alias("last_modified_date"))

        dfs = [df_prot_union, df_pr4_union, df_sun_union, df_pre_union]
        df_tfx_result = reduce(DataFrame.unionAll, dfs)
        
        return df_tfx_result


if __name__ == '__main__':
    trl = LcpL51ETL()
    trl.execute()