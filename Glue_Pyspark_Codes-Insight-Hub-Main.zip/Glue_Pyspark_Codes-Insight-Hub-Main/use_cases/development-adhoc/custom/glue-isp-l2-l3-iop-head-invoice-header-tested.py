# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    14-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_iop_head_all into conform zone
# Author        :- Bakul Seth
# Date          :- 16-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 12:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 12")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'country',
                                   'country_database',
                                   'country_grpid',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l2_isp_iop_head_invoice_header', 'l2_isp_inv_sales_header']
        self.report_file = "l3_isp_iop_head_all"

        # generic variables  ===========================================
        self.country = args['country']
        self.country_database = args['country_database']
        self.country_grpid = args['country_grpid']

        # Generate list of countries for which JOB need to be run
        self.country_list = self.country.split(",")

        # Create country and database and work group id map
        self.country_database_map = dict(map(lambda x: x.split('='), self.country_database.split(',')))
        self.country_grpid_map = dict(map(lambda x: x.split('='), self.country_grpid.split('|')))

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('it will process {} countries'.format(self.country_list))
        print('it will process {} tables'.format(self.input_table_list))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # process country wise data
        for country in self.country_list:
            # get country database and table
            country_database = self.source_database + "_" + self.country_database_map[country]
            country_grpid = list(map(int, self.country_grpid_map[country].split(",")))
            print('it will process {} grpids'.format(country_grpid))
            # generate input table list
            input_table_list = []
            for table in self.input_table_list:
                country_table = table + "_" + country
                input_table_list.append(country_table)
            print("input table list is {}".format(input_table_list))

            # read data from country specific table argument passed(database, table)
            df_country_table_1 = self._get_table(country_database, input_table_list[0]).toDF()
            print("data count of table {}.{} is {}".format(country_database, input_table_list[0],
                                                           df_country_table_1.count()))
            df_country_table_2 = self._get_table(country_database, input_table_list[1]).toDF()
            print("data count of table {}.{} is {}".format(country_database, input_table_list[1],
                                                           df_country_table_2.count()))

            # apply transformation on the dataframe argument passed(dataframe, country)
            df_tfx_table = self._apply_tfx(country, country_grpid, df_country_table_1, df_country_table_2)
            print("data count after transformation ", df_tfx_table.count())

            # union country specific dataframes to get data for all the countries
            final_result_df = self.union_dataframe(final_result_df, df_tfx_table)
            print("Final Write", final_result_df.count())

        # write final result to required destination
        self.write_results(final_result_df)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    @staticmethod
    def union_dataframe(final_result_df, country_df):
        # union the dataframe
        if bool(final_result_df.head(1)):
            final_result_df = final_result_df.union(country_df)
        else:
            final_result_df = country_df
        return final_result_df

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(country, country_grpid, *args):

        # convert all the columns alias to lower case
        df_input_table_1 = args[0].select(
            [f.col(x).alias(x.lower()) for x in args[0].columns])
        df_input_table_2 = args[1].select(
            [f.col(x).alias(x.lower()) for x in args[1].columns])

        if country == 'fr':
            df_tfx_result = df_input_table_1.join(df_input_table_2, (df_input_table_1.inv_id) == (df_input_table_2.id)) \
                .select(df_input_table_1.inv_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.inv_id).alias('ref_inv_id'),
                        df_input_table_1.iop_num, df_input_table_1.iop_head_stat_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.iop_head_stat_id).alias(
                            'fk_iop_head_stat_id'),
                        df_input_table_1.curcy_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.curcy_id).alias('fk_curcy_id'),
                        df_input_table_1.curcy_sign, df_input_table_1.tot_invg_val.cast('double'),
                        df_input_table_1.cab_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.cab_id).alias('fk_cab_id'),
                        df_input_table_1.cust_acct_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.cust_acct_id).alias(
                            'fk_cust_acct_id'),
                        df_input_table_1.crt_date_time.cast('timestamp').alias('crt_date_time'),
                        df_input_table_1.work_grp_id, f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                                                               df_input_table_1.work_grp_id).alias('fk_work_grp_id'),
                        df_input_table_1.inv_date.cast('date').alias('inv_date'),
                        df_input_table_1.gl_date.cast('date').alias('gl_date'),
                        df_input_table_1.tax_pt.cast('date').alias('tax_pt'),
                        df_input_table_1.inv_pt_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.inv_pt_id).alias('fk_inv_pt_id'),
                        df_input_table_1.curcy_code, df_input_table_1.primary_rep_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.primary_rep_id).alias(
                            'fk_primary_rep_id'),
                        df_input_table_1.curcy_exch_type,
                        df_input_table_1.curcy_exch_date.cast('date').alias('curcy_exch_date'),
                        df_input_table_1.exch_rate.cast('double').alias('exch_rate'), df_input_table_1.place_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.place_id).alias('fk_place_id'),
                        df_input_table_1.tot_ival_disp_ex_vat.cast('double').alias('tot_ival_disp_ex_vat'),
                        df_input_table_1.cab_place_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.cab_place_id).alias(
                            'fk_cab_place_id'),
                        df_input_table_1.loc_of_mvt_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.loc_of_mvt_id).alias(
                            'fk_loc_of_mvt_id'),
                        df_input_table_1.iop_num_prefix, df_input_table_1.bp_cmpy_id, df_input_table_1.acct_pt_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.acct_pt_id).alias('fk_acct_pt_id'),
                        df_input_table_1.paymt_term_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.paymt_term_id).alias(
                            'fk_paymt_term_id'),
                        f.lit('ISP_ESP0166').alias('source_system'))

        elif country == 'ch':
            df_tfx_result = df_input_table_1.join(df_input_table_2, (df_input_table_1.inv_id) == (df_input_table_2.id)) \
                .select(df_input_table_1.inv_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.inv_id).alias('ref_inv_id'),
                        df_input_table_1.iop_num, df_input_table_1.iop_head_stat_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.iop_head_stat_id).alias(
                            'fk_iop_head_stat_id'),
                        df_input_table_1.curcy_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.curcy_id).alias('fk_curcy_id'),
                        df_input_table_1.curcy_sign, df_input_table_1.tot_invg_val.cast('double'),
                        df_input_table_1.cab_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.cab_id).alias('fk_cab_id'),
                        df_input_table_1.cust_acct_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.cust_acct_id).alias(
                            'fk_cust_acct_id'),
                        df_input_table_1.crt_date_time.cast('timestamp').alias('crt_date_time'),
                        df_input_table_1.work_grp_id, f.concat(f.lit('ISP_ESP0723'), f.lit('_'),
                                                               df_input_table_1.work_grp_id).alias('fk_work_grp_id'),
                        df_input_table_1.inv_date.cast('date').alias('inv_date'),
                        df_input_table_1.gl_date.cast('date').alias('gl_date'),
                        df_input_table_1.tax_pt.cast('date').alias('tax_pt'),
                        df_input_table_1.inv_pt_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.inv_pt_id).alias('fk_inv_pt_id'),
                        df_input_table_1.curcy_code, df_input_table_1.primary_rep_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.primary_rep_id).alias(
                            'fk_primary_rep_id'),
                        df_input_table_1.curcy_exch_type,
                        df_input_table_1.curcy_exch_date.cast('date').alias('curcy_exch_date'),
                        df_input_table_1.exch_rate.cast('double').alias('exch_rate'), df_input_table_1.place_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.place_id).alias('fk_place_id'),
                        df_input_table_1.tot_ival_disp_ex_vat.cast('double').alias('tot_ival_disp_ex_vat'),
                        df_input_table_1.cab_place_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.cab_place_id).alias(
                            'fk_cab_place_id'),
                        df_input_table_1.loc_of_mvt_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.loc_of_mvt_id).alias(
                            'fk_loc_of_mvt_id'),
                        df_input_table_1.iop_num_prefix, df_input_table_1.bp_cmpy_id, df_input_table_1.acct_pt_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.acct_pt_id).alias('fk_acct_pt_id'),
                        df_input_table_1.paymt_term_id,
                        f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table_1.paymt_term_id).alias(
                            'fk_paymt_term_id'),
                        f.lit('ISP_ESP0723').alias('source_system'))

        else:
            df_tfx_result = df_input_table_1.join(df_input_table_2, (df_input_table_1.inv_id) == (df_input_table_2.id)) \
                .select(df_input_table_1.inv_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.inv_id).alias(
                            'ref_inv_id'),
                        df_input_table_1.iop_num, df_input_table_1.iop_head_stat_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.iop_head_stat_id).alias(
                            'fk_iop_head_stat_id'),
                        df_input_table_1.curcy_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.curcy_id).alias(
                            'fk_curcy_id'),
                        df_input_table_1.curcy_sign, df_input_table_1.tot_invg_val.cast('double'),
                        df_input_table_1.cab_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.cab_id).alias(
                            'fk_cab_id'),
                        df_input_table_1.cust_acct_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.cust_acct_id).alias(
                            'fk_cust_acct_id'),
                        df_input_table_1.crt_date_time.cast('timestamp').alias('crt_date_time'),
                        df_input_table_1.work_grp_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.work_grp_id).alias(
                            'fk_work_grp_id'),
                        df_input_table_1.inv_date.cast('date').alias('inv_date'),
                        df_input_table_1.gl_date.cast('date').alias('gl_date'),
                        df_input_table_1.tax_pt.cast('date').alias('tax_pt'), df_input_table_1.inv_pt_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.inv_pt_id).alias(
                            'fk_inv_pt_id'), df_input_table_1.curcy_code, df_input_table_1.primary_rep_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.primary_rep_id).alias(
                            'fk_primary_rep_id'),
                        df_input_table_1.curcy_exch_type,
                        df_input_table_1.curcy_exch_date.cast('date').alias('curcy_exch_date'),
                        df_input_table_1.exch_rate.cast('double').alias('exch_rate'), df_input_table_1.place_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.place_id).alias(
                            'fk_place_id'),
                        df_input_table_1.tot_ival_disp_ex_vat.cast('double').alias('tot_ival_disp_ex_vat'),
                        df_input_table_1.cab_place_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.cab_place_id).alias(
                            'fk_cab_place_id'), df_input_table_1.loc_of_mvt_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.loc_of_mvt_id).alias(
                            'fk_loc_of_mvt_id'), df_input_table_1.iop_num_prefix,
                        df_input_table_1.bp_cmpy_id, df_input_table_1.acct_pt_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.acct_pt_id).alias(
                            'fk_acct_pt_id'), df_input_table_1.paymt_term_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.paymt_term_id).alias(
                            'fk_paymt_term_id'), df_input_table_1.source_system.alias('source_system'))

        print("df_tfx_result", df_tfx_result.count())

        def df_filter(country, country_grpid, df_tfx_result):
            switcher = {
                "uk": df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000324')),
                "gr": df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000142')),
                "aa": df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000324',
                                                                                                  '10000000142',
                                                                                                  '97010000000013',
                                                                                                  '10000000396',
                                                                                                  '10000000072',
                                                                                                  '10000000411',
                                                                                                  '10000000905',
                                                                                                  '10000000703',
                                                                                                  '10000000234',
                                                                                                  '10000000422',
                                                                                                  '10000000057',
                                                                                                  '97010000000001') == False),
                "cy": df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000703')),
                "me": df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000396',
                                                                                                  '10000000072',
                                                                                                  '10000000411',
                                                                                                  '10000000905')),
                "mz": df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000422')),
                "tr": df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000234')),
                "za": df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000057')),
                "fr": df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('97010000000013')),
                "ch": df_tfx_result.filter(df_tfx_result.bp_cmpy_id.isin('97010000000001'))}
            return switcher.get(country, df_tfx_result)

        df_tfx_result = df_filter(country, country_grpid, df_tfx_result)
        print("df_tfx_result after : ", df_tfx_result.count())

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()
