# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    14-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_inv_sales_all into conform zone
# Author        :- Tingting Wan
# Date          :- 16-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================


import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql import DataFrame
from functools import reduce


class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 12:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 12")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'country',
                                   'country_database',
                                   'country_grpid',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l2_isp_inv_sales_header', 'l2_isp_inv_sales_line', 'l2_isp_port_plant']
        self.report_file = "l3_isp_inv_sales_all"

        # generic variables  ===========================================
        self.country = args['country']
        self.country_database = args['country_database']
        self.country_grpid = args['country_grpid']

        # Generate list of countries for which JOB need to be run
        self.country_list = self.country.split(",")

        # Create country and database and work group id map
        self.country_database_map = dict(map(lambda x: x.split('='), self.country_database.split(',')))
        self.country_grpid_map = dict(map(lambda x: x.split('='), self.country_grpid.split('|')))

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('it will process {} countries'.format(self.country_list))
        print('it will process {} tables'.format(self.input_table_list))

    def execute(self):
        # create list of Transform Latest dataframes
        tran_latest_dfs = []

        # process country wise data
        for country in self.country_list:
            # get country database and table
            country_database = self.source_database + "_" + self.country_database_map[country]
            country_grpid = list(map(str, self.country_grpid_map[country].split(",")))
            print('it will process {} grpids'.format(country_grpid))

            # generate input table list
            input_table_list = []
            for table in self.input_table_list:
                country_table = table + "_" + country
                input_table_list.append(country_table)
            print("input table list is {}".format(input_table_list))

            # read data from country specific table argument passed(database, table)
            df_country_table_header = self._get_table(country_database, input_table_list[0]).toDF()
            # print("data count of table {}.{} is {}".format(country_database, input_table_list[0],
            #                                               df_country_table_header.count()))
            df_country_table_line = self._get_table(country_database, input_table_list[1]).toDF()
            # print("data count of table {}.{} is {}".format(country_database, input_table_list[1],
            #                                               df_country_table_line.count()))
            df_country_table_port = self._get_table(country_database, input_table_list[2]).toDF()
            # print("data count of table {}.{} is {}".format(country_database, input_table_list[2],
            #                                               df_country_table_port.count()))

            # apply transformation on the dataframe argument passed(dataframe, country)
            df_tfx_table = self._apply_tfx(country, country_grpid, df_country_table_header, df_country_table_line,
                                           df_country_table_port)
            # print("data count after transformation ", df_tfx_table.count())

            # union country specific dataframes to get data for all the countries
            tran_latest_dfs.append(df_tfx_table)

            # unionByName all Transform Latest dataframes ONCE outside for loop. Removed the head() operation too.
            # distinct() is moved out of loop into write_results() method
            final_result_df = reduce(DataFrame.unionByName, tran_latest_dfs)

        # write final result to required destination
        self.write_results(final_result_df)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .distinct() \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    def _apply_tfx(self, country, country_grpid, *args):

        # convert all the columns alias to lower case
        df_input_table_header = args[0].select(
            [f.col(x).alias(x.lower()) for x in args[0].columns])
        df_input_table_line = args[1].select(
            [f.col(x).alias(x.lower()) for x in args[1].columns])
        df_input_table_port = args[2].select(
            [f.col(x).alias(x.lower()) for x in args[2].columns])

        if country == 'fr':
            df_tfx_result = df_input_table_header.join(df_input_table_line,
                                                       (f.concat(f.lit('ISP_ESP0166'),
                                                                 f.lit('_'), df_input_table_header.id))
                                                       == (f.concat(f.lit('ISP_ESP0166'),
                                                                    f.lit('_'),
                                                                    df_input_table_line.inv_sales_id))) \
                .select(df_input_table_header.id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_header.id).alias('ref_id'),
                        df_input_table_header.cab_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_header.cab_id).alias('fk_cab_id'),
                        df_input_table_header.curcy_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_header.curcy_id).alias('fk_curcy_id'),
                        df_input_table_header.curcy_id_locl,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_header.curcy_id_locl).alias(
                            'fk_curcy_id_locl'),
                        df_input_table_header.cust_acct_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_header.cust_acct_id).alias(
                            'fk_cust_acct_id'),
                        df_input_table_header.dlvy_note_num_grpng,
                        df_input_table_header.exch_rate_type_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_header.exch_rate_type_id).alias(
                            'fk_exch_rate_type_id'),
                        df_input_table_header.exch_rate_date_type_id,
                        df_input_table_header.inv_pt_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_header.inv_pt_id).alias(
                            'fk_inv_pt_id'),
                        df_input_table_header.ord_id_grpng,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_header.ord_id_grpng).alias(
                            'fk_ord_id_grpng'),
                        df_input_table_header.work_grp_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_header.work_grp_id).alias(
                            'fk_work_grp_id'),
                        df_input_table_header.iop_num,
                        df_input_table_header.inv_date.cast('date').alias('inv_date'),
                        df_input_table_header.plnd_inv_date.cast('date').alias('plnd_inv_date'),
                        df_input_table_header.gl_date.cast('date').alias('gl_date'),
                        df_input_table_header.crt_date_time.cast('timestamp').alias('crt_date_time'),
                        df_input_table_header.inv_status_id,
                        df_input_table_header.tax_point_date.cast('date').alias('tax_point_date'),
                        df_input_table_header.exch_rate.cast('double').alias('exch_rate'),
                        df_input_table_header.iop_num_prefixed, df_input_table_header.bp_cmpy_id,
                        df_input_table_header.port_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_header.port_id).alias('fk_port_id'),
                        df_input_table_header.global_acct_ref_num, df_input_table_header.iop_num_prefix,
                        f.lit('ISP_ESP0166').alias('source_system'))

        else:
            df_tfx_result = df_input_table_header.join(df_input_table_line, (
                f.concat(df_input_table_header.source_system, f.lit('_'), df_input_table_header.id))
                                                       == (f.concat(df_input_table_line.source_system,
                                                                    f.lit('_'),
                                                                    df_input_table_line.inv_sales_id))) \
                .select(df_input_table_header.id,
                        f.concat(df_input_table_header.source_system, f.lit('_'), df_input_table_header.id).alias(
                            'ref_id'),
                        df_input_table_header.cab_id,
                        f.concat(df_input_table_header.source_system, f.lit('_'),
                                 df_input_table_header.cab_id).alias('fk_cab_id'),
                        df_input_table_header.curcy_id,
                        f.concat(df_input_table_header.source_system, f.lit('_'),
                                 df_input_table_header.curcy_id).alias('fk_curcy_id'),
                        df_input_table_header.curcy_id_locl,
                        f.concat(df_input_table_header.source_system, f.lit('_'),
                                 df_input_table_header.curcy_id_locl).alias(
                            'fk_curcy_id_locl'),
                        df_input_table_header.cust_acct_id,
                        f.concat(df_input_table_header.source_system, f.lit('_'),
                                 df_input_table_header.cust_acct_id).alias(
                            'fk_cust_acct_id'),
                        df_input_table_header.dlvy_note_num_grpng,
                        df_input_table_header.exch_rate_type_id,
                        f.concat(df_input_table_header.source_system, f.lit('_'),
                                 df_input_table_header.exch_rate_type_id).alias(
                            'fk_exch_rate_type_id'),
                        df_input_table_header.exch_rate_date_type_id,
                        df_input_table_header.inv_pt_id,
                        f.concat(df_input_table_header.source_system, f.lit('_'),
                                 df_input_table_header.inv_pt_id).alias('fk_inv_pt_id'),
                        df_input_table_header.ord_id_grpng,
                        f.concat(df_input_table_header.source_system, f.lit('_'),
                                 df_input_table_header.ord_id_grpng).alias(
                            'fk_ord_id_grpng'),
                        df_input_table_header.work_grp_id,
                        f.concat(df_input_table_header.source_system, f.lit('_'),
                                 df_input_table_header.work_grp_id).alias(
                            'fk_work_grp_id'),
                        df_input_table_header.iop_num,
                        df_input_table_header.inv_date.cast('date').alias('inv_date'),
                        df_input_table_header.plnd_inv_date.cast('date').alias('plnd_inv_date'),
                        df_input_table_header.gl_date.cast('date').alias('gl_date'),
                        df_input_table_header.crt_date_time.cast('timestamp').alias('crt_date_time'),
                        df_input_table_header.inv_status_id,
                        df_input_table_header.tax_point_date.cast('date').alias('tax_point_date'),
                        df_input_table_header.exch_rate.cast('double').alias('exch_rate'),
                        df_input_table_header.iop_num_prefixed, df_input_table_header.bp_cmpy_id,
                        df_input_table_header.port_id,
                        f.concat(df_input_table_header.source_system, f.lit('_'),
                                 df_input_table_header.port_id).alias('fk_port_id'),
                        df_input_table_header.global_acct_ref_num, df_input_table_header.iop_num_prefix,
                        df_input_table_header.source_system)

        # print("before filter: ", df_tfx_result.count())
        # filter
        def df_filter(self, country, country_grpid, df_input_table_port, df_tfx_result):

            # Flag to check if dataframe contains matching country.
            # If yes, we later apply an additional filter
            COUNTRY_MATCH = False
            if country == "uk":
                COUNTRY_MATCH = True
                df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(
                        country_grpid) & df_tfx_result.port_id.isNull() & df_tfx_result.bp_cmpy_id.isin(
                        '10000000324'))
            elif country == "gr":
                COUNTRY_MATCH = True
                df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(
                        country_grpid) & df_tfx_result.port_id.isNull() & df_tfx_result.bp_cmpy_id.isin(
                        '10000000142'))
            elif country == "aa":
                COUNTRY_MATCH = True
                df_tfx_result = df_tfx_result.filter(
                    (df_tfx_result.work_grp_id.isin(
                        country_grpid) & df_tfx_result.port_id.isNull() & df_tfx_result.bp_cmpy_id.isin(
                        '10000000324', '10000000142',
                        '97010000000013',
                        '10000000396',
                        '10000000072',
                        '10000000411',
                        '10000000905',
                        '10000000703',
                        '10000000234',
                        '10000000422',
                        '10000000057',
                        '97010000000001') == False))
            elif country == "cy":
                COUNTRY_MATCH = True
                df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(
                        country_grpid) & df_tfx_result.port_id.isNull() & df_tfx_result.bp_cmpy_id.isin('10000000703'))
            elif country == "me":
                COUNTRY_MATCH = True
                df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(
                        country_grpid) & df_tfx_result.port_id.isNull() & df_tfx_result.bp_cmpy_id.isin('10000000396',
                                                                                                        '10000000072',
                                                                                                        '10000000411',
                                                                                                        '10000000905'))
            elif country == "mz":
                COUNTRY_MATCH = True
                df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(
                        country_grpid) & df_tfx_result.port_id.isNull() & df_tfx_result.bp_cmpy_id.isin('10000000422'))
            elif country == "tr":
                COUNTRY_MATCH = True
                df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(
                        country_grpid) & df_tfx_result.port_id.isNull() & df_tfx_result.bp_cmpy_id.isin('10000000234'))
            elif country == "za":
                COUNTRY_MATCH = True
                df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(
                        country_grpid) & df_tfx_result.port_id.isNull() & df_tfx_result.bp_cmpy_id.isin(
                        '10000000057'))
            elif country == "fr":
                COUNTRY_MATCH = True
                df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(
                        country_grpid) & df_tfx_result.port_id.isNull() & df_tfx_result.bp_cmpy_id.isin(
                        '97010000000013'))

            if COUNTRY_MATCH:
                df_tfx_result.createOrReplaceTempView('df_tfx_result')
                df_input_table_port.createOrReplaceTempView('df_input_table_port')
                df_tfx_result = self._spark.sql(
                    'select * from df_tfx_result where dest_port_id in (select id from df_input_table_port) or dest_port_id is null')

            return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()