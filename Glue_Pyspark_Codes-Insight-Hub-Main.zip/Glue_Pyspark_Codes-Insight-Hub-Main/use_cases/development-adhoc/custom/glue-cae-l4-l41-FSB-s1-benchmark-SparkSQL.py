# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    13-Feb-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is using SparkSQL to generate
#                  l41_isp_fact_sales_billing_cost_allocation_s1 into conform zone
# Author        :- Tingting Wan
# Date          :- 13-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================

        self.report_file = "l41_isp_fact_sales_billing_cost_allocation_s1_benchmark"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    def execute(self):

        # read data from specific table argument passed(database, table)
        df_table_1 = self._get_table(self.source_database, 'l4_isp_fact_sales_billing')
        df_table_1.toDF().createOrReplaceTempView("l4_isp_fact_sales_billing")
        df_table_2 = self._get_table(self.source_database, 'l3_isp_imi_prod_grps_man')
        df_table_2.toDF().createOrReplaceTempView("l3_isp_imi_prod_grps_man")
        df_table_3 = self._get_table(self.source_database, 'l3_isp_iop_head_all')
        df_table_3.toDF().createOrReplaceTempView("l3_isp_iop_head_all")
        df_table_4 = self._get_table(self.source_database, 'l3_isp_iop_line_all')
        df_table_4.toDF().createOrReplaceTempView("l3_isp_iop_line_all")
        df_table_5 = self._get_table(self.source_database, 'l3_isp_inv_sales_all')
        df_table_5.toDF().createOrReplaceTempView("l3_isp_inv_sales_all")
        df_table_6 = self._get_table(self.source_database, 'l3_isp_inv_sales_line_all')
        df_table_6.toDF().createOrReplaceTempView("l3_isp_inv_sales_line_all")
        df_table_7 = self._get_table(self.source_database, 'l3_isp_fuel_point_all')
        df_table_7.toDF().createOrReplaceTempView("l3_isp_fuel_point_all")
        df_table_8 = self._get_table(self.source_database, 'l4_isp_dim_location')
        df_table_8.toDF().createOrReplaceTempView("l4_isp_dim_location")
        df_table_9 = self._get_table(self.source_database, 'l4_location_mapping_isp')
        df_table_9.toDF().createOrReplaceTempView("l4_location_mapping_isp")
        df_table_10 = self._get_table(self.source_database, 'l4_dim_location')
        df_table_10.toDF().createOrReplaceTempView("l4_dim_location")
        df_table_11 = self._get_table(self.source_database, 'l4_isp_dim_customer')
        df_table_11.toDF().createOrReplaceTempView("l4_isp_dim_customer")
        df_table_12 = self._get_table(self.source_database, 'l3_isp_currency_all')
        df_table_12.toDF().createOrReplaceTempView("l3_isp_currency_all")
        df_table_13 = self._get_table(self.source_database, 'l3_isp_exch_rate_type_exchange_rates_all')
        df_table_13.toDF().createOrReplaceTempView("l3_isp_exch_rate_type_exchange_rates_all")
        df_table_14 = self._get_table(self.source_database, 'l3_isp_exchange_rate_all')
        df_table_14.toDF().createOrReplaceTempView("l3_isp_exchange_rate_all")

        # Write and Execute SQL query
        df_tfx_table = self._spark.sql("""SELECT FSB.REF_ID
              , FSB.BILLING_DOCUMENT
              , FSB.BILLING_ITEM
              , FSB.SOURCE_SYSTEM
              , CASE
                  WHEN FSB.COUNTRY = 'TN' THEN 'EG' -- TN transactions should be treated as EG for cost allocation
                  ELSE FSB.COUNTRY
                END AS COUNTRY_MNMC
              , CASE 
                  WHEN FSB.SHIPTO_PARTY = 'ISP_ESP0762_7620000110464' THEN 'Commercial Airlines' -- 'TAP'
                  WHEN FSB.SHIPTO_PARTY = 'ISP_ESP0762_5250274606412' THEN 'General Aviation' -- 'WORLD FOOD PROGRAMME'
                  WHEN FSB.SHIPTO_PARTY = 'ISP_ESP0762_5250012313042' THEN 'General Aviation' -- 'CARGO AIR CHARTERING'
                  WHEN FSB.SHIPTO_PARTY = 'ISP_ESP0762_5250265710387' THEN 'General Aviation' -- 'SOLENTA AVIATION MOZAMBIQUE, SA'
                  WHEN FSB.SHIPTO_PARTY = 'ISP_ESP0762_5250155225173' THEN 'General Aviation' -- 'WFS TRADING DMCC'
                  WHEN FSB.SHIPTO_PARTY = 'ISP_ESP0762_5250149303851' THEN 'General Aviation' -- 'DHL AVIATION (EEMEA) B.S.C (c)'
                  WHEN FSB.SHIPTO_PARTY = 'ISP_ESP0762_5250104341580' THEN 'General Aviation' -- 'A.N.A AIRLINE MANAGEMENT LTD.'
                  ELSE CUS.SECTOR
                END AS SECTOR
              , FSB.SALES_ORGANISATION
              , IPG.PRODUCT_GRP_1 AS PROD_GRP
              , FSB.ITEM_CATEGORY
              , FSB.MATERIAL_NUMBER
              , FSB.MATERIAL_MNMC
              , SEM.locationid AS SEM_LOC_ID
              , SEM.location_name AS SEM_LOC_NAME
              , LOC.REF_ID AS AIRPORT_ID -- ISP PLANT ID
              , LOC.PLANT AS AIRPORT_MNMC -- ISP PLANT MNMC
              , LOC.LOCATION_NAME AS AIRPORT_NAME -- ISP PLANT NAME
              , '' AS SUN_PLANT_MNMC
              , FSB.LOCATION_OF_SALE
              , FSB.SHIPTO_PARTY AS CUSTOMER_ID
              , CUS.GRN AS CUSTOMER_NUMBER
              , CUS.GRN_HEADER AS CUSTOMER_HEADER
              , CUS.CUSTOMER_ACCOUNT_NAME AS CUSTOMER_NAME
              , CASE 
                  WHEN FSB.COUNTRY = 'GB' AND IFP.MNMC='F0898' THEN 'H2211' -- Use H2211 costs for F0898
                  ELSE IFP.MNMC
                END AS FUEL_POINT_MNMC
              , IFP.NAME AS FUEL_POINT_NAME
              , ISH.EXCH_RATE_DATE_TYPE_ID
              , MEXRT.ID AS M_EXCH_RATE_TYPE_ID
              , FSB.EXCHANGE_RATE_TYPE AS D_EXCH_RATE_TYPE_ID
              , FSB.DELIVERY_DATE
              , FSB.BILLING_DATE -- Invoice Date
              , ISH.PLND_INV_DATE
              , FSB.M3
              , FSB.UGL
              , FSB.LITRES
              , FSB.METRIC_TONS
              , FSB.DOCUMENT_CURRENCY
              , FSB.LOCAL_CURRENCY
              , MILE.EXCH_RATE MILE
              , DILE.EXCH_RATE DILE
              , MLRE.EXCH_RATE MLRE
              , DLRE.EXCH_RATE DLRE
              , CASE 
                  WHEN FSB.COUNTRY = 'FR' THEN FSB.DELIVERY_DATE
                  WHEN ISH.EXCH_RATE_DATE_TYPE_ID = 1 THEN FSB.BILLING_DATE
                  WHEN ISH.EXCH_RATE_DATE_TYPE_ID = 2 THEN FSB.DELIVERY_DATE
                  WHEN ISH.PLND_INV_DATE IS NOT NULL THEN ISH.PLND_INV_DATE
                  ELSE FSB.DELIVERY_DATE
                END AS EXCH_RATE_DATE
              , FSB.EXCHANGE_RATE -- This is Local to Reporting currency exchange rate 
              , FSB.NET_VALUE -- Net value in Invoice/Document Currency
              , CASE
                  WHEN FSB.DOCUMENT_CURRENCY = FSB.LOCAL_CURRENCY THEN CAST((1) AS DOUBLE) 
                  WHEN MILE.EXCH_RATE IS NOT NULL 
                   AND FSB.COUNTRY <> 'TR' THEN MILE.EXCH_RATE
                  WHEN DILE.EXCH_RATE IS NOT NULL THEN DILE.EXCH_RATE
                  ELSE CAST((0) AS DOUBLE) -- No exchange rate found so default to zero
                END AS ILE_EXCH_RATE -- Exchange rate (Invoicing to Local)
              , CASE
                  WHEN FSB.DOCUMENT_CURRENCY = FSB.LOCAL_CURRENCY THEN FSB.NET_VALUE 
                  WHEN MILE.EXCH_RATE IS NOT NULL 
                   AND FSB.COUNTRY <> 'TR' THEN FSB.NET_VALUE * MILE.EXCH_RATE
                  WHEN DILE.EXCH_RATE IS NOT NULL THEN FSB.NET_VALUE * DILE.EXCH_RATE
                  ELSE CAST((0) AS DOUBLE) -- No exchange rate found so default to zero
                END AS LCL_NET_VAL -- Net value in Local Currency
              , CASE
                  WHEN FSB.LOCAL_CURRENCY = 'USD' THEN CAST((1) AS DOUBLE)
                  WHEN MLRE.EXCH_RATE IS NOT NULL 
                   AND FSB.COUNTRY <> 'TR' THEN MLRE.EXCH_RATE
                  WHEN DLRE.EXCH_RATE IS NOT NULL THEN DLRE.EXCH_RATE
                  ELSE CAST((0) AS DOUBLE) -- No exchange rate found so default to zero
                END AS LRE_EXCH_RATE -- Exchange rate (Local to Reporting)
              , CASE
                  WHEN FSB.LOCAL_CURRENCY = 'USD' THEN 
                    CASE
                      WHEN FSB.DOCUMENT_CURRENCY = FSB.LOCAL_CURRENCY THEN FSB.NET_VALUE 
                      WHEN MILE.EXCH_RATE IS NOT NULL 
                       AND FSB.COUNTRY <> 'TR' THEN FSB.NET_VALUE * MILE.EXCH_RATE
                      WHEN DILE.EXCH_RATE IS NOT NULL THEN FSB.NET_VALUE * DILE.EXCH_RATE
                      ELSE FSB.NET_VALUE -- No exchange rate found so default to no conversion
                    END
                  ELSE 
                    CASE
                      WHEN FSB.DOCUMENT_CURRENCY = FSB.LOCAL_CURRENCY THEN 
                        CASE
                          WHEN MLRE.EXCH_RATE IS NOT NULL 
                           AND FSB.COUNTRY <> 'TR' THEN FSB.NET_VALUE * MLRE.EXCH_RATE
                          WHEN DLRE.EXCH_RATE IS NOT NULL THEN FSB.NET_VALUE * DLRE.EXCH_RATE
                          ELSE FSB.NET_VALUE -- No exchange rate found so default to no conversion
                        END
                      ELSE
                        CASE
                          WHEN DILE.EXCH_RATE IS NOT NULL 
                           AND DLRE.EXCH_RATE IS NOT NULL
                           AND FSB.COUNTRY = 'TR' THEN FSB.NET_VALUE * DILE.EXCH_RATE * DLRE.EXCH_RATE
                          WHEN MILE.EXCH_RATE IS NOT NULL 
                           AND MLRE.EXCH_RATE IS NOT NULL  
                           AND FSB.COUNTRY <> 'TR' THEN FSB.NET_VALUE * MILE.EXCH_RATE * MLRE.EXCH_RATE
                          WHEN MILE.EXCH_RATE IS NOT NULL 
                           AND MLRE.EXCH_RATE IS NULL 
                           AND DLRE.EXCH_RATE IS NOT NULL 
                           AND FSB.COUNTRY <> 'TR' THEN FSB.NET_VALUE * MILE.EXCH_RATE * DLRE.EXCH_RATE
                          WHEN MILE.EXCH_RATE IS NULL 
                           AND DILE.EXCH_RATE IS NOT NULL 
                           AND MLRE.EXCH_RATE IS NOT NULL 
                           AND FSB.COUNTRY <> 'TR' THEN FSB.NET_VALUE * DILE.EXCH_RATE * MLRE.EXCH_RATE
                          WHEN MILE.EXCH_RATE IS NULL 
                           AND DILE.EXCH_RATE IS NOT NULL 
                           AND MLRE.EXCH_RATE IS NULL 
                           AND DLRE.EXCH_RATE IS NOT NULL THEN FSB.NET_VALUE * DILE.EXCH_RATE * DLRE.EXCH_RATE
                          ELSE CAST((0) AS DOUBLE) -- No exchange rate found so default to zero
                        END
                    END
                END AS USD_NET_VAL -- Net value in Reporting Currency (USD)
              , FSB.PLANT
              , FSB.STD_VOLUME
         FROM      l4_isp_fact_sales_billing AS FSB
         LEFT JOIN l3_isp_imi_prod_grps_man AS IPG
                ON FSB.MATERIAL_MNMC = IPG.PRODUCT
         LEFT JOIN l3_isp_iop_head_all AS IPH
                ON SPLIT(FSB.REF_ID, '_')[2] = IPH.INV_ID 
               AND FSB.SOURCE_SYSTEM = IPH.SOURCE_SYSTEM
         LEFT JOIN l3_isp_iop_line_all AS IPL
                ON SPLIT(FSB.REF_ID, '_')[2] = IPL.INV_ID 
               AND SPLIT(FSB.REF_ID, '_')[3] = IPL.ITEM_NUM 
               AND SPLIT(FSB.REF_ID, '_')[4] = IPL.ITEM_SEQ_NUM
               AND FSB.SOURCE_SYSTEM = IPL.SOURCE_SYSTEM
         LEFT JOIN l3_isp_inv_sales_all AS ISH
                ON IPL.INV_ID = ISH.ID 
               AND FSB.SOURCE_SYSTEM = ISH.SOURCE_SYSTEM
         LEFT JOIN l3_isp_inv_sales_line_all AS ISL
                ON IPL.INV_ID = ISL.INV_SALES_ID 
               AND IPL.INV_SEQ_NUM = ISL.SEQ_NUM
               AND FSB.SOURCE_SYSTEM = ISL.SOURCE_SYSTEM
         LEFT JOIN l3_isp_fuel_point_all AS IFP
                ON ISL.FK_FUEL_POINT_ID = IFP.REF_ID
         LEFT JOIN l4_isp_dim_location AS LOC
                ON FSB.PLANT = LOC.REF_ID
         LEFT JOIN l4_location_mapping_isp AS LMI
                ON SPLIT(FSB.PLANT, '_')[2] = LMI.isp_mapping
         LEFT JOIN l4_dim_location AS SEM
                ON LMI.location_id = SEM.locationid
         LEFT JOIN l4_isp_dim_customer AS CUS
                ON FSB.SHIPTO_PARTY = CUS.REF_ISP_ID
         LEFT JOIN l3_isp_currency_all AS ICU
                ON FSB.DOCUMENT_CURRENCY = ICU.MNMC
               AND FSB.SOURCE_SYSTEM = ICU.SOURCE_SYSTEM 
         LEFT JOIN l3_isp_exch_rate_type_exchange_rates_all AS MEXRT
                ON MEXRT.MNMC = 'BOKEEP'
               AND FSB.SOURCE_SYSTEM = MEXRT.SOURCE_SYSTEM
         LEFT JOIN l3_isp_currency_all AS LCU
                ON FSB.LOCAL_CURRENCY = LCU.MNMC
               AND FSB.SOURCE_SYSTEM = LCU.SOURCE_SYSTEM 
         LEFT JOIN l3_isp_currency_all AS RCU 
                ON 'USD' = RCU.MNMC -- Reporting currency hard-coded to USD
               AND FSB.SOURCE_SYSTEM = RCU.SOURCE_SYSTEM 
         LEFT JOIN l3_isp_exchange_rate_all AS DILE
                ON ICU.ID = DILE.CURCY_ID_FROM 
               AND LCU.ID = DILE.CURCY_ID_TO
               AND FSB.EXCHANGE_RATE_TYPE = DILE.EXCH_RATE_TYPE_ID
               AND IF(FSB.COUNTRY = 'FR', FSB.DELIVERY_DATE,
                     IF(ISH.EXCH_RATE_DATE_TYPE_ID = 1, FSB.BILLING_DATE,
                       IF(ISH.EXCH_RATE_DATE_TYPE_ID = 2, FSB.DELIVERY_DATE,
                         IFNULL(ISH.PLND_INV_DATE, FSB.DELIVERY_DATE)))) BETWEEN DILE.START_DATE AND DILE.END_DATE
               AND FSB.SOURCE_SYSTEM = DILE.SOURCE_SYSTEM
         LEFT JOIN l3_isp_exchange_rate_all AS MILE
                ON ICU.ID = MILE.CURCY_ID_FROM 
               AND LCU.ID = MILE.CURCY_ID_TO
               AND MEXRT.ID = MILE.EXCH_RATE_TYPE_ID
               AND IF(FSB.COUNTRY = 'FR', FSB.DELIVERY_DATE,
                     IF(ISH.EXCH_RATE_DATE_TYPE_ID = 1, FSB.BILLING_DATE,
                       IF(ISH.EXCH_RATE_DATE_TYPE_ID = 2, FSB.DELIVERY_DATE,
                         IFNULL(ISH.PLND_INV_DATE, FSB.DELIVERY_DATE)))) BETWEEN MILE.START_DATE AND MILE.END_DATE
               AND FSB.SOURCE_SYSTEM = MILE.SOURCE_SYSTEM
         LEFT JOIN l3_isp_exchange_rate_all AS DLRE 
                ON LCU.ID = DLRE.CURCY_ID_FROM 
               AND RCU.ID = DLRE.CURCY_ID_TO 
               AND FSB.EXCHANGE_RATE_TYPE = DLRE.EXCH_RATE_TYPE_ID
               AND IF(FSB.COUNTRY = 'FR', FSB.DELIVERY_DATE,
                     IF(ISH.EXCH_RATE_DATE_TYPE_ID = 1, FSB.BILLING_DATE,
                       IF(ISH.EXCH_RATE_DATE_TYPE_ID = 2, FSB.DELIVERY_DATE,
                         IFNULL(ISH.PLND_INV_DATE, FSB.DELIVERY_DATE)))) BETWEEN DLRE.START_DATE AND DLRE.END_DATE
               AND FSB.SOURCE_SYSTEM = DLRE.SOURCE_SYSTEM
         LEFT JOIN l3_isp_exchange_rate_all AS MLRE 
                ON LCU.ID = MLRE.CURCY_ID_FROM 
               AND RCU.ID = MLRE.CURCY_ID_TO 
               AND MEXRT.ID = MLRE.EXCH_RATE_TYPE_ID
               AND IF(FSB.COUNTRY = 'FR', FSB.DELIVERY_DATE,
                     IF(ISH.EXCH_RATE_DATE_TYPE_ID = 1, FSB.BILLING_DATE,
                       IF(ISH.EXCH_RATE_DATE_TYPE_ID = 2, FSB.DELIVERY_DATE,
                         IFNULL(ISH.PLND_INV_DATE, FSB.DELIVERY_DATE)))) BETWEEN MLRE.START_DATE AND MLRE.END_DATE
               AND FSB.SOURCE_SYSTEM = MLRE.SOURCE_SYSTEM
         WHERE  FSB.COUNTRY IN ('AE', 'AL', 'BH', 'CH', 'CY', 'EG', 'FR', 'GB', 'GR', 'HR', 'IE', 'IT', 'LB', 'MZ', 'RO', 'TN', 'TR', 'ZA')
         AND    YEAR(FSB.DELIVERY_DATE) >= 2018
         """)

        # convert all the columns alias to lower case
        df_tfx_table = df_tfx_table.select([f.col(x).alias(x.lower()) for x in df_tfx_table.columns])

        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()

