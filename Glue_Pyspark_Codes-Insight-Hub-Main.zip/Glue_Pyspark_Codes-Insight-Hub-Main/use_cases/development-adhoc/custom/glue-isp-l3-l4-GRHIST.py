import sys
from pyspark.sql import functions as F
from awsglue.dynamicframe import DynamicFrame
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession
from datetime import datetime

conf = (SparkConf().set("spark.sql.autoBroadcastJoinThreshold","10485760")
                                 .set("spark.sql.crossJoin.enabled", "true"))
sc = SparkSession.builder.config(conf=conf).getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
args = getResolvedOptions(sys.argv,['JOB_NAME'])
job.init(args['JOB_NAME'], args)

# variables
database_name = "conform_main_aviation"
destination = "s3://ws00an-dst-dev-conform/main/aviation/isp_layer_4/"
# report specific======================================================
##map to original sql df A-H(NOT D)
l3_isp_inv_sales_line_all = "l3_isp_inv_sales_line_all"
l3_isp_inv_sales_all = "l3_isp_inv_sales_all"
l3_isp_currency_all = "l3_isp_currency_all"
l3_isp_uom_oil_all = "l3_isp_uom_oil_all"
l3_isp_mtl_art_all = "l3_isp_mtl_art_all"
l3_isp_conf_stk_mvt_all = "l3_isp_conf_stk_mvt_all"
l3_isp_fuel_point_all = "l3_isp_fuel_point_all"

report = "l4_isp_fact_sales_billing_gr_hist_performance"


# function to apply tfx==============================================================================
def run_tfx_fact_sales_billing_gr_hist(table_A, table_B, table_C, table_E, table_F, table_G, table_H):
    # reading data from s3==========================================================================================================================
    df_l4_isp_jobA = glueContext.create_dynamic_frame.from_catalog(database=database_name,
                                                                   table_name=table_A).toDF()
    df_l4_isp_jobB = glueContext.create_dynamic_frame.from_catalog(database=database_name,
                                                                   table_name=table_B).toDF()
    df_l4_isp_jobC = glueContext.create_dynamic_frame.from_catalog(database=database_name,
                                                                   table_name=table_C).toDF()
    df_l4_isp_jobE = glueContext.create_dynamic_frame.from_catalog(database=database_name,
                                                                   table_name=table_E).toDF()
    df_l4_isp_jobF = glueContext.create_dynamic_frame.from_catalog(database=database_name,
                                                                   table_name=table_F).toDF()
    df_l4_isp_jobG = glueContext.create_dynamic_frame.from_catalog(database=database_name,
                                                                   table_name=table_G).toDF()
    df_l4_isp_jobH = glueContext.create_dynamic_frame.from_catalog(database=database_name,
                                                                   table_name=table_H).toDF()
    now = datetime.now()
    print('df_l4_isp_jobA', df_l4_isp_jobA.count(), now)
    now = datetime.now()
    print('df_l4_isp_jobB', df_l4_isp_jobB.count(), now)
    now = datetime.now()
    print('df_l4_isp_jobC', df_l4_isp_jobC.count(), now)
    now = datetime.now()
    print('df_l4_isp_jobE', df_l4_isp_jobE.count(), now)
    now = datetime.now()
    print('df_l4_isp_jobF', df_l4_isp_jobF.count(), now)
    now = datetime.now()
    print('df_l4_isp_jobG', df_l4_isp_jobG.count(), now)
    now = datetime.now()
    print('df_l4_isp_jobH', df_l4_isp_jobH.count(), now)

    # pre transformation
    # select only required cols to reduce the volumne
    df_l4_isp_jobA = df_l4_isp_jobA.select(df_l4_isp_jobA.FK_INV_SALES_ID, df_l4_isp_jobA.VAL_INVG,
                                           df_l4_isp_jobA.FK_UOM_ID, df_l4_isp_jobA.FK_MTL_ART_ID,
                                           df_l4_isp_jobA.FK_CONF_STK_MVT_ID, df_l4_isp_jobA.SOURCE_SYSTEM,
                                           df_l4_isp_jobA.WORK_GRP_ID, df_l4_isp_jobA.DLVY_NOTE_NUM,
                                           df_l4_isp_jobA.MTL_ART_ID, df_l4_isp_jobA.ART_NAME,
                                           df_l4_isp_jobA.CRT_DATE_TIME, df_l4_isp_jobA.FLIGHT_NUMBER,
                                           df_l4_isp_jobA.ACRFT_REG_NUMBER, df_l4_isp_jobA.ACTL_DLVY_DATE)
    now = datetime.now()
    print('df_l4_isp_jobA', df_l4_isp_jobA.count(), now)  # df_l4_isp_jobH 2062848 2020-12-08 17:42:04.580341
    df_l4_isp_jobB = df_l4_isp_jobB.select(df_l4_isp_jobB.FK_CURCY_ID, df_l4_isp_jobB.FK_CURCY_ID_LOCL,
                                           df_l4_isp_jobB.REF_ID, df_l4_isp_jobB.IOP_NUM_PREFIXED,
                                           df_l4_isp_jobB.INV_DATE, df_l4_isp_jobB.EXCH_RATE,
                                           df_l4_isp_jobB.BP_CMPY_ID, df_l4_isp_jobB.CRT_DATE_TIME,
                                           df_l4_isp_jobB.EXCH_RATE_TYPE_ID, df_l4_isp_jobB.WORK_GRP_ID,
                                           df_l4_isp_jobB.FK_PORT_ID, df_l4_isp_jobB.FK_INV_PT_ID)
    now = datetime.now()
    print('df_l4_isp_jobB', df_l4_isp_jobB.count(), now)  # df_l4_isp_jobH 2062314 2020-12-08 17:42:38.572923
    # SUM_TABLE and CURRENCY
    SUM_TABLE = df_l4_isp_jobA.groupBy(df_l4_isp_jobA.FK_INV_SALES_ID).agg(
        sum(df_l4_isp_jobA.VAL_INVG).alias('SUM_VAL_INVG'))
    now = datetime.now()
    print('SUM_TABLE', SUM_TABLE.count(), now)   # df_l4_isp_jobH 105853 2020-12-08 17:42:54.405538

    # SUM_TABLE.printSchema()

    CURRENCY = df_l4_isp_jobC.select(df_l4_isp_jobC.MNMC, df_l4_isp_jobC.REF_ID)
    now = datetime.now()
    print('CURRENCY', CURRENCY.count(), now)  # df_l4_isp_jobH 445 2020-12-08 17:43:29.024514

    # applying transformation
    # fill null cols with given cols in df_l4_isp_jobG
    df_l4_isp_jobG = df_l4_isp_jobG.withColumn('QTY', coalesce(df_l4_isp_jobG.QTY, df_l4_isp_jobG.LOC_WGHT)) \
        .withColumn('REF_QTY_KG', coalesce(df_l4_isp_jobG.REF_QTY_KG, df_l4_isp_jobG.LOC_WGHT)) \
        .withColumn('REF_QTY_L', coalesce(df_l4_isp_jobG.REF_QTY_L, df_l4_isp_jobG.LOC_WGHT))
    now = datetime.now()
    print('df_l4_isp_jobG', df_l4_isp_jobG.count(), now)  # df_l4_isp_jobH 2114685 2020-12-08 17:43:29.722962

    # print("df_l4_isp_jobG", df_l4_isp_jobG.printSchema())

    # column rename tp avoid error
    df_l4_isp_jobB = df_l4_isp_jobB.withColumnRenamed('FK_CURCY_ID', 'FK_CURCY_ID_b') \
        .withColumnRenamed('FK_CURCY_ID_LOCL', 'FK_CURCY_ID_LOCL_b')
    df_l4_isp_jobG = df_l4_isp_jobG.withColumnRenamed('FK_FUEL_POINT_ID', 'FK_FUEL_POINT_ID_g')
    now = datetime.now()
    print('df_l4_isp_jobB', df_l4_isp_jobB.count(), now)
    print('df_l4_isp_jobG', df_l4_isp_jobB.count(), now)  # df_l4_isp_jobH 2062314 2020-12-08 17:44:01.097715

    # main transformation

    final_result_df = df_l4_isp_jobA.join(SUM_TABLE, df_l4_isp_jobA.FK_INV_SALES_ID == SUM_TABLE.FK_INV_SALES_ID,
                                          'left') \
        .join(df_l4_isp_jobB, df_l4_isp_jobA.FK_INV_SALES_ID == df_l4_isp_jobB.REF_ID, 'left') \
        .join(df_l4_isp_jobC, df_l4_isp_jobB.FK_CURCY_ID_b == df_l4_isp_jobC.REF_ID, 'left') \
        .join(CURRENCY, df_l4_isp_jobB.FK_CURCY_ID_LOCL_b == CURRENCY.REF_ID, 'left') \
        .join(df_l4_isp_jobE, df_l4_isp_jobA.FK_UOM_ID == df_l4_isp_jobE.REF_ID, 'left') \
        .join(df_l4_isp_jobF, (df_l4_isp_jobA.FK_MTL_ART_ID == df_l4_isp_jobF.REF_ID) &
              df_l4_isp_jobF.ART_TYPE_ID.isNotNull(), 'left') \
        .join(df_l4_isp_jobG, df_l4_isp_jobA.FK_CONF_STK_MVT_ID == df_l4_isp_jobG.REF_ID, 'left') \
        .join(df_l4_isp_jobH, df_l4_isp_jobG.FK_FUEL_POINT_ID_g == df_l4_isp_jobH.REF_ID, 'left') \
        .filter(trim(upper(df_l4_isp_jobA.SOURCE_SYSTEM)) == lit('ISP_ESP6478')) \
        .select(df_l4_isp_jobA.SOURCE_SYSTEM.alias('SOURCE_SYSTEM'),
                df_l4_isp_jobB.IOP_NUM_PREFIXED.alias('BILLING_DOCUMENT'),
                concat(df_l4_isp_jobA.FK_INV_SALES_ID, lit('_'),
                       row_number().over(Window.partitionBy(df_l4_isp_jobA.FK_INV_SALES_ID)
                                         .orderBy(df_l4_isp_jobA.FK_INV_SALES_ID)), lit('_'), lit(1)).alias('REF_ID'),

                lit(' ').alias('BILLING_TYPE'),
                lit(' ').alias('BILLING_CATEGORY'),
                lit(' ').alias('SALES_DOC_CATEGORY'),
                df_l4_isp_jobC.MNMC.alias('DOCUMENT_CURRENCY'),
                df_l4_isp_jobA.WORK_GRP_ID.alias('SALES_ORGANISATION'),
                lit(' ').alias('DISTRIBUTION_CHANNEL'),
                lit(' ').alias('PRICING_PROCEDURE'),
                lit(' ').alias('DOC_CONDITION_NO'),
                lit(' ').alias('FK_DOC_CONDITION_NO'),
                lit(' ').alias('SHIPPING_CONDITION'),
                df_l4_isp_jobB.INV_DATE.alias('BILLING_DATE'),
                lit(' ').alias('POSTING_STATUS'),
                df_l4_isp_jobB.EXCH_RATE.alias('EXCHANGE_RATE_ACCNTG'),
                lit(' ').alias('TERMS_OF_PAYMENT'),
                df_l4_isp_jobB.BP_CMPY_ID.alias('COMPANY_CODE'),
                SUM_TABLE.SUM_VAL_INVG.alias('TOTAL_NET_VALUE'),
                df_l4_isp_jobB.CRT_DATE_TIME.alias('HEADER_TIME'),
                df_l4_isp_jobB.CRT_DATE_TIME.alias('HEADER_CREATED_ON'),
                lit(' ').alias('STATISTICS_CURRENCY'),
                df_l4_isp_jobB.EXCH_RATE_TYPE_ID.alias('EXCHANGE_RATE_TYPE'),
                lit(' ').alias('DIVISION'),
                CURRENCY.MNMC.alias('LOCAL_CURRENCY'),
                lit(' ').alias('CRED_DATA_EXCH_RATE'),
                lit(' ').alias('LOGICAL_SYSTEM'),
                lit(' ').alias('TRANSLATION_DATE'),
                row_number().over(Window.partitionBy(df_l4_isp_jobA.FK_INV_SALES_ID)
                                  .orderBy(df_l4_isp_jobA.FK_INV_SALES_ID)).alias('BILLING_ITEM'),

                when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                     (df_l4_isp_jobG.QTY > 0) & (df_l4_isp_jobA.VAL_INVG < 0),
                     (df_l4_isp_jobG.QTY) * (-1))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                      (df_l4_isp_jobG.QTY < 0) & (df_l4_isp_jobA.VAL_INVG > 0),
                      (df_l4_isp_jobG.QTY) * (-1))
                .otherwise(lit(0)).alias('BILLED_QUANTITY'),
                df_l4_isp_jobE.MNMC.alias('SALES_UNIT'),
                lit(' ').alias('BASE_UNIT_OF_MEASURE'),
                lit(0).cast('double').alias('BILLING_QTY_IN_SKU'),
                when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                     (df_l4_isp_jobG.QTY > 0) & (df_l4_isp_jobA.VAL_INVG < 0),
                     (df_l4_isp_jobG.QTY) * (-1))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                      (df_l4_isp_jobG.QTY < 0) & (df_l4_isp_jobA.VAL_INVG > 0),
                      (df_l4_isp_jobG.QTY) * (-1))
                .otherwise(lit(0)).alias('REQUIRED_QUANTITY'),
                when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                     (df_l4_isp_jobG.REF_QTY_KG > 0) & (df_l4_isp_jobA.VAL_INVG < 0),
                     (df_l4_isp_jobG.REF_QTY_KG) * (-1))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                      (df_l4_isp_jobG.REF_QTY_KG < 0) & (df_l4_isp_jobA.VAL_INVG > 0),
                      (df_l4_isp_jobG.REF_QTY_KG) * (-1))
                .otherwise(lit(0)).alias('NET_WEIGHT'),
                when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                     (df_l4_isp_jobG.REF_QTY_KG > 0) & (df_l4_isp_jobA.VAL_INVG < 0),
                     (df_l4_isp_jobG.REF_QTY_KG) * (-1))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                      (df_l4_isp_jobG.REF_QTY_KG < 0) & (df_l4_isp_jobA.VAL_INVG > 0),
                      (df_l4_isp_jobG.REF_QTY_KG) * (-1))
                .otherwise(lit(0)).alias('GROSS_WEIGHT'),
                (lit('KG')).alias('WEIGHT_UNIT'),
                when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                     (df_l4_isp_jobG.REF_QTY_KG > 0) & (df_l4_isp_jobA.VAL_INVG < 0),
                     (df_l4_isp_jobG.REF_QTY_L) * (-1))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                      (df_l4_isp_jobG.REF_QTY_KG < 0) & (df_l4_isp_jobA.VAL_INVG > 0),
                      (df_l4_isp_jobG.REF_QTY_L) * (-1))
                .otherwise(lit(0)).alias('VOLUME'),
                (lit('LT')).alias('VOLUME_UNIT'),
                lit(0).cast('double').alias('STD_VOLUME'),
                df_l4_isp_jobB.INV_DATE.alias('PRICING_DATE'),
                df_l4_isp_jobB.EXCH_RATE.alias('EXCHANGE_RATE'),
                df_l4_isp_jobA.VAL_INVG.alias('NET_VALUE'),
                df_l4_isp_jobA.DLVY_NOTE_NUM.alias('REFERENCE_DOCUMENT'),
                lit(' ').alias('REFERENCE_ITEM'),
                lit(' ').alias('PRECEDING_DOC_CATEG'),
                df_l4_isp_jobG.ORD_NUM.alias('SALES_DOCUMENT'),
                lit(' ').alias('SALES_DOCUMENT_ITEM'),
                df_l4_isp_jobA.MTL_ART_ID.alias('MATERIAL_NUMBER'),
                df_l4_isp_jobF.MNMC.alias('MATERIAL_MNMC'),
                df_l4_isp_jobA.ART_NAME.alias('MATERIAL_DESCRIPTION'),
                df_l4_isp_jobF.ART_TYPE_ID.alias('ITEM_CATEGORY'),
                df_l4_isp_jobG.FK_FUEL_POINT_ID_g.alias('SHIPPING_POINT_RECEIVING_PT'),
                when(df_l4_isp_jobG.FK_PORT_ID.isNotNull(), df_l4_isp_jobG.FK_PORT_ID)
                .when(df_l4_isp_jobB.FK_PORT_ID.isNotNull(), df_l4_isp_jobB.FK_PORT_ID)
                .when(df_l4_isp_jobH.FK_PORT_ID.isNotNull(), df_l4_isp_jobH.FK_PORT_ID)
                .otherwise(df_l4_isp_jobG.FK_LOC_OF_MVT_ID).alias('PLANT'),
                (lit('GR')).alias('COUNTRY'),
                df_l4_isp_jobB.WORK_GRP_ID.alias('SALES_OFFICE'),
                df_l4_isp_jobA.CRT_DATE_TIME.alias('LINE_CREATED_ON'),
                df_l4_isp_jobA.CRT_DATE_TIME.alias('LINE_TIME'),
                lit(' ').alias('EXCHANGE_RATE_STATS'),
                lit(' ').alias('PROFIT_CENTRE'),
                lit(' ').alias('PRICE_GROUP_ORDER'),
                lit(' ').alias('PRICE_LIST_ORD'),
                lit(' ').alias('ORDER_REASON'),
                lit(' ').alias('EXTERN_BOL_NO'),
                lit(' ').alias('CONTRACT_NR'),
                lit(' ').alias('REF_CONTRACTITM'),
                lit(' ').alias('PRICING_TIME'),
                lit(' ').alias('INV_CYCLE_IND'),
                lit(' ').alias('STANDARD_SUPPLY_LOC'),
                lit(' ').alias('STANDARD_REFINERY'),
                lit(' ').alias('VESSEL_NAME'),
                lit(' ').alias('TERM_TYPE'),
                df_l4_isp_jobA.FLIGHT_NUMBER.alias('FLIGHT_NUMBER'),
                lit(' ').alias('AIRCRAFT_TYPE_CODE'),
                df_l4_isp_jobA.ACRFT_REG_NUMBER.alias('AIRCRAFT_REGISTRATION'),
                lit(' ').alias('CONTR_DOC_TYPE'),
                when(df_l4_isp_jobG.FK_PORT_ID.isNotNull(), df_l4_isp_jobG.FK_PORT_ID)
                .when(df_l4_isp_jobB.FK_PORT_ID.isNotNull(), df_l4_isp_jobB.FK_PORT_ID)
                .when(df_l4_isp_jobH.FK_PORT_ID.isNotNull(), df_l4_isp_jobH.FK_PORT_ID)
                .otherwise(df_l4_isp_jobG.FK_LOC_OF_MVT_ID).alias('ORIGINAL_PLANT'),
                lit(' ').alias('SHP_TYPE_STAGE'),
                lit(' ').alias('BILLING_UNIT'),
                lit(' ').alias('PC_TYPE'),
                lit(' ').alias('SSR_PC_CATEGORY'),
                lit(' ').alias('CHANNEL_OF_TRADE'),
                lit(' ').alias('CONS_ASSGN'),
                lit(' ').alias('DISTRICT'),
                lit(' ').alias('MET_EVENT_TYPE'),
                df_l4_isp_jobB.EXCH_RATE.alias('AVERAGE_EXCH_RATE'),
                df_l4_isp_jobB.EXCH_RATE.alias('D_1_EXCHANGE_RATE'),
                df_l4_isp_jobB.EXCH_RATE.alias('C_EXCHANGE_RATE'),
                when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                     (df_l4_isp_jobG.REF_QTY_KG > 0) & (df_l4_isp_jobA.VAL_INVG < 0),
                     when(df_l4_isp_jobG.REF_QTY_KG.isNotNull(), df_l4_isp_jobG.REF_QTY_KG / 1000 * (-1))
                     .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']), df_l4_isp_jobG.LOC_WGHT * (-1))
                     .otherwise(df_l4_isp_jobG.LOC_WGHT / 1000 * (-1)))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                      (df_l4_isp_jobG.REF_QTY_KG < 0) & (df_l4_isp_jobA.VAL_INVG > 0),
                      when(df_l4_isp_jobG.REF_QTY_KG.isNotNull(), df_l4_isp_jobG.REF_QTY_KG / 1000 * (-1))
                      .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']), df_l4_isp_jobG.LOC_WGHT * (-1))
                      .otherwise(df_l4_isp_jobG.LOC_WGHT / 1000 * (-1)))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]),
                      when(df_l4_isp_jobG.REF_QTY_KG.isNotNull(), df_l4_isp_jobG.REF_QTY_KG / 1000)
                      .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']), df_l4_isp_jobG.LOC_WGHT)
                      .otherwise(df_l4_isp_jobG.LOC_WGHT / 1000))
                .otherwise(lit(0)).alias('METRIC_TONS'),

                when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                     (df_l4_isp_jobG.REF_QTY_L > 0) & (df_l4_isp_jobA.VAL_INVG < 0),
                     when(df_l4_isp_jobG.REF_QTY_L.isNotNull(), df_l4_isp_jobG.REF_QTY_L * (-1))
                     .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']), df_l4_isp_jobG.LOC_STD_VOL / 1000 * (-1))
                     .otherwise(df_l4_isp_jobG.LOC_STD_VOL * (-1)))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                      (df_l4_isp_jobG.REF_QTY_L < 0) & (df_l4_isp_jobA.VAL_INVG > 0),
                      when(df_l4_isp_jobG.REF_QTY_L.isNotNull(), df_l4_isp_jobG.REF_QTY_L * (-1))
                      .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']), df_l4_isp_jobG.LOC_STD_VOL / 1000 * (-1))
                      .otherwise(df_l4_isp_jobG.LOC_STD_VOL * (-1)))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]),
                      when(df_l4_isp_jobG.REF_QTY_KG.isNotNull(), df_l4_isp_jobG.REF_QTY_L)
                      .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']), df_l4_isp_jobG.LOC_STD_VOL / 1000)
                      .otherwise(df_l4_isp_jobG.LOC_STD_VOL))
                .otherwise(lit(0)).alias('LITRES'),

                when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                     (df_l4_isp_jobG.REF_QTY_L > 0) & (df_l4_isp_jobA.VAL_INVG < 0),
                     when(df_l4_isp_jobG.REF_QTY_L.isNotNull(), df_l4_isp_jobG.REF_QTY_L * (0.264172) * (-1))
                     .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']),
                           df_l4_isp_jobG.LOC_STD_VOL * (0.264172) / 1000 * (-1))
                     .otherwise(df_l4_isp_jobG.LOC_STD_VOL * (0.264172) * (-1)))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                      (df_l4_isp_jobG.REF_QTY_L < 0) & (df_l4_isp_jobA.VAL_INVG > 0),
                      when(df_l4_isp_jobG.REF_QTY_L.isNotNull(), df_l4_isp_jobG.REF_QTY_L * (0.264172) * (-1))
                      .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']),
                            df_l4_isp_jobG.LOC_STD_VOL * (0.264172) / 1000 * (-1))
                      .otherwise(df_l4_isp_jobG.LOC_STD_VOL * (0.264172) * (-1)))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]),
                      when(df_l4_isp_jobG.REF_QTY_KG.isNotNull(), df_l4_isp_jobG.REF_QTY_L * (0.264172))
                      .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']), df_l4_isp_jobG.LOC_STD_VOL * (0.264172) / 1000)
                      .otherwise(df_l4_isp_jobG.LOC_STD_VOL * (0.264172)))
                .otherwise(lit(0)).alias('UGL'),

                when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                     (df_l4_isp_jobG.REF_QTY_L > 0) & (df_l4_isp_jobA.VAL_INVG < 0),
                     when(df_l4_isp_jobG.REF_QTY_L.isNotNull(), df_l4_isp_jobG.REF_QTY_L / 1000 * (-1))
                     .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']), df_l4_isp_jobG.LOC_STD_VOL * (-1))
                     .otherwise(df_l4_isp_jobG.LOC_STD_VOL / 1000 * (-1)))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]) &
                      (df_l4_isp_jobG.REF_QTY_L < 0) & (df_l4_isp_jobA.VAL_INVG > 0),
                      when(df_l4_isp_jobG.REF_QTY_L.isNotNull(), df_l4_isp_jobG.REF_QTY_L / 1000 * (-1))
                      .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']), df_l4_isp_jobG.LOC_STD_VOL * (-1))
                      .otherwise(df_l4_isp_jobG.LOC_STD_VOL / 1000 * (-1)))
                .when(df_l4_isp_jobF.ART_TYPE_ID.isin([1, 3]),
                      when(df_l4_isp_jobG.REF_QTY_KG.isNotNull(), df_l4_isp_jobG.REF_QTY_L / 1000)
                      .when(df_l4_isp_jobE.MNMC.isin(['m3', 'm3s']), df_l4_isp_jobG.LOC_STD_VOL)
                      .otherwise(df_l4_isp_jobG.LOC_STD_VOL / 1000))
                .otherwise(lit(0)).alias('M3'),
                when(df_l4_isp_jobG.FK_CUST_ACCT_ID.isNotNull(), df_l4_isp_jobG.FK_CUST_ACCT_ID)
                .otherwise(df_l4_isp_jobG.FK_CUST_ACCT_ID).alias('SHIPTO_PARTY'),
                df_l4_isp_jobB.FK_INV_PT_ID.alias('BILLTO_PARTY'),
                when(df_l4_isp_jobG.FK_CAB_ID.isNotNull(), df_l4_isp_jobG.FK_CAB_ID)
                .otherwise(df_l4_isp_jobG.FK_CAB_ID).alias('SOLDTO_PARTY'),
                lit(' ').alias('PAYER'),
                lit(' ').alias('DESTINATION_AIRPORT'),
                lit(' ').alias('FINAL_DESTINATION_PARTNER'),
                lit(' ').alias('PARENT_PARTNER'),
                lit(' ').alias('VENDOR'),
                lit(' ').alias('SALES_REP'),
                lit(' ').alias('AGENT_ID'),
                df_l4_isp_jobA.ACTL_DLVY_DATE.alias('DELIVERY_DATE'),
                df_l4_isp_jobH.NAME.alias('FUEL_POINT_NAME'),
                df_l4_isp_jobG.FK_LOC_OF_MVT_ID.alias('LOCATION_ID'),
                lit(' ').alias('LOCATION_OF_SALE'))

    now = datetime.now()
    print("final_result_df", final_result_df.count(), now)
    # print("final_result_df", final_result_df.printSchema())

    return final_result_df


# main=========================================================== =========================================
print("******************************* starting the process************  aviation-dev-isp-l3-l4-fact-sales-billing-gr-hist ")
df_l4_isp_job_final = run_tfx_fact_sales_billing_gr_hist(l3_isp_inv_sales_line_all, l3_isp_inv_sales_all,
                                                         l3_isp_currency_all,
                                                         l3_isp_uom_oil_all, l3_isp_mtl_art_all,
                                                         l3_isp_conf_stk_mvt_all, l3_isp_fuel_point_all)

print("*************** : ", df_l4_isp_job_final.count())
report_path = destination + report + "/"
# write the data ====================================================================================================
df_l4_isp_job_final.write.option("compression", "gzip").mode('overwrite').parquet(report_path)
job.commit()