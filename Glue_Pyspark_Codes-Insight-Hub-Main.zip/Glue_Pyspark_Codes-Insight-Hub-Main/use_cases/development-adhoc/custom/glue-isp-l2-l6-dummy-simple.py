#Glue JOB
import sys
from awsglue.dynamicframe import DynamicFrame
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from pyspark.sql.types import StructType

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
args = getResolvedOptions(sys.argv,['JOB_NAME'])
job.init(args['JOB_NAME'], args)

""" This code is for Demo purpose"""
# variables
database_name = "transform_latest"
destination = "s3://ws00an-dst-dev-enrich/main/aviation/"

# report specific======================================================
l2_isp_work_grp_unique_instances = "l2_isp_work_grp_unique_instances"
report = "l6_dummy_simple"
""" This is for Demo """
# generic
countries = ["gr", "uk"]
country_map = {"gr": "esp6478", "uk": "esp6283"}
schema = StructType([])
final_result_df = spark.createDataFrame(spark.sparkContext.emptyRDD(), schema)


""" This is for demo # Rachit """

def union_dataframe(final_result_df, country_df):
    # union the dataframe
    if bool(final_result_df.head(1)):
        final_result_df = final_result_df.union(country_df)
    else:
        final_result_df = country_df
    return final_result_df


# function to apply tfx==============================================================================
def run_tfx_unique_instances(countries, table_generic, final_result_df):
    # start country wise process
    for country in countries:
        country_table = table_generic + "_" + country
        country_database = database_name + "_" + country_map[country]
        print("table name", country, country_table, country_database)
        # country_table_path = common_path + country_table

        # reading data from s3==========================================================================================================================
        df_l6_dummy = glueContext.create_dynamic_frame\
            .from_catalog(database=country_database, table_name=country_table).toDF()

        print("df_l6_dummy", df_l6_dummy.count())

        # applying transformation
        df_l6_dummy = df_l6_dummy.select(
            df_l6_dummy.ID,
            concat(df_l6_dummy.SOURCE_SYSTEM, lit('_'),
                   df_l6_dummy.ID).alias('REF_ID'),
            df_l6_dummy.NAME, df_l6_dummy.MNMC,
            df_l6_dummy.SOURCE_SYSTEM)
        # union with other countries
        print("completed the processing")
        final_result_df = union_dataframe(final_result_df, df_l6_dummy)

    return final_result_df


# main====================================================================================================
print("******************************* starting the process************  aviation-dev-isp-l2-l3-work-grp-unique-instances-all")
df_l6_dummy_simple_final = run_tfx_unique_instances(countries, l2_isp_work_grp_unique_instances,
                                                                     final_result_df)

print("*************** : ", df_l6_dummy_simple_final.count())
report_path = destination + report + "/"
print(report_path)
# write the data ====================================================================================================
df_l6_dummy_simple_final.write.option("compression", "snappy").mode('overwrite').parquet(report_path)
# ddf_l3_isp_work_grp_unique_instances_final = DynamicFrame
# .fromDF(df_l3_isp_work_grp_unique_instances_final, glueContext, "ddf_l3_isp_work_grp_unique_instances_final")
# sink = glueContext.getSink(connection_type="parquet", path=report_path, enableUpdateCatalog=True,
# updateBehavior="UPDATE_IN_DATABASE")
# sink.setCatalogInfo(catalogDatabase="conform_main_aviation", catalogTableName="l3_isp_work_grp_unique_instances_all")
# sink.writeFrame(ddf_l3_isp_work_grp_unique_instances_final)
job.commit()