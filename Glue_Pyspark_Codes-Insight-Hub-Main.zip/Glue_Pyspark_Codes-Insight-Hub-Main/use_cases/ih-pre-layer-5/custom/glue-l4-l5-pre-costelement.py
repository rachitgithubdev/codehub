# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Hasan Chaudhary 20-May-2021     Initial version
#  0.2              Liz Harvey      21-May-2021     
# =================================================================================================
# Description   :- The aim of the code is to generate l4-l5-pre-costelement into conform zone
# Author        :- Hasan Chaudhary
# Date          :- 24-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database1']
        self.netapp_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l5_pre_summary', 'l4_pre_fact_sales_pricing',
                                 'l4_pre_fact_sales_benchmark', 'l2_l5_dim_waterfall_global'
                                 ]
        self.report_file = "l5_pre_costelement"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
        #                                                                 self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # generate input table list
        source_database = self.source_database
        netapp_database = self.netapp_database
        input_table_list = self.input_table_list
        print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        df_summary = self._get_table(source_database, input_table_list[0]).toDF()
        # print("data count of table {}.{} is {}".format(source_database, input_table_list[0],
        #                                               df_summary.count()))
        df_pricing = self._get_table(source_database, input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(source_database, input_table_list[1],
        #                                               df_pricing.count()))
        df_benchmark = self._get_table(source_database, input_table_list[2]).toDF()
        # print("data count of table {}.{} is {}".format(source_database, input_table_list[2],
        #                                               df_benchmark.count()))
        df_waterfall = self._get_table(netapp_database, input_table_list[3]).toDF()

        # print("data count of table {}.{} is {}".format(netapp_database, input_table_list[3],
        #                                               df_waterfall.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_summary, df_pricing, df_benchmark, df_waterfall)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # MAIN LOGIC FOR SALES BENCHMARK CALCULATION  - Read data
        df_summary = args[0]
        df_pricing = args[1]
        df_benchmark = args[2]
        df_waterfall = args[3]

        df_a = df_pricing.alias("A").join(df_waterfall.alias("B"), f.trim(f.upper(f.col("A.condition_type"))) == f.trim(
            f.upper(f.col("B.condition_type")))) \
            .filter(~(f.trim(f.upper(f.col("B.hierarchy_level_5")))).isin('BUSINESS OVERHEADS',
                                                                          'BUSINESS DEPRECIATION',
                                                                          'TEMP CORRECTION')) \
            .select(f.col("B.hierarchy_level_5").alias("l5_hierarchy"),
                    f.col("B.hierarchy_level_4_key").alias("l4_hierarchy"),
                    f.col("B.hierarchy_level_3_key").alias("l3_hierarchy"),
                    f.col("B.hierarchy_level_2_key").alias("l2_hierarchy"),
                    f.col("B.hierarchy_level_1_key").alias("l1_hierarchy"),
                    (f.when(f.trim(f.upper(f.col("B.hierarchy_level_3_key"))) == "COST",
                            ((f.coalesce(f.col("condition_value_lc"), f.lit(0))) * -1).cast(DoubleType()))
                     .otherwise((f.coalesce(f.col("condition_value_lc"), f.lit(0))).cast(DoubleType()))).alias(
                        "value_lc"),
                    (f.when(f.trim(f.upper(f.col("B.hierarchy_level_3_key"))) == "COST",
                            ((f.coalesce(f.col("condition_value_gc"), f.lit(0))) * -1).cast(DoubleType()))
                     .otherwise((f.coalesce(f.col("condition_value_gc"), f.lit(0))).cast(DoubleType()))).alias(
                        "value_usd"),
                    f.concat(f.col("A.ref_id"), f.lit("_"), f.col("A.item_no").cast(StringType())).alias(
                        "cost_element_key"),
                    f.col("A.condition_type").alias("trx_wfh_key"),
                    ((f.current_timestamp()).cast(DateType())).alias("last_modified_date"))

        df_b = df_benchmark.alias("A").join(df_waterfall.alias("B"),
                                            f.trim(f.upper(f.col("A.condition_type"))) == f.trim(
                                                f.upper(f.col("B.condition_type")))) \
            .join(df_summary.alias("C"), f.concat(f.col("A.billing_document"), f.col("A.billing_item")) == f.concat(
                f.col("C.billing_document"), f.col("C.billing_item"))) \
            .filter((~(f.trim(f.upper(f.col("B.hierarchy_level_5")))).isin('BUSINESS OVERHEADS',
                                                                           'BUSINESS DEPRECIATION',
                                                                           'TEMP CORRECTION'))
                    & (f.col("A.condition_type") == "ZBCA")) \
            .select(f.col("B.hierarchy_level_5").alias("l5_hierarchy"),
                    f.col("B.hierarchy_level_4_key").alias("l4_hierarchy"),
                    f.col("B.hierarchy_level_3_key").alias("l3_hierarchy"),
                    f.col("B.hierarchy_level_2_key").alias("l2_hierarchy"),
                    f.col("B.hierarchy_level_1_key").alias("l1_hierarchy"),
                    (f.when(f.trim(f.upper(f.col("B.hierarchy_level_3_key"))) == "COST",
                            ((f.coalesce(f.col("amount_lc"), f.lit(0))) * -1).cast(DoubleType()))
                     .otherwise((f.coalesce(f.col("amount_lc"), f.lit(0))).cast(DoubleType()))).alias("value_lc"),
                    (f.when(f.trim(f.upper(f.col("B.hierarchy_level_3_key"))) == "COST",
                            ((f.coalesce(f.col("amount_gc"), f.lit(0))) * -1).cast(DoubleType()))
                     .otherwise((f.coalesce(f.col("amount_gc"), f.lit(0))).cast(DoubleType()))).alias("value_usd"),
                    f.col("C.cost_element_key").alias("cost_element_key"),
                    f.col("A.condition_type").alias("trx_wfh_key"),
                    ((f.current_timestamp()).cast(DateType())).alias("last_modified_date"))

        df_tfx_result = df_a.union(df_b)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()

