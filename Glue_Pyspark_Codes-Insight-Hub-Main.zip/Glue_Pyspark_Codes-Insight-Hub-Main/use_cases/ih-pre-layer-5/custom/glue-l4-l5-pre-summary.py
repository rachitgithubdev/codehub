# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Hasan Chaudhary 20-May-2021     Initial version
#  0.2              Hasan Chaudhary 11-June-2021    2.3,2.4 change of Foundry
# =================================================================================================
# Description   :- The aim of the code is to generate l4-l5-pre-summary into conform zone
# Author        :- Hasan Chaudhary
# Date          :- 20-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database1']
        self.netapp_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l4_pre_fact_sales_billing', 'l4_pre_fact_sales_pricing',
                                 'l4_pre_fact_sales_benchmark',
                                 'l4_dim_customer', 'l3_pre_vbak_sales_doc_header', 'l2_l5_dim_waterfall_global'
                                 ]
        self.report_file = "l5_pre_summary"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
        #                                                                 self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # generate input table list
        source_database = self.source_database
        netapp_database = self.netapp_database
        input_table_list = self.input_table_list
        print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        df_billing = self._get_table(source_database, input_table_list[0]).toDF()
        # print("data count of table {}.{} is {}".format(source_database, input_table_list[0],
        #                                               df_billing.count()))
        df_pricing = self._get_table(source_database, input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(source_database, input_table_list[1],
        #                                               df_pricing.count()))
        df_benchmark = self._get_table(source_database, input_table_list[2]).toDF()
        # print("data count of table {}.{} is {}".format(source_database, input_table_list[2],
        #                                               df_benchmark.count()))
        df_customer = self._get_table(source_database, input_table_list[3]).toDF()
        # print("data count of table {}.{} is {}".format(source_database, input_table_list[3],
        #                                               df_customer.count()))
        df_vbak = self._get_table(source_database, input_table_list[4]).toDF()

        # print("data count of table {}.{} is {}".format(source_database, input_table_list[4],
        #                                               df_vbak.count()))
        df_waterfall = self._get_table(netapp_database, input_table_list[5]).toDF()

        # print("data count of table {}.{} is {}".format(netapp_database, input_table_list[5],
        #                                               df_waterfall.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_billing, df_pricing, df_benchmark, df_customer, df_vbak, df_waterfall)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # MAIN LOGIC FOR SALES BENCHMARK CALCULATION  - Read data
        df_billing = args[0].filter((args[0].billing_category.isin(['B', 'C']) == False) &
                                    (args[0].sales_doc_category.isin(['M', 'N', 'O', 'P', 'S', 'U'])) &
                                    (args[0].inv_cycle_ind == 'X') &
                                    (args[0].pricing_procedure.isin(
                                        ['ZSSR04', 'ZSSR02', 'YCF000', 'YCF020', 'ZSSRR3', 'ZSSRR4', 'ZSSRR5',
                                         'ZSSRR7',
                                         'ZSSRR8', 'ZSSRR1', 'ZSSRR9', 'ZSSRRP', 'ZSSRRI', 'ZSSRRE', 'ZSSRRH',
                                         'ZSSR11',
                                         'YCF000', 'YCF020']) == False) &
                                    (args[0].posting_status.isin(['C', 'D', 'H'])) &
                                    (args[0].billing_type.isin(['ZCAR', 'ZNTD']) == False) &
                                    (f.concat(args[0].plant, args[0].soldto_party, args[0].sales_organisation).isin(
                                        ['5F440012391052FR01', '5F840012391054FR01', '5F850012391054FR01',
                                         '03240012391053FR01', '5F270012391053FR01',
                                         '5F280012391053FR01']) == False) &
                                    (args[0].billing_document.isin(
                                        ['4207000001', '4207000002', '4207000003', '4207000005']) == False)) \
            .select(args[0].aircraft_registration, args[0].flight_number, args[0].document_currency, args[0].net_value,
                    args[0].reference_document, args[0].billing_category,
                    args[0].sales_doc_category, args[0].met_event_type, args[0].inv_cycle_ind,
                    args[0].pricing_procedure, args[0].posting_status, args[0].pricing_date, args[0].billing_date,
                    f.when(args[0].soldto_party.isin(['0010000078', '0010023643', '0010023759']), f.lit('PT04'))
					.when(f.concat(args[0].soldto_party, args[0].sales_organisation).isin(['0010033900ES01']),f.lit('FR01'))
                    .when(f.concat(args[0].soldto_party, args[0].sales_organisation).isin(
                        ['0010022973ES01', '0010033924ES01', '0012001314GG08', '0010023650FR01']), f.lit('DE01'))
                    .otherwise(args[0].sales_organisation).alias('sales_organisation'),
                    args[0].plant, args[0].shipto_party, args[0].sales_document, args[0].material_number,
                    args[0].material_description, args[0].billing_document,
                    f.when(args[0].payer == '0010024701', f.lit('0012331735'))
                    .when(args[0].payer == '0012172227', f.lit('0012171784'))
                    .when(args[0].payer == '0010000303', f.lit('0012399266'))
                    .when(args[0].payer == '0010000147', f.lit('0012397823'))
                    .when(args[0].payer == '0012164015', f.lit('0012172218'))
                    .when(args[0].payer == '0010000596', f.lit('0012332714'))
                    .when(args[0].payer == '0010024216', f.lit('0012358204'))
                    .when(args[0].payer == '0010033924', f.lit('0012382213'))
                    .when(args[0].payer == '0012222503', f.lit('0012030307'))
                    .when(args[0].payer == '0012377928', f.lit('0012382087'))
                    .when(args[0].payer == '0012247203', f.lit('0010022507'))
                    .when(args[0].payer == '0050043273', f.lit('0050626926'))
                    .when(args[0].payer == '0050046547', f.lit('0050039501'))
                    .when(args[0].payer == '0050657919', f.lit('0050665031'))
                    .when(args[0].payer == '0050572188', f.lit('0050422383'))
                    .when(args[0].payer == '0050394971', f.lit('0050394160'))
                    .when(args[0].payer == '0050046691', f.lit('0050039857'))
                    .when(args[0].payer == '0050046650', f.lit('0050039867'))
                    .when(args[0].payer == '0050403612', f.lit('0012183398'))
                    .when(args[0].payer == '0050728417', f.lit('0010031841'))
                    .when(args[0].payer == '0050732170', f.lit('0030131236'))
                    .when(args[0].payer == '0030055391', f.lit('0030099467'))
                    .otherwise(args[0].payer).alias('payer'),
                    f.when(args[0].soldto_party == '0010024701', f.lit('0012331735'))
                    .when(args[0].soldto_party == '0012172227', f.lit('0012171784'))
                    .when(args[0].soldto_party == '0010000303', f.lit('0012399266'))
                    .when(args[0].soldto_party == '0010000147', f.lit('0012397823'))
                    .when(args[0].soldto_party == '0012164015', f.lit('0012172218'))
                    .when(args[0].soldto_party == '0010000596', f.lit('0012332714'))
                    .when(args[0].soldto_party == '0010024216', f.lit('0012358204'))
                    .when(args[0].soldto_party == '0010033924', f.lit('0012382213'))
                    .when(args[0].soldto_party == '0012222503', f.lit('0012030307'))
                    .when(args[0].soldto_party == '0012377928', f.lit('0012382087'))
                    .when(args[0].soldto_party == '0012247203', f.lit('0010022507'))
                    .when(args[0].soldto_party == '0012319383', f.lit('0012433434'))
                    .when(args[0].soldto_party == '0012194663', f.lit('0012434934'))
					.when(args[0].soldto_party == '0012427938', f.lit('0030135098'))
					.when(args[0].soldto_party == '0010000369', f.lit('0012441552'))
                    .otherwise(args[0].soldto_party).alias('soldto_party'),
                    args[0].local_currency, args[0].litres, args[0].m3, args[0].ugl, args[0].fk_doc_condition_no,
                    args[0].billing_item, args[0].ref_id,
                    f.when(args[0].billto_party == '0010024701', f.lit('0012331735'))
                    .when(args[0].billto_party == '0012172227', f.lit('0012171784'))
                    .when(args[0].billto_party == '0010000303', f.lit('0012399266'))
                    .when(args[0].billto_party == '0010000147', f.lit('0012397823'))
                    .when(args[0].billto_party == '0012164015', f.lit('0012172218'))
                    .when(args[0].billto_party == '0010000596', f.lit('0012332714'))
                    .when(args[0].billto_party == '0010024216', f.lit('0012358204'))
                    .when(args[0].billto_party == '0010033924', f.lit('0012382213'))
                    .when(args[0].billto_party == '0012222503', f.lit('0012030307'))
                    .when(args[0].billto_party == '0012377928', f.lit('0012382087'))
                    .when(args[0].billto_party == '0012247203', f.lit('0010022507'))
                    .when(args[0].billto_party == '0050035248', f.lit('0050626927'))
                    .when(args[0].billto_party == '0050572189', f.lit('0050422383'))
                    .when(args[0].billto_party == '0050657935', f.lit('0050665032'))
                    .when(args[0].billto_party == '0050394972', f.lit('0050394161'))
                    .when(args[0].billto_party == '0050224986', f.lit('0050155688'))
                    .when(args[0].billto_party == '0050732124', f.lit('0050732123'))
                    .when(args[0].billto_party == '0050242785', f.lit('0010022661'))
                    .when(args[0].billto_party == '0050682607', f.lit('0012392321'))
                    .when(args[0].billto_party == '0050707668', f.lit('0030051240'))
                    .when(args[0].billto_party == '0050035798', f.lit('0010023832'))
                    .when(args[0].billto_party == '0050709706', f.lit('0030059182'))
                    .when(args[0].billto_party == '0050103602', f.lit('0012000017'))
                    .when(args[0].billto_party == '0050732171', f.lit('0030131236'))
                    .when(args[0].billto_party == '0050728418', f.lit('0010031841'))
                    .when(args[0].billto_party == '0050392789', f.lit('0012171143'))
                    .when(args[0].billto_party == '0050628961', f.lit('0010022669'))
                    .when(args[0].billto_party == '0050403613', f.lit('0012183398'))
                    .when(args[0].billto_party == '0050705115', f.lit('0030125620'))
                    .when(args[0].billto_party == '0050403612', f.lit('0012183398'))
                    .when(args[0].billto_party == '0050728417', f.lit('0010031841'))
                    .when(args[0].billto_party == '0050732170', f.lit('0030131236'))
                    .when(args[0].billto_party == '0030055391', f.lit('0030099467'))
                    .otherwise(args[0].billto_party).alias('billto_party'), args[0].billing_type, args[0].delivery_method)

        df_soldto = args[3].filter((args[3].customer_group.isin(
            ['M&S Sold-to party customer IB ( ZMSI )', 'M&S Sold-to party customer ( ZMSP)', 'Natural Person (ZMAN)',
             'BP Group Company (Internal Customer) ( ZMIT)', 'BP Group Companies (E&P) (ZE04)'])) &
                                   (args[3].mdm_partner_id.isin(
                                       ['990020', '990019', '990022', '990021', '990023', '990025', '990011', '990024',
                                        '432366', '431053', '432366', '431053']) == False)) \
            .select(args[3].account_manager, args[3].erp_id, args[3].sales_organisation, args[3].customer_country,
                    args[3].grn_header,
                    args[3].customer_account_name, args[3].grn, args[3].cc_grn, args[3].sector,args[3].segment).distinct()

        df_payer = args[3].filter((args[3].customer_group.isin(
            ['Accounting Details (ZMPY)', 'BP Group Company Accounting Details (ZMCP)'])) &
                                  (args[3].mdm_partner_id.isin(
                                      ['990020', '990019', '990022', '990021', '990023', '990025', '990011', '990024',
                                       '432366', '431053', '432366', '431053']) == False)) \
            .select(args[3].account_manager, args[3].erp_id.alias('erp_id_payer'),
                    args[3].sales_organisation.alias('sales_organisation_payer'), args[3].customer_country,
                    args[3].grn_header,
                    args[3].customer_account_name, args[3].grn, args[3].cc_grn, args[3].sector).distinct()

        df_billto = args[3].filter((args[3].customer_group == 'Billing Details (ZMBI)') &
                                   (args[3].mdm_partner_id.isin(
                                       ['990020', '990019', '990022', '990021', '990023', '990025', '990011', '990024',
                                        '432366', '431053', '432366', '431053']) == False)) \
            .select(args[3].account_manager, args[3].erp_id.alias('erp_id_billto'),
                    args[3].sales_organisation.alias('sales_organisation_billto'), args[3].customer_country,
                    args[3].grn_header,
                    args[3].customer_account_name, args[3].grn, args[3].cc_grn, args[3].sector).distinct()

        

        df_tfx_result = df_billing.join(df_soldto, (df_billing.soldto_party == df_soldto.erp_id) & (
                    df_billing.sales_organisation == df_soldto.sales_organisation), 'left') \
            .join(df_payer, (df_billing.payer == df_payer.erp_id_payer) & (
                    df_billing.sales_organisation == df_payer.sales_organisation_payer), 'left') \
            .join(df_billto, (df_billing.billto_party == df_billto.erp_id_billto) & (
                    df_billing.sales_organisation == df_billto.sales_organisation_billto), 'left') \
            .select(df_billing.pricing_date.cast('date').alias('pricing_date'),
                    df_billing.billing_date.cast('date').alias('billing_date'),
                    df_billing.pricing_date.cast('date').alias('delivery_date'),
                    df_soldto.customer_country.alias('customer_country'),
                    df_soldto.grn_header.alias('grn_header'),
                    df_soldto.customer_account_name.alias('customer_account_name'),
                    df_soldto.grn.alias('grn'), df_soldto.cc_grn.alias('cc_grn'),
                    df_soldto.account_manager.alias('account_manager'), df_soldto.sector.alias('sector'),
					f.when(df_soldto.segment.isNull(), f.lit('NA'))
					 .otherwise(df_soldto.segment).alias('customer_segment'),
                    f.when(df_billing.billto_party.substr(f.lit(0), f.lit(3)).isin(['001', '003']),
                           df_soldto.customer_country)
                    .when(df_billto.customer_country.isNull(), df_soldto.customer_country)
                    .otherwise(df_billto.customer_country).alias('billto_customer_country'),
                    f.when(df_billing.billto_party.substr(f.lit(0), f.lit(3)).isin(['001', '003']),
                           df_soldto.grn_header)
                    .when(df_billto.grn_header.isNull(), df_soldto.grn_header)
                    .otherwise(df_billto.grn_header).alias('billto_grn_header'),
                    f.when(df_billing.billto_party.substr(f.lit(0), f.lit(3)).isin(['001', '003']),
                           df_soldto.customer_account_name)
                    .when(df_billto.customer_account_name.isNull(), df_soldto.customer_account_name)
                    .otherwise(df_billto.customer_account_name).alias('billto_customer_account_name'),
                    f.when(df_billing.billto_party.substr(f.lit(0), f.lit(3)).isin(['001', '003']), df_soldto.grn)
                    .when(df_billto.grn.isNull(), df_soldto.grn)
                    .otherwise(df_billto.grn).alias('billto_grn'),
                    f.when(df_billing.billto_party.substr(f.lit(0), f.lit(3)).isin(['001', '003']), df_soldto.cc_grn)
                    .when(df_billto.cc_grn.isNull(), df_soldto.cc_grn)
                    .otherwise(df_billto.cc_grn).alias('billto_cc_grn'),
                    df_soldto.account_manager.alias('billto_account_manager'), df_soldto.sector.alias('billto_sector'),
                    f.when(df_billing.payer.substr(f.lit(0), f.lit(3)).isin(['001', '003']), df_soldto.customer_country)
                    .when(df_payer.customer_country.isNull(), df_soldto.customer_country)
                    .otherwise(df_payer.customer_country).alias('payer_customer_country'),
                    f.when(df_billing.payer.substr(f.lit(0), f.lit(3)).isin(['001', '003']), df_soldto.grn_header)
                    .when(df_payer.grn_header.isNull(), df_soldto.grn_header)
                    .otherwise(df_payer.grn_header).alias('payer_grn_header'),
                    f.when(df_billing.payer.substr(f.lit(0), f.lit(3)).isin(['001', '003']),
                           df_soldto.customer_account_name)
                    .when(df_payer.customer_account_name.isNull(), df_soldto.customer_account_name)
                    .otherwise(df_payer.customer_account_name).alias('payer_customer_account_name'),
                    f.when(df_billing.payer.substr(f.lit(0), f.lit(3)).isin(['001', '003']), df_soldto.grn)
                    .when(df_payer.grn.isNull(), df_soldto.grn)
                    .otherwise(df_payer.grn).alias('payer_grn'),
                    f.when(df_billing.payer.substr(f.lit(0), f.lit(3)).isin(['001', '003']), df_soldto.cc_grn)
                    .when(df_payer.cc_grn.isNull(), df_soldto.grn)
                    .otherwise(df_payer.cc_grn).alias('payer_cc_grn'),
                    df_soldto.account_manager.alias('payer_account_manager'), df_soldto.sector.alias('payer_sector'),
                    f.lit('PRE').alias('source_system'), df_billing.sales_organisation.alias('sales_organisation'),
                    df_billing.sales_document.alias('sales_document'),
                    df_billing.reference_document.alias('delivery_number'),
                    df_billing.material_number.alias('material_number'),
                    df_billing.material_description.alias('material_description'),
                    df_billing.material_description.alias('local_material_description'),
                    df_billing.billing_document.alias('billing_document'),
                    df_billing.billing_item.cast('string').alias('billing_item'),
                    df_billing.local_currency.alias('local_currency'),
                    df_billing.billing_type.alias('billing_type'),
                    f.when(df_billing.billing_type.isin(['G2', 'L2', 'S2', 'ZD2', 'ZD3', 'ZDS1', 'ZDS2', 'ZDF']),
                           f.lit(0))
                    .otherwise(df_billing.m3).cast('double').alias('qty_in_m3'),
                    f.when(df_billing.billing_type.isin(['G2', 'L2', 'S2', 'ZD2', 'ZD3', 'ZDS1', 'ZDS2', 'ZDF']),
                           f.lit(0))
                    .otherwise(df_billing.ugl).cast('double').alias('qty_in_ugl'),
                    f.when(df_billing.billing_type.isin(['G2', 'L2', 'S2', 'ZD2', 'ZD3', 'ZDS1', 'ZDS2', 'ZDF']),
                           f.lit(0))
                    .otherwise(df_billing.litres).cast('double').alias('qty_in_litres'),
                    df_billing.net_value.cast('double').alias('net_value'),
                    df_billing.document_currency.alias('document_currency'),
                    df_billing.flight_number.alias('flight_number'),
                    df_billing.aircraft_registration.alias('aircraft_registration'),
                    f.concat(df_billing.fk_doc_condition_no,f.lit('_'), df_billing.billing_item.cast('string')).alias(
                        'cost_element_key'),
                    f.concat(df_billing.soldto_party, df_billing.sales_organisation).alias('trx_cust_key'),
                    f.concat(df_soldto.erp_id, df_billing.sales_organisation).alias('dim_cust_key'),
                    f.concat(df_billing.billto_party, df_billing.sales_organisation).alias('trx_billto_key'),
                    f.when(df_billing.billto_party.substr(f.lit(0), f.lit(3)).isin(['001', '003']),
                           f.concat(df_soldto.erp_id, df_soldto.sales_organisation))
                    .when(df_billing.billto_party.isin(
                        ['0050626927', '0050422383', '0050665032', '0050394161', '0050155688', '0050732123',
                         '0010022661', '0012392321', '0030051240', '0010023832', '0030059182', '0012000017',
                         '0030131236', '0010031841', '0012171143', '0010022669', '0012183398', '0030125620',
                         '0012183398', '0010031841', '0030131236']),
                          f.concat(df_billing.billto_party, df_billing.sales_organisation))
                    .otherwise(f.concat(df_billto.erp_id_billto, df_billto.sales_organisation_billto)).alias(
                        'dim_billto_key'),
                    f.concat(df_billing.payer, df_billing.sales_organisation).alias('trx_payer_key'),
                    f.when(df_billing.payer.substr(f.lit(0), f.lit(3)).isin(['001', '003']),
                           f.concat(df_soldto.erp_id, df_soldto.sales_organisation))
                    .when(df_billing.payer.isin(
                        ['0050626926', '0050039501', '0050665031', '0050422383', '0050394160', '0050039857',
                         '0050039867']), f.concat(df_billing.billto_party, df_billing.sales_organisation))
                    .otherwise(f.concat(df_payer.erp_id_payer, df_payer.sales_organisation_payer)).alias('dim_payer_key'),
                    df_billing.plant.alias('trx_loc_key'), df_billing.material_number.alias('trx_pro_key'),
                    df_billing.material_number.alias('dim_pro_key'),
                    df_billing.payer.alias('payer'), df_billing.billto_party.alias('billto_party'),
                    df_billing.soldto_party.alias('soldto_party'),
                    f.when(df_billing.material_number.substr(f.lit(1), f.lit(12)) == '000000000100',
                           f.when(df_billing.delivery_method.isin(['ZNTK', 'ZNTP', 'ZPCO', 'ZPEA', 'ZPRO', 'ZPRE']),
                                  f.lit('Into Plane'))
                           .when(df_billing.delivery_method.isin(['ZPE1', 'ZPEO', 'ZSSO', 'ZTSW']), f.lit('Bulk'))
                           .when(df_billing.delivery_method.isNull(), f.lit('NA'))
                           .otherwise(f.lit('NA')))
                    .otherwise(f.lit('NA')).alias('delivery_method'),
                    f.current_date().alias('last_modified_date'))

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
