# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1             Bakul Seth       29-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l42_isp_fact_sales_billing_cost_allocation into conform zone
# Author        :- Bakul Seth
# Date          :- 29-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class SunIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']
        self.environment = args['environment']

        # report specific =============================================
        self.input_tables = ['l41_isp_fact_sales_billing_cost_allocation_imi_s7',
                             'l41_isp_fact_sales_billing_cost_allocation_imi_s8', 'l3_isp_tput_recs_all',
                             'l41_isp_fact_sales_billing_cost_allocation_zamz_s2',
                             'l41_isp_fact_sales_billing_cost_allocation_mena_s6',
                             'l41_isp_fact_sales_billing_cost_allocation_al_s6',
                             'l41_isp_fact_sales_billing_cost_allocation_ro_s3',
                             'l41_isp_fact_sales_billing_cost_allocation_gr_s9',
                             'l41_isp_fact_sales_billing_cost_allocation_tr_s3',
                             'l41_isp_fact_sales_billing_cost_allocation_s1']
        self.report_file = 'l42_isp_fact_sales_billing_cost_allocation'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):

        # read data from country specific table argument passed(database, table)
        print('Reading data from input tabled {}.{}'.format(self.source_database,  self.input_tables))
        df_input_table = self._get_table(self.source_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('applying the transformations')
        df_tfx_table = self._apply_tfx(df_input_table)
        print('schema after transformation ', df_tfx_table.printSchema())

        # write final result to required destination
        print('Writing the results to desired location')
        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        target_dataset\
            .write.option('compression', 'snappy')\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name[0]))
        df_imi_s7 = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[0],
                                                               transformation_ctx='target_table').toDF()
        df_imi_s7.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[1]))
        df_imi_s8 = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[1],
                                                               transformation_ctx='target_table').toDF()
        df_imi_s8.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[2]))
        df_recs_all = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[2],
                                                                 transformation_ctx='target_table').toDF()
        df_recs_all.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[3]))
        df_zamz_s2 = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[3],
                                                                transformation_ctx='target_table').toDF()
        df_zamz_s2.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[4]))
        df_mena_s6 = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[4],
                                                                transformation_ctx='target_table').toDF()
        df_mena_s6.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[5]))
        df_al_s6 = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[5],
                                                              transformation_ctx='target_table').toDF()
        df_al_s6.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[6]))
        df_ro_s3 = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[6],
                                                              transformation_ctx='target_table').toDF()
        df_ro_s3.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[7]))
        df_gr_s9 = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[7],
                                                              transformation_ctx='target_table').toDF()
        df_gr_s9.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[8]))
        df_tr_s3 = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[8],
                                                              transformation_ctx='target_table').toDF()
        df_tr_s3.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[9]))
        df_s1 = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[9],
                                                           transformation_ctx='target_table').toDF()
        df_s1.printSchema()

        return [df_imi_s7, df_imi_s8, df_recs_all, df_zamz_s2, df_mena_s6, df_al_s6, df_ro_s3, df_gr_s9, df_tr_s3,
                df_s1]

    @staticmethod
    def _apply_tfx(df_input_table):

        # creating dataframe for different tables
        print('creating dataframe for different tables')
        imi_s7 = df_input_table[0]
        imi_s8 = df_input_table[1]
        recs_all = df_input_table[2]
        zamz_s2 = df_input_table[3]
        mena_s6 = df_input_table[4]
        al_s6 = df_input_table[5]
        ro_s3 = df_input_table[6]
        gr_s9 = df_input_table[7]
        tr_s3 = df_input_table[8]
        s1 = df_input_table[9]

        # Applying the transformation
        print('applying the transformations df_imi_s7')
        df_imi_s7 = imi_s7.filter(((imi_s7.country_mnmc.isin(["AL", "CH", "GB", "HR", "IE"]))
                                   & (imi_s7.customer_id != f.concat(imi_s7.source_system, f.lit('_ISP_TPUT_REC')))))\
            .select(
            imi_s7.ref_id, imi_s7.billing_document, imi_s7.source_system, imi_s7.billing_item, imi_s7.country_mnmc,
            imi_s7.sector, imi_s7.prod_grp, imi_s7.item_category, imi_s7.material_number, imi_s7.material_mnmc,
            imi_s7.airport_id, imi_s7.airport_mnmc, imi_s7.airport_name, imi_s7.customer_id, imi_s7.customer_number,
            imi_s7.customer_name, imi_s7.delivery_date, imi_s7.litres, imi_s7.ugl, imi_s7.billing_date,
            imi_s7.document_currency, imi_s7.local_currency, imi_s7.exchange_rate, imi_s7.ile_exch_rate,
            imi_s7.lre_exch_rate, imi_s7.net_value, imi_s7.lcl_net_val, imi_s7.lcl_adj_val,
            f.when(((imi_s7.country_mnmc == f.lit('HR')) & (imi_s7.material_number == f.lit('10001765146')) &
                    (imi_s7.delivery_date.between(f.to_date(f.lit('2019-07-01')), f.to_date(f.lit('2019-10-31'))))),
                   (imi_s7.lcl_cop_val - imi_s7.lcl_net_val)).otherwise(imi_s7.lcl_cop_val).alias('lcl_cop_val'),
            imi_s7.lcl_lag_val, imi_s7.lcl_cso_val, imi_s7.lcl_oic_val, imi_s7.lcl_oaf_val,
            f.when(((imi_s7.country_mnmc == f.lit('HR')) & (imi_s7.material_number == f.lit('10001765146'))),
                   (imi_s7.lcl_oav_val + imi_s7.lcl_net_val)).otherwise(imi_s7.lcl_oav_val).alias('lcl_oav_val'),
            imi_s7.lcl_paf_val, imi_s7.lcl_pav_val,
            f.when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10043711149')) &
                    (imi_s7.airport_mnmc == f.lit('EDI'))), imi_s7.lcl_net_val)
                .otherwise(f.lit(0).cast('double')).alias('lcl_zc59_val'),
            f.when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10001506374')) &
                    (imi_s7.airport_mnmc == f.lit('STN'))), imi_s7.lcl_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002297794')) &
                       (imi_s7.airport_mnmc == f.lit('BRS'))), imi_s7.lcl_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002716830')) &
                       (imi_s7.airport_mnmc.isin(['ABZ', 'EDI', 'GLA', 'STN']))), imi_s7.lcl_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002931478')) &
                        (imi_s7.airport_mnmc == f.lit('LGW'))), imi_s7.lcl_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002931485')) &
                       (imi_s7.airport_mnmc == f.lit('MAN'))), imi_s7.lcl_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10005392887')) &
                       (imi_s7.airport_mnmc == f.lit('LHR'))), imi_s7.lcl_net_val)
                .otherwise(f.lit(0).cast('double')).alias('lcl_zc65_val'),
            f.when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10000596111'))),
                   imi_s7.lcl_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10000620090'))),
                      imi_s7.lcl_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10001765360')) &
                       (imi_s7.airport_mnmc.isin(['EDI', 'GLA']))), imi_s7.lcl_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002907813')) &
                       (imi_s7.airport_mnmc == f.lit('LHR'))), imi_s7.lcl_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10036751763')) &
                       (imi_s7.airport_mnmc == f.lit('BHD'))),imi_s7.lcl_net_val)
                .otherwise(f.lit(0).cast('double')).alias('lcl_zc66_val'),
            f.when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002907805')) &
                    (imi_s7.airport_mnmc == f.lit('LHR'))), imi_s7.lcl_net_val)
                .otherwise(f.lit(0).cast('double')).alias('lcl_zc69_val'),
            f.when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10010966644')) &
                    (imi_s7.airport_mnmc.isin(['EDI', 'GLA']))), imi_s7.lcl_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002002984')) &
                       (imi_s7.airport_mnmc.isin(['BOH', 'BR9', 'BF9']))), imi_s7.lcl_net_val)
                .otherwise(f.lit(0).cast('double')).alias('lcl_zc73_val'),
            imi_s7.usd_net_val, imi_s7.usd_adj_val,
            f.when(((imi_s7.country_mnmc == f.lit('HR')) & (imi_s7.material_number == f.lit('10001765146')) &
                    (imi_s7.delivery_date.between(f.to_date(f.lit('2019-07-01')), f.to_date(f.lit('2019-10-31'))))),
                   (imi_s7.usd_cop_val - imi_s7.usd_net_val)).otherwise(imi_s7.usd_cop_val).alias('usd_cop_val'),
            imi_s7.usd_lag_val, imi_s7.usd_cso_val, imi_s7.usd_oic_val, imi_s7.usd_oaf_val,
            f.when(((imi_s7.country_mnmc == f.lit('HR')) & (imi_s7.material_number == f.lit('10001765146'))),
                   (imi_s7.usd_oav_val + imi_s7.usd_net_val)).otherwise(imi_s7.usd_oav_val).alias('usd_oav_val'),
            imi_s7.usd_paf_val, imi_s7.usd_pav_val,
            f.when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10043711149')) &
                    (imi_s7.airport_mnmc == f.lit('EDI'))), imi_s7.usd_net_val)
                .otherwise(f.lit(0).cast('double')).alias('usd_zc59_val'),
            f.when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10001506374')) &
                    (imi_s7.airport_mnmc == f.lit('STN'))), imi_s7.usd_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002297794')) &
                       (imi_s7.airport_mnmc == f.lit('BRS'))), imi_s7.usd_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002716830')) &
                       (imi_s7.airport_mnmc.isin(['ABZ', 'EDI', 'GLA', 'STN']))), imi_s7.usd_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002931478')) &
                       (imi_s7.airport_mnmc == f.lit('LGW'))), imi_s7.usd_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002931485')) &
                       (imi_s7.airport_mnmc == f.lit('MAN'))), imi_s7.usd_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10005392887')) &
                       (imi_s7.airport_mnmc == f.lit('LHR'))), imi_s7.usd_net_val)
                .otherwise(f.lit(0).cast('double')).alias('usd_zc65_val'),
            f.when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10000596111'))),
                   imi_s7.usd_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10000620090'))),
                      imi_s7.usd_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10001765360')) &
                       (imi_s7.airport_mnmc.isin(['EDI', 'GLA']))), imi_s7.usd_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002907813')) &
                       (imi_s7.airport_mnmc == f.lit('LHR'))), imi_s7.usd_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10036751763')) &
                       (imi_s7.airport_mnmc == f.lit('BHD'))), imi_s7.usd_net_val)
                .otherwise(f.lit(0).cast('double')).alias('usd_zc66_val'),
            f.when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002907805')) &
                    (imi_s7.airport_mnmc == f.lit('LHR'))), imi_s7.usd_net_val)
                .otherwise(f.lit(0).cast('double')).alias('usd_zc69_val'),
            f.when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10010966644')) &
                    (imi_s7.airport_mnmc.isin(['EDI', 'GLA']))), imi_s7.usd_net_val)
                .when(((imi_s7.country_mnmc == f.lit('GB')) & (imi_s7.material_number == f.lit('10002002984')) &
                       (imi_s7.airport_mnmc.isin(['BOH', 'BR9', 'BF9']))), imi_s7.usd_net_val)
                .otherwise(f.lit(0).cast('double')).alias('usd_zc73_val'))

        df_imi_s7.printSchema()
        print(df_imi_s7.count())

        print('applying the transformations df_imi_s8')
        df_imi_s8 = imi_s8.filter(imi_s8.customer_id != f.concat(imi_s8.source_system, f.lit('_ISP_TPUT_REC'))).select(
            imi_s8.ref_id, imi_s8.billing_document, imi_s8.source_system, imi_s8.billing_item, imi_s8.country_mnmc,
            imi_s8.sector, imi_s8.prod_grp, imi_s8.item_category, imi_s8.material_number, imi_s8.material_mnmc,
            imi_s8.airport_id, imi_s8.airport_mnmc, imi_s8.airport_name, imi_s8.customer_id, imi_s8.customer_number,
            imi_s8.customer_name, imi_s8.delivery_date, imi_s8.litres, imi_s8.ugl, imi_s8.billing_date,
            imi_s8.document_currency, imi_s8.local_currency, imi_s8.exchange_rate, imi_s8.ile_exch_rate,
            imi_s8.lre_exch_rate, imi_s8.net_value, imi_s8.lcl_net_val,
            f.when(((imi_s8.country_mnmc == f.lit('CY')) & (imi_s8.material_number == f.lit('10004286641'))),
                   (imi_s8.lcl_adj_val - imi_s8.lcl_net_val))
                .when(((imi_s8.country_mnmc == f.lit('CY')) & (imi_s8.material_number == f.lit('10006203383'))),
                      (imi_s8.lcl_adj_val - imi_s8.lcl_net_val))
                .when(((imi_s8.country_mnmc == f.lit('CY')) & (imi_s8.material_number == f.lit('10023430149'))),
                      (imi_s8.lcl_adj_val - imi_s8.lcl_net_val))
                .when(((imi_s8.country_mnmc == f.lit('CY')) & (imi_s8.material_number == f.lit('10002297801'))),
                      (imi_s8.lcl_adj_val - imi_s8.lcl_net_val))
            .otherwise(imi_s8.lcl_adj_val).alias('lcl_adj_val'),
            imi_s8.lcl_cop_val, imi_s8.lcl_lag_val, imi_s8.lcl_cso_val, imi_s8.lcl_oic_val, imi_s8.lcl_oaf_val,
            imi_s8.lcl_oav_val, imi_s8.lcl_paf_val, imi_s8.lcl_pav_val, f.lit(0).cast('double').alias('lcl_zc59_val'),
            f.lit(0).cast('double').alias('lcl_zc65_val'), f.lit(0).cast('double').alias('lcl_zc66_val'),
            f.lit(0).cast('double').alias('lcl_zc69_val'), f.lit(0).cast('double').alias('lcl_zc73_val'),
            imi_s8.usd_net_val,
            f.when(((imi_s8.country_mnmc == f.lit('cy')) & (imi_s8.material_number == f.lit('10004286641'))),
                   (imi_s8.usd_adj_val - imi_s8.usd_net_val))
                .when(((imi_s8.country_mnmc == f.lit('cy')) & (imi_s8.material_number == f.lit('10006203383'))),
                      (imi_s8.usd_adj_val - imi_s8.usd_net_val))
                .when(((imi_s8.country_mnmc == f.lit('cy')) & (imi_s8.material_number == f.lit('10023430149'))),
                      (imi_s8.usd_adj_val - imi_s8.usd_net_val))
                .when(((imi_s8.country_mnmc == f.lit('cy')) & (imi_s8.material_number == f.lit('10002297801'))),
                      (imi_s8.usd_adj_val - imi_s8.usd_net_val))
            .otherwise(imi_s8.usd_adj_val).alias('usd_adj_val'),
            imi_s8.usd_cop_val, imi_s8.usd_lag_val, imi_s8.usd_cso_val, imi_s8.usd_oic_val, imi_s8.usd_oaf_val,
            imi_s8.usd_oav_val, imi_s8.usd_paf_val, imi_s8.usd_pav_val, f.lit(0).cast('double').alias('usd_zc59_val'),
            f.lit(0).cast('double').alias('usd_zc65_val'), f.lit(0).cast('double').alias('usd_zc66_val'),
            f.lit(0).cast('double').alias('usd_zc69_val'), f.lit(0).cast('double').alias('usd_zc73_val'))

        df_imi_s8.printSchema()
        print(df_imi_s8.count())

        df_imi_s72 = imi_s7.join(recs_all, (f.last_day(imi_s7.delivery_date) == recs_all.period) &
                                 (imi_s7.airport_mnmc == recs_all.location), 'left').\
            filter(imi_s7.customer_id == f.concat(imi_s7.source_system, f.lit('_ISP_TPUT_REC'))).select(
            imi_s7.ref_id, imi_s7.billing_document, imi_s7.source_system, imi_s7.billing_item, imi_s7.country_mnmc,
            imi_s7.sector, imi_s7.prod_grp, imi_s7.item_category, imi_s7.material_number, imi_s7.material_mnmc,
            imi_s7.airport_id, imi_s7.airport_mnmc, imi_s7.airport_name, imi_s7.customer_id, imi_s7.customer_number,
            imi_s7.customer_name, imi_s7.delivery_date, imi_s7.litres, imi_s7.ugl, imi_s7.billing_date,
            imi_s7.document_currency, imi_s7.local_currency, imi_s7.exchange_rate, imi_s7.ile_exch_rate,
            imi_s7.lre_exch_rate, imi_s7.net_value, imi_s7.lcl_net_val, imi_s7.lcl_adj_val, imi_s7.lcl_cop_val,
            imi_s7.lcl_lag_val, imi_s7.lcl_cso_val, (imi_s7.lcl_oic_val + recs_all.tput_rec_value).alias('lcl_oic_val'),
            imi_s7.lcl_oaf_val, imi_s7.lcl_oav_val, imi_s7.lcl_paf_val, imi_s7.lcl_pav_val,
            f.lit(0).cast('double').alias('lcl_zc59_val'), f.lit(0).cast('double').alias('lcl_zc65_val'),
            f.lit(0).cast('double').alias('lcl_zc66_val'), f.lit(0).cast('double').alias('lcl_zc69_val'),
            f.lit(0).cast('double').alias('lcl_zc73_val'), imi_s7.usd_net_val, imi_s7.usd_adj_val, imi_s7.usd_cop_val,
            imi_s7.usd_lag_val, imi_s7.usd_cso_val, (imi_s7.usd_oic_val + recs_all.tput_rec_value).alias('usd_oic_val'),
            imi_s7.usd_oaf_val, imi_s7.usd_oav_val, imi_s7.usd_paf_val, imi_s7.usd_pav_val,
            f.lit(0).cast('double').alias('usd_zc59_val'), f.lit(0).cast('double').alias('usd_zc65_val'),
            f.lit(0).cast('double').alias('usd_zc66_val'), f.lit(0).cast('double').alias('usd_zc69_val'),
            f.lit(0).cast('double').alias('usd_zc73_val'))

        df_imi_s72.printSchema()
        print(df_imi_s72.count())

        print('applying the transformations df_zamz_s2')
        df_zamz_s2 = zamz_s2.select(
            zamz_s2.ref_id, zamz_s2.billing_document, zamz_s2.source_system, zamz_s2.billing_item, zamz_s2.country_mnmc,
            zamz_s2.sector, zamz_s2.prod_grp, zamz_s2.item_category, zamz_s2.material_number, zamz_s2.material_mnmc,
            zamz_s2.airport_id, zamz_s2.airport_mnmc, zamz_s2.airport_name, zamz_s2.customer_id,
            zamz_s2.customer_number, zamz_s2.customer_name, zamz_s2.delivery_date, zamz_s2.litres, zamz_s2.ugl,
            zamz_s2.billing_date, zamz_s2.document_currency, zamz_s2.local_currency, zamz_s2.exchange_rate,
            zamz_s2.ile_exch_rate, zamz_s2.lre_exch_rate, zamz_s2.net_value, zamz_s2.lcl_net_val,
            f.when(zamz_s2.material_number == f.lit('7500290681887'), (zamz_s2.lcl_adj_val - zamz_s2.lcl_net_val))
                .when(zamz_s2.material_number == f.lit('7500290681885'), (zamz_s2.lcl_adj_val - zamz_s2.lcl_net_val))
                .when(zamz_s2.material_number == f.lit('7500290682614'), (zamz_s2.lcl_adj_val - zamz_s2.lcl_net_val))
                .when(zamz_s2.material_number == f.lit('7500162236366'), (zamz_s2.lcl_adj_val - zamz_s2.lcl_net_val))
                .when(zamz_s2.material_number == f.lit('7500162225086'), (zamz_s2.lcl_adj_val - zamz_s2.lcl_net_val))
                .when(zamz_s2.material_number == f.lit('7500226395405'), (zamz_s2.lcl_adj_val - zamz_s2.lcl_net_val))
                .otherwise(zamz_s2.lcl_adj_val).alias('lcl_adj_val'),
            zamz_s2.lcl_cop_val, zamz_s2.lcl_lag_val, zamz_s2.lcl_cso_val, zamz_s2.lcl_oic_val, zamz_s2.lcl_oaf_val,
            zamz_s2.lcl_oav_val, zamz_s2.lcl_paf_val, zamz_s2.lcl_pav_val,
            f.lit(0).cast('double').alias('lcl_zc59_val'), f.lit(0).cast('double').alias('lcl_zc65_val'),
            f.lit(0).cast('double').alias('lcl_zc66_val'), f.lit(0).cast('double').alias('lcl_zc69_val'),
            f.lit(0).cast('double').alias('lcl_zc73_val'), zamz_s2.usd_net_val,
            f.when(zamz_s2.material_number == f.lit('7500290681887'), (zamz_s2.usd_adj_val - zamz_s2.usd_net_val))
                .when(zamz_s2.material_number == f.lit('7500290681885'), (zamz_s2.usd_adj_val - zamz_s2.usd_net_val))
                .when(zamz_s2.material_number == f.lit('7500290682614'), (zamz_s2.usd_adj_val - zamz_s2.usd_net_val))
                .when(zamz_s2.material_number == f.lit('7500162236366'), (zamz_s2.usd_adj_val - zamz_s2.usd_net_val))
                .when(zamz_s2.material_number == f.lit('7500162225086'), (zamz_s2.usd_adj_val - zamz_s2.usd_net_val))
                .when(zamz_s2.material_number == f.lit('7500226395405'), (zamz_s2.usd_adj_val - zamz_s2.usd_net_val))
                .otherwise(zamz_s2.usd_adj_val).alias('usd_adj_val'),
            zamz_s2.usd_cop_val, zamz_s2.usd_lag_val, zamz_s2.usd_cso_val, zamz_s2.usd_oic_val, zamz_s2.usd_oaf_val,
            zamz_s2.usd_oav_val, zamz_s2.usd_paf_val, zamz_s2.usd_pav_val,
            f.lit(0).cast('double').alias('usd_zc59_val'), f.lit(0).cast('double').alias('usd_zc65_val'),
            f.lit(0).cast('double').alias('usd_zc66_val'), f.lit(0).cast('double').alias('usd_zc69_val'),
            f.lit(0).cast('double').alias('usd_zc73_val'))

        df_zamz_s2.printSchema()
        print(df_zamz_s2.count())

        print('applying the transformations df_mena_s6')
        df_mena_s6 = mena_s6.select(
            mena_s6.ref_id, mena_s6.billing_document, mena_s6.source_system, mena_s6.billing_item, mena_s6.country_mnmc,
            mena_s6.sector, mena_s6.prod_grp, mena_s6.item_category, mena_s6.material_number, mena_s6.material_mnmc,
            mena_s6.airport_id, mena_s6.airport_mnmc, mena_s6.airport_name, mena_s6.customer_id,
            mena_s6.customer_number, mena_s6.customer_name, mena_s6.delivery_date, mena_s6.litres, mena_s6.ugl,
            mena_s6.billing_date, mena_s6.document_currency, mena_s6.local_currency, mena_s6.exchange_rate,
            mena_s6.ile_exch_rate, mena_s6.lre_exch_rate, mena_s6.net_value, mena_s6.lcl_net_val, mena_s6.lcl_adj_val,
            mena_s6.lcl_cop_val, mena_s6.lcl_lag_val, mena_s6.lcl_cso_val, mena_s6.lcl_oic_val, mena_s6.lcl_oaf_val,
            mena_s6.lcl_oav_val, mena_s6.lcl_paf_val, mena_s6.lcl_pav_val,
            f.lit(0).cast('double').alias('lcl_zc59_val'), f.lit(0).cast('double').alias('lcl_zc65_val'),
            f.lit(0).cast('double').alias('lcl_zc66_val'), f.lit(0).cast('double').alias('lcl_zc69_val'),
            f.lit(0).cast('double').alias('lcl_zc73_val'), mena_s6.usd_net_val, mena_s6.usd_adj_val,
            mena_s6.usd_cop_val, mena_s6.usd_lag_val, mena_s6.usd_cso_val, mena_s6.usd_oic_val, mena_s6.usd_oaf_val,
            mena_s6.usd_oav_val, mena_s6.usd_paf_val, mena_s6.usd_pav_val,
            f.lit(0).cast('double').alias('usd_zc59_val'), f.lit(0).cast('double').alias('usd_zc65_val'),
            f.lit(0).cast('double').alias('usd_zc66_val'), f.lit(0).cast('double').alias('usd_zc69_val'),
            f.lit(0).cast('double').alias('usd_zc73_val'))
        df_mena_s6.printSchema()
        print(df_mena_s6.count())

        print('applying the transformations df_al_s6')
        df_al_s6 = al_s6.select(
            al_s6.ref_id, al_s6.billing_document, al_s6.source_system, al_s6.billing_item, al_s6.country_mnmc, al_s6.sector,
            al_s6.prod_grp, al_s6.item_category, al_s6.material_number, al_s6.material_mnmc, al_s6.airport_id,
            al_s6.airport_mnmc, al_s6.airport_name, al_s6.customer_id, al_s6.customer_number, al_s6.customer_name,
            al_s6.delivery_date, al_s6.litres, al_s6.ugl, al_s6.billing_date, al_s6.document_currency,
            al_s6.local_currency, al_s6.exchange_rate, al_s6.ile_exch_rate, al_s6.lre_exch_rate, al_s6.net_value,
            al_s6.lcl_net_val, al_s6.lcl_adj_val,
            f.when(((al_s6.country_mnmc == f.lit('AL')) & (al_s6.material_number == f.lit('10001765146')) &
                    (al_s6.delivery_date.between(f.to_date(f.lit('2018-01-01')), f.to_date(f.lit('2020-04-30'))))),
                   (al_s6.lcl_cop_val - al_s6.lcl_net_val)).otherwise(al_s6.lcl_cop_val).alias('lcl_cop_val'),
            al_s6.lcl_lag_val, al_s6.lcl_cso_val, al_s6.lcl_oic_val, al_s6.lcl_oaf_val,
            f.when(((al_s6.country_mnmc == f.lit('AL')) & (al_s6.material_number == f.lit('10001765146'))),
                   (al_s6.lcl_oav_val + al_s6.lcl_net_val)).otherwise(al_s6.lcl_oav_val).alias('lcl_oav_val'),
            al_s6.lcl_paf_val, al_s6.lcl_pav_val,
            f.lit(0).cast('double').alias('lcl_zc59_val'), f.lit(0).cast('double').alias('lcl_zc65_val'),
            f.lit(0).cast('double').alias('lcl_zc66_val'), f.lit(0).cast('double').alias('lcl_zc69_val'),
            f.lit(0).cast('double').alias('lcl_zc73_val'), al_s6.usd_net_val, al_s6.usd_adj_val,
            f.when(((al_s6.country_mnmc == f.lit('AL')) & (al_s6.material_number == f.lit('10001765146')) &
                    (al_s6.delivery_date.between(f.to_date(f.lit('2018-01-01')), f.to_date(f.lit('2020-04-30'))))),
                   (al_s6.usd_cop_val - al_s6.usd_net_val)).otherwise(al_s6.usd_cop_val).alias('usd_cop_val'),
            al_s6.usd_lag_val, al_s6.usd_cso_val, al_s6.usd_oic_val, al_s6.usd_oaf_val,
            f.when(((al_s6.country_mnmc == f.lit('AL')) & (al_s6.material_number == f.lit('10001765146'))),
                   (al_s6.usd_oav_val + al_s6.usd_net_val)).otherwise(al_s6.usd_oav_val).alias('usd_oav_val'),
            al_s6.usd_paf_val, al_s6.usd_pav_val, f.lit(0).cast('double').alias('usd_zc59_val'),
            f.lit(0).cast('double').alias('usd_zc65_val'), f.lit(0).cast('double').alias('usd_zc66_val'),
            f.lit(0).cast('double').alias('usd_zc69_val'), f.lit(0).cast('double').alias('usd_zc73_val'))

        df_al_s6.printSchema()
        print(df_al_s6.count())

        print('applying the transformations df_ro_s3')
        df_ro_s3 = ro_s3.select(
            ro_s3.ref_id, ro_s3.billing_document, ro_s3.source_system, ro_s3.billing_item, ro_s3.country_mnmc,
            ro_s3.sector, ro_s3.prod_grp, ro_s3.item_category, ro_s3.material_number, ro_s3.material_mnmc,
            ro_s3.airport_id, ro_s3.airport_mnmc, ro_s3.airport_name, ro_s3.customer_id, ro_s3.customer_number,
            ro_s3.customer_name, ro_s3.delivery_date, ro_s3.litres, ro_s3.ugl, ro_s3.billing_date,
            ro_s3.document_currency, ro_s3.local_currency, ro_s3.exchange_rate, ro_s3.ile_exch_rate,
            ro_s3.lre_exch_rate, ro_s3.net_value, ro_s3.lcl_net_val, ro_s3.lcl_adj_val, ro_s3.lcl_cop_val,
            ro_s3.lcl_lag_val, ro_s3.lcl_cso_val, ro_s3.lcl_oic_val, ro_s3.lcl_oaf_val, ro_s3.lcl_oav_val,
            ro_s3.lcl_paf_val, ro_s3.lcl_pav_val,
            f.lit(0).cast('double').alias('lcl_zc59_val'), f.lit(0).cast('double').alias('lcl_zc65_val'),
            f.lit(0).cast('double').alias('lcl_zc66_val'), f.lit(0).cast('double').alias('lcl_zc69_val'),
            f.lit(0).cast('double').alias('lcl_zc73_val'), ro_s3.usd_net_val, ro_s3.usd_adj_val, ro_s3.usd_cop_val,
            ro_s3.usd_lag_val, ro_s3.usd_cso_val, ro_s3.usd_oic_val, ro_s3.usd_oaf_val, ro_s3.usd_oav_val,
            ro_s3.usd_paf_val, ro_s3.usd_pav_val,f.lit(0).cast('double').alias('usd_zc59_val'),
            f.lit(0).cast('double').alias('usd_zc65_val'), f.lit(0).cast('double').alias('usd_zc66_val'),
            f.lit(0).cast('double').alias('usd_zc69_val'), f.lit(0).cast('double').alias('usd_zc73_val'))

        df_ro_s3.printSchema()

        print('applying the transformations df_gr_s9')
        df_gr_s9 = gr_s9.select(
            gr_s9.ref_id, gr_s9.billing_document, gr_s9.source_system, gr_s9.billing_item, gr_s9.country_mnmc,
            gr_s9.sector, gr_s9.prod_grp, gr_s9.item_category, gr_s9.material_number, gr_s9.material_mnmc,
            gr_s9.airport_id, gr_s9.airport_mnmc, gr_s9.airport_name, gr_s9.customer_id, gr_s9.customer_number,
            gr_s9.customer_name, gr_s9.delivery_date, gr_s9.litres, gr_s9.ugl, gr_s9.billing_date,
            gr_s9.document_currency, gr_s9.local_currency, gr_s9.exchange_rate, gr_s9.ile_exch_rate,
            gr_s9.lre_exch_rate, gr_s9.net_value, gr_s9.lcl_net_val, gr_s9.lcl_adj_val, gr_s9.lcl_cop_val,
            gr_s9.lcl_lag_val, gr_s9.lcl_cso_val, gr_s9.lcl_oic_val, gr_s9.lcl_oaf_val, gr_s9.lcl_oav_val,
            gr_s9.lcl_paf_val, gr_s9.lcl_pav_val, f.lit(0).cast('double').alias('lcl_zc59_val'),
            f.lit(0).cast('double').alias('lcl_zc65_val'), f.lit(0).cast('double').alias('lcl_zc66_val'),
            f.lit(0).cast('double').alias('lcl_zc69_val'), f.lit(0).cast('double').alias('lcl_zc73_val'),
            gr_s9.usd_net_val, gr_s9.usd_adj_val, gr_s9.usd_cop_val, gr_s9.usd_lag_val, gr_s9.usd_cso_val,
            gr_s9.usd_oic_val, gr_s9.usd_oaf_val, gr_s9.usd_oav_val, gr_s9.usd_paf_val, gr_s9.usd_pav_val,
            f.lit(0).cast('double').alias('usd_zc59_val'), f.lit(0).cast('double').alias('usd_zc65_val'),
            f.lit(0).cast('double').alias('usd_zc66_val'), f.lit(0).cast('double').alias('usd_zc69_val'),
            f.lit(0).cast('double').alias('usd_zc73_val'))
        df_gr_s9.printSchema()

        print('applying the transformations df_tr_s3')
        df_tr_s3 = tr_s3.select(
            tr_s3.ref_id, tr_s3.billing_document, tr_s3.source_system, tr_s3.billing_item, tr_s3.country_mnmc,
            tr_s3.sector, tr_s3.prod_grp, tr_s3.item_category, tr_s3.material_number, tr_s3.material_mnmc,
            tr_s3.airport_id, tr_s3.airport_mnmc, tr_s3.airport_name, tr_s3.customer_id, tr_s3.customer_number,
            tr_s3.customer_name, tr_s3.delivery_date, tr_s3.litres, tr_s3.ugl, tr_s3.billing_date,
            tr_s3.document_currency, tr_s3.local_currency, tr_s3.exchange_rate, tr_s3.ile_exch_rate,
            tr_s3.lre_exch_rate, tr_s3.net_value, tr_s3.lcl_net_val, tr_s3.lcl_adj_val, tr_s3.lcl_cop_val,
            tr_s3.lcl_lag_val, tr_s3.lcl_cso_val, tr_s3.lcl_oic_val, tr_s3.lcl_oaf_val, tr_s3.lcl_oav_val,
            tr_s3.lcl_paf_val, tr_s3.lcl_pav_val, f.lit(0).cast('double').alias('lcl_zc59_val'),
            f.lit(0).cast('double').alias('lcl_zc65_val'), f.lit(0).cast('double').alias('lcl_zc66_val'),
            f.lit(0).cast('double').alias('lcl_zc69_val'), f.lit(0).cast('double').alias('lcl_zc73_val'),
            tr_s3.usd_net_val, tr_s3.usd_adj_val, tr_s3.usd_cop_val, tr_s3.usd_lag_val, tr_s3.usd_cso_val,
            tr_s3.usd_oic_val, tr_s3.usd_oaf_val, tr_s3.usd_oav_val, tr_s3.usd_paf_val, tr_s3.usd_pav_val,
            f.lit(0).cast('double').alias('usd_zc59_val'), f.lit(0).cast('double').alias('usd_zc65_val'),
            f.lit(0).cast('double').alias('usd_zc66_val'), f.lit(0).cast('double').alias('usd_zc69_val'),
            f.lit(0).cast('double').alias('usd_zc73_val'))

        df_tr_s3.printSchema()

        print('applying the transformations df_s1')
        df_s1 = s1.filter(s1.country_mnmc == f.lit('IT')).select(
            s1.ref_id, s1.billing_document, s1.source_system, s1.billing_item, s1.country_mnmc, s1.sector, s1.prod_grp,
            s1.item_category, s1.material_number, s1.material_mnmc, s1.airport_id, s1.airport_mnmc, s1.airport_name,
            s1.customer_id, s1.customer_number, s1.customer_name, s1.delivery_date, s1.litres, s1.ugl, s1.billing_date,
            f.lit('USD').alias('document_currency'), f.lit('USD').alias('local_currency'),
            f.lit(1).alias('exchange_rate'), f.lit(1).alias('ile_exch_rate'), f.lit(1).alias('lre_exch_rate'),
            f.when(s1.source_system == f.lit('SUN_IT'),
                   f.when(s1.customer_number == f.lit('7070305'), (s1.ugl * f.lit(0.03)))
                   .otherwise(f.lit(0).cast('double')))
                .when(s1.source_system == f.lit('ISP_ESP0721'),
                      f.when(s1.customer_number == f.lit('5289801'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('7211001'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('8271600'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('8627000'),(s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9603895'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9833195'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9838895'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9840295'), (s1.ugl * f.lit(0.03)))
                      .when(s1.int_customer_ind == f.lit('N'), f.lit(0).cast('double'))
                      .when(s1.airport_mnmc == f.lit('FCO'), (s1.ugl * f.lit(0.01)))
                      .otherwise(s1.ugl * f.lit(0.03))).alias('net_val'),
            f.when(s1.source_system == f.lit('SUN_IT'),
                   f.when(s1.customer_number == f.lit('7070305'), (s1.ugl * f.lit(0.03)))
                   .otherwise(f.lit(0).cast('double')))
                .when(s1.source_system == f.lit('ISP_ESP0721'),
                      f.when(s1.customer_number == f.lit('5289801'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('7211001'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('8271600'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('8627000'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9603895'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9833195'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9838895'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9840295'), (s1.ugl * f.lit(0.03)))
                      .when(s1.int_customer_ind == f.lit('N'), f.lit(0).cast('double'))
                      .when(s1.airport_mnmc == f.lit('FCO'), (s1.ugl * f.lit(0.01)))
                      .otherwise(s1.ugl * f.lit(0.03))).alias('lcl_net_val'),
            f.lit(0).cast('double').alias('lcl_adj_val'), f.lit(0).cast('double').alias('lcl_cop_val'),
            f.lit(0).cast('double').alias('lcl_lag_val'), f.lit(0).cast('double').alias('lcl_cso_val'),
            f.lit(0).cast('double').alias('lcl_oic_val'), f.lit(0).cast('double').alias('lcl_oaf_val'),
            f.lit(0).cast('double').alias('lcl_oav_val'), f.lit(0).cast('double').alias('lcl_paf_val'),
            f.lit(0).cast('double').alias('lcl_pav_val'), f.lit(0).cast('double').alias('lcl_zc59_val'),
            f.lit(0).cast('double').alias('lcl_zc65_val'), f.lit(0).cast('double').alias('lcl_zc66_val'),
            f.lit(0).cast('double').alias('lcl_zc69_val'), f.lit(0).cast('double').alias('lcl_zc73_val'),
            f.when(s1.source_system == f.lit('SUN_IT'),
                   f.when(s1.customer_number == f.lit('7070305'), (s1.ugl * f.lit(0.03)))
                   .otherwise(f.lit(0).cast('double')))
                .when(s1.source_system == f.lit('ISP_ESP0721'),
                      f.when(s1.customer_number == f.lit('5289801'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('7211001'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('8271600'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('8627000'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9603895'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9833195'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9838895'), (s1.ugl * f.lit(0.03)))
                      .when(s1.customer_number == f.lit('9840295'), (s1.ugl * f.lit(0.03)))
                      .when(s1.int_customer_ind == f.lit('N'), f.lit(0).cast('double'))
                      .when(s1.airport_mnmc == f.lit('FCO'), (s1.ugl * f.lit(0.01)))
                      .otherwise(s1.ugl * f.lit(0.03))).alias('usd_net_val'),
            f.lit(0).cast('double').alias('usd_adj_val'), f.lit(0).cast('double').alias('usd_cop_val'),
            f.lit(0).cast('double').alias('usd_lag_val'), f.lit(0).cast('double').alias('usd_cso_val'),
            f.lit(0).cast('double').alias('usd_oic_val'), f.lit(0).cast('double').alias('usd_oaf_val'),
            f.lit(0).cast('double').alias('usd_oav_val'), f.lit(0).cast('double').alias('usd_paf_val'),
            f.lit(0).cast('double').alias('usd_pav_val'), f.lit(0).cast('double').alias('usd_zc59_val'),
            f.lit(0).cast('double').alias('usd_zc65_val'), f.lit(0).cast('double').alias('usd_zc66_val'),
            f.lit(0).cast('double').alias('usd_zc69_val'), f.lit(0).cast('double').alias('usd_zc73_val')
        )
        df_s1.printSchema()

        df_list = [df_imi_s7, df_imi_s8, df_imi_s72, df_zamz_s2, df_mena_s6, df_al_s6, df_ro_s3, df_gr_s9, df_tr_s3,
                   df_s1]

        print('Union all the Dataframes and get the distinct values')
        df_tfx_result = reduce(DataFrame.union, df_list).distinct()
        df_tfx_result.count()

        return df_tfx_result


if __name__ == '__main__':
    trl = SunIspETL()
    trl.execute()
