# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1             Bakul Seth       03-May-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l42_isp_fact_sales_billing_cost_allocation_final
#                  into conform zone
# Author        :- Bakul Seth
# Date          :- 03-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class SunIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']
        self.environment = args['environment']

        # report specific =============================================
        self.input_tables = ['l42_isp_fact_sales_billing_cost_allocation', 'l42_isp_fact_sales_billing_estimated_cost']
        self.report_file = 'l42_isp_fact_sales_billing_cost_allocation_final'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):

        # read data from country specific table argument passed(database, table)
        print('Reading data from input tabled {}.{}'.format(self.source_database,  self.input_tables))
        df_input_table = self._get_table(self.source_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('applying the transformations')
        df_tfx_table = self._apply_tfx(df_input_table)
        print('schema after transformation ', df_tfx_table.printSchema())

        # write final result to required destination
        print('Writing the results to desired location')
        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        target_dataset\
            .write.option('compression', 'snappy')\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name[0]))
        cost_allocation = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[0],
                                                                     transformation_ctx='target_table').toDF()
        cost_allocation.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[1]))
        estimated_cost = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[1],
                                                                    transformation_ctx='target_table').toDF()
        estimated_cost.printSchema()

        return [cost_allocation, estimated_cost]

    @staticmethod
    def _apply_tfx(df_input_table):

        # creating dataframe for different tables
        print('creating dataframe for different tables')
        cost_alctn = df_input_table[0]
        estimate = df_input_table[1]

        cost_alctn2 = cost_alctn.groupBy(cost_alctn.country_mnmc, cost_alctn.prod_grp, cost_alctn.airport_mnmc,
                                         f.last_day(cost_alctn.delivery_date).alias('delivery_date'))\
            .agg(f.sum(cost_alctn.litres).alias('tot_litres'))\
            .select(cost_alctn.country_mnmc, cost_alctn.prod_grp, cost_alctn.airport_mnmc,
                    f.col('delivery_date').alias('period'), f.col('tot_litres'))

        # Applying the transformation
        print('applying the transformations')
        df_tfx_result = cost_alctn.alias('cost_alctn1')\
            .join(estimate.alias('estimate1'), (f.col('estimate1.country_mnmc') == f.col('cost_alctn1.country_mnmc')) &
                  (f.col('estimate1.prod_grp') == f.col('cost_alctn1.prod_grp')) &
                  (f.col('estimate1.airport_mnmc') == f.col('cost_alctn1.airport_mnmc')) &
                  (f.col('estimate1.COST_TYPE') == f.lit('COP')), 'left')\
            .join(estimate.alias('estimate2'),
                  (f.col('estimate2.country_mnmc') == f.col('cost_alctn1.country_mnmc')) &
                  (f.col('estimate2.prod_grp') == f.col('cost_alctn1.prod_grp')) &
                  (f.col('estimate2.airport_mnmc') == f.col('cost_alctn1.airport_mnmc')) &
                  (f.col('estimate2.cost_type') == f.lit('APC')), 'left')\
            .join(cost_alctn2.alias('cost_alctn2'),
                  (f.col('cost_alctn2.country_mnmc') == f.col('cost_alctn1.country_mnmc')) &
                  (f.col('cost_alctn2.prod_grp') == f.col('cost_alctn1.prod_grp')) &
                  (f.col('cost_alctn2.airport_mnmc') == f.col('cost_alctn1.airport_mnmc')) &
                  (f.col('cost_alctn2.period') == f.last_day(f.col('cost_alctn1.delivery_date'))), 'left').select(
            f.col('cost_alctn1.ref_id'), f.col('cost_alctn1.billing_document'), f.col('cost_alctn1.source_system'),
            f.col('cost_alctn1.billing_item'), f.col('cost_alctn1.country_mnmc'), f.col('cost_alctn1.sector'),
            f.col('cost_alctn1.prod_grp'), f.col('cost_alctn1.item_category'), f.col('cost_alctn1.material_number'),
            f.col('cost_alctn1.material_mnmc'), f.col('cost_alctn1.airport_id'), f.col('cost_alctn1.airport_mnmc'),
            f.col('cost_alctn1.airport_name'), f.col('cost_alctn1.customer_id'), f.col('cost_alctn1.customer_name'),
            f.col('cost_alctn1.delivery_date'), f.col('cost_alctn1.litres'), f.col('cost_alctn1.ugl'),
            f.col('cost_alctn1.billing_date'), f.col('cost_alctn1.document_currency'),
            f.col('cost_alctn1.local_currency'), f.col('cost_alctn1.exchange_rate'), f.col('cost_alctn1.ile_exch_rate'),
            f.col('cost_alctn1.lre_exch_rate'), f.col('cost_alctn1.net_value'), f.col('cost_alctn1.lcl_net_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate1.last_loaded_date'),
                   ((f.col('estimate1.usd_adj_val') / f.col('cost_alctn1.lre_exch_rate')) *
                    (f.col('cost_alctn1.litres') / f.col('cost_alctn2.tot_litres'))))
            .otherwise(f.col('cost_alctn1.lcl_adj_val')).alias('lcl_adj_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate1.last_loaded_date'),
                   (f.col('estimate1.pct_cop_rate') * f.col('cost_alctn1.lcl_net_val')))
            .otherwise(f.col('cost_alctn1.lcl_cop_val')).alias('lcl_cop_val'),
            f.col('cost_alctn1.lcl_lag_val'), f.col('cost_alctn1.lcl_cso_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate2.last_loaded_date'),
                   ((f.col('cost_alctn1.usd_oic_val') / f.col('cost_alctn1.lre_exch_rate')) *
                    (f.col('cost_alctn1.litres') / f.col('cost_alctn2.tot_litres'))))
            .otherwise(f.col('cost_alctn1.lcl_oic_val')).alias('lcl_oic_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate2.last_loaded_date'),
                   ((f.col('estimate2.usd_oaf_val') / f.col('cost_alctn1.lre_exch_rate')) *
                    (f.col('cost_alctn1.litres') / f.col('cost_alctn2.tot_litres'))))
            .otherwise(f.col('cost_alctn1.lcl_oaf_val')).alias('lcl_oaf_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate2.last_loaded_date'),
                   ((f.col('estimate2.usd_oav_val') / f.col('cost_alctn1.lre_exch_rate')) *
                    (f.col('cost_alctn1.litres') / f.col('cost_alctn2.tot_litres'))))
            .otherwise(f.col('cost_alctn1.lcl_oav_val')).alias('lcl_oav_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate2.last_loaded_date'),
                   ((f.col('estimate2.usd_paf_val') / f.col('cost_alctn1.lre_exch_rate')) *
                    (f.col('cost_alctn1.litres') / f.col('cost_alctn2.tot_litres'))))
            .otherwise(f.col('cost_alctn1.lcl_paf_val')).alias('lcl_paf_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate2.last_loaded_date'),
                   (f.col('estimate2.usd_pav_val') / f.col('cost_alctn1.lre_exch_rate')) *
                   (f.col('cost_alctn1.litres') / f.col('cost_alctn2.tot_litres')))
            .otherwise(f.col('cost_alctn1.lcl_pav_val')).alias('lcl_pav_val'),
            f.col('cost_alctn1.lcl_zc59_val'), f.col('cost_alctn1.lcl_zc65_val'), f.col('cost_alctn1.lcl_zc66_val'),
            f.col('cost_alctn1.lcl_zc69_val'), f.col('cost_alctn1.lcl_zc73_val'), f.col('cost_alctn1.usd_net_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate1.last_loaded_date'),
                   (f.col('estimate1.usd_adj_val') * (f.col('cost_alctn1.litres') / f.col('cost_alctn2.tot_litres'))))
            .otherwise(f.col('cost_alctn1.usd_adj_val')).alias('usd_adj_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate1.last_loaded_date'),
                   (f.col('estimate1.pct_cop_rate') * f.col('cost_alctn1.usd_net_val')))
            .otherwise(f.col('cost_alctn1.usd_cop_val')).alias('usd_cop_val'),
            f.col('cost_alctn1.usd_lag_val'), f.col('cost_alctn1.usd_cso_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate2.last_loaded_date'),
                   (f.col('estimate2.usd_oic_val') * (f.col('cost_alctn1.litres') / f.col('cost_alctn2.tot_litres'))))
                .otherwise(f.col('cost_alctn1.usd_oic_val')).alias('usd_oic_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate2.last_loaded_date'),
                   (f.col('estimate2.usd_oaf_val') * (f.col('cost_alctn1.litres') / f.col('cost_alctn2.tot_litres'))))
            .otherwise(f.col('cost_alctn1.usd_oaf_val')).alias('usd_oaf_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate2.last_loaded_date'),
                   (f.col('estimate2.usd_oav_val') * (f.col('cost_alctn1.litres') / f.col('cost_alctn2.tot_litres'))))
            .otherwise(f.col('cost_alctn1.usd_oav_val')).alias('usd_oav_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate2.last_loaded_date'),
                   (f.col('estimate2.usd_paf_val') * (f.col('cost_alctn1.litres') / f.col('cost_alctn2.TOT_LITRES'))))
            .otherwise(f.col('cost_alctn1.usd_paf_val')).alias('usd_paf_val'),
            f.when(f.col('cost_alctn1.delivery_date') > f.col('estimate2.last_loaded_date'),
                   (f.col('estimate2.usd_pav_val') * (f.col('cost_alctn1.litres') / f.col('cost_alctn2.tot_litres'))))
            .otherwise(f.col('cost_alctn1.usd_pav_val')).alias('usd_pav_val'),
            f.col('cost_alctn1.usd_zc59_val'), f.col('cost_alctn1.usd_zc65_val'), f.col('cost_alctn1.usd_zc66_val'),
            f.col('cost_alctn1.usd_zc69_val'), f.col('cost_alctn1.usd_zc73_val'))

        return df_tfx_result


if __name__ == '__main__':
    trl = SunIspETL()
    trl.execute()
