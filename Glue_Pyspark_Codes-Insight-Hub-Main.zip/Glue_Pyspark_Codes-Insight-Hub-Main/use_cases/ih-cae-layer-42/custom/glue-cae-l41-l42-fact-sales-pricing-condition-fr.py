# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1             Bakul Seth       03-May-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l42_isp_fact_sales_pricing_conditions_fr
#                  into conform zone
# Author        :- Bakul Seth
# Date          :- 03-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class SunIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'netapp_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.netapp_database = args['netapp_database']
        self.destination_bucket = args['destination_bucket']
        self.environment = args['environment']

        # report specific =============================================
        self.input_tables = ['l41_isp_fact_sales_billing_cost_allocation_fr_s4', 'l2_isp_dim_pricing_conditions_fr',
                             'l41_isp_fact_sales_billing_cost_allocation_fr_s12', 'l2_isp_dim_pricing_conditions']
        self.report_file = 'l42_isp_fact_sales_pricing_conditions_fr'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):

        # read data from country specific table argument passed(database, table)
        print('Reading data from input tabled {}.{}'.format(self.source_database, self.netapp_database,
                                                            self.input_tables))
        df_input_table = self._get_table(self.source_database, self.netapp_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('applying the transformations')
        df_tfx_table = self._apply_tfx(df_input_table)
        print('schema after transformation ', df_tfx_table.printSchema())

        # write final result to required destination
        print('Writing the results to desired location')
        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        target_dataset\
            .write.option('compression', 'snappy')\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, netapp_database, table_name):

        print('reading data from {}.{}'.format(source_database, table_name[0]))
        fsb_cost_s4 = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[0],
                                                                 transformation_ctx='target_table').toDF()
        print('Data read from {}.{} is complete schema for the table is '.format(source_database, table_name[0]))
        fsb_cost_s4.printSchema()

        print('reading data from {}.{}'.format(netapp_database, table_name[1]))
        pricing_cond_fr = self._gc.create_dynamic_frame.from_catalog(database=netapp_database, table_name=table_name[1],
                                                                     transformation_ctx='target_table').toDF()
        print('Data read from {}.{} is complete schema for the table is '.format(netapp_database, table_name[1]))
        pricing_cond_fr.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[1]))
        fsb_cost_s12 = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[2],
                                                                  transformation_ctx='target_table').toDF()
        print('Data read from {}.{} is complete schema for the table is '.format(source_database, table_name[2]))
        fsb_cost_s12.printSchema()

        print('reading data from {}.{}'.format(netapp_database, table_name[1]))
        pricing_cond = self._gc.create_dynamic_frame.from_catalog(database=netapp_database, table_name=table_name[3],
                                                                  transformation_ctx='target_table').toDF()
        print('Data read from {}.{} is complete schema for the table is '.format(netapp_database, table_name[3]))
        pricing_cond.printSchema()

        return [fsb_cost_s4, pricing_cond_fr, fsb_cost_s12, pricing_cond]

    @staticmethod
    def _apply_tfx(df_input):
        # preparing dataframe
        df_fr_s4 = df_input[0]

        df_price_cond_fr = df_input[1]

        df_fr_s12 = df_input[2]

        df_price_cond = df_input[3]

        # Applying the transformation
        print('applying the transformations df_tfx1')
        df_tfx1 = df_fr_s4.join(df_price_cond_fr, df_fr_s4.cost_sub_category ==
                                df_price_cond_fr.cost_allocation_code, 'left')\
            .filter(df_fr_s4.country_mnmc == f.lit('FR')).select(
            df_fr_s4.source_system, f.lit(None).cast('string').alias('doc_condition_no'), df_fr_s4.ref_id,
            df_fr_s4.billing_item.alias('item_no'), f.lit(0).cast('integer').alias('step_number'),
            f.lit(0).cast('integer').alias('counter'), f.lit(None).cast('string').alias('application'),
            df_fr_s4.item_category.alias('condition_category'),
            f.when(df_price_cond_fr.condition_type.isNotNull(), df_price_cond_fr.condition_type)
            .otherwise(f.lit('XXXX')).alias('condition_type'), f.lit(0).cast('double').alias('condition_base_value'),
            f.lit(0).cast('double').alias('condition_rate'), df_fr_s4.local_currency,
            df_fr_s4.exchange_rate.alias('cond_exchange_rate'), df_fr_s4.net_value.alias('condition_value'),
            df_fr_s4.lcl_cost_value.alias('condition_value_lc'), df_fr_s4.gc_cost_value.alias('condition_value_gc'))

        df_tfx1.printSchema()

        print('applying the transformations df_tfx2')
        df_tfx2 = df_fr_s12.join(df_price_cond, df_fr_s12.material_number ==
                                 df_price_cond.material_number, 'left') \
            .filter(df_fr_s12.country_mnmc == f.lit('FR')).select(
            df_fr_s12.source_system, f.lit(None).cast('string').alias('doc_condition_no'), df_fr_s12.ref_id,
            df_fr_s12.billing_item.alias('item_no'), f.lit(0).cast('integer').alias('step_number'),
            f.lit(0).cast('integer').alias('counter'), f.lit(None).cast('string').alias('application'),
            df_fr_s12.item_category.alias('condition_category'),
            f.when(df_price_cond.pricing_condition.isNotNull(), df_price_cond.pricing_condition)
                .otherwise(f.lit('XXXX')).alias('condition_type'),
            f.lit(0).cast('double').alias('condition_base_value'),
            f.lit(0).cast('double').alias('condition_rate'), df_fr_s12.local_currency,
            df_fr_s12.exchange_rate.alias('cond_exchange_rate'), df_fr_s12.net_value.alias('condition_value'),
            df_fr_s12.lcl_net_val.alias('condition_value_lc'), df_fr_s12.usd_net_val.alias('condition_value_gc'))

        df_tfx2.printSchema()

        print('applying the transformations df_tfx3')
        df_tfx3 = df_fr_s12.join(df_price_cond, df_fr_s12.material_number ==
                                 df_price_cond.material_number, 'left') \
            .filter((df_fr_s12.country_mnmc == f.lit('FR')) & (df_fr_s12.item_category.isin([1, 3]) == False)).select(
            df_fr_s12.source_system, f.lit(None).cast('string').alias('doc_condition_no'), df_fr_s12.ref_id,
            df_fr_s12.billing_item.alias('item_no'), f.lit(0).cast('integer').alias('step_number'),
            f.lit(0).cast('integer').alias('counter'), f.lit(None).cast('string').alias('application'),
            df_fr_s12.item_category.alias('condition_category'),
            f.lit('ZP40').alias('condition_type'), f.lit(0).cast('double').alias('condition_base_value'),
            f.lit(0).cast('double').alias('condition_rate'), df_fr_s12.local_currency,
            df_fr_s12.exchange_rate.alias('cond_exchange_rate'), df_fr_s12.net_value.alias('condition_value'),
            (df_fr_s12.lcl_net_val * f.lit(-1)).alias('condition_value_lc'),
            (df_fr_s12.usd_net_val * f.lit(-1)).alias('condition_value_gc'))

        df_tfx3.printSchema()

        df_list = [df_tfx1, df_tfx2, df_tfx3]

        print('Union all the Dataframes and get the distinct values')
        df_tfx_result = reduce(DataFrame.union, df_list)

        return df_tfx_result


if __name__ == '__main__':
    trl = SunIspETL()
    trl.execute()
