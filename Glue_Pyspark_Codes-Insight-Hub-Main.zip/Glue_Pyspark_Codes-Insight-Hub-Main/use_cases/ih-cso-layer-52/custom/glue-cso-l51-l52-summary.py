# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      15-Jun-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-cso-l52-summary into conform zone
# Author        :- Liz Harvey
# Date          :- 15-Jun-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.types import *

class CsoETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'netapp_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.netapp_database = args['netapp_database']
        self.destination_bucket = args['destination_bucket']
        self.environment = args['environment']

        # report specific =============================================
        self.input_tables = ['l51_summary', 'l51_CS_and_O_cus_summary', 'l51_costelement',
                             'l51_CS_and_O_cus_costelement', 'l51_CS_and_O_vol_costelement',
                             'l5_dim_waterfall_global']

        self.report_file = 'l52_cs_and_o_summary'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}, {}.{}* and write it to {}'.format(self.source_database, self.netapp_database,
                                                                             self.input_tables,
                                                                             self.destination_bucket))

    def execute(self):
        # generate input table list
        source_database = self.source_database
        netapp_database = self.netapp_database
        input_tables = self.input_tables
        print("input table list is {}".format(input_tables))

        # read data from country specific table argument passed(database, table)
        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[0]))
        df_1 = self._get_table(self.source_database, self.input_tables)

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[1]))
        df_2 = self._get_table(self.source_database, self.input_tables)

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[2]))
        df_3 = self._get_table(self.source_database, self.input_tables)

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[3]))
        df_4 = self._get_table(self.source_database, self.input_tables)

        print('Reading data from input table {}.{}'.format(self.source_database, self.input_tables[4]))
        df_5 = self._get_table(self.source_database, self.input_tables)

        print('Reading data from input table {}.{}'.format(self.netapp_database, self.input_tables[5]))
        df_6 = self._get_table(self.netapp_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('applying the transformations')
        df_tfx_table = self._apply_tfx(df_1, df_2, df_3, df_4, df_5, df_6)
        # print('schema after transformation ', df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        l51_sum = args[0]
        cus_sum = args[1]
        l51_ce = args[2]
        cus_ce = args[3]
        vol_ce = args[4]
        waterfall = args[5]

        l51_sum_select = l51_sum.select(f.col("pricing_date"),
                                        f.col("billing_date"),
                                        f.col("delivery_date"),
                                        f.col("customer_country"),
                                        f.col("grn_header"),
                                        f.col("customer_account_name"),
                                        f.col("cc_grn"),
                                        f.col("grn"),
                                        f.col("account_manager"),
                                        f.col("sector"),
                                        f.col("source_system"),
                                        f.col("sales_organisation"),
                                        f.col("sales_document"),
                                        f.col("delivery_number"),
                                        f.col("material_number"),
                                        f.col("material_description"),
                                        f.col("local_material_description"),
                                        f.col("billing_document"),
                                        f.col("billing_item"),
                                        f.col("local_currency"),
                                        f.col("qty_in_m3"),
                                        f.col("qty_in_usg"),
                                        f.col("qty_in_litres"),
                                        f.col("net_value"),
                                        f.col("document_currency"),
                                        f.col("flight_number"),
                                        f.col("aircraft_registration"),
                                        f.col("intercompany_flag"),
                                        f.col("payer"),
                                        f.col("soldto_party"),
                                        f.col("costing_country"),
                                        f.col("last_modified_date"),
                                        f.col("market_space"),
                                        f.col("carrier"),
                                        f.col("sf_account_manager"),
                                        f.col("group"),
                                        f.col("customer_type"),
                                        f.col("marketing_segment"),
                                        f.col("regional_sales_manager"),
                                        f.col("delivery_method"),
                                        f.col("cost_element_key"),
                                        f.col("trx_cust_key"),
                                        f.col("dim_cust_key"),
                                        f.col("trx_loc_key"),
                                        f.col("trx_pro_key"),
                                        f.col("dim_pro_key"))

        cus_sum_select = cus_sum.select(f.col("pricing_date"),
                                        f.col("billing_date"),
                                        f.col("delivery_date"),
                                        f.col("customer_country"),
                                        f.col("grn_header"),
                                        f.col("customer_account_name"),
                                        f.col("cc_grn"),
                                        f.col("grn"),
                                        f.col("account_manager"),
                                        f.col("sector"),
                                        f.col("source_system"),
                                        f.col("sales_organisation"),
                                        f.col("sales_document"),
                                        f.col("delivery_number"),
                                        f.col("material_number"),
                                        f.col("material_description"),
                                        f.col("local_material_description"),
                                        f.col("billing_document"),
                                        f.col("billing_item"),
                                        f.col("local_currency"),
                                        f.col("qty_in_m3"),
                                        f.col("qty_in_usg"),
                                        f.col("qty_in_litres"),
                                        f.col("net_value"),
                                        f.col("document_currency"),
                                        f.col("flight_number"),
                                        f.col("aircraft_registration"),
                                        f.col("intercompany_flag"),
                                        f.col("payer"),
                                        f.col("soldto_party"),
                                        f.col("costing_country"),
                                        f.col("last_modified_date"),
                                        f.col("market_space"),
                                        f.col("carrier"),
                                        f.col("sf_account_manager"),
                                        f.col("group"),
                                        f.col("customer_type"),
                                        f.col("customer_segment"),
                                        f.col("regional_sales_manager"),
                                        f.col("delivery_method"),
                                        f.col("cost_element_key"),
                                        f.col("trx_cust_key"),
                                        f.col("dim_cust_key"),
                                        f.col("trx_loc_key"),
                                        f.col("trx_pro_key"),
                                        f.col("dim_pro_key"))

        l51_ce_u = l51_ce.select(f.col("cost_element_key"),
                                 f.col("trx_wfh_key"),
                                 f.col("value_lc"),
                                 f.col("value_usd"))

        cus_ce_u = cus_ce.select(f.col("cost_element_key"),
                                 f.col("trx_wfh_key"),
                                 f.col("value_lc"),
                                 f.col("value_usd"))

        vol_ce_u = vol_ce.select(f.col("cost_element_key"),
                                 f.col("trx_wfh_key"),
                                 f.col("value_lc"),
                                 f.col("value_usd"))

        cost_dfs = [l51_ce_u, cus_ce_u, vol_ce_u]
        cost_u = reduce(DataFrame.unionAll, cost_dfs)

        cost_u_1 = cost_u.join(waterfall, f.col("cost_u.trx_wfh_key") == f.col("waterfall.condition_type"))

        wfg = cost_u_1.select(f.col("cost.cost_element_key"),
                              f.col("waterfall.hierarchy_level_5").alias("hl5"),
                              f.col("waterfall.hierarchy_level_4_key").alias("hl4"),
                              f.col("waterfall.hierarchy_level_3_key").alias("hl3"),
                              f.col("waterfall.hierarchy_level_2_key").alias("hl2"),
                              f.col("waterfall.hierarchy_level_1_key").alias("hl1"),
                              f.col("cost.value_lc").cast("decimal(17,3)").alias("value_lc"),
                              f.col("cost.value_usd").cast("decimal(17,3)").alias("value_usd"))

        wfh = wfg.groupBy(wfg.cost_element_key).count() \
            .agg(
            (f.sum(f.when((f.col("wfg.hl1") == 'core marketing rcop') & (f.col("wfg.hl3") == 'revenue'),
                          f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .when((f.col("wfg.hl1") == 'core marketing rcop') & (f.col("wfg.hl3") == 'cost'),
                         f.coalesce(f.col("wfg.value_lc") * -1, f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l1_core_marketing_rcop_lc"),
            (f.sum(f.when((f.col("wfg.hl1") == 'core marketing rcop') & (f.col("wfg.hl3") == 'revenue'),
                          f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .when((f.col("wfg.hl1") == 'core marketing rcop') & (f.col("wfg.hl3") == 'cost'),
                         f.coalesce(f.col("wfg.value_usd") * -1, f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l1_core_marketing_rcop_usd"),
            (f.sum(f.when((f.col("wfg.hl2") == 'gross profit') & (f.col("wfg.hl3") == 'revenue'),
                          f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .when((f.col("wfg.hl2") == 'gross profit') & (f.col("wfg.hl3") == 'cost'),
                         f.coalesce(f.col("wfg.value_lc") * -1, f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l2_gross_profit_lc"),
            (f.sum(f.when((f.col("wfg.hl2") == 'gross profit') & (f.col("wfg.hl3") == 'revenue'),
                          f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .when((f.col("wfg.hl2") == 'gross profit') & (f.col("wfg.hl3") == 'cost'),
                         f.coalesce(f.col("wfg.value_usd") * -1, f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l2_gross_profit_usd"),
            (f.sum(f.when(f.col("wfg.hl3") == 'revenue', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l3_revenue_lc"),
            (f.sum(f.when(f.col("wfg.hl3") == 'revenue', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l3_revenue_usd"),
            (f.sum(f.when(f.col("wfg.hl3") == 'cost', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l3_cost_lc"),
            (f.sum(f.when(f.col("wfg.hl3") == 'cost', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l3_cost_usd"),
            (f.sum(f.when(f.col("wfg.hl3") == 'revenue', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("net_value_lc"),
            (f.sum(f.when(f.col("wfg.hl3") == 'revenue', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("net_value_usd"),
            (f.sum(f.when(f.col("wfg.hl4") == 'customer price', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_customer_price_lc"),
            (f.sum(f.when(f.col("wfg.hl4") == 'customer price', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_customer_price_usd"),
            (f.sum(f.when(f.col("wfg.hl4") == 'invoice line item', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_invoice_line_item_lc"),
            (f.sum(f.when(f.col("wfg.hl4") == 'invoice line item', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_invoice_line_item_usd"),
            (f.sum(f.when(f.col("wfg.hl4") == 'taxes & excise duty', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_taxes_excise_duty_lc"),
            (f.sum(f.when(f.col("wfg.hl4") == 'taxes & excise duty', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_taxes_excise_duty_usd"),
            (f.sum(f.when(f.col("wfg.hl4") == 'other costs', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_other_costs_lc"),
            (f.sum(f.when(f.col("wfg.hl4") == 'other costs', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_other_costs_usd"),
            (f.sum(f.when(f.col("wfg.hl4") == 'pre-airfield s&h', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_pre_airfield_sh_lc"),
            (f.sum(f.when(f.col("wfg.hl4") == 'pre-airfield s&h', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_pre_airfield_sh_usd"),
            (f.sum(f.when(f.col("wfg.hl4") == 'pre-airfield transport', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_pre_airfield_transport_lc"),
            (f.sum(f.when(f.col("wfg.hl4") == 'pre-airfield transport', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_pre_airfield_transport_usd"),
            (f.sum(f.when(f.col("wfg.hl4") == 'on airfield costs', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_on_airfield_costs_lc"),
            (f.sum(f.when(f.col("wfg.hl4") == 'on airfield costs', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_on_airfield_costs_usd"),
            (f.sum(f.when(f.col("wfg.hl4") == 'purchase price', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_purchase_price_lc"),
            (f.sum(f.when(f.col("wfg.hl4") == 'purchase price', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_purchase_price_usd"),
            (f.sum(f.when(f.col("wfg.hl4") == 'cs&o', f.coalesce(f.col("wfg.value_lc"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_cs_and_o_lc"),
            (f.sum(f.when(f.col("wfg.hl4") == 'cs&o', f.coalesce(f.col("wfg.value_usd"), f.lit(0)))
                   .otherwise(f.lit(0)))).alias("l4_cs_and_o_usd"),
            (f.sum(f.coalesce(f.col("wfg.value_lc"), f.lit(0)))).alias("gross_profit_lc"),
            (f.sum(f.coalesce(f.col("wfg.value_usd"), f.lit(0)))).alias("gross_profit_usd")
        ) \
            .select(
            f.col("cost_element_key"),
            f.col("l1_core_marketing_rcop_lc"),
            f.col("l1_core_marketing_rcop_usd"),
            f.col("l2_gross_profit_lc"),
            f.col("l2_gross_profit_usd"),
            f.col("l3_revenue_lc"),
            f.col("l3_revenue_usd"),
            f.col("l3_cost_lc"),
            f.col("l3_cost_usd"),
            f.col("net_value_lc"),
            f.col("net_value_usd"),
            f.col("l4_customer_price_lc"),
            f.col("l4_customer_price_usd"),
            f.col("l4_invoice_line_item_lc"),
            f.col("l4_invoice_line_item_usd"),
            f.col("l4_taxes_excise_duty_lc"),
            f.col("l4_taxes_excise_duty_usd"),
            f.col("l4_other_costs_lc"),
            f.col("l4_other_costs_usd"),
            f.col("l4_pre_airfield_sh_lc"),
            f.col("l4_pre_airfield_sh_usd"),
            f.col("l4_pre_airfield_transport_lc"),
            f.col("l4_pre_airfield_transport_usd"),
            f.col("l4_on_airfield_costs_lc"),
            f.col("l4_on_airfield_costs_usd"),
            f.col("l4_purchase_price_lc"),
            f.col("l4_purchase_price_usd"),
            f.col("l4_cs_and_o_lc"),
            f.col("l4_cs_and_o_usd"),
            f.col("gross_profit_lc"),
            f.col("gross_profit_usd")
        )

        summ = l51_sum_select.unionAll(cus_sum_select)

        df_tfx_result = summ.join(wfh, summ.cost_element_key == wfh.cost_element_key, 'left') \
            .select(summ.pricing_date,
                    summ.billing_date,
                    summ.delivery_date,
                    summ.customer_country,
                    summ.grn_header,
                    summ.customer_account_name,
                    summ.cc_grn,
                    summ.grn,
                    summ.account_manager,
                    summ.sector,
                    summ.source_system,
                    summ.sales_organisation,
                    summ.sales_document,
                    summ.delivery_number,
                    summ.material_number,
                    summ.material_description,
                    summ.local_material_description,
                    summ.billing_document,
                    summ.billing_item,
                    summ.local_currency,
                    summ.qty_in_m3,
                    summ.qty_in_usg,
                    summ.qty_in_litres,
                    summ.net_value,
                    summ.document_currency,
                    summ.flight_number,
                    summ.aircraft_registration,
                    f.coalesce(wfh.l1_core_marketing_rcop_lc, f.lit(0)).cast(DoubleType()).alias(
                        "l1_core_marketing_rcop_lc"),
                    f.coalesce(wfh.l1_core_marketing_rcop_usd, f.lit(0)).cast(DoubleType()).alias(
                        "l1_core_marketing_rcop_usd"),
                    f.coalesce(wfh.l2_gross_profit_lc, f.lit(0)).cast(DoubleType()).alias("l2_gross_profit_lc"),
                    f.coalesce(wfh.l2_gross_profit_usd, f.lit(0)).cast(DoubleType()).alias("l2_gross_profit_usd"),
                    f.coalesce(wfh.l3_revenue_lc, f.lit(0)).cast(DoubleType()).alias("l3_revenue_lc"),
                    f.coalesce(wfh.l3_revenue_usd, f.lit(0)).cast(DoubleType()).alias("l3_revenue_usd"),
                    f.coalesce(wfh.l3_cost_lc, f.lit(0)).cast(DoubleType()).alias("l3_cost_lc"),
                    f.coalesce(wfh.l3_cost_usd, f.lit(0)).cast(DoubleType()).alias("l3_cost_usd"),
                    f.coalesce(wfh.net_value_lc, f.lit(0)).cast(DoubleType()).alias("net_value_lc"),
                    f.coalesce(wfh.net_value_usd, f.lit(0)).cast(DoubleType()).alias("net_value_usd"),
                    f.coalesce(wfh.l4_customer_price_lc, f.lit(0)).cast(DoubleType()).alias("l4_customer_price_lc"),
                    f.coalesce(wfh.l4_customer_price_usd, f.lit(0)).cast(DoubleType()).alias("l4_customer_price_usd"),
                    f.coalesce(wfh.l4_invoice_line_item_lc, f.lit(0)).cast(DoubleType()).alias("l4_invoice_line_item_lc"),
                    f.coalesce(wfh.l4_invoice_line_item_usd, f.lit(0)).cast(DoubleType()).alias(
                        "l4_invoice_line_item_usd"),
                    f.coalesce(wfh.l4_taxes_excise_duty_lc, f.lit(0)).cast(DoubleType()).alias("l4_taxes_excise_duty_lc"),
                    f.coalesce(wfh.l4_taxes_excise_duty_usd, f.lit(0)).cast(DoubleType()).alias(
                        "l4_taxes_excise_duty_usd"),
                    f.coalesce(wfh.l4_other_costs_lc, f.lit(0)).cast(DoubleType()).alias("l4_other_costs_lc"),
                    f.coalesce(wfh.l4_other_costs_usd, f.lit(0)).cast(DoubleType()).alias("l4_other_costs_usd"),
                    f.coalesce(wfh.l4_pre_airfield_sh_lc, f.lit(0)).cast(DoubleType()).alias("l4_pre_airfield_sh_lc"),
                    f.coalesce(wfh.l4_pre_airfield_sh_usd, f.lit(0)).cast(DoubleType()).alias("l4_pre_airfield_sh_usd"),
                    f.coalesce(wfh.l4_pre_airfield_transport_lc, f.lit(0)).cast(DoubleType()).alias(
                        "l4_pre_airfield_transport_lc"),
                    f.coalesce(wfh.l4_pre_airfield_transport_usd, f.lit(0)).cast(DoubleType()).alias(
                        "l4_pre_airfield_transport_usd"),
                    f.coalesce(wfh.l4_on_airfield_costs_lc, f.lit(0)).cast(DoubleType()).alias("l4_on_airfield_costs_lc"),
                    f.coalesce(wfh.l4_on_airfield_costs_usd, f.lit(0)).cast(DoubleType()).alias(
                        "l4_on_airfield_costs_usd"),
                    f.coalesce(wfh.l4_purchase_price_lc, f.lit(0)).cast(DoubleType()).alias("l4_purchase_price_lc"),
                    f.coalesce(wfh.l4_purchase_price_usd, f.lit(0)).cast(DoubleType()).alias("l4_purchase_price_usd"),
                    f.coalesce(wfh.l4_cs_and_o_lc, f.lit(0)).cast(DoubleType()).alias("l4_cs_and_o_lc"),
                    f.coalesce(wfh.l4_cs_and_o_usd, f.lit(0)).cast(DoubleType()).alias("l4_cs_and_o_usd"),
                    f.coalesce(wfh.l2_gross_profit_lc, f.lit(0)).cast(DoubleType()).alias("gross_profit_lc"),
                    f.coalesce(wfh.l2_gross_profit_usd, f.lit(0)).cast(DoubleType()).alias("gross_profit_usd"),
                    summ.intercompany_flag,
                    summ.payer,
                    summ.soldto_party,
                    summ.costing_country,
                    summ.last_modified_date,
                    summ.market_space,
                    summ.carrier,
                    summ.sf_account_manager,
                    summ.group,
                    summ.customer_type,
                    summ.marketing_segment,
                    summ.regional_sales_manager,
                    summ.delivery_method,
                    summ.cost_element_key,
                    summ.trx_cust_key,
                    summ.dim_cust_key,
                    summ.trx_loc_key,
                    summ.trx_pro_key,
                    summ.dim_pro_key)

        return df_tfx_result


if __name__ == '__main__':
    trl = CsoETL()
    trl.execute()
