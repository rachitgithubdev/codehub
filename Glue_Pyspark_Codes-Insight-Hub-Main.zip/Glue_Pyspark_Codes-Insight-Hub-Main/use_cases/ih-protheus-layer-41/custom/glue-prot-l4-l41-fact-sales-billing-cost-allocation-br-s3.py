# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    07-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to l41_prot_fact_sales_billing_cost_allocation_br_s3
#                   into conform zone
# Author        :- Tingting Wan
# Date          :- 07-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================

        self.report_file = "l41_prot_fact_sales_billing_cost_allocation_br_s3"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(self.source_database, 'l41_prot_fact_sales_billing_cost_allocation_br_s2').toDF()
        # print("data count of table {}.{} is {}".format(self.source_database,
        #                                                'l41_prot_fact_sales_billing_cost_allocation_br_s2',
        #                                                df_table_1.count()))
        df_table_2 = self._get_table(self.source_database, 'l3_prot_man_costs').toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, 'l3_prot_man_costs',
        #                                                df_table_2.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2)
        #print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign all input tables
        df_table_S = args[0].cache()
        df_table_MAN = args[1].cache()

        # df_table_S --- l41_prot_fact_sales_billing_cost_allocation_br_s2
        # df_table_MAN --- l3_prot_man_costs
        # create table OAFD
        df_table_OAFD = df_table_S.filter(df_table_S.cae_plant != 'Bulk')\
            .groupBy(
            df_table_S.plant_sector,
            df_table_S.period
        ) \
            .agg(f.count('*').alias('sec_del_cnt'),
                 f.sum(df_table_S.litres).alias('sec_vol_tot'),
                 f.sum(df_table_S.lcl_oaf_val2).alias('sec_oaf_val')).select(
            f.col('plant_sector'),
            f.col('period'),
            f.col('sec_del_cnt'),
            f.col('sec_vol_tot'),
            f.col('sec_oaf_val')
        )

        # create table OAVD
        df_table_OAVD = df_table_S.filter(df_table_S.cae_plant != 'Bulk')\
            .groupBy(
            df_table_S.plant_sector,
            df_table_S.period
        ) \
            .agg(f.count('*').alias('sec_del_cnt'),
                 f.sum(df_table_S.litres).alias('sec_vol_tot'),
                 f.sum(df_table_S.lcl_oav_val2).alias('sec_oav_val')).select(
            f.col('plant_sector'),
            f.col('period'),
            f.col('sec_del_cnt'),
            f.col('sec_vol_tot'),
            f.col('sec_oav_val')
        )

        # create table PAFD
        df_table_PAFD = df_table_S.filter((df_table_S.cae_plant != 'Bulk')
                                          & (df_table_S.cae_paf_loc != 'N/A'))\
            .groupBy(
            df_table_S.plant_sector,
            df_table_S.period
        ) \
            .agg(f.count('*').alias('sec_del_cnt'),
                 f.sum(df_table_S.litres).alias('sec_vol_tot'),
                 f.sum(df_table_S.lcl_paf_val2).alias('sec_paf_val')).select(
            f.col('plant_sector'),
            f.col('period'),
            f.col('sec_del_cnt'),
            f.col('sec_vol_tot'),
            f.col('sec_paf_val')
        )

        # create table PAVD
        df_table_PAVD = df_table_S.filter(df_table_S.pav_sector != 'Hub')\
            .groupBy(
            df_table_S.pav_sector,
            df_table_S.period
        ) \
            .agg(f.count('*').alias('sec_del_cnt'),
                 f.sum(df_table_S.litres).alias('sec_vol_tot'),
                 f.sum(df_table_S.lcl_pav_val2).alias('sec_pav_val')).select(
            f.col('pav_sector'),
            f.col('period'),
            f.col('sec_del_cnt'),
            f.col('sec_vol_tot'),
            f.col('sec_pav_val')
        )


        # transformation
        df_tfx_result = df_table_S.alias('S') \
            .join(df_table_MAN.alias('OAFC'),
                  (f.upper(f.col('S.plant_sector')) == f.upper(f.col('OAFC.sector')))
                  & (f.col('S.period') == f.col('OAFC.period'))
                  & (f.col('OAFC.cost_type') == 'OAF'), 'left') \
            .join(df_table_MAN.alias('OAVC'),
                  (f.upper(f.col('S.plant_sector')) == f.upper(f.col('OAVC.sector')))
                  & (f.col('S.period') == f.col('OAVC.period'))
                  & (f.col('OAVC.cost_type') == 'OAV'), 'left') \
            .join(df_table_MAN.alias('PAFC'),
                  (f.upper(f.col('S.plant_sector')) == f.upper(f.col('PAFC.sector')))
                  & (f.col('S.period') == f.col('PAFC.period'))
                  & (f.col('PAFC.cost_type') == 'PAF'), 'left') \
            .join(df_table_MAN.alias('PAVC'),
                  (f.upper(f.col('S.plant_sector')) == f.upper(f.col('PAVC.sector')))
                  & (f.col('S.period') == f.col('PAVC.period'))
                  & (f.col('PAVC.cost_type') == 'PAV'), 'left') \
            .join(df_table_OAFD.alias('OAFD'),
                  (f.col('S.plant_sector') == f.col('OAFD.plant_sector'))
                  & (f.col('S.period') == f.col('OAFD.period')), 'left') \
            .join(df_table_OAVD.alias('OAVD'),
                  (f.col('S.plant_sector') == f.col('OAVD.plant_sector'))
                  & (f.col('S.period') == f.col('OAVD.period')), 'left') \
            .join(df_table_PAFD.alias('PAFD'),
                  (f.col('S.plant_sector') == f.col('PAFD.plant_sector'))
                  & (f.col('S.period') == f.col('PAFD.period')), 'left') \
            .join(df_table_PAVD.alias('PAVD'),
                  (f.col('S.pav_sector') == f.col('PAVD.pav_sector'))
                  & (f.col('S.period') == f.col('PAVD.period')), 'left') \
            .select(
            f.col('S.*'),
            f.when(f.col('S.cae_plant') == 'Bulk', f.lit(0))
                .when(f.col('S.cae_sector').isin('CA', 'GA'), f.col('S.lcl_oaf_val2') + f.coalesce(
                (f.col('OAFC.cost') - f.col('OAFD.sec_oaf_val')) / f.col('OAFD.sec_del_cnt'), f.lit(0)))
                .otherwise(f.lit(0)).alias('lcl_oaf_val3'),
            f.when(f.col('S.cae_plant') == 'Bulk', f.lit(0))
                .when(f.col('S.cae_sector').isin('CA', 'GA'), f.col('S.lcl_oav_val2') + f.coalesce(
                (f.col('OAVC.cost') - f.col('OAVD.sec_oav_val')) / f.col('OAVD.sec_del_cnt'), f.lit(0)))
                .otherwise(f.lit(0)).alias('lcl_oav_val3'),
            f.when(f.col('S.cae_plant') == 'Bulk', f.lit(0))
                .when(f.col('S.cae_paf_loc') == 'N/A', f.lit(0))
                .otherwise(f.col('S.lcl_paf_val2') + f.coalesce(
                (f.col('PAFC.cost') - f.col('PAFD.sec_paf_val')) * (f.col('S.litres') / f.col('PAFD.sec_vol_tot')),
                f.lit(0))).alias('lcl_paf_val3'),
            f.when(f.col('S.pav_sector') == 'Hub', f.lit(0))
                .otherwise(f.col('S.lcl_pav_val2') + f.coalesce(
                (f.col('PAVC.cost') - f.col('PAVD.sec_pav_val')) * (f.col('S.litres') / f.col('PAVD.sec_vol_tot')),
                f.lit(0))).alias('lcl_pav_val3')
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()
