# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    06-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to l41_prot_fact_sales_billing_cost_allocation_br_s2
#                   into conform zone
# Author        :- Tingting Wan
# Date          :- 06-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================

        self.report_file = "l41_prot_fact_sales_billing_cost_allocation_br_s2"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):

        # generate input table list
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, 'l41_prot_fact_sales_billing_cost_allocation_br_s1').toDF()
        # print("data count of table {}.{} is {}".format(source_database,
        #                                                'l41_prot_fact_sales_billing_cost_allocation_br_s1',
        #                                                df_table_1.count()))
        df_table_2 = self._get_table(source_database, 'l3_prot_temp').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_prot_temp',
        #                                                df_table_2.count()))
        df_table_3 = self._get_table(source_database, 'l3_prot_oic').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_prot_oic',
        #                                                df_table_3.count()))
        df_table_4 = self._get_table(source_database, 'l3_prot_man_costs').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_prot_man_costs',
        #                                                df_table_4.count()))
        df_table_5 = self._get_table(source_database, 'l3_prot_man_expenses').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_prot_man_expenses',
        #                                                df_table_5.count()))
        df_table_6 = self._get_table(source_database, 'l3_prot_man_ca_expenses').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_prot_man_ca_expenses',
        #                                                df_table_6.count()))
        df_table_7 = self._get_table(source_database, 'l3_prot_paf_costs').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_prot_paf_costs',
        #                                                df_table_7.count()))
        df_table_8 = self._get_table(source_database, 'l3_prot_freight_costs').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_prot_freight_costs',
        #                                                df_table_8.count()))
        df_table_9 = self._get_table(source_database, 'l3_prot_man_airport_fee').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_prot_man_airport_fee',
        #                                                df_table_9.count()))
        df_table_10 = self._get_table(source_database, 'l3_prot_man_icms_st').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_prot_man_icms_st',
        #                                                df_table_10.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2, df_table_3, df_table_4, df_table_5,
                                       df_table_6, df_table_7, df_table_8, df_table_9, df_table_10)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)


    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign all input tables
        df_table_S = args[0].cache()
        df_table_TMPC = args[1].cache()
        df_table_OICC = args[2].cache()
        df_table_OAFC = args[3].cache()
        df_table_OAFE = args[4].cache()
        df_table_CAE = args[5].cache()
        df_table_PAF = args[6].cache()
        df_table_FRT = args[7].cache()
        df_table_AF = args[8].cache()
        df_table_ICMSC = args[9].cache()

        # df_table_S --- l41_prot_fact_sales_billing_cost_allocation_br_s1
        # create table TMPV
        df_table_TMPV = df_table_S.groupBy(
            df_table_S.prod_grp,
            df_table_S.period
        ) \
            .agg(f.sum(df_table_S.litres).alias('vol_tot')).select(
            f.col('prod_grp'),
            f.col('period'),
            f.col('vol_tot')
        )

        # create table OICA
        df_table_OICA = df_table_S.groupBy(
            df_table_S.period
        ) \
            .agg(f.sum(df_table_S.litres).alias('vol_tot')).select(
            f.col('period'),
            f.col('vol_tot')
        )

        # create table OICS
        df_table_OICS = df_table_S.groupBy(
            df_table_S.cae_sector,
            df_table_S.period
        ) \
            .agg(f.sum(df_table_S.litres).alias('vol_tot')).select(
            f.col('cae_sector'),
            f.col('period'),
            f.col('vol_tot')
        )

        # create table OAC
        df_table_OAC = df_table_S.groupBy(
            df_table_S.plant_sector,
            df_table_S.cae_plant,
            df_table_S.period
        ) \
            .agg(f.count('*').alias('del_cnt')).select(
            f.col('plant_sector'),
            f.col('cae_plant'),
            f.col('period'),
            f.col('del_cnt')
        )

        # create table PAT
        df_table_PAT = df_table_S.filter(df_table_S.cae_plant != 'Bulk') \
            .groupBy(
            df_table_S.cae_paf_loc,
            df_table_S.period
        ) \
            .agg(f.sum(df_table_S.litres).alias('vol_tot')).select(
            f.col('cae_paf_loc'),
            f.col('period'),
            f.col('vol_tot')
        )

        # df_table_PAF --- l3_prot_paf_costs
        # create table PAFREC
        df_table_PAFREC = df_table_PAF.filter(
            df_table_PAF.type.isin('Transport', 'Other')
            | ((df_table_PAF.type == 'Product') & (df_table_PAF.location == 'REC'))
        ) \
            .groupBy(
            df_table_PAF.period
        ) \
            .agg(f.sum(df_table_PAF.cost).alias('cost')).select(
            f.col('period'),
            f.col('cost')
        )

        # df_table_OAFC --- l3_prot_man_costs
        # create table PAFCT
        df_table_PAFCT = df_table_OAFC.filter(df_table_OAFC.cost_type == 'PAF') \
            .groupBy(
            df_table_OAFC.period
        ) \
            .agg(f.sum(df_table_OAFC.cost).alias('tot_cost')).select(
            f.col('period'),
            f.col('tot_cost')
        )

        # df_table_S --- l41_prot_fact_sales_billing_cost_allocation_br_s1, df_table_ICMSC -- l3_prot_man_icms_st
        # create table ICMSV
        df_table_ICMSV = df_table_S.alias('a').join(
            df_table_ICMSC.alias('b'),
            (f.col('a.prod_grp') == f.col('b.prod_grp'))
            & (f.col('a.cae_sector') == (f.when(f.col('b.cae_sector') == 'ALL',
                                                f.when(f.col('a.cae_sector') == 'MILITARY', f.lit('XX'))
                                                .otherwise(f.col('a.cae_sector')))
                                         .otherwise(f.col('b.cae_sector'))))
            & (f.col('a.cae_plant') == (f.when(f.col('b.cae_plant') == 'ALL', f.col('a.cae_plant'))
                                        .otherwise(f.col('b.cae_plant'))))
            & (f.col('a.plant') == (f.when(f.col('b.plant') == 'ALL', f.col('a.plant'))
                                    .otherwise(f.col('b.plant'))))
            & (f.col('a.period') == f.col('b.period'))
        ) \
            .groupBy(
            f.col('b.prod_grp'),
            f.col('b.cae_sector'),
            f.col('b.cae_plant'),
            f.col('b.plant'),
            f.col('b.period'),
        ) \
            .agg(f.sum(f.col('a.litres')).alias('vol_tot')).select(
            f.col('prod_grp'),
            f.col('cae_sector'),
            f.col('cae_plant'),
            f.col('plant'),
            f.col('period'),
            f.col('vol_tot')
        )

        # transformation
        df_tfx_result = df_table_S.alias('S') \
            .join(df_table_TMPC.alias('TMPC'),
                  (f.col('S.prod_grp') == f.col('TMPC.prod_grp'))
                  & (f.col('S.period') == f.col('TMPC.period')), 'left') \
            .join(df_table_TMPV.alias('TMPV'),
                  (f.col('S.prod_grp') == f.col('TMPV.prod_grp'))
                  & (f.col('S.period') == f.col('TMPV.period')), 'left') \
            .join(df_table_OICC.alias('OICC'),
                  (f.col('S.period') == f.col('OICC.period')), 'left') \
            .join(df_table_OICA.alias('OICA'),
                  (f.col('S.period') == f.col('OICA.period')), 'left') \
            .join(df_table_OICS.alias('OICS'),
                  (f.col('S.period') == f.col('OICS.period'))
                  & (f.col('S.cae_sector') == f.col('OICS.cae_sector')), 'left') \
            .join(df_table_OAFC.alias('OAFC'),
                  (f.upper(f.col('S.plant_sector')) == f.upper(f.col('OAFC.sector')))
                  & (f.col('S.period') == f.col('OAFC.period'))
                  & (f.col('OAFC.cost_type') == 'OAF'), 'left') \
            .join(df_table_OAFE.alias('OAFE'),
                  (f.col('S.cae_plant') == f.col('OAFE.location'))
                  & (f.col('S.period') == f.col('OAFE.period'))
                  & (f.col('OAFE.type') == 'Fixed'), 'left') \
            .join(df_table_CAE.alias('CAE'),
                  (f.col('S.cae_plant') == f.col('CAE.location'))
                  & (f.col('S.period') == f.col('CAE.period')), 'left') \
            .join(df_table_OAFC.alias('OAVC'),
                  (f.upper(f.col('S.plant_sector')) == f.upper(f.col('OAVC.sector')))
                  & (f.col('S.period') == f.col('OAVC.period'))
                  & (f.col('OAVC.cost_type') == 'OAV'), 'left') \
            .join(df_table_OAFE.alias('OAVE'),
                  (f.col('S.cae_plant') == f.col('OAVE.location'))
                  & (f.col('S.period') == f.col('OAVE.period'))
                  & (f.col('OAVE.type') == 'Variable'), 'left') \
            .join(df_table_PAFREC.alias('PAFREC'),
                  (f.col('S.period') == f.col('PAFREC.period')), 'left') \
            .join(df_table_PAF.alias('PAFTU1'),
                  (f.col('PAFTU1.location') == 'TU1')
                  & (f.col('S.period') == f.col('PAFTU1.period')), 'left') \
            .join(df_table_PAF.alias('PAFAR1'),
                  (f.col('PAFAR1.location') == 'AR1')
                  & (f.col('S.period') == f.col('PAFAR1.period')), 'left') \
            .join(df_table_OAFC.alias('PAFCS'),
                  (f.upper(f.col('S.plant_sector')) == f.upper(f.col('PAFCS.sector')))
                  & (f.col('S.period') == f.col('PAFCS.period'))
                  & (f.col('PAFCS.cost_type') == 'PAF'), 'left') \
            .join(df_table_PAFCT.alias('PAFCT'),
                  (f.col('S.period') == f.col('PAFCT.period')), 'left') \
            .join(df_table_FRT.alias('FRT'),
                  (f.col('S.plant') == f.col('FRT.plant'))
                  & (f.col('S.prod_grp') == f.col('FRT.prod_grp'))
                  & (f.col('S.period') == f.col('FRT.period')), 'left') \
            .join(df_table_OAC.alias('OAC'),
                  (f.col('S.plant_sector') == f.col('OAC.plant_sector'))
                  & (f.col('S.cae_plant') == f.col('OAC.cae_plant'))
                  & (f.col('S.period') == f.col('OAC.period')), 'left') \
            .join(df_table_PAT.alias('PAT'),
                  (f.col('S.cae_paf_loc') == f.col('PAT.cae_paf_loc'))
                  & (f.col('S.period') == f.col('PAT.period')), 'left') \
            .join(df_table_AF.alias('AF'),
                  (f.col('S.material_number') == f.col('AF.material_number'))
                  & (f.col('S.plant') == f.col('AF.plant'))
                  & (f.year(f.col('S.period')) == f.col('AF.af_year')), 'left') \
            .join(df_table_ICMSC.alias('ICMSC'),
                  (f.col('S.prod_grp') == f.col('ICMSC.prod_grp'))
                  & (f.col('S.period') == f.col('ICMSC.period'))
                  & (f.col('S.cae_sector') == (f.when(f.col('ICMSC.cae_sector') == 'ALL',
                                                      f.when(f.col('S.cae_sector') == 'MILITARY', f.lit('XX'))
                                                      .otherwise(f.col('S.cae_sector')))
                                               .otherwise(f.col('ICMSC.cae_sector'))))
                  & (f.col('S.cae_plant') == (f.when(f.col('ICMSC.cae_plant') == 'ALL', f.col('S.cae_plant'))
                                              .otherwise(f.col('ICMSC.cae_plant'))))
                  & (f.col('S.plant') == (f.when(f.col('ICMSC.plant') == 'ALL', f.col('S.plant'))
                                          .otherwise(f.col('ICMSC.plant'))))
                  , 'left') \
            .join(df_table_ICMSV.alias('ICMSV'),
                  (f.col('S.prod_grp') == f.col('ICMSV.prod_grp'))
                  & (f.col('S.period') == f.col('ICMSV.period'))
                  & (f.col('S.cae_sector') == (f.when(f.col('ICMSV.cae_sector') == 'ALL',
                                                      f.when(f.col('S.cae_sector') == 'MILITARY', f.lit('XX'))
                                                      .otherwise(f.col('S.cae_sector')))
                                               .otherwise(f.col('ICMSV.cae_sector'))))
                  & (f.col('S.cae_plant') == (f.when(f.col('ICMSV.cae_plant') == 'ALL', f.col('S.cae_plant'))
                                              .otherwise(f.col('ICMSV.cae_plant'))))
                  & (f.col('S.plant') == (f.when(f.col('ICMSV.plant') == 'ALL', f.col('S.plant'))
                                          .otherwise(f.col('ICMSV.plant'))))
                  , 'left') \
            .select(
            f.col('S.*'),
            (f.col('S.lcl_net_val') - f.coalesce(f.col('AF.apf_rate') * f.col('S.litres'), f.lit(0)) -
             (f.coalesce(f.col('ICMSC.icmsst_val'), f.lit(0)) * f.coalesce(
                 f.col('S.litres') / f.col('ICMSV.vol_tot'), f.lit(0)))).alias('lcl_man_val'),
            f.coalesce(f.col('TMPC.temp_val') * (f.col('S.litres') / f.col('TMPV.vol_tot')), f.lit(0)).alias(
                'lcl_tmp_val'),
            f.coalesce(f.col('AF.apf_rate') * f.col('S.litres'), f.lit(0)).alias('lcl_apf_val'),
            (f.coalesce(f.col('ICMSC.icmsst_val'), f.lit(0)) * f.coalesce(f.col('S.litres') / f.col('ICMSV.vol_tot'),
                                                                          f.lit(0))).alias('lcl_icm_val'),
            (f.coalesce(f.col('TMPC.temp_val') * (f.col('S.litres') / f.col('TMPV.vol_tot')), f.lit(0)) - f.coalesce(
                f.col('AF.apf_rate') * f.col('S.litres'), f.lit(0)) - (
                         f.coalesce(f.col('ICMSC.icmsst_val'), f.lit(0)) * f.coalesce(
                     f.col('S.litres') / f.col('ICMSV.vol_tot'), f.lit(0)))).alias('lcl_adj_val'),
            f.when((f.col('S.period') < f.to_date(f.lit('2020-06-01'))) & (f.col('S.cae_sector') == 'GA'),
                   f.coalesce(f.col('OICC.oic_val'), f.lit(0)) * (f.col('S.litres') / f.col('OICS.vol_tot')))
                .when((f.col('S.period') < f.to_date(f.lit('2020-06-01'))) & (f.col('S.cae_sector') != 'GA'), f.lit(0))
                .otherwise(
                f.coalesce(f.col('OICC.oic_val'), f.lit(0)) * (f.col('S.litres') / f.col('OICA.vol_tot'))).alias(
                'lcl_oic_val'),
            f.when(f.col('S.cae_plant') == 'Bulk', f.lit(0))
                .when(f.col('S.cae_sector') == 'GA',
                      f.coalesce(f.col('OAFC.cost'), f.lit(0)) * f.coalesce(f.col('OAFE.exp'), f.lit(0)) * (
                              1 - f.coalesce(f.col('CAE.rate'), f.lit(0))) / f.coalesce(f.col('OAFC.cost'),
                                                                                        f.lit(0)) / f.col(
                          'OAC.del_cnt'))
                .when(f.col('S.cae_sector') == 'CA',
                      f.coalesce(f.col('OAFC.cost'), f.lit(0)) * f.coalesce(f.col('OAFE.exp'),
                                                                            f.lit(0)) * f.coalesce(
                          f.col('CAE.rate'), f.lit(0)) / f.coalesce(f.col('OAFC.cost'), f.lit(0)) / f.col(
                          'OAC.del_cnt'))
                .otherwise(f.lit(0)).alias('lcl_oaf_val2'),
            f.when(f.col('S.cae_plant') == 'Bulk', f.lit(0))
                .when(f.col('S.cae_sector') == 'GA',
                      f.coalesce(f.col('OAVC.cost'), f.lit(0)) * f.coalesce(f.col('OAVE.exp'), f.lit(0)) * (
                              1 - f.coalesce(f.col('CAE.rate'), f.lit(0))) / f.coalesce(f.col('OAVC.cost'),
                                                                                        f.lit(0)) / f.col(
                          'OAC.del_cnt'))
                .when(f.col('S.cae_sector') == 'CA',
                      f.coalesce(f.col('OAVC.cost'), f.lit(0)) * f.coalesce(f.col('OAVE.exp'),
                                                                            f.lit(0)) * f.coalesce(
                          f.col('CAE.rate'), f.lit(0)) / f.coalesce(f.col('OAVC.cost'), f.lit(0)) / f.col(
                          'OAC.del_cnt'))
                .otherwise(f.lit(0)).alias('lcl_oav_val2'),
            f.when(f.col('S.cae_plant') == 'Bulk', f.lit(0))
                .when(f.col('S.cae_paf_loc') == 'N/A', f.lit(0))
                .when(f.col('S.cae_paf_loc') == 'CAREC', f.coalesce(
                (f.col('PAFREC.cost') + f.col('PAFTU1.cost')) * (
                        f.col('PAFCS.cost') / f.col('PAFCT.tot_cost')) * (
                        f.col('S.litres') / f.col('PAT.vol_tot')), f.lit(0)))
                .when(f.col('S.cae_paf_loc') == 'GAREC', f.coalesce(
                (f.col('PAFREC.cost') - f.col('PAFTU1.cost')) * (
                        f.col('PAFCS.cost') / f.col('PAFCT.tot_cost')) * (
                        f.col('S.litres') / f.col('PAT.vol_tot')), f.lit(0)))
                .when(f.col('S.cae_paf_loc') == 'TU1', f.coalesce(
                f.col('PAFTU1.cost') * (f.col('PAFCS.cost') / f.col('PAFCT.tot_cost')) * (
                        f.col('S.litres') / f.col('PAT.vol_tot')), f.lit(0)))
                .when((f.col('S.cae_paf_loc') == 'GAAR1') | (f.col('S.cae_paf_loc') == 'CAAR1'), f.coalesce(
                f.col('PAFAR1.cost') * (f.col('PAFCS.cost') / f.col('PAFCT.tot_cost')) * (
                        f.col('S.litres') / f.col('PAT.vol_tot')), f.lit(0)))
                .otherwise(f.lit(0)).alias('lcl_paf_val2'),
            f.col('FRT.avg_frt_rate').alias('frt_rate'),
            f.when(f.col('S.pav_sector') == 'Hub', f.lit(0))
                .otherwise(f.coalesce(f.col('FRT.avg_frt_rate') * f.col('S.litres'), f.lit(0))).alias('lcl_pav_val2')

        )


        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()
