# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    06-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to l41_prot_fact_sales_billing_cost_allocation_br_s1
#                   into conform zone
# Author        :- Tingting Wan
# Date          :- 06-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================

        self.report_file = "l41_prot_fact_sales_billing_cost_allocation_br_s1"

        #print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):

        # generate input table list
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, 'l4_prot_fact_sales_billing').toDF()
        #print("data count of table {}.{} is {}".format(source_database, 'l4_prot_fact_sales_billing',
        #                                               df_table_1.count()))
        df_table_2 = self._get_table(source_database, 'l4_prot_dim_customer').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l4_prot_dim_customer',
        #                                                df_table_2.count()))
        df_table_3 = self._get_table(source_database, 'l4_prot_dim_location').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l4_prot_dim_location',
        #                                                df_table_3.count()))
        df_table_4 = self._get_table(source_database, 'l3_prot_za0010_price_hdr').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_prot_za0010_price_hdr',
        #                                                df_table_4.count()))
        df_table_5 = self._get_table(source_database, 'l32_prot_za1010_price_itm').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l32_prot_za1010_price_itm',
        #                                                df_table_5.count()))
        df_table_6 = self._get_table(source_database, 'l3_prot_man_cogs').toDF()
        # print("data count of table {}.{} is {}".format(source_database, 'l3_prot_man_cogs',
        #                                                df_table_6.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2, df_table_3, df_table_4, df_table_5, df_table_6)
        #print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign all input tables
        df_table_F = args[0].cache()
        df_table_C = args[1]
        df_table_L = args[2]
        df_table_PH = args[3]
        df_table_PI = args[4]
        df_table_COGS = args[5]

        # join and filter dataframes
        # create table PIA
        df_table_PIA = df_table_PI.groupBy(
            df_table_PI.za1_codtab,
            df_table_PI.za1_rev
        ) \
            .agg(f.avg(df_table_PI.za1_exref).alias('za1_exref')).select(
            f.col('za1_codtab'),
            f.col('za1_rev'),
            f.col('za1_exref')
        )

        # transformation
        df_tfx_result = df_table_F\
            .join(df_table_C.alias('C'),
                  (f.col('C.erp_id') == df_table_F.shipto_party)
                  & (f.col('C.source_system') == 'BRA'), 'left')\
            .join(df_table_L.alias('L'),
                  (f.col('L.plant') == df_table_F.plant)
                  & (f.col('L.source_system') == 'BRA'), 'left')\
            .join(df_table_PH.alias('PH'),
                  (f.col('PH.za0_codpro') == df_table_F.material_number)
                  & (f.col('PH.za0_ativa') == 1)
                  & (df_table_F.delivery_date.between(f.col('PH.za0_dtini'), f.col('PH.za0_dtfim'))), 'left')\
            .join(df_table_PI.alias('PI'),
                  (f.col('PI.za1_codtab') == f.col('PH.za0_codtab'))
                  & (f.col('PI.za1_rev') == f.col('PH.za0_rev'))
                  & (f.col('PI.za1_base') == f.col('L.unique_location_identifier')), 'left')\
            .join(df_table_PIA.alias('PIA'),
                  (f.col('PIA.za1_codtab') == f.col('PH.za0_codtab'))
                  & (f.col('PIA.za1_rev') == f.col('PH.za0_rev')), 'left')\
            .join(df_table_COGS.alias('COGS'),
                  (df_table_F.material_number == f.col('COGS.material_number'))
                  & (df_table_F.plant == f.col('COGS.plant'))
                  & (f.substring(df_table_F.shipto_party, 1, 6) == f.col('COGS.customer_mnmc'))
                  & (f.last_day(df_table_F.billing_date).cast('date') == f.col('COGS.period')), 'left') \
            .filter(
            ((df_table_F.material_number == 'A08240N') | (f.substring(df_table_F.material_number, 1, 6) == 'A08601'))
            & (df_table_F.f2_fimp == 'S')
            & (f.year(df_table_F.delivery_date) >= 2018)
        )  \
            .select(
            df_table_F.ref_id,
            f.lit('BR').alias('country_mnmc'),
            df_table_F.sales_document,
            df_table_F.billing_document,
            df_table_F.billing_item,
            df_table_F.billing_type,
            df_table_F.billing_type_desc,
            df_table_F.sales_organisation,
            f.col('C.sector'),
            f.when(f.col('C.sector') == 'Commercial Airlines', f.lit('CA'))
                .when(f.col('C.sector') == 'Military', f.lit('MILITARY'))
                .otherwise(f.lit('GA')).alias('cae_sector'),
            df_table_F.shipto_party.alias('customer_id'),
            f.substring(df_table_F.shipto_party, 1, 6).alias('customer_mnmc'),
            f.substring(df_table_F.shipto_party, 7, 2).alias('customer_store'),
            f.col('C.customer_account_name').alias('customer_name'),
            f.col('C.group').alias('customer_group'),
            f.col('L.unique_location_identifier').alias('plant_id'),
            df_table_F.plant,
            f.col('L.airport_name').alias('plant_name'),
            f.when(df_table_F.plant == 'CFB', f.lit('CFB'))
                .when(f.substring(df_table_F.shipto_party, 1, 6) == 'CGR068', f.lit('CFB'))
                .when(df_table_F.shipto_party == 'CGM43601', f.lit('CGB'))
                .when(df_table_F.shipto_party == 'CGJ12201', f.lit('CPR'))
                .when(df_table_F.shipto_party == 'CGB04101', f.lit('DAM'))
                .when(df_table_F.shipto_party == 'CGP09601', f.lit('DJD'))
                .when(df_table_F.shipto_party == 'CGV22701', f.lit('GYN'))
                .when(df_table_F.shipto_party == 'CGC53501', f.lit('IGU'))
                .when(df_table_F.shipto_party == 'CGJ11901', f.lit('JCR'))
                .when(df_table_F.shipto_party == 'CGJ08001', f.lit('MEA'))
                .when(df_table_F.shipto_party == 'CGP10801', f.lit('MGF'))
                .when((df_table_F.shipto_party == 'CGJ10601') |
                      (df_table_F.shipto_party == 'CGJ10604'), f.lit('PLU'))
                .when(df_table_F.shipto_party == 'CGP10301', f.lit('RAO'))
                .when(df_table_F.shipto_party == 'CGP11201', f.lit('SP2'))
                .when(df_table_F.shipto_party == 'CGJ09701', f.lit('VIX'))
                .when(f.substring(df_table_F.shipto_party, 1, 2) == 'CG', f.lit('Bulk'))
                .otherwise(df_table_F.plant).alias('cae_plant'),
            f.when((df_table_F.plant == 'CFB')
                   | (f.substring(df_table_F.shipto_party, 1, 6) == 'CGR068')
                   | (df_table_F.shipto_party == 'CGM43601')
                   | (df_table_F.shipto_party == 'CGJ12201')
                   | (df_table_F.shipto_party == 'CGB04101')
                   | (df_table_F.shipto_party == 'CGP09601')
                   | (df_table_F.shipto_party == 'CGV22701')
                   | (df_table_F.shipto_party == 'CGC53501')
                   | (df_table_F.shipto_party == 'CGJ11901')
                   | (df_table_F.shipto_party == 'CGJ08001')
                   | (df_table_F.shipto_party == 'CGP10801')
                   | (df_table_F.shipto_party == 'CGJ10601')
                   | (df_table_F.shipto_party == 'CGJ10604')
                   | (df_table_F.shipto_party == 'CGP10301')
                   | (df_table_F.shipto_party == 'CGP11201')
                   | (df_table_F.shipto_party == 'CGJ09701'),
                   f.when((f.col('C.sector') == 'Commercial Airlines') & (df_table_F.plant == 'GRU'), f.lit('Hub'))
                   .when((f.col('C.sector') == 'Commercial Airlines') & (df_table_F.plant != 'GRU'), f.lit('Regional'))
                   .when(f.col('C.sector') == 'Military', f.lit('MILITARY'))
                   .otherwise(f.lit('GA')))
                .when(f.substring(df_table_F.shipto_party, 1, 2) == 'CG', f.lit('GA'))
                .otherwise(
                f.when((f.col('C.sector') == 'Commercial Airlines') & (df_table_F.plant == 'GRU'), f.lit('Hub'))
                    .when((f.col('C.sector') == 'Commercial Airlines') & (df_table_F.plant != 'GRU'), f.lit('Regional'))
                    .when(f.col('C.sector') == 'Military', f.lit('MILITARY'))
                    .otherwise(f.lit('GA'))
            ).alias('pav_sector'),
            f.when((f.col('C.sector') == 'Commercial Airlines') & (df_table_F.plant == 'GRU'), f.lit('Hub'))
                .when((f.col('C.sector') == 'Commercial Airlines') & (df_table_F.plant != 'GRU'), f.lit('Regional'))
                .when(f.col('C.sector') == 'Military', f.lit('Military'))
                .otherwise(f.lit('GA')).alias('plant_sector'),
            f.when((f.col('C.sector') == 'Commercial Airlines') & (df_table_F.plant == 'GRU'), f.lit('N/A'))
                .when(f.col('C.sector') == 'Military', f.lit('N/A'))
                .when(df_table_F.material_number == 'A08240N', f.lit('TU1'))
                .when((f.substring(df_table_F.material_number, 1, 6) == 'A08601') & (df_table_F.plant == 'REC')
                      & (f.col('C.sector') == 'Commercial Airlines'), f.lit('CAREC'))
                .when((f.substring(df_table_F.material_number, 1, 6) == 'A08601') & (df_table_F.plant == 'REC'),
                      f.lit('GAREC'))
                .when((f.substring(df_table_F.material_number, 1, 6) == 'A08601')
                      & ((df_table_F.plant == 'AR1') | (df_table_F.plant == 'CGB') | (df_table_F.plant == 'MGF') | (
                    df_table_F.plant == 'CWB') | (df_table_F.plant == 'IGU'))
                      & (f.col('C.sector') == 'Commercial Airlines'), f.lit('CAAR1'))
                .when((f.substring(df_table_F.material_number, 1, 6) == 'A08601')
                      & ((df_table_F.plant == 'AR1') | (df_table_F.plant == 'CGB') | (df_table_F.plant == 'MGF') | (
                    df_table_F.plant == 'CWB') | (df_table_F.plant == 'IGU')), f.lit('GAAR1'))
                .otherwise(f.lit('N/A')).alias('cae_paf_loc'),
            df_table_F.material_number,
            df_table_F.material_description,
            f.when(df_table_F.material_number == 'A08240N', f.lit('#AVGAS'))
                .when(f.substring(df_table_F.material_number, 1, 6) == 'A08601', f.lit('#JETS'))
                .otherwise(f.lit('#NONFUEL')).alias('prod_grp'),
            f.when(df_table_F.material_number == 'A08240N', f.lit('A'))
                .when(f.substring(df_table_F.material_number, 1, 6) == 'A08601', f.lit('J'))
                .otherwise(f.lit('X')).alias('item_category'),
            df_table_F.exchange_rate_type,
            df_table_F.exchange_rate,
            df_table_F.delivery_date.cast('date').alias('delivery_date'),
            df_table_F.d2_emissao.cast('date').alias('d2_emissao'),
            df_table_F.billing_date.cast('date').alias('billing_date'),
            f.last_day(df_table_F.billing_date.cast('date')).alias('period'),
            df_table_F.document_currency,
            df_table_F.local_currency,
            df_table_F.litres,
            df_table_F.ugl,
            (df_table_F.net_value / df_table_F.net_value_lc).alias('ile_exch_rate'),
            (df_table_F.net_value_lc / df_table_F.net_value_gc).alias('lre_exch_rate'),
            (df_table_F.net_value / df_table_F.net_value_gc).alias('ire_exch_rate'),
            df_table_F.net_value,
            df_table_F.net_value_lc.alias('lcl_net_val'),
            df_table_F.net_value_gc.alias('usd_net_val'),
            f.col('PH.za0_codtab'), f.col('PH.za0_rev'),
            f.col('PI.za1_exref').alias('pi_za1_exref'),
            f.col('PIA.za1_exref').alias('pia_za1_exref'),
            f.coalesce(f.col('PI.za1_exref'), f.col('PIA.za1_exref')).alias('lcl_cop_sys_rate'),
            f.coalesce(f.col('COGS.cogs_rate'), f.lit(0)).alias('lcl_cop_man_rate'),
            f.coalesce(f.coalesce(f.col('PI.za1_exref'), f.col('PIA.za1_exref')) * df_table_F.litres, f.lit(0)).alias(
                'lcl_cop_sys_val'),
            (f.coalesce(f.coalesce(f.col('PI.za1_exref'), f.col('PIA.za1_exref')) * df_table_F.litres, f.lit(0))
             - f.coalesce(f.col('COGS.cogs_rate') * df_table_F.litres, f.lit(0))).alias('lcl_cosa_val'),
            f.when(f.last_day(df_table_F.billing_date.cast('date')).between('2018-01-01',
                                                                            '2020-12-31'),
                   f.coalesce(f.col('COGS.cogs_rate') * df_table_F.litres, f.lit(0)))
                .otherwise(f.coalesce(f.coalesce(f.col('PI.za1_exref'), f.col('PIA.za1_exref')) * df_table_F.litres,
                                      f.lit(0))).alias('lcl_cop_val'),
            f.lit(0).cast('double').alias('lcl_lag_val')
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()
