# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      07-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to l41_prot_fact_sales_billing_s4 into conform zone
# Author        :- Liz Harvey
# Date          :- 07-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import expr, col
from awsglue.job import Job


class LcpPROTETL:

    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l41_prot_fact_sales_billing_cost_allocation_br_s3"
        self.report_file = "l41_prot_fact_sales_billing_cost_allocation_br_s4"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(self.source_database, 'l41_prot_fact_sales_billing_cost_allocation_br_s3').toDF()
        #print("data count of table {}.{} is {}".format(self.source_database,
        #                                               'l41_prot_fact_sales_billing_cost_allocation_br_s3',
        #                                               df_table_1.count()))
        df_table_2 = self._get_table(self.source_database, 'l3_prot_man_costs').toDF()
        #print("data count of table {}.{} is {}".format(self.source_database, 'l3_prot_man_costs',
        #                                               df_table_2.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2)
        #print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # assign input tables
        df_table_S = args[0].cache()
        df_table_MAN = args[1].cache()

        # df_table_S --- l41_prot_fact_sales_billing_cost_allocation_br_s3
        # df_table_MAN --- l31_prot_man_costs

        # OAFD table creation
        df_table_oafd = df_table_S.filter(f.col("cae_plant") != "Bulk") \
            .groupBy(f.col("period")) \
            .agg(f.count('*').alias('del_cnt'),
                 f.sum(f.col("litres")).alias("vol_tot"),
                 f.sum(f.col("lcl_oaf_val3")).alias("oaf_val")).select(
            f.col('period'),
            f.col('del_cnt'),
            f.col('vol_tot'),
            f.col('oaf_val')
        )

        # OAVD table creation
        df_table_oavd = df_table_S.filter(f.col("cae_plant") != "Bulk") \
            .groupBy(f.col("period")) \
            .agg(f.count(f.col("*")).alias("del_cnt"),
                 f.sum(f.col("litres")).alias("vol_tot"),
                 f.sum(f.col("lcl_oav_val3")).alias("oav_val")).select(
            f.col('period'),
            f.col('del_cnt'),
            f.col('vol_tot'),
            f.col('oav_val')
        )

        # PAFD table creation
        df_table_pafd = df_table_S.filter(f.col("cae_plant") != "Bulk") \
            .filter(f.col("cae_paf_loc") != "N/A") \
            .groupBy(f.col("period")) \
            .agg(f.count(f.col("*")).alias("del_cnt"),
                 f.sum(f.col("litres")).alias("vol_tot"),
                 f.sum(f.col("lcl_paf_val3")).alias("paf_val")).select(
            f.col('period'),
            f.col('del_cnt'),
            f.col('vol_tot'),
            f.col('paf_val')
        )

        # PAVD table creation
        df_table_pavd = df_table_S.filter(f.col("pav_sector") != "Hub") \
            .groupBy(f.col("period")) \
            .agg(f.count(f.col("*")).alias("del_cnt"),
                 f.sum(f.col("litres")).alias("vol_tot"),
                 f.sum(f.col("lcl_pav_val3")).alias("pav_val")).select(
            f.col('period'),
            f.col('del_cnt'),
            f.col('vol_tot'),
            f.col('pav_val')
        )

        # transform cost tables =========================================
        # OAFC table creation
        df_table_oafc = df_table_MAN.filter(f.col("cost_type") == "OAF") \
            .groupBy("period") \
            .agg(f.sum("cost").alias("cost")).select(
            f.col('period'),
            f.col('cost')
        )

        # OAVC table creation
        df_table_oavc = df_table_MAN.filter(f.col("cost_type") == "OAV") \
            .groupBy("period") \
            .agg(f.sum("cost").alias("cost")).select(
            f.col('period'),
            f.col('cost')
        )

        # PAFC table creation
        df_table_pafc = df_table_MAN.filter(f.col("cost_type") == "PAF") \
            .groupBy("period") \
            .agg(f.sum("cost").alias("cost")).select(
            f.col('period'),
            f.col('cost')
        )

        # PAVC table creation
        df_table_pavc = df_table_MAN.filter(f.col("cost_type") == "PAV") \
            .groupBy(f.col("period")) \
            .agg(f.sum("cost").alias("cost")).select(
            f.col('period'),
            f.col('cost')
        )

        # transformation
        df_tfx_result = df_table_S.alias('S') \
            .join(df_table_oafc.alias('OAFC'),
                  (f.col('S.period') == f.col('OAFC.period')), 'left') \
            .join(df_table_oavc.alias('OAVC'),
                  (f.col('S.period') == f.col('OAVC.period')), 'left') \
            .join(df_table_pafc.alias('PAFC'),
                  (f.col('S.period') == f.col('PAFC.period')), 'left') \
            .join(df_table_pavc.alias('PAVC'),
                  (f.col('S.period') == f.col('PAVC.period')), 'left') \
            .join(df_table_oafd.alias('OAFD'),
                  (f.col('S.period') == f.col('OAFD.period')), 'left') \
            .join(df_table_oavd.alias('OAVD'),
                  (f.col('S.period') == f.col('OAVD.period')), 'left') \
            .join(df_table_pafd.alias('PAFD'),
                  (f.col('S.period') == f.col('PAFD.period')), 'left') \
            .join(df_table_pavd.alias('PAVD'),
                  (f.col('S.period') == f.col('PAVD.period')), 'left') \
            .select(f.col("S.*"),
            f.when(f.col("S.cae_plant") == 'Bulk', f.lit(0))
             .when(f.col("S.cae_sector").isin('CA', 'GA'),
                   f.coalesce((f.col('OAFC.cost') - f.col('OAFD.oaf_val')) /
                   f.col('OAFD.del_cnt'), f.lit(0)))
             .otherwise(f.lit(0)).alias('lcl_oaf_add4'),
            f.when(f.col("S.cae_plant") == 'Bulk', f.lit(0))
             .when(f.col("S.cae_sector").isin('CA', 'GA'),
                   f.coalesce((f.col('OAVC.cost') - f.col('OAVD.oav_val')) /
                   f.col('OAVD.del_cnt'), f.lit(0)))
             .otherwise(f.lit(0)).alias('lcl_oav_add4'),
            f.when(f.col("S.cae_plant") == 'Bulk', f.lit(0))
             .when(f.col("S.cae_paf_loc") == 'N/A', f.lit(0))
             .otherwise(f.coalesce((f.col("PAFC.cost") - f.col("PAFD.paf_val")) *
                        (f.col("S.litres") / f.col("PAFD.vol_tot")), f.lit(0)))
             .alias('lcl_paf_add4'),
            f.when(f.col("S.pav_sector") == 'Hub', f.lit(0))
             .otherwise(f.coalesce((f.col("PAVC.cost") - f.col("PAVD.pav_val")) *
                        (f.col("S.litres") / f.col("PAVD.vol_tot")), f.lit(0)))
             .alias('lcl_pav_add4'),
            f.when(f.col("S.cae_plant") == 'Bulk', f.lit(0))
             .when(f.col("S.cae_sector").isin('CA', 'GA'),
                   f.col("S.lcl_oaf_val3") +
                   f.coalesce((f.col("OAFC.cost") - f.col("OAFD.oaf_val")) /
                   f.col("OAFD.del_cnt"), f.lit(0)))
             .otherwise(f.lit(0)).alias('lcl_oaf_val'),
            f.when(f.col("S.cae_plant") == 'Bulk', f.lit(0))
             .when(f.col("cae_sector").isin('CA', 'GA'),
                   f.col("S.lcl_oav_val3") +
                   f.coalesce((f.col("OAVC.cost") - f.col("OAVD.oav_val")) /
                   f.col("OAVD.del_cnt"), f.lit(0)))
             .otherwise(f.lit(0)).alias('lcl_oav_val'),
            f.col("PAFC.cost").alias("paf_cost"),
            f.when(f.col("S.cae_plant") == 'Bulk', f.lit(0))
             .when(f.col("S.cae_paf_loc") == 'N/A', f.lit(0))
             .otherwise(f.col("S.lcl_paf_val3") +
                        f.coalesce((f.col("PAFC.cost") - f.col("PAFD.paf_val")) *
                        (f.col("S.litres") / f.col("PAFD.vol_tot")), f.lit(0)))
             .alias("lcl_paf_val"),
            f.when(f.col("S.pav_sector") == 'Hub', f.lit(0))
             .otherwise(f.col("S.lcl_pav_val3") +
                        f.coalesce((f.col("PAVC.cost") - f.col("PAVD.pav_val")) *
                        (f.col("S.litres") / f.col("PAVD.vol_tot")), f.lit(0)))
             .alias("lcl_pav_val")
            )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()