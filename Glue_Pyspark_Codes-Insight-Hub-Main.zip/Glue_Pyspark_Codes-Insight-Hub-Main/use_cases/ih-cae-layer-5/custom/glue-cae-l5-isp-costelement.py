# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1             Bakul Seth       29-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-cae-l5-isp-costelement into conform zone
# Author        :- Bakul Seth
# Date          :- 29-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class SunIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'netapp_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.netapp_database = args['netapp_database']
        self.destination_bucket = args['destination_bucket']
        self.environment = args['environment']

        # report specific =============================================
        self.input_tables = ['l42_isp_fact_sales_pricing_conditions', 'l4_isp_fact_sales_billing',
                             'l2_l5_dim_waterfall_global']
        self.report_file = 'l5_isp_costelement'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        print('Reading data from input tabled {}.{}'.format(self.source_database, self.input_tables))
        df_input_table = self._get_table(self.source_database, self.netapp_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('applying the transformations')
        df_tfx_table = self._apply_tfx(df_input_table)
        print('schema after transformation ', df_tfx_table.printSchema())

        # write final result to required destination
        print('Writing the results to desired location')
        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, netapp_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name[0]))
        df_price_cond = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[0],
                                                                   transformation_ctx='target_table').toDF()
        df_price_cond.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[1]))
        df_sale_billing = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[1],
                                                                     transformation_ctx='target_table').toDF()
        df_sale_billing.printSchema()

        print('reading data from {}.{}'.format(netapp_database, table_name[2]))
        df_waterfall = self._gc.create_dynamic_frame.from_catalog(database=netapp_database, table_name=table_name[2],
                                                                  transformation_ctx='target_table').toDF()
        df_waterfall.printSchema()

        return [df_price_cond, df_sale_billing, df_waterfall]

    @staticmethod
    def _apply_tfx(df_input_table):
        # creating dataframe for different tables
        print('creating dataframe for different tables')
        price_cond = df_input_table[0]

        sales_billing = df_input_table[1]

        waterfall = df_input_table[2]

        # Applying the transformation
        print('applying the transformations df_cost_all1')
        df_tfx_result = price_cond.join(waterfall, f.trim(f.upper(price_cond.condition_type)) ==
                                        f.trim(f.upper(waterfall.condition_type)), 'left') \
            .join(sales_billing, price_cond.ref_id == sales_billing.ref_id, 'left') \
            .filter((f.trim(f.upper(waterfall.hierarchy_level_5)).isin(['BUSINESS OVERHEADS', 'BUSINESS DEPRECIATION',
                                                                        'TEMP CORRECTION']) == False) &
                    (price_cond.ref_id.isin(['ISP_ESP0750_7500217236641_1_1', 'ISP_ESP0750_7500250974070_1_1',
                                             'ISP_ESP0750_7500258029379_1_1', 'ISP_ESP0750_7500258812927_1_1',
                                             'ISP_ESP0750_7500261584096_1_1', 'ISP_ESP0750_7500261584108_1_1',
                                             'ISP_ESP0750_7500281376800_1_1', 'ISP_ESP0750_7500287321768_1_1',
                                             'ISP_ESP0750_7500287693951_1_1', 'ISP_ESP0750_7500288547622_1_1',
                                             'ISP_ESP0750_7500291273441_1_1', 'ISP_ESP0750_7500297520987_1_1',
                                             'ISP_ESP0750_7500305229323_1_1', 'ISP_ESP0750_7500305229390_1_1',
                                             'ISP_ESP0750_7500305229397_1_1', 'ISP_ESP0750_7500305229959_1_1',
                                             'ISP_ESP0750_7500317942182_1_1', 'ISP_ESP0750_7500317942352_1_1',
                                             'ISP_ESP0750_7500317942591_1_1', 'ISP_ESP0750_7500317942639_1_1',
                                             'ISP_ESP0750_7500320231513_1_1', 'ISP_ESP0750_7500320241573_1_1',
                                             'ISP_ESP0750_7500320241580_1_1', 'ISP_ESP0750_7500320241604_1_1',
                                             'ISP_ESP0750_7500320241609_1_1', 'ISP_ESP0166_1660403877476_1_1',
                                             'ISP_ESP0166_1660403877476_2_1', 'ISP_ESP0166_1660403880085_1_1',
                                             'ISP_ESP0166_1660403880085_2_1', 'ISP_ESP0166_1660403880108_1_1',
                                             'ISP_ESP0166_1660403901491_1_1', 'ISP_ESP0166_1660403901491_2_1',
                                             'ISP_ESP0166_1660403901495_1_1', 'ISP_ESP0166_1660403901541_1_1',
                                             'ISP_ESP0166_1660403901541_3_1', 'ISP_ESP0166_1660403901547_1_1',
                                             'ISP_ESP0166_1660403901560_1_1', 'ISP_ESP0166_1660403901560_2_1',
                                             'ISP_ESP0166_1660403901560_4_1', 'ISP_ESP0166_1660403901560_5_1',
                                             'ISP_ESP0166_1660403901560_7_1', 'ISP_ESP0166_1660403901560_8_1',
                                             'ISP_ESP0166_1660403901591_1_1', 'ISP_ESP0166_1660403901599_1_1',
                                             'ISP_ESP0166_1660403901599_3_1', 'ISP_ESP0166_1660403901599_5_1',
                                             'ISP_ESP0166_1660403901599_7_1', 'ISP_ESP0166_1660403901599_9_1',
                                             'ISP_ESP0166_1660403901621_1_1', 'ISP_ESP0166_1660403901621_3_1',
                                             'ISP_ESP0166_1660403901650_1_1', 'ISP_ESP0166_1660403901657_1_1',
                                             'ISP_ESP0166_1660403901657_2_1', 'ISP_ESP0166_1660403901657_3_1',
                                             'ISP_ESP0166_1660403901680_1_1', 'ISP_ESP0166_1660403901680_2_1',
                                             'ISP_ESP0166_1660403901680_3_1', 'ISP_ESP0166_1660403901680_4_1',
                                             'ISP_ESP0166_1660403901680_6_1', 'ISP_ESP0166_1660403901680_7_1',
                                             'ISP_ESP0166_1660403901680_8_1', 'ISP_ESP0166_1660403901680_9_1',
                                             'ISP_ESP0166_1660403901689_1_1', 'ISP_ESP0166_1660403901689_11_1',
                                             'ISP_ESP0166_1660403901689_12_1', 'ISP_ESP0166_1660403901689_13_1',
                                             'ISP_ESP0166_1660403901689_14_1', 'ISP_ESP0166_1660403901689_16_1',
                                             'ISP_ESP0166_1660403901689_17_1', 'ISP_ESP0166_1660403901689_18_1',
                                             'ISP_ESP0166_1660403901689_19_1', 'ISP_ESP0166_1660403901689_2_1',
                                             'ISP_ESP0166_1660403901689_3_1', 'ISP_ESP0166_1660403901689_4_1',
                                             'ISP_ESP0166_1660403901689_6_1', 'ISP_ESP0166_1660403901689_7_1',
                                             'ISP_ESP0166_1660403901689_8_1', 'ISP_ESP0166_1660403901689_9_1',
                                             'ISP_ESP0166_1660403901706_1_1', 'ISP_ESP0166_1660403901706_2_1',
                                             'ISP_ESP0166_1660403901706_3_1', 'ISP_ESP0166_1660403901706_4_1',
                                             'ISP_ESP0166_1660403901706_6_1', 'ISP_ESP0166_1660403901706_7_1',
                                             'ISP_ESP0166_1660403901706_8_1', 'ISP_ESP0166_1660403901706_9_1',
                                             'ISP_ESP0166_1660403901787_1_1', 'ISP_ESP0166_1660403901787_2_1',
                                             'ISP_ESP0166_1660403901811_1_1', 'ISP_ESP0166_1660403901818_1_1',
                                             'ISP_ESP0166_1660403901818_2_1', 'ISP_ESP0166_1660403901818_4_1',
                                             'ISP_ESP0166_1660403901818_5_1', 'ISP_ESP0166_1660403901827_1_1',
                                             'ISP_ESP0166_1660403901838_1_1', 'ISP_ESP0166_1660403901845_1_1',
                                             'ISP_ESP0166_1660403901845_2_1', 'ISP_ESP0166_1660403901845_4_1',
                                             'ISP_ESP0166_1660403901845_5_1', 'ISP_ESP0166_1660403901862_1_1',
                                             'ISP_ESP0166_1660403901867_1_1', 'ISP_ESP0166_1660403901872_1_1',
                                             'ISP_ESP0166_1660403901877_1_1', 'ISP_ESP0166_1660403901882_1_1',
                                             'ISP_ESP0166_1660403901888_1_1', 'ISP_ESP0166_1660403901894_1_1',
                                             'ISP_ESP0166_1660403901902_1_1', 'ISP_ESP0166_1660403901902_3_1',
                                             'ISP_ESP0166_1660403901902_5_1', 'ISP_ESP0166_1660403901902_7_1',
                                             'ISP_ESP0166_1660403901902_9_1', 'ISP_ESP0166_1660403901939_1_1',
                                             'ISP_ESP0166_1660403901939_3_1', 'ISP_ESP0166_1660403901954_1_1',
                                             'ISP_ESP0166_1660403901961_1_1', 'ISP_ESP0166_1660403901961_3_1',
                                             'ISP_ESP0166_1660403901974_1_1', 'ISP_ESP0166_1660403901974_11_1',
                                             'ISP_ESP0166_1660403901974_13_1', 'ISP_ESP0166_1660403901974_3_1',
                                             'ISP_ESP0166_1660403901974_5_1', 'ISP_ESP0166_1660403901974_7_1',
                                             'ISP_ESP0166_1660403901974_9_1', 'ISP_ESP0166_1660403902024_1_1',
                                             'ISP_ESP0166_1660403902024_3_1', 'ISP_ESP0166_1660403902037_1_1',
                                             'ISP_ESP0166_1660403902037_3_1', 'ISP_ESP0166_1660403902037_5_1',
                                             'ISP_ESP0166_1660403902037_7_1', 'ISP_ESP0166_1660403902037_9_1',
                                             'ISP_ESP0166_1660403902068_1_1', 'ISP_ESP0166_1660403902209_1_1',
                                             'ISP_ESP0166_1660403902209_3_1', 'ISP_ESP0166_1660403902209_5_1',
                                             'ISP_ESP0166_1660403902209_7_1', 'ISP_ESP0166_1660403902234_1_1',
                                             'ISP_ESP0166_1660403902234_2_1', 'ISP_ESP0166_1660403902244_1_1',
                                             'ISP_ESP0166_1660403902251_1_1', 'ISP_ESP0166_1660403902258_1_1',
                                             'ISP_ESP0166_1660403902258_2_1', 'ISP_ESP0166_1660403902268_1_1',
                                             'ISP_ESP0166_1660403902268_3_1', 'ISP_ESP0166_1660403902268_5_1',
                                             'ISP_ESP0166_1660403902268_7_1', 'ISP_ESP0166_1660403902297_1_1',
                                             'ISP_ESP0166_1660403902297_3_1', 'ISP_ESP0166_1660403902312_1_1',
                                             'ISP_ESP0166_1660403902319_1_1', 'ISP_ESP0166_1660403902319_2_1',
                                             'ISP_ESP0166_1660403902319_4_1', 'ISP_ESP0166_1660403902319_5_1',
                                             'ISP_ESP0166_1660403902355_1_1', 'ISP_ESP0166_1660403902362_1_1',
                                             'ISP_ESP0166_1660403902413_1_1', 'ISP_ESP0166_1660403902413_2_1',
                                             'ISP_ESP0166_1660403902502_1_1', 'ISP_ESP0166_1660403902502_3_1',
                                             'ISP_ESP0166_1660403902517_1_1', 'ISP_ESP0166_1660403902517_10_1',
                                             'ISP_ESP0166_1660403902517_11_1', 'ISP_ESP0166_1660403902517_2_1',
                                             'ISP_ESP0166_1660403902517_4_1', 'ISP_ESP0166_1660403902517_5_1',
                                             'ISP_ESP0166_1660403902517_7_1', 'ISP_ESP0166_1660403902517_8_1',
                                             'ISP_ESP0166_1660403902554_1_1', 'ISP_ESP0166_1660403902561_1_1',
                                             'ISP_ESP0166_1660403902568_1_1', 'ISP_ESP0166_1660403902575_1_1',
                                             'ISP_ESP0166_1660403902575_2_1', 'ISP_ESP0166_1660403902575_4_1',
                                             'ISP_ESP0166_1660403902575_5_1', 'ISP_ESP0166_1660403902594_1_1',
                                             'ISP_ESP0166_1660403902594_2_1', 'ISP_ESP0166_1660403902604_1_1',
                                             'ISP_ESP0166_1660403902611_1_1', 'ISP_ESP0166_1660403902611_2_1',
                                             'ISP_ESP0166_1660403902621_1_1', 'ISP_ESP0166_1660403902621_3_1',
                                             'ISP_ESP0166_1660403902636_1_1', 'ISP_ESP0166_1660403902636_2_1',
                                             'ISP_ESP0166_1660403902646_1_1']) == False) &
                    (f.trim(f.substring(sales_billing.plant, 13, 14)).isin(['10003090878', '10055249639']) == False) |
                    (f.substring(price_cond.ref_id, 1, 3) == f.lit('SUN')))\
            .select(
            waterfall.hierarchy_level_5.alias('l5_hierarchy'), waterfall.hierarchy_level_4_key.alias('l4_hierarchy'),
            waterfall.hierarchy_level_3_key.alias('l3_hierarchy'),
            waterfall.hierarchy_level_2_key.alias('l2_hierarchy'),
            waterfall.hierarchy_level_1_key.alias('l1_hierarchy'),
            f.when(f.trim(f.upper(waterfall.hierarchy_level_3_key)) == f.lit('COST'),
                   (price_cond.condition_value_lc * f.lit(-1)))
            .otherwise(price_cond.condition_value_lc).alias('value_lc'),
            f.when(f.trim(f.upper(waterfall.hierarchy_level_3_key)) == f.lit('COST'),
                   (price_cond.condition_value_gc * f.lit(-1)))
            .otherwise(price_cond.condition_value_gc).alias('value_usd'),
            price_cond.ref_id.alias('cost_element_key'), price_cond.condition_type.alias('trx_wfh_key'),
            f.current_timestamp().cast('date').alias('last_modified_date'))

        print('df_tfx_result*******************', df_tfx_result.count())

        return df_tfx_result


if __name__ == '__main__':
    trl = SunIspETL()
    trl.execute()
