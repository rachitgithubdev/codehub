# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1             Bakul Seth       29-Apr-2021     Initial version
#  0.2             Tingting Wan     02-Jun-2021     Change logs --'l4_location_mapping_isp','l4_dim_location'
# =================================================================================================
# Description   :- The aim of the code is to generate l5_isp_summary into conform zone
# Author        :- Bakul Seth
# Date          :- 29-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class SunIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 10')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'netapp_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.netapp_database = args['netapp_database']
        self.destination_bucket = args['destination_bucket']
        self.environment = args['environment']

        # report specific =============================================
        self.input_tables = ['l4_isp_fact_sales_billing', 'l4_isp_dim_customer', 'l4_dim_customer',
                             'l2_l4_isp_dim_material', 'l4_location_mapping_isp', 'l4_dim_location']
        self.report_file = 'l5_isp_summary'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        print('Reading data from input tabled {}.{}'.format(self.source_database, self.input_tables))
        df_input_table = self._get_table(self.source_database, self.netapp_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('applying the transformations')
        df_tfx_table = self._apply_tfx(self.environment, df_input_table)
        print('schema after transformation ', df_tfx_table.printSchema())

        # write final result to required destination
        print('Writing the results to desired location')
        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, netapp_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name[0]))
        df_isp_fsb = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[0],
                                                                transformation_ctx='target_table').toDF()
        # df_isp_fsb.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[1]))
        df_isp_cust = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[1],
                                                                 transformation_ctx='target_table').toDF()
        # df_isp_cust.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[2]))
        df_dim_cust = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[2],
                                                                 transformation_ctx='target_table').toDF()
        # df_dim_cust.printSchema()

        print('reading data from {}.{}'.format(netapp_database, table_name[3]))
        df_material = self._gc.create_dynamic_frame.from_catalog(database=netapp_database, table_name=table_name[3],
                                                                 transformation_ctx='target_table').toDF()
        # df_material.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[4]))
        df_mapping_isp = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[4],
                                                                    transformation_ctx='target_table').toDF()
        # df_mapping_isp.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[5]))
        df_dim_loc = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[5],
                                                                transformation_ctx='target_table').toDF()
        # df_dim_loc.printSchema()

        return [df_isp_fsb, df_isp_cust, df_dim_cust, df_material, df_mapping_isp, df_dim_loc]

    @staticmethod
    def _apply_tfx(env, df_input_table):
        # creating dataframe for different tables
        print('creating dataframe for different tables')
        isp_fsb = df_input_table[0]
        isp_cust = df_input_table[1].cache()
        dim_cust = df_input_table[2].cache()
        material = df_input_table[3]

        mapping_isp = df_input_table[4]
        dim_loc = df_input_table[5]

        # Filter isp_fsb before join
        if env == 'dev' or 'test':
            isp_fsb = isp_fsb.alias('A').filter(
                (f.col('A.ref_id').isin(['ISP_ESP6750_7500217236641_1_1', 'ISP_ESP6750_7500250974070_1_1',
                                      'ISP_ESP6750_7500258029379_1_1', 'ISP_ESP6750_7500258812927_1_1',
                                      'ISP_ESP6750_7500261584096_1_1', 'ISP_ESP6750_7500261584108_1_1',
                                      'ISP_ESP6750_7500281376800_1_1', 'ISP_ESP6750_7500287321768_1_1',
                                      'ISP_ESP6750_7500287693951_1_1', 'ISP_ESP6750_7500288547622_1_1',
                                      'ISP_ESP6750_7500291273441_1_1', 'ISP_ESP6750_7500297520987_1_1',
                                      'ISP_ESP6750_7500305229323_1_1', 'ISP_ESP6750_7500305229390_1_1',
                                      'ISP_ESP6750_7500305229397_1_1', 'ISP_ESP6750_7500305229959_1_1',
                                      'ISP_ESP6750_7500317942182_1_1', 'ISP_ESP6750_7500317942352_1_1',
                                      'ISP_ESP6750_7500317942591_1_1', 'ISP_ESP6750_7500317942639_1_1',
                                      'ISP_ESP6750_7500320231513_1_1', 'ISP_ESP6750_7500320241573_1_1',
                                      'ISP_ESP6750_7500320241580_1_1', 'ISP_ESP6750_7500320241604_1_1',
                                      'ISP_ESP6750_7500320241609_1_1', 'ISP_ESP0166_1660403877476_1_1',
                                      'ISP_ESP0166_1660403877476_2_1', 'ISP_ESP0166_1660403880085_1_1',
                                      'ISP_ESP0166_1660403880085_2_1', 'ISP_ESP0166_1660403880108_1_1',
                                      'ISP_ESP0166_1660403901491_1_1', 'ISP_ESP0166_1660403901491_2_1',
                                      'ISP_ESP0166_1660403901495_1_1', 'ISP_ESP0166_1660403901541_1_1',
                                      'ISP_ESP0166_1660403901541_3_1', 'ISP_ESP0166_1660403901547_1_1',
                                      'ISP_ESP0166_1660403901560_1_1', 'ISP_ESP0166_1660403901560_2_1',
                                      'ISP_ESP0166_1660403901560_4_1', 'ISP_ESP0166_1660403901560_5_1',
                                      'ISP_ESP0166_1660403901560_7_1', 'ISP_ESP0166_1660403901560_8_1',
                                      'ISP_ESP0166_1660403901591_1_1', 'ISP_ESP0166_1660403901599_1_1',
                                      'ISP_ESP0166_1660403901599_3_1', 'ISP_ESP0166_1660403901599_5_1',
                                      'ISP_ESP0166_1660403901599_7_1', 'ISP_ESP0166_1660403901599_9_1',
                                      'ISP_ESP0166_1660403901621_1_1', 'ISP_ESP0166_1660403901621_3_1',
                                      'ISP_ESP0166_1660403901650_1_1', 'ISP_ESP0166_1660403901657_1_1',
                                      'ISP_ESP0166_1660403901657_2_1', 'ISP_ESP0166_1660403901657_3_1',
                                      'ISP_ESP0166_1660403901680_1_1', 'ISP_ESP0166_1660403901680_2_1',
                                      'ISP_ESP0166_1660403901680_3_1', 'ISP_ESP0166_1660403901680_4_1',
                                      'ISP_ESP0166_1660403901680_6_1', 'ISP_ESP0166_1660403901680_7_1',
                                      'ISP_ESP0166_1660403901680_8_1', 'ISP_ESP0166_1660403901680_9_1',
                                      'ISP_ESP0166_1660403901689_1_1',
                                      'ISP_ESP0166_1660403901689_11_1',
                                      'ISP_ESP0166_1660403901689_12_1',
                                      'ISP_ESP0166_1660403901689_13_1',
                                      'ISP_ESP0166_1660403901689_14_1',
                                      'ISP_ESP0166_1660403901689_16_1',
                                      'ISP_ESP0166_1660403901689_17_1',
                                      'ISP_ESP0166_1660403901689_18_1',
                                      'ISP_ESP0166_1660403901689_19_1',
                                      'ISP_ESP0166_1660403901689_2_1',
                                      'ISP_ESP0166_1660403901689_3_1', 'ISP_ESP0166_1660403901689_4_1',
                                      'ISP_ESP0166_1660403901689_6_1', 'ISP_ESP0166_1660403901689_7_1',
                                      'ISP_ESP0166_1660403901689_8_1', 'ISP_ESP0166_1660403901689_9_1',
                                      'ISP_ESP0166_1660403901706_1_1', 'ISP_ESP0166_1660403901706_2_1',
                                      'ISP_ESP0166_1660403901706_3_1', 'ISP_ESP0166_1660403901706_4_1',
                                      'ISP_ESP0166_1660403901706_6_1', 'ISP_ESP0166_1660403901706_7_1',
                                      'ISP_ESP0166_1660403901706_8_1', 'ISP_ESP0166_1660403901706_9_1',
                                      'ISP_ESP0166_1660403901787_1_1', 'ISP_ESP0166_1660403901787_2_1',
                                      'ISP_ESP0166_1660403901811_1_1', 'ISP_ESP0166_1660403901818_1_1',
                                      'ISP_ESP0166_1660403901818_2_1', 'ISP_ESP0166_1660403901818_4_1',
                                      'ISP_ESP0166_1660403901818_5_1', 'ISP_ESP0166_1660403901827_1_1',
                                      'ISP_ESP0166_1660403901838_1_1', 'ISP_ESP0166_1660403901845_1_1',
                                      'ISP_ESP0166_1660403901845_2_1', 'ISP_ESP0166_1660403901845_4_1',
                                      'ISP_ESP0166_1660403901845_5_1', 'ISP_ESP0166_1660403901862_1_1',
                                      'ISP_ESP0166_1660403901867_1_1', 'ISP_ESP0166_1660403901872_1_1',
                                      'ISP_ESP0166_1660403901877_1_1', 'ISP_ESP0166_1660403901882_1_1',
                                      'ISP_ESP0166_1660403901888_1_1', 'ISP_ESP0166_1660403901894_1_1',
                                      'ISP_ESP0166_1660403901902_1_1', 'ISP_ESP0166_1660403901902_3_1',
                                      'ISP_ESP0166_1660403901902_5_1', 'ISP_ESP0166_1660403901902_7_1',
                                      'ISP_ESP0166_1660403901902_9_1', 'ISP_ESP0166_1660403901939_1_1',
                                      'ISP_ESP0166_1660403901939_3_1', 'ISP_ESP0166_1660403901954_1_1',
                                      'ISP_ESP0166_1660403901961_1_1', 'ISP_ESP0166_1660403901961_3_1',
                                      'ISP_ESP0166_1660403901974_1_1',
                                      'ISP_ESP0166_1660403901974_11_1',
                                      'ISP_ESP0166_1660403901974_13_1',
                                      'ISP_ESP0166_1660403901974_3_1',
                                      'ISP_ESP0166_1660403901974_5_1', 'ISP_ESP0166_1660403901974_7_1',
                                      'ISP_ESP0166_1660403901974_9_1', 'ISP_ESP0166_1660403902024_1_1',
                                      'ISP_ESP0166_1660403902024_3_1', 'ISP_ESP0166_1660403902037_1_1',
                                      'ISP_ESP0166_1660403902037_3_1', 'ISP_ESP0166_1660403902037_5_1',
                                      'ISP_ESP0166_1660403902037_7_1', 'ISP_ESP0166_1660403902037_9_1',
                                      'ISP_ESP0166_1660403902068_1_1', 'ISP_ESP0166_1660403902209_1_1',
                                      'ISP_ESP0166_1660403902209_3_1', 'ISP_ESP0166_1660403902209_5_1',
                                      'ISP_ESP0166_1660403902209_7_1', 'ISP_ESP0166_1660403902234_1_1',
                                      'ISP_ESP0166_1660403902234_2_1', 'ISP_ESP0166_1660403902244_1_1',
                                      'ISP_ESP0166_1660403902251_1_1', 'ISP_ESP0166_1660403902258_1_1',
                                      'ISP_ESP0166_1660403902258_2_1', 'ISP_ESP0166_1660403902268_1_1',
                                      'ISP_ESP0166_1660403902268_3_1', 'ISP_ESP0166_1660403902268_5_1',
                                      'ISP_ESP0166_1660403902268_7_1', 'ISP_ESP0166_1660403902297_1_1',
                                      'ISP_ESP0166_1660403902297_3_1', 'ISP_ESP0166_1660403902312_1_1',
                                      'ISP_ESP0166_1660403902319_1_1', 'ISP_ESP0166_1660403902319_2_1',
                                      'ISP_ESP0166_1660403902319_4_1', 'ISP_ESP0166_1660403902319_5_1',
                                      'ISP_ESP0166_1660403902355_1_1', 'ISP_ESP0166_1660403902362_1_1',
                                      'ISP_ESP0166_1660403902413_1_1', 'ISP_ESP0166_1660403902413_2_1',
                                      'ISP_ESP0166_1660403902502_1_1', 'ISP_ESP0166_1660403902502_3_1',
                                      'ISP_ESP0166_1660403902517_1_1',
                                      'ISP_ESP0166_1660403902517_10_1',
                                      'ISP_ESP0166_1660403902517_11_1',
                                      'ISP_ESP0166_1660403902517_2_1',
                                      'ISP_ESP0166_1660403902517_4_1', 'ISP_ESP0166_1660403902517_5_1',
                                      'ISP_ESP0166_1660403902517_7_1', 'ISP_ESP0166_1660403902517_8_1',
                                      'ISP_ESP0166_1660403902554_1_1', 'ISP_ESP0166_1660403902561_1_1',
                                      'ISP_ESP0166_1660403902568_1_1', 'ISP_ESP0166_1660403902575_1_1',
                                      'ISP_ESP0166_1660403902575_2_1', 'ISP_ESP0166_1660403902575_4_1',
                                      'ISP_ESP0166_1660403902575_5_1', 'ISP_ESP0166_1660403902594_1_1',
                                      'ISP_ESP0166_1660403902594_2_1', 'ISP_ESP0166_1660403902604_1_1',
                                      'ISP_ESP0166_1660403902611_1_1', 'ISP_ESP0166_1660403902611_2_1',
                                      'ISP_ESP0166_1660403902621_1_1', 'ISP_ESP0166_1660403902621_3_1',
                                      'ISP_ESP0166_1660403902636_1_1', 'ISP_ESP0166_1660403902636_2_1',
                                      'ISP_ESP0166_1660403902646_1_1']) == False) &
                (f.trim(f.substring(f.col('A.plant'), 13, 14)).isin(
                    ['10003090878', '10055249639']) == False)).cache()
        else:
            isp_fsb = isp_fsb.alias('A').filter(
                (f.col('A.ref_id').isin(['ISP_ESP0750_7500217236641_1_1', 'ISP_ESP0750_7500250974070_1_1',
                                      'ISP_ESP0750_7500258029379_1_1', 'ISP_ESP0750_7500258812927_1_1',
                                      'ISP_ESP0750_7500261584096_1_1', 'ISP_ESP0750_7500261584108_1_1',
                                      'ISP_ESP0750_7500281376800_1_1', 'ISP_ESP0750_7500287321768_1_1',
                                      'ISP_ESP0750_7500287693951_1_1', 'ISP_ESP0750_7500288547622_1_1',
                                      'ISP_ESP0750_7500291273441_1_1', 'ISP_ESP0750_7500297520987_1_1',
                                      'ISP_ESP0750_7500305229323_1_1', 'ISP_ESP0750_7500305229390_1_1',
                                      'ISP_ESP0750_7500305229397_1_1', 'ISP_ESP0750_7500305229959_1_1',
                                      'ISP_ESP0750_7500317942182_1_1', 'ISP_ESP0750_7500317942352_1_1',
                                      'ISP_ESP0750_7500317942591_1_1', 'ISP_ESP0750_7500317942639_1_1',
                                      'ISP_ESP0750_7500320231513_1_1', 'ISP_ESP0750_7500320241573_1_1',
                                      'ISP_ESP0750_7500320241580_1_1', 'ISP_ESP0750_7500320241604_1_1',
                                      'ISP_ESP0750_7500320241609_1_1', 'ISP_ESP0166_1660403877476_1_1',
                                      'ISP_ESP0166_1660403877476_2_1', 'ISP_ESP0166_1660403880085_1_1',
                                      'ISP_ESP0166_1660403880085_2_1', 'ISP_ESP0166_1660403880108_1_1',
                                      'ISP_ESP0166_1660403901491_1_1', 'ISP_ESP0166_1660403901491_2_1',
                                      'ISP_ESP0166_1660403901495_1_1', 'ISP_ESP0166_1660403901541_1_1',
                                      'ISP_ESP0166_1660403901541_3_1', 'ISP_ESP0166_1660403901547_1_1',
                                      'ISP_ESP0166_1660403901560_1_1', 'ISP_ESP0166_1660403901560_2_1',
                                      'ISP_ESP0166_1660403901560_4_1', 'ISP_ESP0166_1660403901560_5_1',
                                      'ISP_ESP0166_1660403901560_7_1', 'ISP_ESP0166_1660403901560_8_1',
                                      'ISP_ESP0166_1660403901591_1_1', 'ISP_ESP0166_1660403901599_1_1',
                                      'ISP_ESP0166_1660403901599_3_1', 'ISP_ESP0166_1660403901599_5_1',
                                      'ISP_ESP0166_1660403901599_7_1', 'ISP_ESP0166_1660403901599_9_1',
                                      'ISP_ESP0166_1660403901621_1_1', 'ISP_ESP0166_1660403901621_3_1',
                                      'ISP_ESP0166_1660403901650_1_1', 'ISP_ESP0166_1660403901657_1_1',
                                      'ISP_ESP0166_1660403901657_2_1', 'ISP_ESP0166_1660403901657_3_1',
                                      'ISP_ESP0166_1660403901680_1_1', 'ISP_ESP0166_1660403901680_2_1',
                                      'ISP_ESP0166_1660403901680_3_1', 'ISP_ESP0166_1660403901680_4_1',
                                      'ISP_ESP0166_1660403901680_6_1', 'ISP_ESP0166_1660403901680_7_1',
                                      'ISP_ESP0166_1660403901680_8_1', 'ISP_ESP0166_1660403901680_9_1',
                                      'ISP_ESP0166_1660403901689_1_1',
                                      'ISP_ESP0166_1660403901689_11_1',
                                      'ISP_ESP0166_1660403901689_12_1',
                                      'ISP_ESP0166_1660403901689_13_1',
                                      'ISP_ESP0166_1660403901689_14_1',
                                      'ISP_ESP0166_1660403901689_16_1',
                                      'ISP_ESP0166_1660403901689_17_1',
                                      'ISP_ESP0166_1660403901689_18_1',
                                      'ISP_ESP0166_1660403901689_19_1',
                                      'ISP_ESP0166_1660403901689_2_1',
                                      'ISP_ESP0166_1660403901689_3_1', 'ISP_ESP0166_1660403901689_4_1',
                                      'ISP_ESP0166_1660403901689_6_1', 'ISP_ESP0166_1660403901689_7_1',
                                      'ISP_ESP0166_1660403901689_8_1', 'ISP_ESP0166_1660403901689_9_1',
                                      'ISP_ESP0166_1660403901706_1_1', 'ISP_ESP0166_1660403901706_2_1',
                                      'ISP_ESP0166_1660403901706_3_1', 'ISP_ESP0166_1660403901706_4_1',
                                      'ISP_ESP0166_1660403901706_6_1', 'ISP_ESP0166_1660403901706_7_1',
                                      'ISP_ESP0166_1660403901706_8_1', 'ISP_ESP0166_1660403901706_9_1',
                                      'ISP_ESP0166_1660403901787_1_1', 'ISP_ESP0166_1660403901787_2_1',
                                      'ISP_ESP0166_1660403901811_1_1', 'ISP_ESP0166_1660403901818_1_1',
                                      'ISP_ESP0166_1660403901818_2_1', 'ISP_ESP0166_1660403901818_4_1',
                                      'ISP_ESP0166_1660403901818_5_1', 'ISP_ESP0166_1660403901827_1_1',
                                      'ISP_ESP0166_1660403901838_1_1', 'ISP_ESP0166_1660403901845_1_1',
                                      'ISP_ESP0166_1660403901845_2_1', 'ISP_ESP0166_1660403901845_4_1',
                                      'ISP_ESP0166_1660403901845_5_1', 'ISP_ESP0166_1660403901862_1_1',
                                      'ISP_ESP0166_1660403901867_1_1', 'ISP_ESP0166_1660403901872_1_1',
                                      'ISP_ESP0166_1660403901877_1_1', 'ISP_ESP0166_1660403901882_1_1',
                                      'ISP_ESP0166_1660403901888_1_1', 'ISP_ESP0166_1660403901894_1_1',
                                      'ISP_ESP0166_1660403901902_1_1', 'ISP_ESP0166_1660403901902_3_1',
                                      'ISP_ESP0166_1660403901902_5_1', 'ISP_ESP0166_1660403901902_7_1',
                                      'ISP_ESP0166_1660403901902_9_1', 'ISP_ESP0166_1660403901939_1_1',
                                      'ISP_ESP0166_1660403901939_3_1', 'ISP_ESP0166_1660403901954_1_1',
                                      'ISP_ESP0166_1660403901961_1_1', 'ISP_ESP0166_1660403901961_3_1',
                                      'ISP_ESP0166_1660403901974_1_1',
                                      'ISP_ESP0166_1660403901974_11_1',
                                      'ISP_ESP0166_1660403901974_13_1',
                                      'ISP_ESP0166_1660403901974_3_1',
                                      'ISP_ESP0166_1660403901974_5_1', 'ISP_ESP0166_1660403901974_7_1',
                                      'ISP_ESP0166_1660403901974_9_1', 'ISP_ESP0166_1660403902024_1_1',
                                      'ISP_ESP0166_1660403902024_3_1', 'ISP_ESP0166_1660403902037_1_1',
                                      'ISP_ESP0166_1660403902037_3_1', 'ISP_ESP0166_1660403902037_5_1',
                                      'ISP_ESP0166_1660403902037_7_1', 'ISP_ESP0166_1660403902037_9_1',
                                      'ISP_ESP0166_1660403902068_1_1', 'ISP_ESP0166_1660403902209_1_1',
                                      'ISP_ESP0166_1660403902209_3_1', 'ISP_ESP0166_1660403902209_5_1',
                                      'ISP_ESP0166_1660403902209_7_1', 'ISP_ESP0166_1660403902234_1_1',
                                      'ISP_ESP0166_1660403902234_2_1', 'ISP_ESP0166_1660403902244_1_1',
                                      'ISP_ESP0166_1660403902251_1_1', 'ISP_ESP0166_1660403902258_1_1',
                                      'ISP_ESP0166_1660403902258_2_1', 'ISP_ESP0166_1660403902268_1_1',
                                      'ISP_ESP0166_1660403902268_3_1', 'ISP_ESP0166_1660403902268_5_1',
                                      'ISP_ESP0166_1660403902268_7_1', 'ISP_ESP0166_1660403902297_1_1',
                                      'ISP_ESP0166_1660403902297_3_1', 'ISP_ESP0166_1660403902312_1_1',
                                      'ISP_ESP0166_1660403902319_1_1', 'ISP_ESP0166_1660403902319_2_1',
                                      'ISP_ESP0166_1660403902319_4_1', 'ISP_ESP0166_1660403902319_5_1',
                                      'ISP_ESP0166_1660403902355_1_1', 'ISP_ESP0166_1660403902362_1_1',
                                      'ISP_ESP0166_1660403902413_1_1', 'ISP_ESP0166_1660403902413_2_1',
                                      'ISP_ESP0166_1660403902502_1_1', 'ISP_ESP0166_1660403902502_3_1',
                                      'ISP_ESP0166_1660403902517_1_1',
                                      'ISP_ESP0166_1660403902517_10_1',
                                      'ISP_ESP0166_1660403902517_11_1',
                                      'ISP_ESP0166_1660403902517_2_1',
                                      'ISP_ESP0166_1660403902517_4_1', 'ISP_ESP0166_1660403902517_5_1',
                                      'ISP_ESP0166_1660403902517_7_1', 'ISP_ESP0166_1660403902517_8_1',
                                      'ISP_ESP0166_1660403902554_1_1', 'ISP_ESP0166_1660403902561_1_1',
                                      'ISP_ESP0166_1660403902568_1_1', 'ISP_ESP0166_1660403902575_1_1',
                                      'ISP_ESP0166_1660403902575_2_1', 'ISP_ESP0166_1660403902575_4_1',
                                      'ISP_ESP0166_1660403902575_5_1', 'ISP_ESP0166_1660403902594_1_1',
                                      'ISP_ESP0166_1660403902594_2_1', 'ISP_ESP0166_1660403902604_1_1',
                                      'ISP_ESP0166_1660403902611_1_1', 'ISP_ESP0166_1660403902611_2_1',
                                      'ISP_ESP0166_1660403902621_1_1', 'ISP_ESP0166_1660403902621_3_1',
                                      'ISP_ESP0166_1660403902636_1_1', 'ISP_ESP0166_1660403902636_2_1',
                                      'ISP_ESP0166_1660403902646_1_1']) == False) &
                (f.trim(f.substring(f.col('A.plant'), 13, 14)).isin(
                    ['10003090878', '10055249639']) == False)).cache()

        # print(isp_fsb.count())

        # create table loctype
        loctype = mapping_isp.join(dim_loc, mapping_isp.location_id == dim_loc.locationid, 'left') \
            .select(f.col('isp_mapping'), f.col('location_type'))


        # Applying the transformation
        print('applying the transformations')
        df_tfx_result = isp_fsb.alias('A').join(isp_cust, f.col('A.shipto_party') == isp_cust.ref_isp_id, 'left') \
            .join(isp_cust.alias('payb'),
                  f.concat(
                      f.when(f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == '4430002396956',
                             f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('5240000060798')))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500003573825250000357380',
                                f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('5250226360209')))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500795591135250079559112',
                                f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('5250260520638')))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52503053281713800161398192',
                                f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('3800161398240')))
                          .otherwise(f.col('A.shipto_party')),
                      f.when(f.trim(f.substring(f.col('A.payer'), 13, 14)) == '5250000357380',
                             f.concat(f.substring(f.col('A.payer'), 1, 12), f.lit('5250226359884')))
                          .when(f.trim(f.substring(f.col('A.payer'), 13, 14)) == '5250079559112',
                                f.concat(f.substring(f.col('A.payer'), 1, 12), f.lit('5250260520636')))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500175740735250079835826',
                                f.concat(f.substring(f.col('A.payer'), 1, 12), f.lit('5250017574072')))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500000178335250113976983',
                                f.concat(f.substring(f.col('A.payer'), 1, 12), f.lit('5250000017825')))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52502416014245250244303889',
                                f.concat(f.substring(f.col('A.payer'), 1, 12), f.lit('5250241344076')))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500003573825250000357380',
                                f.concat(f.substring(f.col('A.payer'), 1, 12), f.lit('5250226359884')))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500795591135250079559112',
                                f.concat(f.substring(f.col('A.payer'), 1, 12), f.lit('5250260520636'))).otherwise(
                          f.col('A.payer')))
                  == f.concat(f.col('payb.ref_isp_id'), f.col('payb.fk_isp_payer')), 'left') \
            .join(isp_cust.alias('billb'),
                  (f.when(f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == '1660280680714',
                          f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('1660279293986')))
                   .when((f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == '1660289431496') & (
                          f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '1660288461667'),
                         f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('1660288461669')))
                   .when((f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == '1660288461812') & (
                          f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '1660288461667'),
                         f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('1660288461669')))
                   .when(f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == '3800052923762',
                         f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('3760000007622')))
                   .otherwise(f.col('A.shipto_party'))
                   == f.col('billb.ref_isp_id')
                   )
                  & (f.when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '1660279293984',
                            f.concat(f.substring(f.col('A.billto_party'), 1, 12), f.lit('1660279293984')))
                     .otherwise(f.col('A.billto_party'))
                     == f.col('billb.fk_isp_bill_to')
                     ), 'left') \
            .join(dim_cust.alias('C1'),
                  (f.when(f.trim(f.substring(f.col('A.soldto_party'), 13, 14)).isin(['5250085098100', '2830224167489']),
                          f.lit('5250238539072'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500113482442'))),
                         f.lit('7500113482439'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5240000149889'))),
                         f.lit('5240000149886'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500181513078'))),
                         f.lit('7500181512619'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5250269561506'))),
                         f.lit('5250269561480'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5250250928229'))),
                         f.lit('5250250926406'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500239668069'))),
                         f.lit('7500239667852'))
                   .otherwise(f.trim(f.substring(f.col('A.soldto_party'), 13, 14))) ==
                   (f.when(((f.col('C1.customer_type') == f.lit('International')) & (
                           f.col('C1.sales_organisation') == f.lit('ISPI')) &
                            ((f.col('C1.customer_group') == f.lit('M&S Sold-to party customer IB ( ZMSI )')) | (
                                    f.col('C1.customer_group') == f.lit('M&S Sold-to party customer ( ZMSP)')) |
                             (f.col('C1.customer_group') == f.lit('Natural Person (ZMAN)')) | (
                                     f.col('C1.customer_group') == f.lit(
                                 'BP Group Company (Internal Customer) ( ZMIT)')) |
                             (f.col('C1.customer_group') == f.lit('BP Group Companies (E&P) (ZE04)'))) &
                            (f.col('C1.mdm_partner_id') == f.col('C1.sold_to_mdm_id'))),
                           f.col('C1.isp_sold_to'))
                    .otherwise(f.lit(None)))), 'left') \
            .join(dim_cust.alias('C2'),
                  (f.when(f.trim(f.substring(f.col('A.soldto_party'), 13, 14)).isin(['5250085098100', '2830224167489']),
                          f.lit('5250238539072'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500113482442'))),
                         f.lit('7500113482439'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5240000149889'))),
                         f.lit('5240000149886'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500181513078'))),
                         f.lit('7500181512619'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5250269561506'))),
                         f.lit('5250269561480'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5250250928229'))),
                         f.lit('5250250926406'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500239668069'))),
                         f.lit('7500239667852'))
                   .otherwise(f.trim(f.substring(f.col('A.soldto_party'), 13, 14))) ==
                   (f.when(((f.col('C2.customer_type') == f.lit('Local')) & (
                           f.col('C2.customer_group') == f.lit('M&S Sold-to party customer IB ( ZMSI )')) &
                            (f.col('C2.customer_country_key') == f.substring(
                                f.col('C2.sales_organisation'), 1, 2))
                            & (f.col('C2.sales_organisation').isin('GB4J', 'GB08') == False)),
                           f.col('C2.isp_sold_to'))
                    .otherwise(f.lit(None)))), 'left') \
            .join(dim_cust.alias('C3'),
                  (f.when(f.trim(f.substring(f.col('A.soldto_party'), 13, 14)).isin(['5250085098100', '2830224167489']),
                          f.lit('5250238539072'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500113482442'))),
                         f.lit('7500113482439'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5240000149889'))),
                         f.lit('5240000149886'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500181513078'))),
                         f.lit('7500181512619'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5250269561506'))),
                         f.lit('5250269561480'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5250250928229'))),
                         f.lit('5250250926406'))
                   .when(((f.col('A.soldto_party').isNull()) & (
                          f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500239668069'))),
                         f.lit('7500239667852'))
                   .otherwise(f.trim(f.substring(f.col('A.soldto_party'), 13, 14))) ==
                   (f.when(((f.col('C3.customer_group') == f.lit('Natural Person (ZMAN)')) &
                            (f.col('C3.customer_country_key') == f.substring(
                                f.col('C3.sales_organisation'), 1, 2))
                            & (f.col('C3.sales_organisation').isin('GB4J', 'GB08') == False)),
                           f.col('C3.isp_sold_to'))
                    .otherwise(f.lit(None)))), 'left') \
            .join(dim_cust.alias('P1'),
                  f.concat(
                      f.when(f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == '4430002396956',
                             f.lit('5240000060798'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500003573825250000357380',
                                f.lit('5250226360209'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500795591135250079559112',
                                f.lit('5250260520638'))
                          .otherwise(f.trim(f.substring(f.col('A.shipto_party'), 13, 14))),
                      f.when(f.trim(f.substring(f.col('A.payer'), 13, 14)) == '5250000357380', f.lit('5250226359884'))
                          .when(f.trim(f.substring(f.col('A.payer'), 13, 14)) == '5250079559112', f.lit('5250260520636'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500175740735250079835826',
                                f.lit('5250017574072'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500000178335250113976983',
                                f.lit('5250000017825'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52502416014245250244303889',
                                f.lit('5250241344076'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500003573825250000357380',
                                f.lit('5250226359884'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500795591135250079559112',
                                f.lit('5250260520636'))
                          .otherwise(f.trim(f.substring(f.col('A.payer'), 13, 14))))
                  ==
                  (f.when((f.col('P1.customer_type') == f.lit('International'))
                          & (f.col('P1.sales_organisation') == f.lit('ISPI'))
                          & (f.col('P1.customer_group') == f.lit('Accounting Details (ZMPY)')),
                          f.concat(f.col('P1.isp_payer'), f.col('P1.isp_id')))
                   .otherwise(f.lit(None))), 'left') \
            .join(dim_cust.alias('P2'),
                  f.concat(
                      f.when(f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == '4430002396956',
                             f.lit('5240000060798'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500003573825250000357380',
                                f.lit('5250226360209'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500795591135250079559112',
                                f.lit('5250260520638'))
                          .otherwise(f.trim(f.substring(f.col('A.shipto_party'), 13, 14))),
                      f.when(f.trim(f.substring(f.col('A.payer'), 13, 14)) == '5250000357380', f.lit('5250226359884'))
                          .when(f.trim(f.substring(f.col('A.payer'), 13, 14)) == '5250079559112', f.lit('5250260520636'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500175740735250079835826',
                                f.lit('5250017574072'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500000178335250113976983',
                                f.lit('5250000017825'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52502416014245250244303889',
                                f.lit('5250241344076'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500003573825250000357380',
                                f.lit('5250226359884'))
                          .when(f.concat(f.substring(f.col('A.shipto_party'), 13, 14),
                                         f.trim(f.substring(f.col('A.payer'), 13, 14))) == '52500795591135250079559112',
                                f.lit('5250260520636'))
                          .otherwise(f.trim(f.substring(f.col('A.payer'), 13, 14))))
                  ==
                  (f.when(((f.col('P2.customer_type') == f.lit('Local'))
                           & (f.col('P2.customer_group') == f.lit('Accounting Details (ZMPY)'))
                           & (f.col('P2.customer_country_key') == f.substring(f.col('P2.sales_organisation'), 1, 2))
                           & (f.col('P2.sales_organisation').isin('GB4J', 'GB08') == False)),
                          f.concat(f.col('P2.isp_payer'), f.col('P2.isp_id')))
                   .otherwise(f.lit(None))), 'left') \
            .join(dim_cust.alias('B1'),
                  f.when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '7500186160796',
                         f.lit('7500000017988'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250188852111',
                        f.lit('1660032583289'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000144541',
                        f.lit('1660340371949'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250182134237',
                        f.lit('5240000190170'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250182132990',
                        f.lit('5240000121845'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '1660088557886',
                        f.lit('1660340371812'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250079559111',
                        f.lit('5250260520637'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '6030006511715',
                        f.lit('6030000008965'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250215710778',
                        f.lit('5250216422556'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250000011676',
                        f.lit('7200000008572'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '7200000008099',
                        f.lit('7200000008579'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000182172',
                        f.lit('6030000023004'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250019594224',
                        f.lit('5250001162501'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000117631',
                        f.lit('1660054415179'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000139207',
                        f.lit('7200000009137'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000149186',
                        f.lit('1660340371953'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '3800030071603',
                        f.lit('3800257427531'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '7500185991656',
                        f.lit('7500036430652'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250011627642',
                        f.lit('5250097927553'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250000190251',
                        f.lit('5240000131621'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000249580',
                        f.lit('5310019146747'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '1660297395691',
                        f.lit('5250195706089'))
                  .otherwise(f.trim(f.substring(f.col('A.billto_party'), 13, 14)))
                  ==
                  (f.when((f.col('B1.customer_type') == f.lit('International'))
                          & (f.col('B1.sales_organisation') == f.lit('ISPI'))
                          & (f.col('B1.customer_group') == f.lit('Billing Details (ZMBI)')),
                          f.col('B1.isp_bill_to'))
                   .otherwise(f.lit(None))), 'left') \
            .join(dim_cust.alias('B2'),
                  f.when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '7500186160796',
                         f.lit('7500000017988'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250188852111',
                        f.lit('1660032583289'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000144541',
                        f.lit('1660340371949'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250182134237',
                        f.lit('5240000190170'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250182132990',
                        f.lit('5240000121845'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '1660088557886',
                        f.lit('1660340371812'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250079559111',
                        f.lit('5250260520637'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '6030006511715',
                        f.lit('6030000008965'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250215710778',
                        f.lit('5250216422556'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250000011676',
                        f.lit('7200000008572'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '7200000008099',
                        f.lit('7200000008579'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000182172',
                        f.lit('6030000023004'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250019594224',
                        f.lit('5250001162501'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000117631',
                        f.lit('1660054415179'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000139207',
                        f.lit('7200000009137'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000149186',
                        f.lit('1660340371953'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '3800030071603',
                        f.lit('3800257427531'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '7500185991656',
                        f.lit('7500036430652'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250011627642',
                        f.lit('5250097927553'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250000190251',
                        f.lit('5240000131621'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000249580',
                        f.lit('5310019146747'))
                  .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '1660297395691',
                        f.lit('5250195706089'))
                  .otherwise(f.trim(f.substring(f.col('A.billto_party'), 13, 14)))
                  ==
                  (f.when((f.col('B2.customer_type') == f.lit('Local'))
                          & (f.col('B2.customer_group') == f.lit('Billing Details (ZMBI)'))
                          & (f.col('B2.customer_country_key') == f.substring(f.col('B2.sales_organisation'), 1, 2))
                          & (f.col('B2.sales_organisation').isin('GB4J', 'GB08') == False)
                          & (f.col('B2.erp_id').isin('0050692730', '0050692906') == False),
                          f.col('B2.isp_bill_to'))
                   .otherwise(f.lit(None))), 'left') \
            .join(material, f.col('A.material_number') == material.isp_mtl_art_id, 'left') \
            .join(loctype, f.trim(f.substring(f.col('A.plant'), 13, 14)) == loctype.isp_mapping, 'left') \
            .select(f.col('A.pricing_date').alias('pricing_date'), f.col('A.billing_date').alias('billing_date'),
                    f.col('A.delivery_date').alias('delivery_date'),
                    f.when(f.col('C1.customer_country').isNotNull(), f.col('C1.customer_country'))
                    .when(((f.col('C1.customer_country').isNull()) &
                           (f.col('C2.customer_country').isNotNull())), f.col('C2.customer_country'))
                    .when(((f.col('C1.customer_country').isNull()) &
                           (f.col('C2.customer_country').isNull()) &
                           (f.col('C3.customer_country').isNotNull())), f.col('C3.customer_country'))
                    .otherwise(isp_cust.customer_country).alias('customer_country'),
                    f.when(f.col('C1.grn_header').isNotNull(), f.col('C1.grn_header'))
                    .when(((f.col('C1.grn_header').isNull()) &
                           (f.col('C2.grn_header').isNotNull())), f.col('C2.grn_header'))
                    .when(((f.col('C1.grn_header').isNull()) &
                           (f.col('C2.grn_header').isNull()) &
                           (f.col('C3.grn_header').isNotNull())), f.col('C3.grn_header'))
                    .otherwise(isp_cust.grn_header).alias('grn_header'),
                    f.when(f.col('C1.customer_account_name').isNotNull(),
                           f.col('C1.customer_account_name'))
                    .when(((f.col('C1.customer_account_name').isNull()) &
                           (f.col('C2.customer_account_name').isNotNull())),
                          f.col('C2.customer_account_name'))
                    .when(((f.col('C1.customer_account_name').isNull()) &
                           (f.col('C2.customer_account_name').isNull()) &
                           (f.col('C3.customer_account_name').isNotNull())),
                          f.col('C3.customer_account_name'))
                    .otherwise(isp_cust.customer_account_name).alias('customer_account_name'),
                    f.when(f.col('C1.cc_grn').isNotNull(), f.col('C1.cc_grn'))
                    .when(((f.col('C1.cc_grn').isNull()) & (f.col('C2.cc_grn').isNotNull())),
                          f.col('C2.cc_grn'))
                    .when(((f.col('C1.cc_grn').isNull()) & (f.col('C2.cc_grn').isNull()) &
                           (f.col('C3.cc_grn').isNotNull())), f.col('C3.cc_grn'))
                    .otherwise(isp_cust.grn_header).alias('cc_grn'),
                    f.when(f.col('C1.grn').isNotNull(), f.col('C1.grn'))
                    .when(((f.col('C1.grn').isNull()) & (f.col('C2.grn').isNotNull())),
                          f.col('C2.grn'))
                    .when(((f.col('C1.grn').isNull()) & (f.col('C2.grn').isNull()) &
                           (f.col('C3.grn').isNotNull())), f.col('C3.grn'))
                    .otherwise(isp_cust.grn).alias('grn'),
                    f.when(f.col('C1.account_manager').isNotNull(), f.col('C1.account_manager'))
                    .when(((f.col('C1.account_manager').isNull()) &
                           (f.col('C2.account_manager').isNotNull())), f.col('C2.account_manager'))
                    .when(((f.col('C1.account_manager').isNull()) & (f.col('C2.account_manager').isNull())
                           & (f.col('C3.account_manager').isNotNull())), f.col('C3.account_manager'))
                    .otherwise(isp_cust.account_manager).alias('account_manager'),
                    f.when(f.trim(f.substring(f.col('A.soldto_party'), 13, 14)).isin('5240000126763', '3800270105499'),
                           f.lit('General Aviation'))
                    .when(f.trim(f.substring(f.col('A.soldto_party'), 13, 14)) == '4780032303755', f.lit('Supply Sales'))
                    .when(f.col('C1.sector').isNotNull(), f.col('C1.sector'))
                    .when(f.col('C1.sector').isNull() & f.col('C2.sector').isNotNull(), f.col('C2.sector'))
                    .when(f.col('C1.sector').isNull() & f.col('C2.sector').isNull() & f.col('C3.sector').isNotNull(),
                          f.col('C3.sector'))
                    .otherwise(isp_cust.sector).alias('sector'),
                    f.when(f.col('C1.segment').isNotNull(), f.col('C1.segment'))
                    .when(f.col('C1.segment').isNull() & f.col('C2.segment').isNotNull(),
                          f.col('C2.segment'))
                    .when(f.col('C1.segment').isNull() & f.col('C2.segment').isNull() & f.col('C3.segment').isNotNull(),
                          f.col('C3.segment'))
                    .otherwise(f.lit('NA')).alias('customer_segment'),

                    f.when(f.col('P1.customer_country').isNotNull(), f.col('P1.customer_country'))
                    .when(f.col('P1.customer_country').isNull() & f.col('P2.customer_country').isNotNull(),
                          f.col('P2.customer_country'))
                    .otherwise(f.col('payb.customer_country')).alias('payer_customer_country'),
                    f.when(f.col('P1.grn_header').isNotNull(), f.col('P1.grn_header'))
                    .when(f.col('P1.grn_header').isNull() & f.col('P2.grn_header').isNotNull(), f.col('P2.grn_header'))
                    .otherwise(f.col('payb.grn_header')).alias('payer_grn_header'),
                    f.when(f.col('P1.customer_account_name').isNotNull(), f.col('P1.customer_account_name'))
                    .when(f.col('P1.customer_account_name').isNull() & f.col('P2.customer_account_name').isNotNull(),
                          f.col('P2.customer_account_name'))
                    .otherwise(f.col('payb.customer_account_name')).alias('payer_customer_account_name'),
                    f.when(f.col('P1.cc_grn').isNotNull(), f.col('P1.cc_grn'))
                    .when(f.col('P1.cc_grn').isNull() & f.col('P2.cc_grn').isNotNull(), f.col('P2.cc_grn'))
                    .otherwise(f.col('payb.grn')).alias('payer_cc_grn'),
                    f.when(f.col('P1.grn').isNotNull(), f.col('P1.grn'))
                    .when(f.col('P1.grn').isNull() & f.col('P2.grn').isNotNull(), f.col('P2.grn'))
                    .otherwise(f.col('payb.grn')).alias('payer_grn'),
                    f.when(f.col('C1.account_manager').isNotNull(), f.col('C1.account_manager'))
                    .when(f.col('C1.account_manager').isNull() & f.col('C2.account_manager').isNotNull(),
                          f.col('C2.account_manager'))
                    .when(f.col('C1.account_manager').isNull() & f.col('C2.account_manager').isNull() & f.col(
                        'C3.account_manager').isNotNull(), f.col('C3.account_manager'))
                    .otherwise(isp_cust.account_manager).alias('payer_account_manager'),
                    f.when(f.col('P1.sector').isNotNull(), f.col('P1.sector'))
                    .when(f.col('P1.sector').isNull() & f.col('P2.sector').isNotNull(), f.col('P2.sector'))
                    .otherwise(f.col('payb.sector')).alias('payer_sector'),
                    f.when(f.col('B1.customer_country').isNotNull(), f.col('B1.customer_country'))
                    .when(f.col('B1.customer_country').isNull() & f.col('B2.customer_country').isNotNull(),
                          f.col('B2.customer_country'))
                    .otherwise(f.col('billb.customer_country')).alias('billto_customer_country'),
                    f.when(f.col('B1.grn_header').isNotNull(), f.col('B1.grn_header'))
                    .when(f.col('B1.grn_header').isNull() & f.col('B2.grn_header').isNotNull(), f.col('B2.grn_header'))
                    .otherwise(f.col('billb.grn_header')).alias('billto_grn_header'),
                    f.when(f.col('B1.customer_account_name').isNotNull(), f.col('B1.customer_account_name'))
                    .when(f.col('B1.customer_account_name').isNull() & f.col('B2.customer_account_name').isNotNull(),
                          f.col('B2.customer_account_name'))
                    .otherwise(f.col('billb.customer_account_name')).alias('billto_customer_account_name'),
                    f.when(f.col('B1.cc_grn').isNotNull(), f.col('B1.cc_grn'))
                    .when(f.col('B1.cc_grn').isNull() & f.col('B2.cc_grn').isNotNull(), f.col('B2.cc_grn'))
                    .otherwise(f.col('billb.grn_header')).alias('billto_cc_grn'),
                    f.when(f.col('B1.grn').isNotNull(), f.col('B1.grn'))
                    .when(f.col('B1.grn').isNull() & f.col('B2.grn').isNotNull(), f.col('B2.grn'))
                    .otherwise(f.col('billb.grn')).alias('billto_grn'),
                    f.when(f.col('C1.account_manager').isNotNull(), f.col('C1.account_manager'))
                    .when(f.col('C1.account_manager').isNull() & f.col('C2.account_manager').isNotNull(),
                          f.col('C2.account_manager'))
                    .when(
                        f.col('C1.account_manager').isNull() & f.col('C2.account_manager').isNull() & f.col(
                            'C3.account_manager').isNotNull(), f.col('C3.account_manager'))
                    .otherwise(isp_cust.account_manager).alias('billto_account_manager'),
                    f.when(f.col('B1.sector').isNotNull(), f.col('B1.sector'))
                    .when(f.col('B1.sector').isNull() & f.col('B2.sector').isNotNull(), f.col('B2.sector'))
                    .otherwise(f.col('billb.sector')).alias('billto_sector'),
                    f.lit('ISP').alias('source_system'), f.col('A.sales_organisation').alias('sales_organisation'),
                    f.col('A.sales_document').alias('sales_document'), f.col('A.reference_document').alias('delivery_number'),
                    f.col('A.material_number').alias('material_number'),
                    f.col('A.material_description').alias('local_material_description'),
                    f.when(material.sap_material_name.isNotNull(), material.sap_material_name)
                    .otherwise(f.col('A.material_description')).alias('material_description'),
                    f.col('A.billing_document').alias('billing_document'), f.col('A.billing_item').alias('billing_item'),
                    f.col('A.local_currency').alias('local_currency'), f.col('A.m3').alias('qty_in_m3'),
                    f.col('A.ugl').alias('qty_in_usg'), f.col('A.litres').alias('qty_in_litres'),
                    f.col('A.net_value').alias('net_value'),
                    f.col('A.document_currency').alias('document_currency'), f.col('A.flight_number').alias('flight_number'),
                    f.col('A.aircraft_registration').alias('aircraft_registration'),
                    # f.col('A1.l1_core_marketing_rcop_lc'),
                    # f.col('A2.l1_core_marketing_rcop_usd'),
                    # f.col('A3.l2_gross_profit_lc'),
                    # f.col('A4.l2_gross_profit_usd'),
                    # f.col('A5.l3_revenue_lc'),
                    # f.col('A6.l3_revenue_usd'),
                    # f.col('A7.l3_cost_lc'),
                    # f.col('A8.l3_cost_usd'),
                    # f.col('A9.net_value_lc'),
                    # f.col('A10.net_value_usd'),
                    # f.col('A11.l4_customer_price_lc'),
                    # f.col('A12.l4_customer_price_usd'),
                    # f.col('A13.l4_invoice_line_item_lc'),
                    # f.col('A14.l4_invoice_line_item_usd'),
                    # f.col('A15.l4_taxes_excise_duty_lc'),
                    # f.col('A16.l4_taxes_excise_duty_usd'),
                    # f.col('A17.l4_other_costs_lc'),
                    # f.col('A18.l4_other_costs_usd'),
                    # f.col('A19.l4_pre_airfield_sh_lc'),
                    # f.col('A20.l4_pre_airfield_sh_usd'),
                    # f.col('A21.l4_pre_airfield_transport_lc'),
                    # f.col('A22.l4_pre_airfield_transport_usd'),
                    # f.col('A23.l4_on_airfield_costs_lc'),
                    # f.col('A24.l4_on_airfield_costs_usd'),
                    # f.col('A25.l4_purchase_price_lc'),
                    # f.col('A26.l4_purchase_price_usd'),
                    # f.col('A27.gross_profit_lc'),
                    # f.col('A28.gross_profit_usd'),
                    #
                    # f.col('A1.ref_id').alias('cost_element_key'),
                    f.col('A.ref_id').alias('cost_element_key'),
                    f.when(f.trim(f.substring(f.col('A.soldto_party'), 13, 14)).isin(['5250085098100', '2830224167489']),
                           f.lit('5250238539072'))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500113482442'))),
                          f.lit('7500113482439'))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5240000149889'))),
                          f.lit('5240000149886'))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500181513078'))),
                          f.lit('7500181512619'))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5250269561506'))),
                          f.lit('5250269561480'))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5250250928229'))),
                          f.lit('5250250926406'))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500239668069'))),
                          f.lit('7500239667852'))
                    .when(f.col('C1.isp_sold_to').isNotNull(), f.trim(f.substring(f.col('A.soldto_party'), 13, 14)))
                    .when(((f.col('C1.isp_sold_to').isNull()) & (f.col('C2.isp_sold_to').isNotNull())),
                          f.trim(f.substring(f.col('A.soldto_party'), 13, 14)))
                    .when(((f.col('C1.isp_sold_to').isNull()) & (f.col('C2.isp_sold_to').isNull()) & (
                        f.col('C3.isp_sold_to').isNotNull())),
                          f.trim(f.substring(f.col('A.soldto_party'), 13, 14)))
                    .otherwise(f.trim(f.substring(f.col('A.shipto_party'), 13, 14))).alias('trx_cust_key'),
                    f.when(f.col('C1.isp_sold_to').isNotNull(), f.col('C1.isp_sold_to'))
                    .when(((f.col('C1.isp_sold_to').isNull()) & (f.col('C2.isp_sold_to').isNotNull())),
                          f.col('C2.isp_sold_to'))
                    .when(((f.col('C1.isp_sold_to').isNull()) & (f.col('C2.isp_sold_to').isNull()) & (
                        f.col('C3.isp_sold_to').isNotNull())),
                          f.col('C3.isp_sold_to'))
                    .otherwise(f.trim(f.substring(isp_cust.ref_isp_id, 13, 14))).alias('dim_cust_key'),
                    f.when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '1660081245076', f.lit(None))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '7500186160796', f.lit('7500000017988'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250188852111', f.lit('1660032583289'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000144541', f.lit('1660340371949'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250182134237', f.lit('5240000190170'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250182132990', f.lit('5240000121845'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '1660088557886', f.lit('1660340371812'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250079559111', f.lit('5250260520637'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '6030006511715', f.lit('6030000008965'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250215710778', f.lit('5250216422556'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250000011676', f.lit('7200000008572'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '7200000008099', f.lit('7200000008579'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000182172', f.lit('6030000023004'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250019594224', f.lit('5250001162501'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000117631', f.lit('1660054415179'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000139207', f.lit('7200000009137'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000149186', f.lit('1660340371953'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '3800030071603', f.lit('3800257427531'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '7500185991656', f.lit('7500036430652'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250011627642', f.lit('5250097927553'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5250000190251', f.lit('5240000131621'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '5240000249580', f.lit('5310019146747'))
                    .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '1660297395691', f.lit('5250195706089'))
                    .otherwise(f.trim(f.substring(f.col('A.billto_party'), 13, 14))).alias('trx_billto_key'),
                    f.when(f.col('B1.isp_bill_to').isNotNull(), f.col('B1.isp_bill_to'))
                    .when(f.col('B1.isp_bill_to').isNull() & f.col('B2.isp_bill_to').isNotNull(),
                          f.col('B2.isp_bill_to'))
                    .otherwise(f.trim(f.substring(f.col('billb.fk_isp_bill_to'), 13, 14))).alias('dim_billto_key'),
                    f.concat(
                        f.when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == 'ISP_TPUT_REC',
                               f.lit('ISP_TPUT_REC'))
                            .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == '4430002396956',
                                  f.lit('5240000060798'))
                            .when(f.concat(f.substring(f.col('A.billto_party'), 13, 14), f.trim(
                            f.substring(f.col('A.payer'), 13, 14))) == '52500003573825250000357380',
                                  f.lit('5250226360209'))
                            .when(f.concat(f.substring(f.col('A.billto_party'), 13, 14), f.trim(
                            f.substring(f.col('A.payer'), 13, 14))) == '52500795591135250079559112',
                                  f.lit('5250260520638'))
                            .when(f.concat(f.substring(f.col('A.billto_party'), 13, 14), f.trim(
                            f.substring(f.col('A.payer'), 13, 14))) == '52503053281713800161398192',
                                  f.lit('3800161398240'))
                            .otherwise(f.trim(f.substring(f.col('A.billto_party'), 13, 14))),
                        f.when(f.col('A.payer').isNull(), f.lit(None))
                            .when(f.col('A.payer') == '', f.lit(None))
                            .when(f.trim(f.substring(f.col('A.billto_party'), 13, 14)) == 'ISP_TPUT_REC',
                                  f.lit(''))
                            .when(f.trim(f.substring(f.col('A.payer'), 13, 14)) == '5250000357380',
                                  f.lit('5250226359884'))
                            .when(f.trim(f.substring(f.col('A.payer'), 13, 14)) == '5250079559112',
                                  f.lit('5250260520636'))
                            .when(f.concat(f.substring(f.col('A.billto_party'), 13, 14), f.trim(
                            f.substring(f.col('A.payer'), 13, 14))) == '52500175740735250079835826',
                                  f.lit('5250017574072'))
                            .when(f.concat(f.substring(f.col('A.billto_party'), 13, 14), f.trim(
                            f.substring(f.col('A.payer'), 13, 14))) == '52500000178335250113976983',
                                  f.lit('5250000017825'))
                            .when(f.concat(f.substring(f.col('A.billto_party'), 13, 14), f.trim(
                            f.substring(f.col('A.payer'), 13, 14))) == '52502416014245250244303889',
                                  f.lit('5250241344076'))
                            .when(f.concat(f.substring(f.col('A.billto_party'), 13, 14), f.trim(
                            f.substring(f.col('A.payer'), 13, 14))) == '52500003573825250000357380',
                                  f.lit('5250226359884'))
                            .when(f.concat(f.substring(f.col('A.billto_party'), 13, 14), f.trim(
                            f.substring(f.col('A.payer'), 13, 14))) == '52500795591135250079559112',
                                  f.lit('5250260520636'))
                            .otherwise(f.trim(f.substring(f.col('A.payer'), 13, 14)))).alias('trx_payer_key'),
                    f.when(f.concat(f.col('P1.isp_payer'), f.col('P1.isp_id')).isNotNull(),
                           f.concat(f.col('P1.isp_payer'), f.col('P1.isp_id')))
                    .when(f.concat(f.col('P1.isp_payer'), f.col('P1.isp_id')).isNull() & f.concat(
                        f.col('P2.isp_payer'), f.col('P2.isp_id')).isNotNull(),
                          f.concat(f.col('P2.isp_payer'), f.col('P2.isp_id')))
                    .otherwise(f.concat(f.substring(f.col('payb.ref_isp_id'), 13, 14),
                                        f.substring(f.col('payb.fk_isp_payer'), 13, 14))).alias(
                        'dim_payer_key'),
                    f.when(f.substring(f.col('A.plant'), 13, 11) == f.lit('10078880080'),
                           f.concat(f.substring(f.col('A.plant'), 1, 12), f.lit('5240000179233')))
                    .when(f.col('A.plant').isin(
                        ['ISP_ESP0166_1660323864384', 'ISP_ESP0166_90750000058480',
                         'ISP_ESP0166_90750000058430',
                         'ISP_ESP0166_10077968010', 'ISP_ESP0166_10004294237',
                         'ISP_ESP0166_10000320238', 'ISP_ESP0166_10023188994', 'ISP_ESP0166_90750000058714',
                         'ISP_ESP0166_90750000043448', 'ISP_ESP0166_90750000058432',
                         'ISP_ESP0166_10000051711', 'ISP_ESP0166_90750000058722',
                         'ISP_ESP0166_90750000058495',
                         'ISP_ESP0166_90750000043446']),
                        f.when(f.col('A.location_of_sale') == f.lit('10BRIEJ-FR'),
                               f.lit('ISP_ESP0166_1660137543562'))
                            .when(f.col('A.location_of_sale') == f.lit('17STGNA-FR'),
                                  f.lit('ISP_ESP0166_1660066843576'))
                            .when(f.col('A.location_of_sale') == f.lit('17STGNJ-FR'),
                                  f.lit('ISP_ESP0166_1660066843576'))
                            .when(f.col('A.location_of_sale') == f.lit('22BMCS-FR'),
                                  f.lit('ISP_ESP0166_1660322263544'))
                            .when(f.col('A.location_of_sale') == f.lit('30AVIGJ-FR'),
                                  f.lit('ISP_ESP0166_5240000185606'))
                            .when(f.col('A.location_of_sale') == f.lit('31CUGNA-FR'),
                                  f.lit('ISP_ESP0166_1660375568893'))
                            .when(f.col('A.location_of_sale') == f.lit('37BMCS-FR'),
                                  f.lit('ISP_ESP0166_1660319370774'))
                            .when(f.col('A.location_of_sale') == f.lit('50GRANJ-FR'),
                                  f.lit('ISP_ESP0166_5240000180896'))
                            .when(f.col('A.location_of_sale') == f.lit('56LANNB-FR'),
                                  f.lit('ISP_ESP0166_1660388895114'))
                            .when(f.col('A.location_of_sale') == f.lit('65TARBE-FR'),
                                  f.lit('ISP_ESP0166_1660388337393'))
                            .when(f.col('A.location_of_sale') == f.lit('66PERPI-FR'),
                                  f.lit('ISP_ESP0166_1660388971118'))
                            .when(f.col('A.location_of_sale') == f.lit('76CAUDE-FR'),
                                  f.lit('ISP_ESP0166_1660363992363'))
                            .when(f.col('A.location_of_sale') == f.lit('83CANET-FR'),
                                  f.lit('ISP_ESP0166_5250004178874'))
                            .when(f.col('A.location_of_sale') == f.lit('83CANJU-FR'),
                                  f.lit('ISP_ESP0166_1660388897666'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660330783329'),
                                  f.lit('ISP_ESP0166_1660237496978'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660332298874'),
                                  f.lit('ISP_ESP0166_CEQ_Bulk'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660032274905'),
                                  f.lit('ISP_ESP0166_5240000181008'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250274386698'),
                                  f.lit('ISP_ESP0166_1660066843576'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660032923741'),
                                  f.lit('ISP_ESP0166_5240000181027'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660330808222'),
                                  f.lit('ISP_ESP0166_5250004176698'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250271856521'),
                                  f.lit('ISP_ESP0166_5240000181932'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660341708047'),
                                  f.lit('ISP_ESP0166_1660341707704'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660296641016'),
                                  f.lit('ISP_ESP0166_1660066843576'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660033059110'),
                                  f.lit('ISP_ESP0166_5250004176698'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660030270797'),
                                  f.lit('ISP_ESP0166_5240000180831'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250219647485'),
                                  f.lit('ISP_ESP0166_5240000180839'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250219643359'),
                                  f.lit('ISP_ESP0166_5240000180839'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660388342121'),
                                  f.lit('ISP_ESP0166_1660388337393'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250287848779'),
                                  f.lit('ISP_ESP0166_1660319370767'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660032333428'),
                                  f.lit('ISP_ESP0166_5240000185606'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660319234711'),
                                  f.lit('ISP_ESP0166_1660237496978'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250220065904'),
                                  f.lit('ISP_ESP0166_1660137543562'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660032333499'),
                                  f.lit('ISP_ESP0166_5240000181044'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660032135836'),
                                  f.lit('ISP_ESP0166_5240000181940'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660038519481'),
                                  f.lit('ISP_ESP0166_1660036457786'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660341708262'),
                                  f.lit('ISP_ESP0166_1660341707704'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660032075638'),
                                  f.lit('ISP_ESP0166_5240000180823'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250281829921'),
                                  f.lit('ISP_ESP0166_5240000180839'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660224126394'),
                                  f.lit('ISP_ESP0166_5250003947410'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660177085072'),
                                  f.lit('ISP_ESP0166_1660176995378'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660275276869'),
                                  f.lit('ISP_ESP0166_1660276278601'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660033057529'),
                                  f.lit('ISP_ESP0166_5240000184227'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660344680126'),
                                  f.lit('ISP_ESP0166_5240000180483'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660035423716'),
                                  f.lit('ISP_ESP0166_5240000184036'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250231168235'),
                                  f.lit('ISP_ESP0166_5250003947374'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660314911008'),
                                  f.lit('ISP_ESP0166_1660314952544'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660332298895'),
                                  f.lit('ISP_ESP0166_CEQ_Bulk'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660388897654'),
                                  f.lit('ISP_ESP0166_1660388895114'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250231169030'),
                                  f.lit('ISP_ESP0166_5250003947374'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660345175248'),
                                  f.lit('ISP_ESP0166_5250007375897'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660032239543'),
                                  f.lit('ISP_ESP0166_5240000180806'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660032277249'),
                                  f.lit('ISP_ESP0166_5250007502902'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660271174651'),
                                  f.lit('ISP_ESP0166_1660250627295'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_1660345173890'),
                                  f.lit('ISP_ESP0166_1660108285943'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250215575641'),
                                  f.lit('ISP_ESP0166_1660363992363'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250271811288'),
                                  f.lit('ISP_ESP0166_5240000180839'))
                            .when(f.col('A.shipto_party') == f.lit('ISP_ESP0166_5250271887926'),
                                  f.lit('ISP_ESP0166_5240000181932'))
                            .when(f.col('A.location_of_sale') == f.lit('31EDEIS-FR'),
                                  f.lit('ISP_ESP0166_1660401063502'))
                            .when(((f.col('A.plant') == f.lit('ISP_ESP0166_1660323864384')) & (
                                f.year(f.col('A.delivery_date')) == f.lit(2020))),
                                  f.lit('ISP_ESP0166_1660323864384'))
                            .when(((f.col('A.shipto_party').isin(
                            ['ISP_ESP0166_1660081286690', 'ISP_ESP0166_1660162083904',
                             'ISP_ESP0166_1660148887823',
                             'ISP_ESP0166_1660162209642', 'ISP_ESP0166_1660192703521',
                             'ISP_ESP0166_1660271176093',
                             'ISP_ESP0166_1660323865215', 'ISP_ESP0166_1660364366084',
                             'ISP_ESP0166_1660364377561',
                             'ISP_ESP0166_1660388753977', 'ISP_ESP0166_1660388897722',
                             'ISP_ESP0166_1660391033051'])) &
                                   (f.col('A.material_mnmc') == f.lit('JETA1'))), f.lit('ISP_ESP0166_SEA')))
                    .otherwise(f.col('A.plant')).alias('trx_loc_key'),
                    f.col('A.material_number').alias('trx_pro_key'),
                    material.isp_mtl_art_id.cast('long').alias('dim_pro_key'),
                    f.col('A.payer').alias('payer'),
                    f.when(f.trim(f.substring(f.col('A.soldto_party'), 13, 14)).isin(
                        ['5250085098100', '2830224167489']),
                        f.concat(f.substring(f.col('A.soldto_party'), 1, 12), f.lit('5250238539072')))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500113482442'))),
                          f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('7500113482439')))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5240000149889'))),
                          f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('5240000149886')))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500181513078'))),
                          f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('7500181512619')))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5250269561506'))),
                          f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('5250269561480')))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('5250250928229'))),
                          f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('5250250926406')))
                    .when(((f.col('A.soldto_party').isNull()) & (
                            f.trim(f.substring(f.col('A.shipto_party'), 13, 14)) == f.lit('7500239668069'))),
                          f.concat(f.substring(f.col('A.shipto_party'), 1, 12), f.lit('7500239667852')))
                    .otherwise(f.col('A.soldto_party')).alias('soldto_party'),
                    f.current_date().alias('last_modified_date'), f.col('A.country').alias('costing_country'),
                    f.when(f.col('A.country') == 'TR', f.lit('Into Plane'))
                    .when((f.col('A.country') == 'GR') & (loctype.location_type == 'Airport'),
                          f.lit('Into Plane'))
                    .when((f.col('A.country') == 'GR') & (loctype.location_type == 'Non-Airport'),
                          f.lit('Bulk'))
                    .otherwise(material.delivery_method).alias('delivery_method'))

        # print(df_tfx_result.count())

        return df_tfx_result


if __name__ == '__main__':
    trl = SunIspETL()
    trl.execute()
