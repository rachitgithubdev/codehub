# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Hasan Chaudhary 25-Feb-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-pre-l2-l3-master.py into conform zone
# Author        :- Hasan Chaudhary
# Date          :- 25-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['makt', 'mara', 'marm', 'mvke']
        self.l3_report_file1 = "l3_pre_makt_material_descriptions"
        self.l3_report_file2 = "l3_pre_mara_general_material_data"
        self.l3_report_file3 = "l3_pre_marm_material_uom"
        self.l3_report_file4 = "l3_pre_mvke_sales_data_for_material"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # generate input table list
        source_database = self.source_database
        input_table_list = self.input_table_list
        print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        df_makt = self._get_table(source_database, input_table_list[0]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[0],
        #                                               df_makt.count()))
        df_mara = self._get_table(source_database, input_table_list[1]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[1],
        #                                               df_mara.count()))
        df_marm = self._get_table(source_database, input_table_list[2]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[2],
        #                                               df_marm.count()))
        df_mvke = self._get_table(source_database, input_table_list[3]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[3],
        #                                               df_mvke.count()))
        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx = self._apply_tfx(df_makt, df_mara, df_marm, df_mvke)

        # write final result  destination
        self.write_results(df_tfx[0], self.l3_report_file1)

        # write final result  destination
        self.write_results(df_tfx[1], self.l3_report_file2)

        # write final result to destination
        self.write_results(df_tfx[2], self.l3_report_file3)

        # write final result to destination
        self.write_results(df_tfx[3], self.l3_report_file4)

    def write_results(self, target_dataset, report):
        final_path = self.destination_bucket + "/" + report
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # convert all the columns alias to lower case
        df_makt = args[0].select([f.col(x).alias(x.lower()) for x in args[0].columns])
        df_mara = args[1].select([f.col(x).alias(x.lower()) for x in args[1].columns])
        df_marm = args[2].select([f.col(x).alias(x.lower()) for x in args[2].columns])
        df_mvke = args[3].select([f.col(x).alias(x.lower()) for x in args[3].columns])

        # TRANSFORMATIONS
        df_makt = df_makt.filter(df_makt.spras == 'E') \
            .select(df_makt.matnr, df_makt.spras, df_makt.maktx)

        df_mara = df_mara.select(df_mara.matnr, df_mara.mtart)

        df_marm = df_marm.select(df_marm.matnr, df_marm.meinh, df_marm.umrez, df_marm.umren)

        df_mvke = df_mvke.select(df_mvke.matnr, df_mvke.vkorg, df_mvke.vtweg, df_mvke.mvgr4)

        # transformation
        df_tfx_result = [df_makt, df_mara, df_marm, df_mvke]
        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
