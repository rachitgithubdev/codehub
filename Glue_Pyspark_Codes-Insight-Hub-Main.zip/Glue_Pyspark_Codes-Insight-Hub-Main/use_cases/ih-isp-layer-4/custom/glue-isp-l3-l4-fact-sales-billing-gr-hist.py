# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    18-Jan-2021     Initial version
#  0.2              Tingting Wan    24-May-2021     Change Logs - Left join Table I--
#                                                   l3_isp_exchange_rate_all & parameterise source system
# =================================================================================================
# Description   :- The aim of the code is to generate l4_isp_fact_sales_billing_gr_hist into conform zone
# Author        :- Tingting Wan
# Date          :- 18-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window


class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'country_database',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l3_isp_inv_sales_line_all', 'l3_isp_inv_sales_all', 'l3_isp_currency_all',
                                 'l3_isp_uom_oil_all', 'l3_isp_mtl_art_all', 'l3_isp_conf_stk_mvt_all',
                                 'l3_isp_fuel_point_all', 'l3_isp_exchange_rate_all']
        self.report_file = "l4_isp_fact_sales_billing_gr_hist"

        # generic variables  ===========================================
        self.country_database = args['country_database']

        # Create country and its source_system
        country = 'gr'
        self.country_database_map = dict(map(lambda x: x.split('='), self.country_database.split(',')))
        self.source_system = 'ISP_' + (self.country_database_map[country]).upper()

        print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
        #                                                                  self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_table_A = self._get_table(self.source_database, self.input_table_list[0]).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[0],
                                                       df_table_A.count()))
        df_table_B = self._get_table(self.source_database, self.input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[1],
        #                                                df_table_B.count()))
        df_table_C = self._get_table(self.source_database, self.input_table_list[2]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[2],
        #                                                df_table_C.count()))

        df_table_E = self._get_table(self.source_database, self.input_table_list[3]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[3],
        #                                                df_table_E.count()))
        df_table_F = self._get_table(self.source_database, self.input_table_list[4]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[4],
        #                                                df_table_F.count()))
        df_table_G = self._get_table(self.source_database, self.input_table_list[5]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[5],
        #                                                df_table_G.count()))
        df_table_H = self._get_table(self.source_database, self.input_table_list[6]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[6],
        #                                                df_table_H.count()))
        df_table_I = self._get_table(self.source_database, self.input_table_list[7]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table_list[7],
        #                                                 df_table_I.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(self.source_system, df_table_A, df_table_B,
                                       df_table_C,
                                       df_table_E, df_table_F,
                                       df_table_G, df_table_H,
                                       df_table_I)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(source_system, *args):
        # assign tables
        df_input_table_A = args[0]

        df_input_table_B = args[1].cache()
        df_input_table_C = args[2].cache()

        df_input_table_E = args[3].cache()
        df_input_table_F = args[4].cache()
        df_input_table_G = args[5]
        df_input_table_H = args[6].cache()
        df_input_table_I = args[7].cache()

        # pre transformation
        # sum_table and currency
        df_sum_table = df_input_table_A.groupBy(f.col('fk_inv_sales_id')) \
            .agg(f.sum(f.col('val_invg')).alias('sum_val_invg')) \
            .select(f.col('fk_inv_sales_id'), f.col('sum_val_invg')).cache()

        df_currency_table = df_input_table_C.select(f.col('mnmc'), f.col('ref_id'))

        # create billing_item col in df_input_table_A
        # df_input_table_A = df_input_table_A0 \
        #     .withColumn('billing_item', f.row_number().over(Window.partitionBy(df_input_table_A.fk_inv_sales_id)
        #                                                     .orderBy(df_input_table_A.fk_inv_sales_id))).cache()

        # fill null cols with given cols in df_input_table_G
        df_input_table_G = df_input_table_G.withColumn('qty_ifnull',
                                                       f.coalesce(df_input_table_G.qty, df_input_table_G.loc_wght)) \
            .withColumn('ref_qty_kg_ifnull', f.coalesce(df_input_table_G.ref_qty_kg, df_input_table_G.loc_wght)) \
            .withColumn('ref_qty_l_ifnull',
                        f.coalesce(df_input_table_G.ref_qty_l, df_input_table_G.loc_std_vol)).cache()

        # main transformation
        # join tables
        df_tfx_result = df_input_table_A.alias('A') \
            .filter(f.trim(f.upper(f.col('A.source_system'))) == source_system) \
            .join(df_sum_table, f.col('A.fk_inv_sales_id') == df_sum_table.fk_inv_sales_id, 'left') \
            .join(df_input_table_B, f.col('A.fk_inv_sales_id') == df_input_table_B.ref_id, 'left') \
            .join(df_input_table_C.alias('global_curr'), df_input_table_B.fk_curcy_id == f.col("global_curr.ref_id"),
                  'left') \
            .join(df_currency_table.alias('local_curr'),
                  df_input_table_B.fk_curcy_id_locl == f.col("local_curr.ref_id"),
                  'left') \
            .join(df_input_table_E, f.col('A.fk_uom_id') == df_input_table_E.ref_id, 'left') \
            .join(df_input_table_F, (f.col('A.fk_mtl_art_id') == df_input_table_F.ref_id) &
                  df_input_table_F.art_type_id.isNotNull(), 'left') \
            .join(df_input_table_G, f.col('A.fk_conf_stk_mvt_id') == df_input_table_G.ref_id, 'left') \
            .join(df_input_table_H, df_input_table_G.fk_fuel_point_id == df_input_table_H.ref_id, 'left') \
            .join(df_input_table_I, (df_input_table_B.exch_rate_type_id == df_input_table_I.exch_rate_type_id)
                  & (df_input_table_B.curcy_id == df_input_table_I.curcy_id_from)
                  & (df_input_table_B.curcy_id_locl == df_input_table_I.curcy_id_to)
                  & ((f.when(df_input_table_B.exch_rate_date_type_id == '1', df_input_table_B.inv_date)
                      .when(df_input_table_B.exch_rate_date_type_id == '2', f.col('A.actl_dlvy_date'))
                      .otherwise(f.coalesce(df_input_table_B.plnd_inv_date, f.col('A.actl_dlvy_date')))
                      ).between(df_input_table_I.start_date, df_input_table_I.end_date))
                  & (f.col('A.source_system') == df_input_table_I.source_system)
                  , 'left') \
            .select(
            f.col('A.source_system').alias('source_system'),
            df_input_table_B.iop_num_prefixed.alias('billing_document'),
            f.concat(f.col('A.fk_inv_sales_id'), f.lit('_'),
                     f.row_number().over(Window.partitionBy(f.col('A.fk_inv_sales_id'))
                                         .orderBy(f.col('A.fk_inv_sales_id'))), f.lit('_'), f.lit(1)).alias(
                'ref_id'),
            f.lit(' ').alias('billing_type'), f.lit(' ').alias('billing_category'),
            f.lit(' ').alias('sales_doc_category'),
            f.col('global_curr.mnmc').alias('document_currency'),
            f.col('A.work_grp_id').alias('sales_organisation'),
            f.lit(' ').alias('distribution_channel'), f.lit(' ').alias('pricing_procedure'),
            f.lit(' ').alias('doc_condition_no'), f.lit(' ').alias('fk_doc_condition_no'),
            f.lit(' ').alias('shipping_condition'), df_input_table_B.inv_date.alias('billing_date'),
            f.lit(' ').alias('posting_status'), df_input_table_B.exch_rate.alias('exchange_rate_accntg'),
            f.when(df_input_table_B.curcy_id == df_input_table_B.curcy_id_locl, f.lit(1).cast('double'))
                .otherwise(df_input_table_I.exch_rate).alias('ile_exchange_rate'),
            f.lit(' ').alias('terms_of_payment'), df_input_table_B.bp_cmpy_id.alias('company_code'),
            df_sum_table.sum_val_invg.alias('total_net_value'), df_input_table_B.crt_date_time.alias('header_time'),
            df_input_table_B.crt_date_time.alias('header_created_on'), f.lit(' ').alias('statistics_currency'),
            df_input_table_B.exch_rate_type_id.alias('exchange_rate_type'), f.lit(' ').alias('division'),
            f.col('local_curr.mnmc').alias('local_currency'), f.lit(' ').alias('cred_data_exch_rate'),
            f.lit(' ').alias('logical_system'), f.lit(' ').alias('translation_date'),
            f.row_number().over(Window.partitionBy(f.col('A.fk_inv_sales_id'))
                                .orderBy(f.col('A.fk_inv_sales_id'))).alias('billing_item'),
            f.when(df_input_table_F.art_type_id.isin('1', '3') &
                   (df_input_table_G.qty_ifnull > 0) & (f.col('A.val_invg') < 0),
                   df_input_table_G.qty_ifnull * (-1))
                .when(df_input_table_F.art_type_id.isin('1', '3') &
                      (df_input_table_G.qty_ifnull < 0) & (f.col('A.val_invg') > 0),
                      df_input_table_G.qty_ifnull * (-1))
                .otherwise(f.lit(0)).alias('billed_quantity'),
            df_input_table_E.mnmc.alias('sales_unit'), f.lit(' ').alias('base_unit_of_measure'),
            f.lit(0).cast('double').alias('billing_qty_in_sku'),
            f.when(df_input_table_F.art_type_id.isin('1', '3') &
                   (df_input_table_G.qty_ifnull > 0) & (f.col('A.val_invg') < 0),
                   df_input_table_G.qty_ifnull * (-1))
                .when(df_input_table_F.art_type_id.isin('1', '3') &
                      (df_input_table_G.qty_ifnull < 0) & (f.col('A.val_invg') > 0),
                      df_input_table_G.qty_ifnull * (-1))
                .otherwise(f.lit(0)).alias('required_quantity'),
            f.when(df_input_table_F.art_type_id.isin('1', '3') &
                   (df_input_table_G.ref_qty_kg_ifnull > 0) & (f.col('A.val_invg') < 0),
                   df_input_table_G.ref_qty_kg_ifnull * (-1))
                .when(df_input_table_F.art_type_id.isin('1', '3') &
                      (df_input_table_G.ref_qty_kg_ifnull < 0) & (f.col('A.val_invg') > 0),
                      df_input_table_G.ref_qty_kg_ifnull * (-1))
                .otherwise(f.lit(0)).alias('net_weight'),
            f.when(df_input_table_F.art_type_id.isin('1', '3') &
                   (df_input_table_G.ref_qty_kg_ifnull > 0) & (f.col('A.val_invg') < 0),
                   df_input_table_G.ref_qty_kg_ifnull * (-1))
                .when(df_input_table_F.art_type_id.isin('1', '3') &
                      (df_input_table_G.ref_qty_kg_ifnull < 0) & (f.col('A.val_invg') > 0),
                      df_input_table_G.ref_qty_kg_ifnull * (-1))
                .otherwise(f.lit(0)).alias('gross_weight'),
            f.lit('KG').alias('weight_unit'),
            f.when(df_input_table_F.art_type_id.isin('1', '3') &
                   (df_input_table_G.ref_qty_l_ifnull > 0) & (f.col('A.val_invg') < 0),
                   df_input_table_G.ref_qty_l_ifnull * (-1))
                .when(df_input_table_F.art_type_id.isin('1', '3') &
                      (df_input_table_G.ref_qty_l_ifnull < 0) & (f.col('A.val_invg') > 0),
                      df_input_table_G.ref_qty_l_ifnull * (-1))
                .otherwise(f.lit(0)).alias('volume'),
            f.lit('LT').alias('volume_unit'), f.lit(0).cast('double').alias('std_volume'),
            df_input_table_B.inv_date.alias('pricing_date'), df_input_table_B.exch_rate.alias('exchange_rate'),
            f.col('A.val_invg').alias('net_value'), f.col('A.dlvy_note_num').alias('reference_document'),
            f.lit(' ').alias('reference_item'), f.lit(' ').alias('preceding_doc_categ'),
            df_input_table_G.ord_num.alias('sales_document'), f.lit(' ').alias('sales_document_item'),
            f.col('A.mtl_art_id').alias('material_number'), df_input_table_F.mnmc.alias('material_mnmc'),
            f.col('A.art_name').alias('material_description'),
            df_input_table_F.art_type_id.alias('item_category'),
            df_input_table_G.fk_fuel_point_id.alias('shipping_point_receiving_pt'),
            f.when(df_input_table_G.fk_port_id.isNotNull(), df_input_table_G.fk_port_id)
                .when(df_input_table_B.fk_port_id.isNotNull(), df_input_table_B.fk_port_id)
                .when(df_input_table_H.fk_port_id.isNotNull(), df_input_table_H.fk_port_id)
                .otherwise(df_input_table_G.fk_loc_of_mvt_id).alias('plant'),
            f.lit('GR').alias('country'), df_input_table_B.work_grp_id.alias('sales_office'),
            f.col('A.crt_date_time').alias('line_created_on'), f.col('A.crt_date_time').alias('line_time'),
            f.lit(' ').alias('exchange_rate_stats'), f.lit(' ').alias('profit_centre'),
            f.lit(' ').alias('price_group_order'), f.lit(' ').alias('price_list_ord'), f.lit(' ').alias('order_reason'),
            f.lit(' ').alias('extern_bol_no'), f.lit(' ').alias('contract_nr'), f.lit(' ').alias('ref_contractitm'),
            f.lit(' ').alias('pricing_time'), f.lit(' ').alias('inv_cycle_ind'),
            f.lit(' ').alias('standard_supply_loc'),
            f.lit(' ').alias('standard_refinery'), f.lit(' ').alias('vessel_name'), f.lit(' ').alias('term_type'),
            f.col('A.flight_number').alias('flight_number'), f.lit(' ').alias('aircraft_type_code'),
            f.col('A.acrft_reg_number').alias('aircraft_registration'), f.lit(' ').alias('contr_doc_type'),
            f.when(df_input_table_G.fk_port_id.isNotNull(), df_input_table_G.fk_port_id)
                .when(df_input_table_B.fk_port_id.isNotNull(), df_input_table_B.fk_port_id)
                .when(df_input_table_H.fk_port_id.isNotNull(), df_input_table_H.fk_port_id)
                .otherwise(df_input_table_G.fk_loc_of_mvt_id).alias('original_plant'),
            f.lit(' ').alias('shp_type_stage'), f.lit(' ').alias('billing_unit'), f.lit(' ').alias('pc_type'),
            f.lit(' ').alias('ssr_pc_category'), f.lit(' ').alias('channel_of_trade'), f.lit(' ').alias('cons_assgn'),
            f.lit(' ').alias('district'), f.lit(' ').alias('met_event_type'),
            df_input_table_B.exch_rate.alias('average_exch_rate'),
            df_input_table_B.exch_rate.alias('d_1_exchange_rate'),
            df_input_table_B.exch_rate.alias('c_exchange_rate'),
            f.when(df_input_table_F.art_type_id.isin('1', '3') &
                   (df_input_table_G.ref_qty_kg_ifnull > 0) &
                   (f.col('A.val_invg') < 0),
                   f.when(df_input_table_G.ref_qty_kg.isNotNull(), df_input_table_G.ref_qty_kg / 1000 * (-1))
                   .when(df_input_table_E.mnmc.isin('M3', 'M3S'), df_input_table_G.loc_wght * (-1))
                   .otherwise(df_input_table_G.loc_wght / 1000 * (-1)))
                .when(df_input_table_F.art_type_id.isin('1', '3') &
                      (df_input_table_G.ref_qty_kg_ifnull < 0) & (f.col('A.val_invg') > 0),
                      f.when(df_input_table_G.ref_qty_kg.isNotNull(), df_input_table_G.ref_qty_kg / 1000 * (-1))
                      .when(df_input_table_E.mnmc.isin('M3', 'M3S'), df_input_table_G.loc_wght * (-1))
                      .otherwise(df_input_table_G.loc_wght / 1000 * (-1)))
                .when(df_input_table_F.art_type_id.isin('1', '3'),
                      f.when(df_input_table_G.ref_qty_kg.isNotNull(), df_input_table_G.ref_qty_kg / 1000)
                      .when(df_input_table_E.mnmc.isin('M3', 'M3S'), df_input_table_G.loc_wght)
                      .otherwise(df_input_table_G.loc_wght / 1000))
                .otherwise(f.lit(0)).alias('metric_tons'),
            f.when(df_input_table_F.art_type_id.isin('1', '3') &
                   (df_input_table_G.ref_qty_l_ifnull > 0) & (f.col('A.val_invg')< 0),
                   f.when(df_input_table_G.ref_qty_l.isNotNull(), df_input_table_G.ref_qty_l * (-1))
                   .when(df_input_table_E.mnmc.isin('M3', 'M3S'), df_input_table_G.loc_std_vol / 1000 * (-1))
                   .otherwise(df_input_table_G.loc_std_vol * (-1)))
                .when(df_input_table_F.art_type_id.isin('1', '3') &
                      (df_input_table_G.ref_qty_l_ifnull < 0) & (f.col('A.val_invg') > 0),
                      f.when(df_input_table_G.ref_qty_l.isNotNull(), df_input_table_G.ref_qty_l * (-1))
                      .when(df_input_table_E.mnmc.isin('M3', 'M3S'), df_input_table_G.loc_std_vol / 1000 * (-1))
                      .otherwise(df_input_table_G.loc_std_vol * (-1)))
                .when(df_input_table_F.art_type_id.isin('1', '3'),
                      f.when(df_input_table_G.ref_qty_l.isNotNull(), df_input_table_G.ref_qty_l)
                      .when(df_input_table_E.mnmc.isin('M3', 'M3S'), df_input_table_G.loc_std_vol / 1000)
                      .otherwise(df_input_table_G.loc_std_vol))
                .otherwise(f.lit(0)).alias('litres'),
            f.when(df_input_table_F.art_type_id.isin('1', '3') &
                   (df_input_table_G.ref_qty_l_ifnull > 0) & (f.col('A.val_invg') < 0),
                   f.when(df_input_table_G.ref_qty_l.isNotNull(), df_input_table_G.ref_qty_l * (0.264172) * (-1))
                   .when(df_input_table_E.mnmc.isin('M3', 'M3S'),
                         df_input_table_G.loc_std_vol * (0.264172) / 1000 * (-1))
                   .otherwise(df_input_table_G.loc_std_vol * (0.264172) * (-1)))
                .when(df_input_table_F.art_type_id.isin('1', '3') &
                      (df_input_table_G.ref_qty_l_ifnull < 0) & (f.col('A.val_invg') > 0),
                      f.when(df_input_table_G.ref_qty_l.isNotNull(), df_input_table_G.ref_qty_l * (0.264172) * (-1))
                      .when(df_input_table_E.mnmc.isin('M3', 'M3S'),
                            df_input_table_G.loc_std_vol * (0.264172) / 1000 * (-1))
                      .otherwise(df_input_table_G.loc_std_vol * (0.264172) * (-1)))
                .when(df_input_table_F.art_type_id.isin('1', '3'),
                      f.when(df_input_table_G.ref_qty_l.isNotNull(), df_input_table_G.ref_qty_l * (0.264172))
                      .when(df_input_table_E.mnmc.isin('M3', 'M3S'), df_input_table_G.loc_std_vol * (0.264172) / 1000)
                      .otherwise(df_input_table_G.loc_std_vol * (0.264172)))
                .otherwise(f.lit(0)).alias('ugl'),
            f.when(df_input_table_F.art_type_id.isin('1', '3') &
                   (df_input_table_G.ref_qty_l_ifnull > 0) & (f.col('A.val_invg') < 0),
                   f.when(df_input_table_G.ref_qty_l.isNotNull(), df_input_table_G.ref_qty_l / 1000 * (-1))
                   .when(df_input_table_E.mnmc.isin('M3', 'M3S'), df_input_table_G.loc_std_vol * (-1))
                   .otherwise(df_input_table_G.loc_std_vol / 1000 * (-1)))
                .when(df_input_table_F.art_type_id.isin('1', '3') &
                      (df_input_table_G.ref_qty_l_ifnull < 0) & (f.col('A.val_invg') > 0),
                      f.when(df_input_table_G.ref_qty_l.isNotNull(), df_input_table_G.ref_qty_l / 1000 * (-1))
                      .when(df_input_table_E.mnmc.isin('M3', 'M3S'), df_input_table_G.loc_std_vol * (-1))
                      .otherwise(df_input_table_G.loc_std_vol / 1000 * (-1)))
                .when(df_input_table_F.art_type_id.isin('1', '3'),
                      f.when(df_input_table_G.ref_qty_l.isNotNull(), df_input_table_G.ref_qty_l / 1000)
                      .when(df_input_table_E.mnmc.isin('M3', 'M3S'), df_input_table_G.loc_std_vol)
                      .otherwise(df_input_table_G.loc_std_vol / 1000))
                .otherwise(f.lit(0)).alias('m3'),
            f.when(df_input_table_G.fk_cust_acct_id.isNotNull(), df_input_table_G.fk_cust_acct_id)
                .otherwise(df_input_table_G.fk_cust_acct_id).alias('shipto_party'),
            df_input_table_B.fk_inv_pt_id.alias('billto_party'),
            f.when(df_input_table_G.fk_cab_id.isNotNull(), df_input_table_G.fk_cab_id)
                .otherwise(df_input_table_G.fk_cab_id).alias('soldto_party'),
            f.lit(' ').alias('payer'), f.lit(' ').alias('destination_airport'),
            f.lit(' ').alias('final_destination_partner'), f.lit(' ').alias('parent_partner'),
            f.lit(' ').alias('vendor'),
            f.lit(' ').alias('sales_rep'), f.lit(' ').alias('agent_id'),
            f.col('A.actl_dlvy_date').alias('delivery_date'), df_input_table_H.name.alias('fuel_point_name'),
            df_input_table_G.fk_loc_of_mvt_id.alias('location_id'), f.lit(' ').alias('location_of_sale')
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()
