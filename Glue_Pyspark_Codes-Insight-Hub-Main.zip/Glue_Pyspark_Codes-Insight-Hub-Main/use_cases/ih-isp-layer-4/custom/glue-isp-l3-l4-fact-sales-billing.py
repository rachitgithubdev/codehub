# ================================Revision History============================================
# #
#  Change Version,  Change Author   , Change Date , Change Component, Change Description
#  0.1              Bakul Seth                      Initial version
#  0.2              Tingting Wan                    added GR hist &CAE union - l31_isp_ext_cus_mena
#  0.3              Tingting Wan     24-May-2021     Change Logs - added CAE union - l31_isp_tput_recs_trx
# ============================================================================================
# Description :- The aim of the code is to generate glue-isp-l3-l4-fact-sales-billing into conform zone
# Author :-  Bakul Seth
# Date :- 16-Dec-2020
# Version :-  0.1
# AWS component used :- S3 and Glue
# ===========================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql import DataFrame
from awsglue.job import Job
from functools import reduce


class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'country_database',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.confirm_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l3_isp_iop_head_all', 'l3_isp_iop_line_all', 'l3_isp_inv_sales_all',
                                 'l3_isp_currency_all', 'l3_isp_conf_stk_mvt_all', 'l3_isp_fuel_point_all',
                                 'l3_isp_inv_sales_line_all', 'l3_isp_fuel_point_all', 'l3_isp_port_all',
                                 'l3_isp_plant_map_all', 'l3_isp_exchange_rate_all',
                                 'l4_isp_fact_sales_billing_gr_hist', 'l3_isp_ext_cus_mena',
                                 'l3_isp_tput_recs_trx']
        self.report_file = "l4_isp_fact_sales_billing"

        # generic variables  ===========================================
        self.country_database = args['country_database']

        # Create country and its source_system
        country_list = ['gr', 'me']
        self.country_database_map = dict(map(lambda x: x.split('='), self.country_database.split(',')))
        self.source_system_list = ['ISP_' + (self.country_database_map[country]).upper() for country in country_list]

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_table_A = self._get_table(self.confirm_database, self.input_table_list[0]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[0],
        #                                               df_table_A.count()))
        df_table_B = self._get_table(self.confirm_database, self.input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[1],
        #                                               df_table_B.count()))
        df_table_C = self._get_table(self.confirm_database, self.input_table_list[2]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[2],
        #                                               df_table_C.count()))
        df_table_D = self._get_table(self.confirm_database, self.input_table_list[3]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[3],
        #                                               df_table_D.count()))
        df_table_E = self._get_table(self.confirm_database, self.input_table_list[4]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[4],
        #                                               df_table_E.count()))
        df_table_F = self._get_table(self.confirm_database, self.input_table_list[5]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[5],
        #                                               df_table_F.count()))
        df_table_G = self._get_table(self.confirm_database, self.input_table_list[6]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[6],
        #                                               df_table_G.count()))
        df_table_H = self._get_table(self.confirm_database, self.input_table_list[7]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[7],
        #                                               df_table_H.count()))
        df_table_I = self._get_table(self.confirm_database, self.input_table_list[8]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[8],
        #                                               df_table_I.count()))
        df_table_J = self._get_table(self.confirm_database, self.input_table_list[9]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[9],
        #                                               df_table_J.count()))
        df_table_K = self._get_table(self.confirm_database, self.input_table_list[10]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[10],
        #                                               df_table_J.count()))
        df_table_union1 = self._get_table(self.confirm_database, self.input_table_list[11]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[11],
        #                                               df_table_union1.count()))
        df_table_union2 = self._get_table(self.confirm_database, self.input_table_list[12]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[12],
        #                                               df_table_union2.count()))
        df_table_union3 = self._get_table(self.confirm_database, self.input_table_list[13]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[13],
        #                                               df_table_union3.count()))

        # apply transformation on the dataframe argument passed(dataframe)
        df_tfx_table = self._apply_tfx(self.source_system_list, df_table_A, df_table_B,
                                       df_table_C, df_table_D,
                                       df_table_E, df_table_F,
                                       df_table_G, df_table_H,
                                       df_table_I, df_table_J, df_table_K,
                                       df_table_union1, df_table_union2, df_table_union3)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(source_system_list, *args):
        # create source_system and fk_port_id
        source_system = source_system_list[0]
        fk_port_id = source_system_list[1] + '_7200022122090'

        # assign tables and cache some multiple calling tables
        df_input_table_a = args[0]
        df_input_table_b = args[1].cache()
        df_input_table_c = args[2]
        df_input_table_d = args[3]
        df_input_table_e = args[4]
        df_input_table_f = args[5]
        df_input_table_g = args[6]
        df_input_table_h = args[7]
        df_input_table_i = args[8]
        df_input_table_j = args[9]
        df_input_table_k = args[10]
        df_input_table_union1 = args[11]
        df_input_table_union2 = args[12]
        df_input_table_union3 = args[13]

        ## pre transformation
        # create sum_table and disc_net_value
        sum_table = df_input_table_b.filter(
            (df_input_table_b.art_type_id.isNotNull()) |
            (f.concat(df_input_table_b.source_system, df_input_table_b.iop_line_type_id) == f.lit('ISP_ESP01662'))) \
            .groupBy(df_input_table_b.ref_inv_id) \
            .agg(f.sum(f.coalesce(df_input_table_b.invg_val, f.lit(0))).alias('sum_invg_val'))

        disc_net_value = df_input_table_b.filter(
            (df_input_table_b.art_type_id.isNotNull()) |
            (f.concat(df_input_table_b.source_system, df_input_table_b.iop_line_type_id) == f.lit('ISP_ESP01662'))) \
            .groupBy(df_input_table_b.ref_inv_id, df_input_table_b.item_num) \
            .agg(f.sum(f.coalesce(df_input_table_b.invg_val, f.lit(0))).alias('sum_net_value'))

        # print('disc_net_value', disc_net_value.count())
        # generate min(inv_date) in GR hist
        min_inv_date = df_input_table_a.filter(df_input_table_a.source_system == f.lit(source_system)).agg({"inv_date": "min"}).collect()[0][0]
        print(min_inv_date)

        # applying transformation
        df_input_table1 = df_input_table_a.alias('A').join(df_input_table_b.alias('B'), f.col('A.ref_inv_id') ==
                                                           f.col('B.ref_inv_id'), 'left') \
            .join(sum_table.alias('sum_df'), f.col('A.ref_inv_id') == f.col('sum_df.ref_inv_id'), 'left') \
            .join(disc_net_value.alias('disc_net'), f.concat(f.col('B.ref_inv_id'), f.col('B.item_num')) ==
                  f.concat(f.col('disc_net.ref_inv_id'), f.col('disc_net.item_num')), 'left') \
            .join(df_input_table_c.alias('C'), f.col('A.ref_inv_id') == f.col('C.ref_id'), 'left') \
            .join(df_input_table_d.alias('D'), f.col('C.fk_curcy_id_locl') == f.col('D.ref_id'), 'left') \
            .join(df_input_table_e.alias('E'), f.col('B.fk_stk_mvt_id') == f.col('E.ref_id'), 'left') \
            .join(df_input_table_f.alias('F'), f.col('E.fk_fuel_point_id') == f.col('F.ref_id'), 'left') \
            .join(df_input_table_g.alias('G'), (f.col('B.ref_inv_id') == f.col('G.fk_inv_sales_id')) &
                  (f.col('B.inv_seq_num') == f.col('G.seq_num')), 'left') \
            .join(df_input_table_h.alias('H'), f.col('G.fk_fuel_point_id') == f.col('H.ref_id'), 'left') \
            .join(df_input_table_i.alias('I'), f.col('H.fk_port_id') == f.col('I.ref_id'), 'left') \
            .join(df_input_table_j.alias('J'),
                  ((f.when(f.col('E.fk_cust_acct_id').isNotNull(), f.col('E.fk_cust_acct_id'))
                    .otherwise(f.col('A.fk_cust_acct_id'))) == f.col('J.cus_id'))
                  & (f.col('B.fk_mtl_art_id') == f.col('J.material_number')), 'left') \
            .join(df_input_table_k.alias('K'),
                  (f.col('C.exch_rate_type_id') == f.col('K.exch_rate_type_id'))
                  & (f.col('C.curcy_id') == f.col('K.curcy_id_from'))
                  & (f.col('C.curcy_id_locl') == f.col('K.curcy_id_to'))
                  & (f.col('C.source_system') == f.col('K.source_system'))
                  & (f.when(f.trim(f.col('A.bp_cmpy_id')) == '97010000000013', f.col('B.dlvd_date_time'))
                     .otherwise(f.col('A.curcy_exch_date'))).between(f.col('K.start_date'), f.col('K.end_date')),
                  'left') \
            .filter((f.col('B.art_type_id').isNotNull()) &
                    ((f.col('B.source_system') == f.lit(source_system)) & (
                            f.col('A.inv_date') >= f.coalesce(f.lit(min_inv_date), f.current_date())) |
                     (f.col('B.source_system') != f.lit(source_system)))) \
            .select(
            f.col('B.source_system'), f.col('C.iop_num_prefixed').alias('billing_document'),
            f.concat(f.col('B.ref_inv_id'), f.lit('_'), f.col('B.item_num'), f.lit('_'),
                     f.col('B.item_seq_num')).alias('ref_id'), f.lit(' ').alias('billing_type'),
            f.lit(' ').alias('billing_category'), f.lit(' ').alias('sales_doc_category'),
            f.col('A.curcy_code').alias('document_currency'),
            f.col('B.work_grp_id').alias('sales_organisation'),
            f.lit(' ').alias('distribution_channel'), f.lit(' ').alias('pricing_procedure'),
            f.lit(' ').alias('doc_condition_no'), f.lit(' ').alias('fk_doc_condition_no'),
            f.lit(' ').alias('shipping_condition'), f.col('A.inv_date').alias('billing_date'),
            f.lit(' ').alias('posting_status'), f.col('A.exch_rate').alias('exchange_rate_accntg'),
            f.when(f.col('C.curcy_id') == f.col('C.curcy_id_locl'), f.lit(1).cast('double'))
                .otherwise(f.col('K.exch_rate')).alias('ile_exchange_rate'),
            f.col('A.fk_paymt_term_id').alias('terms_of_payment'),
            f.col('A.bp_cmpy_id').alias('company_code'),
            f.col('sum_df.sum_invg_val').alias('total_net_value'), f.col('A.crt_date_time').alias('header_time'),
            f.col('A.crt_date_time').alias('header_created_on'), f.lit(' ').alias('statistics_currency'),
            f.col('A.curcy_exch_type').alias('exchange_rate_type'), f.lit(' ').alias('division'),
            f.col('D.mnmc').alias('local_currency'), f.lit(0).cast('double').alias('cred_data_exch_rate'),
            f.lit(' ').alias('logical_system'), f.lit(None).cast('date').alias('translation_date'),
            f.col('B.item_num').alias('billing_item'),
            f.when(f.col('B.art_type_id').isin(1, 3),
                   f.when(((f.col('B.qty') > 0) & (f.col('B.invg_val_disp_exc_vat') < 0)),
                          f.col('B.qty') * (-1))
                   .when(((f.col('B.qty') < 0) & (f.col('B.invg_val_disp_exc_vat') > 0)),
                         f.col('B.qty') * (-1))
                   .otherwise(f.col('B.qty'))).otherwise(0).alias('billed_quantity'),
            f.col('B.uom_mnmc').alias('sales_unit'), f.col('B.base_uom_mnmc').alias('base_unit_of_measure'),
            f.when(f.col('B.art_type_id').isin(1, 3),
                   f.when(((f.col('B.base_qty') > 0) & (f.col('B.invg_val_disp_exc_vat') < 0)),
                          f.col('B.base_qty') * (-1))
                   .when(((f.col('B.base_qty') < 0) & (f.col('B.invg_val_disp_exc_vat') > 0)),
                         f.col('B.base_qty') * (-1))
                   .otherwise(f.col('B.base_qty'))).otherwise(0).alias('billing_qty_in_sku'),
            f.when(f.col('B.art_type_id').isin(1, 3),
                   f.when(((f.col('B.qty') > 0) & (f.col('B.invg_val_disp_exc_vat') < 0)),
                          f.col('B.qty') * (-1))
                   .when(((f.col('B.qty') < 0) & (f.col('B.invg_val_disp_exc_vat') > 0)),
                         f.col('B.qty') * (-1))
                   .otherwise(f.col('B.qty'))).otherwise(0).alias('required_quantity'),
            f.when(f.col('B.art_type_id').isin(1, 3),
                   f.when(((f.col('B.dlvd_qty_wt') > 0) & (f.col('B.invg_val_disp_exc_vat') < 0)),
                          f.col('B.dlvd_qty_wt') * (-1))
                   .when(((f.col('B.dlvd_qty_wt') < 0) & (f.col('B.invg_val_disp_exc_vat') > 0)),
                         f.col('B.dlvd_qty_wt') * (-1))
                   .otherwise(f.col('B.dlvd_qty_wt'))).otherwise(0).alias('net_weight'),
            f.when(f.col('B.art_type_id').isin(1, 3),
                   f.when(((f.col('B.dlvd_qty_wt') > 0) & (f.col('B.invg_val_disp_exc_vat') < 0)),
                          f.col('B.dlvd_qty_wt') * (-1))
                   .when(((f.col('B.dlvd_qty_wt') < 0) & (f.col('B.invg_val_disp_exc_vat') > 0)),
                         f.col('B.dlvd_qty_wt') * (-1))
                   .otherwise(f.col('B.dlvd_qty_wt'))).otherwise(0).alias('gross_weight'),
            f.lit('KG').alias('weight_unit'),
            f.when(f.col('B.art_type_id').isin(1, 3),
                   f.when(((f.col('B.dlvd_qty_vol') > 0) & (f.col('B.invg_val_disp_exc_vat') < 0)),
                          f.col('B.dlvd_qty_vol') * (-1))
                   .when(((f.col('B.dlvd_qty_vol') < 0) & (f.col('B.invg_val_disp_exc_vat') > 0)),
                         f.col('B.dlvd_qty_vol') * (-1))
                   .otherwise(f.col('B.dlvd_qty_vol'))).otherwise(0).alias('volume'),
            f.lit('LT').alias('volume_unit'),
            f.when(f.col('B.art_type_id').isin(1, 3),
                   f.when(((f.col('E.loc_std_vol') > 0) & (f.col('B.invg_val_disp_exc_vat') < 0)),
                          f.col('E.loc_std_vol') * (-1))
                   .when(((f.col('E.loc_std_vol') < 0) & (f.col('B.invg_val_disp_exc_vat') > 0)),
                         f.col('E.loc_std_vol') * (-1))
                   .otherwise(f.col('E.loc_std_vol'))).otherwise(0).alias('std_volume'),
            f.col('A.inv_date').alias('pricing_date'), f.col('A.exch_rate').alias('exchange_rate'),
            f.coalesce(f.col('disc_net.sum_net_value'), f.lit(0)).alias('net_value'),
            f.col('B.dlvy_num').alias('reference_document'),
            f.lit(' ').alias('reference_item'), f.lit(' ').alias('preceding_doc_categ'),
            f.col('B.ord_ref').substr(f.instr(f.col('B.ord_ref'), '/') + f.lit(1),
                                      f.lit(7)).alias('sales_document'),
            f.lit(' ').alias('sales_document_item'), f.col('B.mtl_art_id').alias('material_number'),
            f.col('B.item_mnmc').alias('material_mnmc'),
            f.col('B.item_descn').alias('material_description'),
            f.col('B.art_type_id').alias('item_category'),
            f.col('E.fk_fuel_point_id').alias('shipping_point_receiving_pt'),
            f.when(f.col('E.fk_port_id').isNotNull(), f.col('E.fk_port_id'))
                .when(f.col('C.fk_port_id').isNotNull(), f.col('C.fk_port_id'))
                .when(f.col('F.fk_port_id').isNotNull(), f.col('F.fk_port_id'))
                .when(f.col('H.fk_port_id').isNotNull(), f.col('H.fk_port_id'))
                .otherwise(f.col('B.fk_loc_of_mvt_id')).alias('plant'),
            f.when(f.trim(f.upper(f.col('E.fk_port_id'))) == f.lit(fk_port_id), f.lit('IQ'))
                .when(f.trim(f.upper(f.col('C.fk_port_id'))) == f.lit(fk_port_id), f.lit('IQ'))
                .when(f.trim(f.upper(f.col('F.fk_port_id'))) == f.lit(fk_port_id), f.lit('IQ'))
                .when(f.trim(f.upper(f.col('H.fk_port_id'))) == f.lit(fk_port_id), f.lit('IQ'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000057'), f.lit('ZA'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000072'), f.lit('BH'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000142'), f.lit('GR'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000234'), f.lit('TR'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000321'), f.lit('LB'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000324'), f.lit('GB'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000396'), f.lit('AE'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000411'), f.lit('OM'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000422'), f.lit('MZ'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000564'), f.lit('AL'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000565'), f.lit('EG'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000572'), f.lit('RO'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000586'), f.lit('CN'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000587'), f.lit('HR'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000589'), f.lit('EE'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000590'), f.lit('FI'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000593'), f.lit('IN'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000594'), f.lit('IL'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000599'), f.lit('LB'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000610'), f.lit('RU'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000612'), f.lit('SA'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000615'), f.lit('SI'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000620'), f.lit('UA'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000622'), f.lit('IE'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000681'), f.lit('IT'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000683'), f.lit('TZ'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000694'), f.lit('CL'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000703'), f.lit('CY'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000882'), f.lit('HU'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000895'), f.lit('TN'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000905'), f.lit('IQ'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('10000000908'), f.lit('HR'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('97010000000001'), f.lit('CH'))
                .when(f.trim(f.col('A.bp_cmpy_id')) == f.lit('97010000000013'), f.lit('FR'))
                .otherwise('').alias('country'),
            f.lit(' ').alias('sales_office'), f.col('B.crt_date_time').alias('line_created_on'),
            f.col('B.crt_date_time').alias('line_time'), f.lit(0).cast('double').alias('exchange_rate_stats'),
            f.lit(' ').alias('profit_centre'), f.lit(' ').alias('price_group_order'),
            f.lit(' ').alias('price_list_ord'),
            f.lit(' ').alias('order_reason'), f.lit(' ').alias('extern_bol_no'), f.lit(' ').alias('contract_nr'),
            f.lit(0).cast('double').alias('ref_contractitm'), f.lit(' ').alias('pricing_time'),
            f.lit(' ').alias('inv_cycle_ind'), f.lit(' ').alias('standard_supply_loc'),
            f.lit(' ').alias('standard_refinery'), f.lit(' ').alias('vessel_name'), f.lit(' ').alias('term_type'),
            f.col('B.flight_number').alias('flight_number'),
            f.col('B.aircraft_type_name').alias('aircraft_type_code'),
            f.col('B.acrft_reg_number').alias('aircraft_registration'), f.lit(' ').alias('contr_doc_type'),
            f.when(f.col('E.fk_port_id').isNotNull(), f.col('E.fk_port_id'))
                .when(f.col('C.fk_port_id').isNotNull(), f.col('C.fk_port_id'))
                .when(f.col('F.fk_port_id').isNotNull(), f.col('F.fk_port_id'))
                .when(f.col('H.fk_port_id').isNotNull(), f.col('H.fk_port_id'))
                .otherwise(f.col('B.fk_loc_of_mvt_id')).alias('original_plant'),
            f.lit(' ').alias('shp_type_stage'), f.lit(' ').alias('billing_unit'), f.lit(' ').alias('pc_type'),
            f.lit(' ').alias('ssr_pc_category'), f.lit(' ').alias('channel_of_trade'), f.lit(' ').alias('cons_assgn'),
            f.lit(' ').alias('district'), f.lit(' ').alias('met_event_type'),
            f.col('A.exch_rate').alias('average_exch_rate'),
            f.col('A.exch_rate').alias('d_1_exchange_rate'),
            f.col('A.exch_rate').alias('c_exchange_rate'),
            f.when(f.col('B.art_type_id').isin(1, 3),
                   f.when(((f.col('B.dlvd_qty_wt') > 0) & (f.col('B.invg_val_disp_exc_vat') < 0)),
                          f.col('B.dlvd_qty_wt') / 1000 * (-1))
                   .when(((f.col('B.dlvd_qty_wt') < 0) & (f.col('B.invg_val_disp_exc_vat') > 0)),
                         f.col('B.dlvd_qty_wt') / 1000 * (-1))
                   .otherwise(f.col('B.dlvd_qty_wt') / 1000)).otherwise(0).alias('metric_tons'),
            f.when(f.col('B.art_type_id').isin(1, 3),
                   f.when(((f.col('B.dlvd_qty_vol') > 0) & (f.col('B.invg_val_disp_exc_vat') < 0)),
                          f.col('B.dlvd_qty_vol') * (-1))
                   .when(((f.col('B.dlvd_qty_vol') < 0) & (f.col('B.invg_val_disp_exc_vat') > 0)),
                         f.col('B.dlvd_qty_vol') * (-1))
                   .otherwise(f.col('B.dlvd_qty_vol'))).otherwise(0).alias('litres'),
            f.when(f.col('B.art_type_id').isin(1, 3),
                   f.when(((f.col('B.dlvd_qty_vol') > 0) & (f.col('B.invg_val_disp_exc_vat') < 0)),
                          f.col('B.dlvd_qty_vol') * 0.264172 * (-1))
                   .when(((f.col('B.dlvd_qty_vol') < 0) & (f.col('B.invg_val_disp_exc_vat') > 0)),
                         f.col('B.dlvd_qty_vol') * 0.264172 * (-1))
                   .otherwise(f.col('B.dlvd_qty_vol') * 0.264172)).otherwise(0).alias('ugl'),
            f.when(f.col('B.art_type_id').isin(1, 3),
                   f.when(((f.col('B.dlvd_qty_vol') > 0) & (f.col('B.invg_val_disp_exc_vat') < 0)),
                          f.col('B.dlvd_qty_vol') * 0.001 * (-1))
                   .when(((f.col('B.dlvd_qty_vol') < 0) & (f.col('B.invg_val_disp_exc_vat') > 0)),
                         f.col('B.dlvd_qty_vol') * 0.001 * (-1))
                   .otherwise(f.col('B.dlvd_qty_vol') * 0.001)).otherwise(0).alias('m3'),
            f.when(f.col('E.fk_cust_acct_id').isNotNull(), f.col('E.fk_cust_acct_id'))
                .otherwise(f.col('A.fk_cust_acct_id')).alias('shipto_party'),
            f.col('A.fk_inv_pt_id').alias('billto_party'),
            f.when(f.col('E.fk_cab_id').isNotNull(), f.col('E.fk_cab_id'))
                .otherwise(f.col('A.fk_cab_id')).alias('soldto_party'),
            f.col('A.fk_acct_pt_id').alias('payer'), f.lit(' ').alias('destination_airport'),
            f.lit(' ').alias('final_destination_partner'), f.lit(' ').alias('parent_partner'),
            f.lit(' ').alias('vendor'),
            f.lit(' ').alias('sales_rep'), f.lit(' ').alias('agent_id'),
            f.col('B.dlvd_date_time').cast('date').alias('delivery_date'),
            f.col('B.fuel_point_name').alias('fuel_point_name'),
            f.col('B.fk_loc_of_mvt_id').alias('location_id'),
            f.col('B.los_mnmc').alias('location_of_sale'))

        # print('df_input_table1', df_input_table1.count())



        # generate L4 FSB gr hist table
        df_input_table2 = df_input_table_union1.filter(f.col('billing_date') < f.coalesce(f.lit(min_inv_date), f.current_date())) \
            .select(
            f.col('source_system'), f.col('billing_document'), f.col('ref_id'),
            f.col('billing_type'), f.col('billing_category'),
            f.col('sales_doc_category'),
            f.col('document_currency'), f.col('sales_organisation'),
            f.col('distribution_channel'), f.col('pricing_procedure'),
            f.col('doc_condition_no'), f.col('fk_doc_condition_no'),
            f.col('shipping_condition'), f.col('billing_date'),
            f.col('posting_status'),
            f.col('exchange_rate_accntg'),
            f.col('ile_exchange_rate'),
            f.col('terms_of_payment'),
            f.col('company_code'),
            f.coalesce(f.col('total_net_value'), f.lit(0)).alias('total_net_value'),
            f.col('header_time'),
            f.col('header_created_on'),
            f.col('statistics_currency'), f.col('exchange_rate_type'),
            f.col('division'),
            f.col('local_currency'),
            f.col('cred_data_exch_rate').cast('double').alias('cred_data_exch_rate'),
            f.col('logical_system'),
            f.col('translation_date').cast('date').alias('translation_date'),
            f.col('billing_item'), f.col('billed_quantity'), f.col('sales_unit'),
            f.col('base_unit_of_measure'), f.col('billing_qty_in_sku'),
            f.col('required_quantity'), f.col('net_weight'),
            f.col('gross_weight'), f.col('weight_unit'),
            f.col('volume'), f.col('volume_unit'),
            f.col('std_volume').cast('double').alias('std_volume'),
            f.col('pricing_date'), f.col('exchange_rate'),
            f.coalesce(f.col('net_value'), f.lit(0)).alias('net_value'),
            f.col('reference_document'), f.col('reference_item'),
            f.col('preceding_doc_categ'), f.col('sales_document'),
            f.col('sales_document_item'), f.col('material_number'),
            f.col('material_mnmc'),
            f.col('material_description'), f.col('item_category'),
            f.col('shipping_point_receiving_pt'), f.col('plant'),
            f.col('country'),
            f.col('sales_office'), f.col('line_created_on'), f.col('line_time'),
            f.col('exchange_rate_stats').cast('double').alias('exchange_rate_stats'),
            f.col('profit_centre'), f.col('price_group_order'),
            f.col('price_list_ord'),
            f.col('order_reason'), f.col('extern_bol_no'), f.col('contract_nr'),
            f.col('ref_contractitm').cast('double').alias('ref_contractitm'),
            f.col('pricing_time'),
            f.col('inv_cycle_ind'), f.col('standard_supply_loc'),
            f.col('standard_refinery'), f.col('vessel_name'), f.col('term_type'),
            f.col('flight_number'), f.col('aircraft_type_code'),
            f.col('aircraft_registration'), f.col('contr_doc_type'),
            f.col('original_plant'), f.col('shp_type_stage'),
            f.col('billing_unit'),
            f.col('pc_type'), f.col('ssr_pc_category'),
            f.col('channel_of_trade'),
            f.col('cons_assgn'), f.col('district'), f.col('met_event_type'),
            f.col('average_exch_rate'), f.col('d_1_exchange_rate'),
            f.col('c_exchange_rate'), f.col('metric_tons'), f.col('litres'),
            f.col('ugl'), f.col('m3'), f.col('shipto_party'),
            f.col('billto_party'), f.col('soldto_party'), f.col('payer'),
            f.col('destination_airport'), f.col('final_destination_partner'),
            f.col('parent_partner'), f.col('vendor'), f.col('sales_rep'),
            f.col('agent_id'), f.col('delivery_date'), f.col('fuel_point_name'),
            f.col('location_id'), f.col('location_of_sale'))

        # generate l3_isp_ext_cus_mena -- CAE usecase
        df_input_table3 = df_input_table_union2.select(
            f.col('source_system'), f.col('billing_document'), f.col('ref_id'),
            f.lit(' ').alias('billing_type'), f.lit(' ').alias('billing_category'),
            f.lit(' ').alias('sales_doc_category'),
            f.col('currency').alias('document_currency'),
            f.col('work_grp_id').alias('sales_organisation'),
            f.lit(' ').alias('distribution_channel'), f.lit(' ').alias('pricing_procedure'),
            f.lit(' ').alias('doc_condition_no'), f.lit(' ').alias('fk_doc_condition_no'),
            f.lit(' ').alias('shipping_condition'), f.col('delivery_date').alias('billing_date'),
            f.lit(' ').alias('posting_status'),
            f.lit(1).cast('double').alias('exchange_rate_accntg'),
            f.lit(1).cast('double').alias('ile_exchange_rate'),
            f.lit(' ').alias('terms_of_payment'),
            f.col('company_code'),
            f.col('usd_value').alias('total_net_value'),
            f.unix_timestamp().cast('timestamp').alias('header_time'),
            f.unix_timestamp().cast('timestamp').alias('header_created_on'),
            f.lit(' ').alias('statistics_currency'), f.lit(' ').alias('exchange_rate_type'),
            f.lit(' ').alias('division'),
            f.col('currency').alias('local_currency'),
            f.lit(0).cast('double').alias('cred_data_exch_rate'),
            f.lit(' ').alias('logical_system'),
            f.lit(None).cast('date').alias('translation_date'),
            f.lit('1').alias('billing_item'), f.col('ugl').alias('billed_quantity'),
            f.lit('GL').alias('sales_unit'),
            f.lit('LT').alias('base_unit_of_measure'), f.col('litres').alias('billing_qty_in_sku'),
            f.col('ugl').alias('required_quantity'), f.col('kg').alias('net_weight'),
            f.col('kg').alias('gross_weight'), f.lit('KG').alias('weight_unit'),
            f.col('litres').alias('volume'), f.lit('LT').alias('volume_unit'),
            f.lit(0).cast('double').alias('std_volume'),
            f.col('delivery_date').alias('pricing_date'), f.lit(1).cast('double').alias('exchange_rate'),
            f.col('usd_value').alias('net_value'),
            f.col('reference_document'), f.lit(' ').alias('reference_item'),
            f.lit(' ').alias('preceding_doc_categ'), f.col('sales_document'),
            f.lit(' ').alias('sales_document_item'), f.col('material_number'),
            f.col('material_mnmc'),
            f.col('material_description'), f.col('item_category'),
            f.lit(None).alias('shipping_point_receiving_pt'), f.col('plant'),
            f.col('country'),
            f.lit(' ').alias('sales_office'), f.unix_timestamp().cast('timestamp').alias('line_created_on'),
            f.unix_timestamp().cast('timestamp').alias('line_time'),
            f.lit(0).cast('double').alias('exchange_rate_stats'),
            f.lit(' ').alias('profit_centre'), f.lit(' ').alias('price_group_order'),
            f.lit(' ').alias('price_list_ord'),
            f.lit(' ').alias('order_reason'), f.lit(' ').alias('extern_bol_no'), f.lit(' ').alias('contract_nr'),
            f.lit(0).cast('double').alias('ref_contractitm'),
            f.lit(' ').alias('pricing_time'),
            f.lit(' ').alias('inv_cycle_ind'), f.lit(' ').alias('standard_supply_loc'),
            f.lit(' ').alias('standard_refinery'), f.lit(' ').alias('vessel_name'), f.lit(' ').alias('term_type'),
            f.lit(None).alias('flight_number'), f.lit(None).alias('aircraft_type_code'),
            f.lit(None).alias('aircraft_registration'), f.lit(' ').alias('contr_doc_type'),
            f.col('plant').alias('original_plant'), f.lit(' ').alias('shp_type_stage'),
            f.lit(' ').alias('billing_unit'),
            f.lit(' ').alias('pc_type'), f.lit(' ').alias('ssr_pc_category'), f.lit(' ').alias('channel_of_trade'),
            f.lit(' ').alias('cons_assgn'), f.lit(' ').alias('district'), f.lit(' ').alias('met_event_type'),
            f.lit(1).cast('double').alias('average_exch_rate'), f.lit(1).cast('double').alias('d_1_exchange_rate'),
            f.lit(1).cast('double').alias('c_exchange_rate'), (f.col('kg') / 1000).alias('metric_tons'),
            f.col('litres'),
            f.col('ugl'), (f.col('litres') / 1000).alias('m3'),
            f.col('shipto_party'),
            f.col('billto_party'), f.col('soldto_party'), f.col('payer'),
            f.lit(' ').alias('destination_airport'), f.lit(' ').alias('final_destination_partner'),
            f.lit(' ').alias('parent_partner'), f.lit(' ').alias('vendor'), f.lit(' ').alias('sales_rep'),
            f.lit(' ').alias('agent_id'), f.col('delivery_date'), f.lit(' ').alias('fuel_point_name'),
            f.lit(None).alias('location_id'), f.lit(' ').alias('location_of_sale')
        )
        # print('df_input_table3', df_input_table3.count())

        # generate l3_isp_tput_recs_trx -- CAE usecase
        df_input_table4 = df_input_table_union3.select(
            f.col('source_system'), f.col('billing_document'), f.col('ref_id'),
            f.lit(' ').alias('billing_type'), f.lit(' ').alias('billing_category'),
            f.lit(' ').alias('sales_doc_category'),
            f.col('currency').alias('document_currency'),
            f.col('work_grp_id').alias('sales_organisation'),
            f.lit(' ').alias('distribution_channel'), f.lit(' ').alias('pricing_procedure'),
            f.lit(' ').alias('doc_condition_no'), f.lit(' ').alias('fk_doc_condition_no'),
            f.lit(' ').alias('shipping_condition'), f.col('delivery_date').alias('billing_date'),
            f.lit(' ').alias('posting_status'),
            f.lit(1).cast('double').alias('exchange_rate_accntg'),
            f.lit(1).cast('double').alias('ile_exchange_rate'),
            f.lit(' ').alias('terms_of_payment'),
            f.col('company_code'),
            f.col('usd_value').alias('total_net_value'),
            f.unix_timestamp().cast('timestamp').alias('header_time'),
            f.unix_timestamp().cast('timestamp').alias('header_created_on'),
            f.lit(' ').alias('statistics_currency'), f.lit(' ').alias('exchange_rate_type'),
            f.lit(' ').alias('division'),
            f.col('currency').alias('local_currency'),
            f.lit(0).cast('double').alias('cred_data_exch_rate'),
            f.lit(' ').alias('logical_system'),
            f.lit(None).cast('date').alias('translation_date'),
            f.lit('1').alias('billing_item'), f.col('ugl').alias('billed_quantity'),
            f.lit('LT').alias('sales_unit'),
            f.lit('LT').alias('base_unit_of_measure'), f.col('litres').alias('billing_qty_in_sku'),
            f.col('ugl').alias('required_quantity'), f.col('kg').alias('net_weight'),
            f.col('kg').alias('gross_weight'), f.lit('KG').alias('weight_unit'),
            f.col('litres').alias('volume'), f.lit('LT').alias('volume_unit'),
            f.lit(0).cast('double').alias('std_volume'),
            f.col('delivery_date').alias('pricing_date'), f.lit(1).cast('double').alias('exchange_rate'),
            f.col('usd_value').alias('net_value'),
            f.col('reference_document'), f.lit(' ').alias('reference_item'),
            f.lit(' ').alias('preceding_doc_categ'), f.col('sales_document'),
            f.lit(' ').alias('sales_document_item'), f.col('material_number'),
            f.col('material_mnmc'),
            f.col('material_description'), f.col('item_category'),
            f.lit(None).alias('shipping_point_receiving_pt'), f.col('plant'),
            f.col('country'),
            f.lit(' ').alias('sales_office'), f.unix_timestamp().cast('timestamp').alias('line_created_on'),
            f.unix_timestamp().cast('timestamp').alias('line_time'),
            f.lit(0).cast('double').alias('exchange_rate_stats'),
            f.lit(' ').alias('profit_centre'), f.lit(' ').alias('price_group_order'),
            f.lit(' ').alias('price_list_ord'),
            f.lit(' ').alias('order_reason'), f.lit(' ').alias('extern_bol_no'), f.lit(' ').alias('contract_nr'),
            f.lit(0).cast('double').alias('ref_contractitm'),
            f.lit(' ').alias('pricing_time'),
            f.lit(' ').alias('inv_cycle_ind'), f.lit(' ').alias('standard_supply_loc'),
            f.lit(' ').alias('standard_refinery'), f.lit(' ').alias('vessel_name'), f.lit(' ').alias('term_type'),
            f.lit(None).alias('flight_number'), f.lit(None).alias('aircraft_type_code'),
            f.lit(None).alias('aircraft_registration'), f.lit(' ').alias('contr_doc_type'),
            f.col('plant').alias('original_plant'), f.lit(' ').alias('shp_type_stage'),
            f.lit(' ').alias('billing_unit'),
            f.lit(' ').alias('pc_type'), f.lit(' ').alias('ssr_pc_category'), f.lit(' ').alias('channel_of_trade'),
            f.lit(' ').alias('cons_assgn'), f.lit(' ').alias('district'), f.lit(' ').alias('met_event_type'),
            f.lit(1).cast('double').alias('average_exch_rate'), f.lit(1).cast('double').alias('d_1_exchange_rate'),
            f.lit(1).cast('double').alias('c_exchange_rate'), (f.col('kg') / 1000).alias('metric_tons'),
            f.col('litres'),
            f.col('ugl'), (f.col('litres') / 1000).alias('m3'),
            f.col('shipto_party'),
            f.col('billto_party'), f.col('soldto_party'), f.col('payer'),
            f.lit(' ').alias('destination_airport'), f.lit(' ').alias('final_destination_partner'),
            f.lit(' ').alias('parent_partner'), f.lit(' ').alias('vendor'), f.lit(' ').alias('sales_rep'),
            f.lit(' ').alias('agent_id'), f.col('delivery_date'), f.lit(' ').alias('fuel_point_name'),
            f.lit(None).alias('location_id'), f.lit(' ').alias('location_of_sale')
        )
        # print('df_input_table4', df_input_table4.count())

        # union all dataframes
        df_list = [df_input_table1, df_input_table2,
                   df_input_table3, df_input_table4]

        # print('Union All the Dataframes')
        df_tfx_result = reduce(DataFrame.unionAll, df_list)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()
