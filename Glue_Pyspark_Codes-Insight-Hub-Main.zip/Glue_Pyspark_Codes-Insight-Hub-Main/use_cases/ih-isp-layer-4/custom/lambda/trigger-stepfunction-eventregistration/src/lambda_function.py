# ================================Revision History=================================================
# #
#  Change Version,  Change Author,        Change Date,    Change Component
#  0.1              Arvind Shrivastava    01-Feb-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to trigger the workflow Orchestration of ISP Layer 4 when workflow orchestration of ISP layer 3 completed
# Author        :- Arvind Shrivastava
# Date          :- 01-Feb-2021
# Version       :- 0.1
# AWS component :- SQS ,  Labda and Step Function
# ================================================================================================

import json
import boto3
import os
import uuid
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

client = boto3.client('stepfunctions')

def lambda_handler(event, context):
    transactionId=str(uuid.uuid1())
    
    # creating input for the setp function
    input = {'TransactionId':transactionId,'Type':'TRIGGER_STEP_FUNCTION'}
    logger.info('## Process Started')
    # trigger step function
    REGION = os.environ.get('AWS_REGION')
    account_id = context.invoked_function_arn.split(':')[4]
    sf_var = f'arn:aws:states:{REGION}:{account_id}:stateMachine:sdlf-aviation-ih-isp-layer-4'  
    response = client.start_execution(        
        stateMachineArn=sf_var,
        name=transactionId,
        input=json.dumps(input))
    return {
        'statusCode': 200,
        'body': json.dumps('IH-ISP layer 4 Workflow Triggered!')
    }
