# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    14-Jan-2021     Initial version
#  0.2              Tingting Wan    24-May-2021     Change Logs - added filter condition
# =================================================================================================
# Description   :- The aim of the code is to generate l4_isp_dim_customer into conform zone
# Author        :- Tingting Wan
# Date          :- 18-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window

class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.confrim_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l3_isp_cust_acct_all','l3_isp_cust_agt_broker_all','l3_isp_cust_distn_cat_all',
                                 'l3_isp_place_all','l3_isp_country_all','l3_isp_sector_all',
                                 'l3_isp_job_alloc_cust_acct_all','l3_isp_job_all']
        self.report_file = "l4_isp_dim_customer"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):

        # read data from country specific table argument passed(database, table)
        df_table_A = self._get_table(self.confrim_database, self.input_table_list[0]).toDF()
        # print("data count of table {}.{} is {}".format(self.confrim_database, self.input_table_list[0],
        #                                               df_table_A.count()))
        df_table_B = self._get_table(self.confrim_database, self.input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(self.confrim_database, self.input_table_list[1],
        #                                               df_table_B.count()))
        df_table_C = self._get_table(self.confrim_database, self.input_table_list[2]).toDF()
        # print("data count of table {}.{} is {}".format(self.confrim_database, self.input_table_list[2],
        #                                               df_table_C.count()))
        df_table_D = self._get_table(self.confrim_database, self.input_table_list[3]).toDF()
        # print("data count of table {}.{} is {}".format(self.confrim_database, self.input_table_list[3],
        #                                               df_table_D.count()))
        df_table_E = self._get_table(self.confrim_database, self.input_table_list[4]).toDF()
        # print("data count of table {}.{} is {}".format(self.confrim_database, self.input_table_list[4],
        #                                               df_table_E.count()))
        df_table_F = self._get_table(self.confrim_database, self.input_table_list[5]).toDF()
        # print("data count of table {}.{} is {}".format(self.confrim_database, self.input_table_list[5],
        #                                               df_table_F.count()))
        df_table_G = self._get_table(self.confrim_database, self.input_table_list[6]).toDF()
        # print("data count of table {}.{} is {}".format(self.confrim_database, self.input_table_list[6],
        #                                               df_table_G.count()))
        df_table_H = self._get_table(self.confrim_database, self.input_table_list[7]).toDF()
        # print("data count of table {}.{} is {}".format(self.confrim_database, self.input_table_list[7],
        #                                               df_table_H.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_A, df_table_B,
                                       df_table_C, df_table_D,
                                       df_table_E, df_table_F,
                                       df_table_G, df_table_H)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table\
            .write.option("compression", "snappy")\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):

        # convert all the columns alias to lower case
        df_input_table_A = args[0].cache()
        df_input_table_B = args[1].cache()
        df_input_table_C = args[2].cache()
        df_input_table_D = args[3].cache()
        df_input_table_E = args[4].cache()
        df_input_table_F = args[5].cache()
        df_input_table_G = args[6].cache()
        df_input_table_H = args[7].cache()

        # join inner dataframes
        df_input_table_inner = df_input_table_A.join(df_input_table_G,
                                                     df_input_table_A.ref_id == df_input_table_G.fk_cust_acct_id,
                                                     'left') \
            .join(df_input_table_B, df_input_table_A.fk_cab_id == df_input_table_B.ref_id, 'left') \
            .join(df_input_table_C, df_input_table_B.fk_cust_distn_cat_id == df_input_table_C.ref_id, 'left') \
            .join(df_input_table_D, df_input_table_B.fk_place_id == df_input_table_D.ref_id, 'left') \
            .join(df_input_table_E, df_input_table_D.fk_cntry_id == df_input_table_E.ref_id, 'left') \
            .join(df_input_table_F, df_input_table_A.fk_sector_id == df_input_table_F.ref_id, 'left') \
            .join(df_input_table_H, df_input_table_G.fk_job_id == df_input_table_H.ref_id, 'left') \
            .filter(((f.trim(df_input_table_G.job_alloc_type_id) == '1') & ((df_input_table_G.end_date >= f.current_date())
                                                                          | (df_input_table_G.end_date.isNull())))
                    | ((f.trim(df_input_table_G.job_alloc_type_id) == '1')
                       & (df_input_table_G.cust_acct_id.isin('4780000169620', '4780048795712', '4780050809465')
                          & (df_input_table_G.end_date == f.lit('2019-11-22'))))
                    | ((f.trim(df_input_table_G.job_alloc_type_id) == '1')
                       & (df_input_table_G.cust_acct_id.isin('4780000169620')
                          & (df_input_table_G.end_date == f.lit('2020-12-31'))))
                          ) \
            .select(f.lit(' ').alias('mdm_partner_id'), f.lit(' ').alias('sold_to_mdm_id'),
                    f.lit(' ').alias('bill_to_mdm_id'), f.lit(' ').alias('payer_mdm_id'),
                    f.lit(' ').alias('erp_id'), f.lit(' ').alias('ref_erp_id'),
                    df_input_table_A.id.alias('isp_id'), df_input_table_A.ref_id.alias('ref_isp_id'),
                    df_input_table_A.cab_id.alias('isp_sold_to'), df_input_table_A.fk_cab_id.alias('fk_isp_sold_to'),
                    df_input_table_A.inv_pt_id.alias('isp_bill_to'),
                    df_input_table_A.fk_inv_pt_id.alias('fk_isp_bill_to'),
                    df_input_table_A.acct_pt_id.alias('isp_payer'),
                    df_input_table_A.fk_acct_pt_id.alias('fk_isp_payer'),
                    df_input_table_A.work_grp_id.alias('isp_work_group'), df_input_table_A.fk_work_grp_id
                    .alias('fk_isp_work_group'), df_input_table_B.global_ref_num.alias('grn_header'),
                    df_input_table_A.global_acct_ref_num.alias('grn'), f.lit(' ').alias('grn_subaccount'),
                    df_input_table_C.name.alias('customer_type'), f.lit(' ').alias('customer_group'),
                    f.lit(' ').alias('subaccount_reason'), df_input_table_B.orig_system_ref.alias('duns_number'),
                    df_input_table_B.name.alias('customer_account_name'), df_input_table_D.road_name.alias('street'),
                    df_input_table_E.name.alias('customer_country'),
                    df_input_table_E.mnmc.alias('customer_country_key'),
                    f.lit(' ').alias('city'), df_input_table_D.pstcd.alias('postal_code'), f.lit(' ').alias('website'),
                    df_input_table_B.vat_regn_num.alias('vat_reg_no'),
                    df_input_table_A.work_grp_id.alias('sales_organisation'),
                    f.lit(' ').alias('division'), f.lit(' ').alias('distribution_channel'),
                    df_input_table_H.name.alias('account_manager'), f.lit(' ').alias('airline_code'),
                    f.lit(' ').alias('collection_country'),
                    f.when(df_input_table_A.id.isin('4780054656555', '4780037418616', '4780037368647'), 'supply sales')
                    .otherwise(df_input_table_F.parent_sector).alias('sector'), f.lit(' ').alias('group'),
                    f.lit(' ').alias('carrier'), df_input_table_B.end_date, f.lit(None).cast('date').alias('end_date_sap'),
                    f.row_number().over(Window.partitionBy(df_input_table_A.ref_id)
                                        .orderBy(df_input_table_G.last_updt_date_time.desc())).alias('seq')
                    )

        # outer dataframe
        df_tfx_result = df_input_table_inner.filter(df_input_table_inner.seq == 1).drop(f.col('seq'))
        # print("df_tfx_result", df_tfx_result.count())

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()

