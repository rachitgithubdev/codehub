# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    14-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l4_isp_dim_location into conform zone
# Author        :- Tingting Wan
# Date          :- 18-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================


import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') !=9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.confirm_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l3_isp_port_all','l3_isp_loc_location_all','l3_isp_country_all',
                                 'l3_isp_place_all','l3_isp_dstct_district_all']
        self.report_file = "l4_isp_dim_location"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):

        # read data from country specific table argument passed(database, table)
        df_table_A1 = self._get_table(self.confirm_database, self.input_table_list[0]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[0],
        #                                               df_table_A1.count()))
        df_table_A2 = self._get_table(self.confirm_database, self.input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[1],
        #                                               df_table_A2.count()))
        df_table_B = self._get_table(self.confirm_database, self.input_table_list[2]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[2],
        #                                               df_table_B.count()))
        df_table_C = self._get_table(self.confirm_database, self.input_table_list[3]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[3],
        #                                               df_table_C.count()))
        df_table_D = self._get_table(self.confirm_database, self.input_table_list[4]).toDF()
        # print("data count of table {}.{} is {}".format(self.confirm_database, self.input_table_list[4],
        #                                               df_table_D.count()))

        # apply transformation on the dataframe argument passed
        df_tfx_table = self._apply_tfx(df_table_A1, df_table_A2, df_table_B,
                                       df_table_C, df_table_D)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):

        # assign tables from *args
        df_input_table_A1 = args[0].cache()
        df_input_table_A2 = args[1].cache()
        df_input_table_B = args[2].cache()
        df_input_table_C = args[3].cache()
        df_input_table_D = args[4].cache()

        # join dataframes
        df_table_job1 = df_input_table_A1.join(df_input_table_C, df_input_table_A1.fk_place_id ==
                                               df_input_table_C.ref_id, 'left') \
            .join(df_input_table_D, df_input_table_C.fk_dstct_id == df_input_table_D.ref_id, 'left') \
            .join(df_input_table_B, df_input_table_C.fk_cntry_id == df_input_table_B.ref_id, 'left') \
            .select(df_input_table_A1.ref_id.alias('ref_id'), df_input_table_A1.mnmc.alias('plant'),
                    df_input_table_A1.name.alias('location_name'),
                    df_input_table_A1.work_grp_id.alias('sales_organisation'),
                    df_input_table_B.mnmc.alias('country_iso2'),
                    df_input_table_D.name.alias('performance_region_name'))

        #print("df_table_job1", df_table_job1.count())

        df_table_job2 = df_input_table_A2.join(df_input_table_C, df_input_table_A2.fk_place_id ==
                                               df_input_table_C.ref_id, 'left') \
            .join(df_input_table_D, df_input_table_C.fk_dstct_id == df_input_table_D.ref_id, 'left') \
            .join(df_input_table_B, df_input_table_C.fk_cntry_id == df_input_table_B.ref_id, 'left') \
            .select(df_input_table_A2.ref_id.alias('ref_id'), df_input_table_A2.mnmc.alias('plant'),
                    df_input_table_A2.name.alias('location_name'),
                    f.lit('DEPOT').alias('sales_organisation'),
                    df_input_table_B.mnmc.alias('country_iso2'),
                    df_input_table_D.name.alias('performance_region_name')) \
            .filter(df_input_table_A2.loc_type_id == f.lit(3))
        #print("df_table_job2", df_table_job2.count())

        # union dataframes
        df_tfx_result = df_table_job1.union(df_table_job2).distinct()

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()
