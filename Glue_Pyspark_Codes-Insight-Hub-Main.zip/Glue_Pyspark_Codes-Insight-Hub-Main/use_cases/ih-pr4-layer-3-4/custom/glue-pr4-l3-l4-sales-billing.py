# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    28-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l4_pr4_fact_sales_billing from
#                  l3_pr4_sales_billing
# Author        :- Tingting Wan
# Date          :- 28-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window


class LCPPR4ETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.conform_database = args['source_database1']
        self.source_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_tables = ['l3_pr4_sales_billing', 't001w']
        self.report_file = "l4_pr4_fact_sales_billing"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        # generate input table list
        conform_database = self.conform_database
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(conform_database, self.input_tables[0]).toDF()
        print("Schema of table {}.{} is {}".format(source_database, self.input_tables[0],
                                                   df_table_1.printSchema()))
        df_table_2 = self._get_table(source_database, self.input_tables[1]).toDF()
        print("Schema of table {}.{} is {}".format(source_database, self.input_tables[1],
                                                       df_table_2.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2)

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_table_1, df_table_2):
        # convert all the columns alias to lower case
        df_table_1 = df_table_1.select([f.col(x).alias(x.lower()) for x in df_table_1.columns])
        df_table_2 = df_table_2.select([f.col(x).alias(x.lower()) for x in df_table_2.columns])

        df_tfx_result = df_table_1.join(df_table_2, df_table_1.werks_plant == df_table_2.werks, 'left') \
            .select(
            df_table_1.month_id.alias('month_id'),
            df_table_1.ref_id.alias('ref_id'),
            df_table_1.source_system.alias('source_system'),
            df_table_2.land1.alias('country_key'),
            df_table_1.vblen_billing_doc.alias('billing_document'),
            df_table_1.line_number.alias('billing_item'),
            df_table_1.delivery_num.alias('delivery_num'),
            df_table_1.delivery_date.alias('delivery_date'),
            df_table_1.aubel_sales_document.alias('sales_document'),
            df_table_1.prsdt_pricing_date.alias('pricing_date'),
            df_table_1.fkdat_billing_date.alias('billing_date'),
            df_table_1.pu.alias('pu'),
            df_table_1.cluster.alias('cluster'),
            df_table_1.aland_country.alias('country'),
            df_table_1.airport_terminal.alias('airport_terminal'),
            df_table_1.iata_code_bo.alias('iata_code_bo'),
            df_table_1.average_of_latitude.alias('average_of_latitude'),
            df_table_1.average_of_longitude.alias('average_of_longitude'),
            df_table_1.name.alias('name'),
            df_table_1.supply_envelope.alias('supply_envelope'),
            df_table_1.supply_pricing.alias('supply_pricing'),
            df_table_1.terminal.alias('terminal'),
            df_table_1.customer_country.alias('customer_country'),
            df_table_1.global_ref_num.alias('global_ref_num'),
            df_table_1.cust_acct_name.alias('cust_acct_name'),
            df_table_1.global_acct_ref_num.alias('global_acct_ref_num'),
            df_table_1.lead_account_holder_name.alias('lead_account_holder_name'),
            df_table_1.account_holder_name.alias('account_holder_name'),
            df_table_1.sector.alias('sector'),
            df_table_1.segment.alias('segment'),
            df_table_1.local_non_nordics_ah_account_holder.alias('local_non_nordics_ah_account_holder'),
            df_table_1.vkorg_sales_org.alias('sales_organization'),
            df_table_1.werks_plant.alias('plant'),
            df_table_1.kunnr_customer_shipto.alias('ship_to_party'),
            df_table_1.party_description.alias('party_description'),
            df_table_1.matnr_material.alias('material'),
            df_table_1.matx_material_description.alias('material_description'),
            df_table_1.ib_global_cust_ref.alias('ib_global_cust_ref'),
            df_table_1.sold_to.alias('sold_to_party'),
            df_table_1.sold_to_name.alias('party_description_1'),
            df_table_1.cmwae_currency.alias('local_currency'),
            df_table_1.currency_description.alias('currency_description'),
            df_table_1.qty_m3.alias('m3'),
            df_table_1.qty_ugl.alias('ugl'),
            df_table_1.debit_credit_ind.alias('debit_credit_ind'),
            df_table_1.flightnum.alias('flightnum'),
            df_table_1.aircraftreg.alias('aircraftreg'),
            df_table_1.mot.alias('mot'),
            df_table_1.delivery_note_number.alias('delivery_note_number'),
            df_table_1.posting_date.alias('posting_date'),
            df_table_1.doccreatedate.alias('doccreatedate')
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LCPPR4ETL()
    trl.execute()