# ================================Revision History=================================================
# #
#  Change Version,  Change Author,        Change Date,    Change Component
#  0.1              Liz Harvey            27-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to l2-l3 pr4 pricing condition into conform zone
# Author        :- Liz Harvey
# Date          :- 27-Apr-2021
# Version       :- 27-Apr-2021
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from pyspark.sql.window import Window as Window
from awsglue.job import Job
from datetime import datetime as dt
import pandas as pd


class LcpPr4TETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 12:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 12")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment',
                                   'pc_hist_end_date',
                                   'pc_start_date'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = ['l2_pr4_us_pricing_condition', 'l2_pr4_us_pricing_condition_hist']
        self.report_file = "l3_pr4_pricing_condition"

        # generic variables  ===========================================
        self.pc_hist_end_date = args['pc_hist_end_date']
        self.pc_start_date = args['pc_start_date']

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))
        print('it will process {} tables'.format(self.input_table))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        startdate = '2000-01-01'
        enddate = self.pc_hist_end_date
        pc_hist_month_range = pd.date_range(startdate, enddate, freq='MS').strftime("%Y%m").tolist()

        startdate = self.pc_start_date
        pc_month_range = pd.date_range(startdate, dt.today(), freq='MS').strftime("%Y%m").tolist()

        # get source database
        input_table_pc = self.input_table[0]

        input_table_pc_hist = self.input_table[1]

        source_database = self.source_database

        # # read data from country specific table argument passed(database, table)
        df_input_table_pc1 = self._get_table(source_database, input_table_pc).toDF()
        
        df_input_table_pc = self._get_table(source_database, input_table_pc).toDF()
        print("Schema of table {}.{} is {}".format(source_database, input_table_pc, df_input_table_pc.printSchema()))

        df_input_table_pc_hist = self._get_table(source_database, input_table_pc_hist).toDF()
        print("Schema of table {}.{} is {}".format(source_database, input_table_pc_hist,
                                                       df_input_table_pc_hist.printSchema()))

        # apply transformation on the dataframe argument passed
        df_tfx_result = self._apply_tfx(df_input_table_pc, df_input_table_pc_hist, pc_hist_month_range, pc_month_range)
        print("Schema after transformation ", df_tfx_result.printSchema())

        final_result_df = df_tfx_result
        print("Final schema", final_result_df.printSchema())

        self.write_results(final_result_df)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table_pc, df_input_table_pc_hist, pc_hist_month_range, pc_month_range):
        # convert all the columns alias to lower case

        pc_hist = df_input_table_pc_hist.select([f.col(x).alias(x.lower()) for x in df_input_table_pc_hist.columns])

        pc = df_input_table_pc.select([f.col(x).alias(x.lower()) for x in df_input_table_pc.columns])

        df_tfx_result_pc_hist = pc_hist.filter(
            pc_hist.month_id.isin(pc_hist_month_range)) \
            .select(f.col("Month_Id"),
                    f.col("Ref_Id"),
                    f.col("Source_System"),
                    f.col("VBLEN_Billing_Doc"),
                    f.col("line_number"),
                    f.col("hierarchy_level_5_Code"),
                    f.col("hierarchy_level_5"),
                    f.col("hierarchy_level_4_key"),
                    f.col("hierarchy_level_3_key"),
                    f.col("hierarchy_level_2_key"),
                    f.col("hierarchy_level_1_key"),
                    f.col("wf_cond_value_gc"),
                    f.col("wf_cond_value_lc"),
                    f.col("CMWAE_Currency"),
                    f.col("Source_Extract_As_At"),
                    f.col("creation_date"),
                    f.col("source_file_name")
                    )

        print('Schema of table is df_tfx_result_pc_hist', df_tfx_result_pc_hist.printSchema())

        df_tfx_result_pc_rn = pc.filter(
            pc.month_id.isin(pc_month_range)) \
            .select(f.col('*'),
                    f.dense_rank().over(Window.partitionBy(pc.month_id).orderBy(pc.creation_date.desc())).alias('rn')
                    )

        pc_rn = df_tfx_result_pc_rn

        df_tfx_result_pc = pc_rn.filter(
            pc_rn.rn.isin(1)) \
            .select(f.col("Month_Id"),
                    f.col("Ref_Id"),
                    f.col("Source_System"),
                    f.col("VBLEN_Billing_Doc"),
                    f.col("line_number"),
                    f.col("hierarchy_level_5_Code"),
                    f.col("hierarchy_level_5"),
                    f.col("hierarchy_level_4_key"),
                    f.col("hierarchy_level_3_key"),
                    f.col("hierarchy_level_2_key"),
                    f.col("hierarchy_level_1_key"),
                    f.col("wf_cond_value_gc").cast(DoubleType()),
                    f.col("wf_cond_value_lc").cast(DoubleType()),
                    f.col("CMWAE_Currency"),
                    f.col("Source_Extract_As_At"),
                    f.col("creation_date"),
                    f.col("source_file_name")
                    )

        print('Schema of table is df_tfx_result_pc', df_tfx_result_pc.printSchema())

        df_tfx_result = df_tfx_result_pc_hist.union(df_tfx_result_pc)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPr4TETL()
    trl.execute()

