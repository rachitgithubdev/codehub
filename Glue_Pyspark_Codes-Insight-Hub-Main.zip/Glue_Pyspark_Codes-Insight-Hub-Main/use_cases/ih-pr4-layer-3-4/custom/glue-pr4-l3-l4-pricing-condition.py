# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Liz Harvey      28-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l4_pr4_fact_pricing_condition from
#                  l3_pr4_pricing_condition
# Author        :- Liz Harvey
# Date          :- 28-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql.window import Window


class LCPPr4ETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = ['l3_pr4_pricing_condition']
        self.report_file = "l4_pr4_fact_pricing_condition"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # generate input table list
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, self.input_table[0]).toDF()
        print("Schema of table {}.{} is {}".format(source_database, self.input_table[0],
                                                   df_table_1.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1)
        print("Schema after transformation ", df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_table_1):
        df_tfx_result = df_table_1.select(
            f.col("month_id").alias("month_id"),
            f.col("Ref_Id").alias("ref_id"),
            f.col("Source_System").alias("source_system"),
            f.col("VBLEN_Billing_Doc").alias("billing_document"),
            f.col("line_number").alias("billing_item"),
            f.col("hierarchy_level_5_Code").alias("condition_type"),
            f.col("hierarchy_level_5").alias("hierarchy_level_5"),
            f.col("hierarchy_level_4_key").alias("hierarchy_level_4"),
            f.col("hierarchy_level_3_key").alias("hierarchy_level_3"),
            f.col("hierarchy_level_2_key").alias("hierarchy_level_2"),
            f.col("hierarchy_level_1_key").alias("hierarchy_level_1"),
            f.col("wf_cond_value_gc").cast(DoubleType()).alias("condition_value_gc"),
            f.col("wf_cond_value_lc").cast(DoubleType()).alias("condition_value_lc"),
            f.col("CMWAE_Currency").alias("local_currency")
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LCPPr4ETL()
    trl.execute()

