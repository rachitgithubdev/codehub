# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      05-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_pre_date_currency into conform zone
# Author        :- Bakul Seth
# Date          :- 05-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from datetime import date, timedelta, datetime
from pyspark.sql.types import *


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 8:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 8')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.report_file = 'l3_pre_date_currency'

        # hardcoded values currency list
        self.curr_list = ['CUP', 'GMD', 'RUB', 'VES', 'BYN', 'BDT', 'UYU', 'MGA', 'DKK', 'CNY', 'XAF', 'ZAR', 'MNT',
                          'SLL', 'YER', 'LSL', 'ISK', 'KES', 'PEN', 'CVE', 'DZD', 'BRL', 'HTG', 'AUD', 'LAK', 'CHF',
                          'SYP', 'IRR', 'LBP', 'LKR', 'XCD', 'ETB', 'PLN', 'NOK', 'BMD', 'UGX', 'AMD', 'MXN', 'SCR',
                          'BGN', 'USD', 'RSD', 'NZD', 'TRY', 'MRU', 'HNL', 'DJF', 'SDG', 'ERN', 'AWG', 'MUR', 'LRD',
                          'HUF', 'DOP', 'ZMW', 'GIP', 'XDR', 'MZN', 'PAB', 'SGD', 'CDF', 'KGS', 'BAM', 'ANG', 'SOS',
                          'RWF', 'MAD', 'AFN', 'UAH', 'BND', 'PYG', 'BOB', 'KHR', 'TOP', 'TJS', 'XOF', 'KMF', 'AOA',
                          'MYR', 'TZS', 'MWK', 'JOD', 'BHD', 'SEK', 'IDR', 'RON', 'JPY', 'VUV', 'MKD', 'BSD', 'EUR',
                          'MDL', 'INR', 'VND', 'ARS', 'SRD', 'GTQ', 'BWP', 'MVR', 'ILS', 'HRK', 'GHS', 'NIO', 'LYD',
                          'TND', 'JMD', 'HKD', 'CAD', 'TTD', 'SVC', 'EGP', 'CLP', 'NAD', 'MOP', 'GNF', 'QAR', 'GBP',
                          'BZD', 'THB', 'CZK', 'BBD', 'PKR', 'KZT', 'GYD', 'SZL', 'SBD', 'KRW', 'MMK', 'TWD', 'UZS',
                          'PGK', 'ALL', 'OMR', 'KPW', 'AED', 'PHP', 'AZN', 'SAR', 'BIF', 'IQD', 'NPR', 'WST', 'XPF',
                          'KWD', 'COP', 'STN', 'KYD', 'FJD', 'NGN', 'CRC', 'GEL', 'BTN']
        self.curr_type = ['ECB', 'RBA', 'M', 'CBIS', 'ANZB', 'CBM']
        self.tcurr_range = ['USD', 'MXN', 'AUD', 'NZD', 'ISK', 'EUR']
        self._spark.conf.set('spark.sql.shuffle.partitions', '1')

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        # read data from country specific table argument passed(database, table)
        print('Preparing Start and end date')
        start_date = datetime.strptime('2014-01-01', '%Y-%m-%d').date()
        end_date = datetime.strptime('2028-12-31', '%Y-%m-%d').date()

        # creating list of all dates in the range
        print('creating list of all the dates from start date to end date')
        date_array = list((start_date + timedelta(days=i)).strftime('%Y-%m-%d') for i in
                          range((end_date - start_date).days + 1))

        # create dataframe from the date range
        df_date = self._spark.createDataFrame(date_array, StringType())\
            .select(f.col('value').alias('curr_date').cast('date')).cache()
        print('count of the dates in date range', df_date.count())

        # create currency type dataframe
        df_curr_type = self._spark.createDataFrame(self.curr_type, StringType()) \
            .withColumnRenamed('value', 'curr_type').cache()
        print('count of the currency type', df_curr_type.count())

        # creating currency dataframe from the passed value
        df_currency = self._spark.createDataFrame(self.curr_list, StringType()) \
            .withColumnRenamed('value', 'curr').cache()
        print('count of the different currencies', df_currency.count())

        # creating tcurr dataframe from the passed value
        df_tcurr = self._spark.createDataFrame(self.tcurr_range, StringType()) \
            .withColumnRenamed('value', 't_curr').cache()
        print('count of the different currencies', df_currency.count())

        # cross join of date and currency
        print('cross join to get the combination of date, currencies and currency type')
        date_pre = df_currency.crossJoin(df_tcurr)
        date_cure_df = df_date.crossJoin(date_pre)
        date_cure_type_df = date_cure_df.crossJoin(df_curr_type)

        print('Writing the final date and currency combination to desired location')
        date_cure_type_df.printSchema()
        self.write_results(date_cure_type_df)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
