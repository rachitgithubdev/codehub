# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      09-Mar-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to create tender benchmark-adjustment l3 table in
#                  conform zone
# Author        :- Bakul Seth
# Date          :- 09-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = 'zcas_bmca'
        self.report_file = 'l3_pre_zcas_bmca_benchmark_adj'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # read data from country specific table argument passed(database, table)
        df_bmca = self._get_table(self.source_database, self.input_table).toDF()
        #print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_bmca.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_bmca)
        #print("data count after transformation ", df_tfx_table.printSchema())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(input_table):
        # convert all the columns alias to lower case
        df_zcas_bmca = input_table.select([f.col(x).alias(x.lower()) for x in input_table.columns])

        # transformation
        df_tfx_result = df_zcas_bmca.filter((df_zcas_bmca.spart == '01') & (df_zcas_bmca.vtweg == '06'))\
            .select(df_zcas_bmca.vbeln, df_zcas_bmca.posnr, df_zcas_bmca.fkart, df_zcas_bmca.vbtyp, df_zcas_bmca.cogs,
                    df_zcas_bmca.bm_pp, df_zcas_bmca.alt_bm_pp, df_zcas_bmca.bm_pp_c, df_zcas_bmca.waers,
                    df_zcas_bmca.zzavcurr, df_zcas_bmca.exchange_rate, df_zcas_bmca.vkorg, df_zcas_bmca.vtweg,
                    df_zcas_bmca.spart, df_zcas_bmca.matnr, df_zcas_bmca.fkdat, df_zcas_bmca.datefrom,
                    df_zcas_bmca.dateto, df_zcas_bmca.yf51_avg, df_zcas_bmca.yf51_curr, df_zcas_bmca.yf51_ddate,
                    df_zcas_bmca.zex_off_rate_type)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
