# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Hasan Chaudhary 1-Mar-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-pre-l2-l3-konv.py into conform zone
# Author        :- Hasan Chaudhary
# Date          :- 1-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self._spark.conf.set('spark.sql.broadcastTimeout', '1800')
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['konv', 'vbrk']
        self.report_file = "l3_pre_konv_pricing_conditions"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
                                                                         self.destination_bucket))

    def execute(self):
        # generate input table list
        source_database = self.source_database
        input_table_list = self.input_table_list

        # read pre.vbrk table
        df_vbrk = self._gc.create_dynamic_frame.from_catalog(
            database='transform_latest_pre',
            table_name='vbrk',
            transformation_ctx='my_table'
        ) \
            .select_fields(['knumv','spart','vtweg']) \
            .toDF() \
            .filter("spart = '01' and vtweg = '06'") \
            .select("knumv")

        # read pre.konv table
        df_konv = self._gc.create_dynamic_frame.from_catalog(
            database='transform_latest_pre',
            table_name='konv',
            transformation_ctx='my_table'
        ) \
         .select_fields(['knumv','kposn','stunr','zaehk','kappl','kntyp','kschl','kawrt','kbetr','waers','kkurs','kwert','kinak']) \
         .toDF()

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_konv, df_vbrk)
        # repartition to get sensible number of target files
        df_tfx_table = df_tfx_table.repartition(20)

        self.write_results(df_tfx_table)


    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    @staticmethod
    def _apply_tfx(*args):
        # convert all the columns alias to lower case
        df_konv = args[0]
        df_vbrk = args[1]
        # transformation (this uses BROADCAST join)
        df_tfx_result = df_konv.join(f.broadcast(df_vbrk), (df_konv.knumv == df_vbrk.knumv) & (df_konv.kinak == ''), 'inner') \
            .select(df_konv.knumv, df_konv.kposn, df_konv.stunr, df_konv.zaehk, df_konv.kappl, df_konv.kntyp,
                    df_konv.kschl, df_konv.kawrt, df_konv.kbetr, df_konv.waers, df_konv.kkurs, df_konv.kwert)
        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
