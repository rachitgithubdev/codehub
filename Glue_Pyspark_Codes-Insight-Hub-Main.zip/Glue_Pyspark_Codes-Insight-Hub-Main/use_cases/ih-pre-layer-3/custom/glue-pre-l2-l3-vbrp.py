# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Hasan Chaudhary 25-Feb-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-pre-l2-l3-vbrp.py into conform zone
# Author        :- Hasan Chaudhary
# Date          :- 25-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self._spark.conf.set('spark.sql.broadcastTimeout', '1800')
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "vbrp"
        self.report_file = "l3_pre_vbrp_billing_items"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):


        # read data from country specific table argument passed(database, table)
        source_database = self.source_database
        input_table = self.input_table
        #df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        df_input_table = self._gc.create_dynamic_frame.from_catalog(
	                              database='transform_latest_pre',
			                      table_name='vbrp',
                                  transformation_ctx='my_table'
                                  )  \
                              .select_fields(['vbeln', 'posnr', 'fkimg', 'vrkme', 'meins', 'fklmg',
                                           'lmeng', 'ntgew', 'brgew', 'gewei', 'volum', 'voleh',
                                           'prsdt', 'kursk', 'netwr', 'vgbel', 'vgpos', 'vgtyp',
                                           'aubel', 'aupos', 'matnr', 'pstyv', 'vstel', 'spart',
                                           'werks', 'aland', 'vkbur', 'spara', 'erdat', 'erzet',
                                           'stcur', 'prctr', 'konda_auft', 'pltyp_auft', 'vtweg_auft',
                                           'augru_auft', 'oid_extbol', 'oicontnr', 'oic_kmpos', 'oic_time',
                                           'oiinvcyc9', 'zzsup_loc', 'zzimport_reg', 'zzvesselname',
                                           'zztermtype', 'zzflnum', 'zzairctycd', 'zztailno', 'zzcontract_type',
                                           'zzorigplant', 'vsart', 'zzbillunit', 'ssr_ccins', 'ssr_cctyp',
                                           'zsds_chot', 'zzconsass', 'zz_distric', 'oircmetrev',
                                           'zzavgcurrdocloc', 'zzdminus1rate', 'posar', 'shkzg', 'autyp',
                                           'zzexchrate_wf']) \
		                      .toDF() \
                              .filter("spart = '01' and vtweg_auft == '06'") \
        #print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_input_table.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table)
        df_tfx_table = df_tfx_table.repartition(20)
        #print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    @staticmethod
    def _apply_tfx(df_input_table):
        # convert all the columns alias to lower case
        df_vbrp = df_input_table.select([f.col(x).alias(x.lower()) for x in df_input_table.columns])

        # transformation
        df_tfx_result = df_vbrp.select(df_vbrp.vbeln, df_vbrp.posnr, df_vbrp.fkimg, df_vbrp.vrkme, df_vbrp.meins, df_vbrp.fklmg,
                    df_vbrp.lmeng, df_vbrp.ntgew, df_vbrp.brgew, df_vbrp.gewei, df_vbrp.volum, df_vbrp.voleh,
                    df_vbrp.prsdt, df_vbrp.kursk, df_vbrp.netwr, df_vbrp.vgbel, df_vbrp.vgpos, df_vbrp.vgtyp,
                    df_vbrp.aubel, df_vbrp.aupos, df_vbrp.matnr, df_vbrp.pstyv, df_vbrp.vstel, df_vbrp.spart,
                    df_vbrp.werks, df_vbrp.aland, df_vbrp.vkbur, df_vbrp.spara, df_vbrp.erdat, df_vbrp.erzet,
                    df_vbrp.stcur, df_vbrp.prctr, df_vbrp.konda_auft, df_vbrp.pltyp_auft, df_vbrp.vtweg_auft,
                    df_vbrp.augru_auft, df_vbrp.oid_extbol, df_vbrp.oicontnr, df_vbrp.oic_kmpos, df_vbrp.oic_time,
                    df_vbrp.oiinvcyc9, df_vbrp.zzsup_loc, df_vbrp.zzimport_reg, df_vbrp.zzvesselname,
                    df_vbrp.zztermtype, df_vbrp.zzflnum, df_vbrp.zzairctycd, df_vbrp.zztailno, df_vbrp.zzcontract_type,
                    df_vbrp.zzorigplant, df_vbrp.vsart, df_vbrp.zzbillunit, df_vbrp.ssr_ccins, df_vbrp.ssr_cctyp,
                    df_vbrp.zsds_chot, df_vbrp.zzconsass, df_vbrp.zz_distric, df_vbrp.oircmetrev,
                    df_vbrp.zzavgcurrdocloc, df_vbrp.zzdminus1rate, df_vbrp.posar, df_vbrp.shkzg, df_vbrp.autyp,
                    df_vbrp.zzexchrate_wf)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
