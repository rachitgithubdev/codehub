# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      05-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-pre-l2-l3-tcurr into conform zone
# Author        :- Bakul Seth
# Date          :- 05-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql import Window
from awsglue.job import Job
from datetime import date, timedelta, datetime


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 10')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'confirm_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.confirm_database = args['confirm_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_tables = ['tcurr', 'l3_pre_date_currency']
        self.report_file = 'l3_pre_tcurr_exrates'
        self.exchange_rate_file = 'l3_pre_exchange_rates'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        # read data from country specific table argument passed(database, table)
        print('Reading the data from the input tables')
        df_input_table = self._get_table(self.source_database,  self.confirm_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('Applying transformations on dataframe to get results')
        df_tfx_table = self._apply_tfx(df_input_table)

        # Writing the results to the desired location
        print('Writing tcurr file  to desired location, schema of tcurrr table is ')
        df_tfx_table[0].printSchema()
        self.write_results(self.report_file, df_tfx_table[0])

        print('Writing exchange rate file to desired location, schema of tcurrr table is ')
        df_tfx_table[1].printSchema()
        self.write_results(self.exchange_rate_file, df_tfx_table[1])

    def write_results(self, report_file, target_dataset):
        final_path = self.destination_bucket + '/' + report_file
        print('final_path', final_path)
        target_dataset \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, confirm_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name[0]))
        df_tcurr = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[0],
                                                              transformation_ctx='target_table').toDF()
        df_tcurr.printSchema()

        print('reading data from {}.{}'.format(confirm_database, table_name[1]))
        df_date = self._gc.create_dynamic_frame.from_catalog(database=confirm_database, table_name=table_name[1],
                                                             transformation_ctx='target_table').toDF().cache()
        df_date.printSchema()
        print(df_date.count())

        return [df_tcurr, df_date]

    @staticmethod
    def _apply_tfx(df_input_table):
        # convert all the columns alias to lower case
        df_tcurr = df_input_table[0].select([f.col(x).alias(x.lower()) for x in df_input_table[0].columns])

        # fetching date range till today
        end_date = date.today()
        df_date = df_input_table[1].alias('df_date').filter(f.col('df_date.curr_date') <= f.lit(end_date))

        # transformation
        print('Applying transformation of the to get desired results')
        df_tcurr = df_tcurr.select(df_tcurr.kurst, df_tcurr.fcurr, df_tcurr.tcurr, df_tcurr.gdatu, df_tcurr.ukurs)\
            .withColumn('gdatu', f.to_date((99999999 - df_tcurr.gdatu.cast('integer')).cast('string'), 'yyyyMMdd'))

        # Populate missing date exchange rate from historical data
        # filter the input table for given currency type
        print('Filtering the data for specific values')
        df_filtered = df_tcurr.filter(df_tcurr.kurst.isin(['ECB', 'RBA', 'M', 'CBIS', 'ANZB', 'CBM']))

        print('Getting rest of the data')
        df_non_filtered = df_tcurr.filter(df_tcurr.kurst.isin(['ECB', 'RBA', 'M', 'CBIS', 'ANZB', 'CBM']) == False)

        print('Joining currency and date values with filtered data')
        df_joined = df_date.join(df_filtered, (df_date.curr_date == df_filtered.gdatu) &
                                 (df_date.curr == df_filtered.fcurr) & (df_date.curr_type == df_filtered.kurst) &
                                 (df_date.t_curr == df_filtered.tcurr), 'left')

        # apply window function to populate missing value
        print('creating window to populate missing transaction rate ')
        window = Window.partitionBy(df_joined.curr, df_joined.curr_type, df_joined.t_curr).orderBy(df_joined.curr_date)

        print('populating missing trisection rate values from past')
        df_tfx_result = df_joined. \
            select(df_joined.curr_date, df_joined.curr, df_joined.curr_type, df_joined.kurst, df_joined.fcurr,
                   df_joined.t_curr, df_joined.tcurr, df_joined.gdatu, df_joined.ukurs,
                   f.last(df_joined.kurst, ignorenulls=True).over(window).alias('kurst_1'),
                   f.last(df_joined.fcurr, ignorenulls=True).over(window).alias('fcurr_1'),
                   f.last(df_joined.tcurr, ignorenulls=True).over(window).alias('tcurr_1'),
                   f.last(df_joined.ukurs, ignorenulls=True).over(window).alias('updated_col'),
                   f.last(df_joined.gdatu, ignorenulls=True).over(window).alias('gdatu_updated'))

        print('selecting only required columns')
        df_tfx_result1 = df_tfx_result. \
            select(df_tfx_result.kurst_1.alias('kurst'), df_tfx_result.fcurr_1.alias('fcurr'),
                   df_tfx_result.tcurr_1.alias('tcurr'), df_tfx_result.curr_date.alias('gdatu'),
                   df_tfx_result.updated_col.alias('ukurs'))

        # remove rows with null values and duplicates
        print('removing null and duplicate values after receiving the data')
        df_tfx_result1 = df_tfx_result1.na.drop(subset=["kurst", "fcurr", "tcurr", "ukurs"]).distinct()

        # union filtered and non-filtered data
        print('union the populated filtered and non-filtered data')
        df_tfx_result_final = df_tfx_result1.unionAll(df_non_filtered)

        return [df_tcurr, df_tfx_result_final]


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
