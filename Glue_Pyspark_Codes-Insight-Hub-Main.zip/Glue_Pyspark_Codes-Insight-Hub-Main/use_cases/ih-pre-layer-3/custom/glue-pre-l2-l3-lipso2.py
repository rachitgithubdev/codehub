# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Hasan Chaudhary 25-Feb-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-pre-l2-l3-lipso2.py into conform zone
# Author        :- Hasan Chaudhary
# Date          :- 25-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        #self._spark.conf.set('spark.sql.broadcastTimeout', '1800')
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['lipso2', 'vbrp']
        self.report_file = "l3_pre_lipso2_delivery_addl_qty"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table_list,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog

        # generate input table list
        source_database = self.source_database
        input_table_list = self.input_table_list
        print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        #df_lipso2 = self._get_table(source_database, input_table_list[0]).toDF()
        df_lipso2 = self._gc.create_dynamic_frame.from_catalog(
            database='transform_latest_pre',
            table_name='lipso2',
            transformation_ctx='my_table') \
            .select_fields(['vbeln', 'posnr', 'msehi','adqntp']) \
            .toDF()
            
        df_vbrp = self._gc.create_dynamic_frame.from_catalog(
	        database='transform_latest_pre',
	        table_name='vbrp',
	        transformation_ctx='my_table') \
	        .select_fields(['vgbel', 'vgpos', 'spart', 'vtweg_auft']) \
	        .toDF() \
	        .filter("spart = '01' and vtweg_auft = '06'") \
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[1],
        #                                               df_vbrp.count()))
        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_lipso2, df_vbrp)
        #df_tfx_table = df_tfx_table.repartition(10)
        #print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    @staticmethod
    def _apply_tfx(*args):
        # convert all the columns alias to lower case
        df_lipso2 = args[0].select([f.col(x).alias(x.lower()) for x in args[0].columns])
        df_vbrp = args[1].select([f.col(x).alias(x.lower()) for x in args[1].columns])
        # transformation
        #df_lipso2 = df_lipso2.orderBy(['vbeln', 'posnr'], ascending=True)
        #df_vbrp = df_vbrp.orderBy(['vgbel', 'vgpos'], ascending=True)
        df_tfx_result = df_vbrp.join(df_lipso2, (df_lipso2.vbeln == df_vbrp.vgbel) & (df_lipso2.posnr == df_vbrp.vgpos), 'inner') \
	        .select(df_lipso2.vbeln, df_lipso2.posnr, df_lipso2.msehi, df_lipso2.adqntp)
        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
