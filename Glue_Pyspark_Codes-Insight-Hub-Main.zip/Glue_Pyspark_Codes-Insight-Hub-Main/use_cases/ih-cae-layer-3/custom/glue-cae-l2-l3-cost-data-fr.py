# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    26-Feb-2021      Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_cost_data_fr into conform zone
# Author        :- Tingting Wan
# Date          :- 26-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = ['l2_isp_cost_data_fr', 'l2_isp_cost_data_fr_2020']
        self.report_file = "l3_isp_cost_data_fr"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        input_table_list = self.input_table
        df_input_table_1 = self._get_table(self.source_database, input_table_list[0]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, input_table_list[0],
        #                                                df_input_table_1.count()))
        df_input_table_2 = self._get_table(self.source_database, input_table_list[1]).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, input_table_list[1],
        #                                                df_input_table_2.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_1, df_input_table_2)
        # print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # convert all the columns alias to lower case
        df_input_table_1 = args[0].select(
            [f.col(x).alias(x.lower()) for x in args[0].columns])
        df_input_table_2 = args[1].select(
            [f.col(x).alias(x.lower()) for x in args[1].columns])

        # transformation
        # l3_isp_cost_data_fr
        df_table_1 = df_input_table_1.filter(df_input_table_1.type.isin('03. Last Year', '01. Actuals')) \
            .select(
            df_input_table_1.type.alias('type'),
            f.when(df_input_table_1.type == '03. Last Year', f.lit(2018))
                .when(df_input_table_1.type == '01. Actuals', f.lit(2019))
                .otherwise(df_input_table_1.type).alias('cost_year'),
            df_input_table_1.category.alias('cost_category'),
            df_input_table_1.sub_category.alias('cost_sub_category'),
            df_input_table_1.site.alias('plant'),
            df_input_table_1.product.alias('product'),
            df_input_table_1.customer.alias('customer'),
            df_input_table_1.cot.alias('sector'),
            f.col('01').cast('double').alias('jan'),
            f.col('02').cast('double').alias('feb'),
            f.col('03').cast('double').alias('mar'),
            f.col('04').cast('double').alias('apr'),
            f.col('05').cast('double').alias('may'),
            f.col('06').cast('double').alias('jun'),
            f.col('07').cast('double').alias('jul'),
            f.col('08').cast('double').alias('aug'),
            f.col('09').cast('double').alias('sep'),
            f.col('10').cast('double').alias('oct'),
            f.col('11').cast('double').alias('nov'),
            f.col('12').cast('double').alias('dec')
        )

        # l3_isp_cost_data_fr_2020
        df_table_2 = df_input_table_2.filter(df_input_table_2.type.isin('01. Actuals')) \
            .select(
            df_input_table_2.type.alias('type'),
            f.lit(2020).alias('cost_year'),
            df_input_table_2.category.alias('cost_category'),
            df_input_table_2.sub_category.alias('cost_sub_category'),
            df_input_table_2.site.alias('plant'),
            df_input_table_2.product.alias('product'),
            df_input_table_2.customer.alias('customer'),
            df_input_table_2.cot.alias('sector'),
            f.col('01').cast('double').alias('jan'),
            f.col('02').cast('double').alias('feb'),
            f.col('03').cast('double').alias('mar'),
            f.col('04').cast('double').alias('apr'),
            f.col('05').cast('double').alias('may'),
            f.col('06').cast('double').alias('jun'),
            f.col('07').cast('double').alias('jul'),
            f.col('08').cast('double').alias('aug'),
            f.col('09').cast('double').alias('sep'),
            f.col('10').cast('double').alias('oct'),
            f.col('11').cast('double').alias('nov'),
            f.col('12').cast('double').alias('dec')
        )

        df_tfx_result = df_table_1.union(df_table_2)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
