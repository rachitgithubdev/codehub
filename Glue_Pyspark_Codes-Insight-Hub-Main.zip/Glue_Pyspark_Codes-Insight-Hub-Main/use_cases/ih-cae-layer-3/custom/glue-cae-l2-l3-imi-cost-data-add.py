# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    29-Jan-2021      Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_imi_cost_data_add_all into conform zone
# Author        :- Tingting Wan
# Date          :- 29-Jan-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql import DataFrame
from functools import reduce


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l3_isp_imi_cost_data_all"
        self.report_file = "l3_isp_imi_cost_data_add_all"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_input_table.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table):
        # convert all the columns alias to lower case
        df_input_table = df_input_table.select([f.col(x).alias(x.lower()) for x in df_input_table.columns])

        # transformation
        # create table C
        df_table_C = df_input_table.select(f.col('*'))

        # -- Copy Friday COP to Saturday if rates are missing
        df_table_F = df_input_table.alias('F') \
            .join(df_input_table.alias('S'),
                  (f.col('S.cost_type') == f.col('F.cost_type'))
                  & (f.col('S.start_date') == f.col('S.end_date'))
                  & (f.col('S.prod_grp') == f.col('F.prod_grp'))
                  & (f.col('S.sector') == f.col('F.sector'))
                  & (f.col('S.cty_mnmc') == f.col('F.cty_mnmc'))
                  & (f.coalesce(f.col('S.airport'), f.lit('XXX')) == f.coalesce(f.col('F.airport'), f.lit('XXX')))
                  & (f.coalesce(f.col('S.fuel_point'), f.lit('XXX01')) == f.coalesce(f.col('F.fuel_point'),
                                                                                     f.lit('XXX01')))
                  & (f.coalesce(f.col('S.customer_number'), f.lit('XXX01')) == f.coalesce(
                      f.col('F.customer_number'), f.lit('XXX01')))
                  & (f.col('S.start_date') == f.date_add(f.col('F.end_date'), 1)), 'left') \
            .filter((f.col('F.cost_type') == f.lit('COP_RATE'))
                    & (f.col('F.cty_mnmc').isin('GB', 'IE'))
                    & (f.col('F.start_date') == f.col('F.end_date'))
                    & (f.date_format(f.col('F.end_date'), 'EEE') == 'Fri')
                    & (f.col('S.cost_rate').isNull())
                    ) \
            .select(
            f.col('F.prod_grp'), f.col('F.sector'),
            f.col('F.cty_mnmc'), f.col('F.airport'),
            f.col('F.fuel_point'), f.col('F.customer_number'),
            f.date_add(f.col('F.start_date'), 1).alias('start_date'),
            f.date_add(f.col('F.end_date'), 1).alias('end_date'),
            f.col('F.cost_type'), f.col('F.cost_rate'),
            f.col('F.cur'), f.col('F.uom')
        )

        # -- Copy Friday COP to Sunday if rates are missing
        df_table_S = df_input_table.alias('F') \
            .join(df_input_table.alias('S'),
                  (f.col('S.cost_type') == f.col('F.cost_type'))
                  & (f.col('S.start_date') == f.col('S.end_date'))
                  & (f.col('S.prod_grp') == f.col('F.prod_grp'))
                  & (f.col('S.sector') == f.col('F.sector'))
                  & (f.col('S.cty_mnmc') == f.col('F.cty_mnmc'))
                  & (f.coalesce(f.col('S.airport'), f.lit('XXX')) == f.coalesce(f.col('F.airport'), f.lit('XXX')))
                  & (f.coalesce(f.col('S.fuel_point'), f.lit('XXX01')) == f.coalesce(f.col('F.fuel_point'),
                                                                                     f.lit('XXX01')))
                  & (f.coalesce(f.col('S.customer_number'), f.lit('XXX01')) == f.coalesce(
                      f.col('F.customer_number'), f.lit('XXX01')))
                  & (f.col('S.start_date') == f.date_add(f.col('F.end_date'), 2)), 'left') \
            .filter((f.col('F.cost_type') == f.lit('COP_RATE'))
                    & (f.col('F.start_date') == f.col('F.end_date'))
                    & (f.date_format(f.col('F.end_date'), 'EEE') == 'Fri')
                    & (f.col('S.cost_rate').isNull())
                    ) \
            .select(
            f.col('F.prod_grp'), f.col('F.sector'),
            f.col('F.cty_mnmc'), f.col('F.airport'),
            f.col('F.fuel_point'), f.col('F.customer_number'),
            f.date_add(f.col('F.start_date'), 2).alias('start_date'),
            f.date_add(f.col('F.end_date'), 2).alias('end_date'),
            f.col('F.cost_type'), f.col('F.cost_rate'),
            f.col('F.cur'), f.col('F.uom')
        )

        # union all dataframes
        df_list = [df_table_C, df_table_F,
                   df_table_S]

        # print('Union All the Dataframes')
        df_tfx_result = reduce(DataFrame.unionAll, df_list)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
