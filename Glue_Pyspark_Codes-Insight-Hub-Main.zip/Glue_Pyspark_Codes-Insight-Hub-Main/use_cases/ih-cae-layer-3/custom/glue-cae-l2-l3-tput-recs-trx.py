# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    01-Feb-2021      Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_tput_recs_trx into conform zone
# Author        :- Tingting Wan
# Date          :- 01-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'country_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database1']
        self.conform_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l3_isp_tput_recs_all', 'l2_isp_port_plant', 'l2_isp_mtl_art_material']
        self.report_file = "l3_isp_tput_recs_trx"

        # generic variables  ===========================================
        self.country = 'uk'
        self.country_database = args['country_database']

        # Create country and database map
        self.country_database_map = dict(map(lambda x: x.split('='), self.country_database.split(',')))

        print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
        #                                                                 self.destination_bucket))

    def execute(self):
        input_table_list = self.input_table_list
        print(input_table_list[0])

        df_input_table_T = self._get_table(self.conform_database, self.input_table_list[0]).toDF()
        print("data count of table {}.{} is {}".format(self.conform_database, self.input_table_list[0],
                                                       df_input_table_T.count()))

        # get country database and table
        country = self.country
        country_database = self.source_database + "_" + self.country_database_map[country]
        country_table_list = [input_table + "_" + country for input_table in self.input_table_list[1:]]

        # read data from country specific table argument passed(database, table)
        df_input_table_P = self._get_table(country_database, country_table_list[0]).toDF()
        print(
            "data count of table {}.{} is {}".format(country_database, country_table_list[0], df_input_table_P.count()))
        df_input_table_M = self._get_table(country_database, country_table_list[1]).toDF()
        print(
            "data count of table {}.{} is {}".format(country_database, country_table_list[1], df_input_table_M.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_T, df_input_table_P, df_input_table_M)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # convert all the columns alias to lower case
        df_input_table_T = args[0]
        df_input_table_P = args[1].select(
            [f.col(x).alias(x.lower()) for x in args[1].columns])
        df_input_table_M = args[2].select(
            [f.col(x).alias(x.lower()) for x in args[2].columns])

        # transformation

        df_tfx_result = df_input_table_T.alias('T').join(
            df_input_table_P.alias('P'), f.col('P.mnmc') == f.col('T.location')) \
            .join(df_input_table_M.alias('M'), f.col('M.source_system') == f.col('P.source_system')) \
            .filter((f.col('T.period') < f.current_date())
                    & (f.col('M.id') == '90750000129162')) \
            .select(
            f.lit('GB').alias('country'),
            f.lit('10000000324').alias('company_code'),
            f.concat(f.lit('GB_TPUT_'), f.date_format(f.col('T.period'), 'ddMMyyyy')).alias('billing_document'),
            f.concat(f.col('P.source_system'), f.lit('_GB_TPUT_'), f.col('T.location'), f.lit('_'),
                     f.date_format(f.col('T.period'), 'ddMMyyyy')).alias('ref_id'),
            f.concat(f.lit('GB_TPUT_'), f.col('T.location'), f.lit('_'),
                     f.date_format(f.col('T.period'), 'ddMMyyyy')).alias('sales_document'),
            f.concat(f.lit('GB_TPUT_'), f.col('T.location'), f.lit('_'),
                     f.date_format(f.col('T.period'), 'ddMMyy')).alias('reference_document'),
            f.concat(f.col('P.source_system'), f.lit('_ISP_TPUT_REC')).alias('shipto_party'),
            f.concat(f.col('P.source_system'), f.lit('_ISP_TPUT_REC')).alias('billto_party'),
            f.concat(f.col('P.source_system'), f.lit('_ISP_TPUT_REC')).alias('soldto_party'),
            f.concat(f.col('P.source_system'), f.lit('_ISP_TPUT_REC')).alias('payer'),
            f.col('P.source_system'),
            f.lit('2830').alias('work_grp_id'),
            f.col('M.id').alias('material_number'),
            f.col('M.mnmc').alias('material_mnmc'),
            f.col('M.descn').alias('material_description'),
            f.col('M.art_type_id').alias('item_category'),
            f.concat(f.col('P.source_system'), f.lit('_'), f.col('P.id')).alias('plant'),
            f.lit('LT').alias('uom'),
            f.lit(0).cast('double').alias('ugl'),
            f.lit(0).cast('double').alias('litres'),
            f.lit(0).cast('double').alias('kg'),
            f.lit('USD').alias('currency'),
            f.lit(0).cast('double').alias('usd_value'),
            f.col('T.period').alias('delivery_date')
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
