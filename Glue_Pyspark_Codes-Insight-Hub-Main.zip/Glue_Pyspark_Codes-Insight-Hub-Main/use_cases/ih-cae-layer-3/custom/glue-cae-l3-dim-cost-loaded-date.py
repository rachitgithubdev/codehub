# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1             Bakul Seth       29-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_dim_cost_loaded_date into conform zone
# Author        :- Bakul Seth
# Date          :- 29-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class SunIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print('Incorrect command line argument passed to JOB')
            print('Argument expected : 9')
            print('Argument passed : ', str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']
        self.environment = args['environment']

        # report specific =============================================
        self.input_tables = ['l3_isp_imi_cost_data_all', 'l3_isp_cost_data_mena', 'l3_isp_cost_data_sec_zamz',
                             'l3_isp_apc_alro_all', 'l3_isp_cost_data_gr', 'l3_isp_cost_data_tr',
                             'l3_isp_cost_data_fr']
        self.report_file = 'l3_isp_dim_cost_loaded_date'

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_tables,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        print('Reading data from input tabled {}.{}'.format(self.source_database, self.input_tables))
        df_input_table = self._get_table(self.source_database, self.input_tables)

        # apply transformation on the dataframe argument passed(dataframe, country)
        print('applying the transformations')
        df_tfx_table = self._apply_tfx(df_input_table)
        print('schema after transformation ', df_tfx_table.printSchema())

        # write final result to required destination
        print('Writing the results to desired location')
        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option('compression', 'snappy') \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name[0]))
        df_cost_all = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[0],
                                                                 transformation_ctx='target_table').toDF()
        df_cost_all.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[1]))
        df_cost_mena = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[1],
                                                                  transformation_ctx='target_table').toDF()
        df_cost_mena.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[2]))
        df_cost_sec = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[2],
                                                                 transformation_ctx='target_table').toDF()
        df_cost_sec.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[3]))
        df_apc_alro = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[3],
                                                                 transformation_ctx='target_table').toDF()
        df_apc_alro.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[4]))
        df_cost_gr = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[4],
                                                                transformation_ctx='target_table').toDF()
        df_cost_gr.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[5]))
        df_cost_tr = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[5],
                                                                transformation_ctx='target_table').toDF()
        df_cost_tr.printSchema()

        print('reading data from {}.{}'.format(source_database, table_name[6]))
        df_cost_fr = self._gc.create_dynamic_frame.from_catalog(database=source_database, table_name=table_name[6],
                                                                transformation_ctx='target_table').toDF()
        df_cost_fr.printSchema()

        return [df_cost_all, df_cost_mena, df_cost_sec, df_apc_alro, df_cost_gr, df_cost_tr, df_cost_fr]

    @staticmethod
    def _apply_tfx(df_input_table):
        # creating dataframe for different tables
        print('creating dataframe for different tables')
        cost_all = df_input_table[0]

        cost_mena = df_input_table[1]

        cost_sec = df_input_table[2]

        cost_alro = df_input_table[3]

        cost_gr = df_input_table[4]

        cost_tr = df_input_table[5]

        cost_fr = df_input_table[6]

        # Applying the transformation
        print('applying the transformations df_cost_all1')
        df_cost_all1 = cost_all.filter(cost_all.cost_type == f.lit('COP_RATE')) \
            .groupBy(cost_all.cty_mnmc) \
            .agg(f.max(cost_all.end_date).alias('last_loaded_date')) \
            .select(cost_all.cty_mnmc.alias('country_mnmc'), f.lit('COP').alias('cost_type'), f.col('last_loaded_date'))

        print('applying the transformations df_cost_all2')
        df_cost_all2 = cost_all.filter(cost_all.cost_type.isin(['ONAIRFIELD_FXD', 'ONAIRFIELD_VAR', 'PREAIRFIELD_FXD',
                                                                'PREAIRFIELD_VAR'])) \
            .groupBy(cost_all.cty_mnmc) \
            .agg(f.max(cost_all.end_date).alias('last_loaded_date')) \
            .select(cost_all.cty_mnmc.alias('country_mnmc'), f.lit('APC').alias('cost_type'), f.col('last_loaded_date'))

        print('applying the transformations df_cost_mena')
        df_cost_mena = cost_mena.filter(cost_mena.cost_type.isin(['COP', 'OAF', 'OAV', 'PAF', 'PAV', 'PRIM_TRANS',
                                                                  'SEC_TRANS_STAFF'])) \
            .groupBy(cost_mena.cty_mnmc) \
            .agg(f.max(cost_mena.end_date).alias('last_loaded_date')) \
            .select(cost_mena.cty_mnmc.alias('country_mnmc'), f.lit('ALL').alias('cost_type'),
                    f.col('last_loaded_date'))

        print('applying the transformations df_sec_zamz')
        df_sec_zamz = cost_sec.groupBy(cost_sec.country) \
            .agg(f.max(cost_sec.end_date).alias('last_loaded_date')) \
            .select(cost_sec.country.alias('country_mnmc'), f.lit('ALL').alias('cost_type'), f.col('last_loaded_date'))

        print('applying the transformations df_apc_alro1')
        df_apc_alro1 = cost_alro.filter(((cost_alro.country_mnmc == f.lit('AL')) &
                                        ((cost_alro.cop > f.lit(0)) | (cost_alro.oaf > f.lit(0)) |
                                         (cost_alro.oav > f.lit(0)) | (cost_alro.paf > f.lit(0)) |
                                         (cost_alro.pav > f.lit(0))))) \
            .groupBy(cost_alro.country_mnmc) \
            .agg(f.max(f.last_day(cost_alro.period)).alias('last_loaded_date')) \
            .select(cost_alro.country_mnmc.alias('country_mnmc'), f.lit('APC').alias('cost_type'),
                    f.col('last_loaded_date'))

        print('applying the transformations df_apc_alro2')
        df_apc_alro2 = cost_alro.filter(((cost_alro.country_mnmc == f.lit('RO')) &
                                        ((cost_alro.cop > f.lit(0)) | (cost_alro.oaf > f.lit(0)) |
                                         (cost_alro.oav > f.lit(0)) | (cost_alro.paf > f.lit(0)) |
                                         (cost_alro.pav > f.lit(0))))) \
            .groupBy(cost_alro.country_mnmc) \
            .agg(f.max(f.last_day(cost_alro.period)).alias('last_loaded_date')) \
            .select(cost_alro.country_mnmc.alias('country_mnmc'), f.lit('ALL').alias('cost_type'),
                    f.col('last_loaded_date'))

        print('applying the transformations df_cost_gr')
        df_cost_gr = cost_gr.filter((cost_gr.lcl_cop_val.isNotNull()) | (cost_gr.lcl_oaf_val.isNotNull()) |
                                     (cost_gr.lcl_oav_val.isNotNull()) | (cost_gr.lcl_paf_val.isNotNull()) |
                                     (cost_gr.lcl_pav_val.isNotNull()))\
            .select(f.lit('GR').alias('country_mnmc'), f.lit('ALL').alias('cost_type'),
                    f.max(cost_gr.end_date).alias('last_loaded_date'))

        print('applying the transformations df_cost_tr')
        df_cost_tr = cost_tr. \
            select(f.lit('TR').alias('country_mnmc'), f.lit('ALL').alias('cost_type'),
                   f.max(cost_tr.period).alias('last_loaded_date'))

        print('applying the transformations df_cost_fr')
        df_cost_fr = cost_fr \
            .select(f.lit('FR').alias('country_mnmc'), f.lit('ALL').alias('COST_TYPE'),
                    f.max(f.last_day(f.to_date(f.unix_timestamp(f.concat(cost_fr.cost_year.cast('string'), f.lit('12')),
                                                                'yyyyMM').cast('timestamp')))))

        df_list = [df_cost_all1, df_cost_all2, df_cost_mena, df_sec_zamz, df_apc_alro1, df_apc_alro2, df_cost_gr,
                   df_cost_tr, df_cost_fr]

        print('Union all the Dataframes and get the distinct values')
        df_tfx_result = reduce(DataFrame.union, df_list).distinct()

        return df_tfx_result


if __name__ == '__main__':
    trl = SunIspETL()
    trl.execute()
