# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    25-Feb-2021      Initial version
#  0.2              Tingting Wan    14-May-2021      change logs
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_ext_cus_mena into conform zone
# Author        :- Tingting Wan
# Date          :- 25-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 12:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 12")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'source_database3',
                                   'country_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database1']
        self.netapp_database = args['source_database2']
        self.conform_database = args['source_database3']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l2_isp_ext_cus_lb', 'l4_dim_customer',
                                 'l2_isp_cust_acct', 'l2_isp_mtl_art_material', 'l2_isp_port_plant']
        self.report_file = "l3_isp_ext_cus_mena"

        # generic variables  ===========================================
        self.country = 'me'
        self.country_database = args['country_database']

        # Create country and database map
        self.country_database_map = dict(map(lambda x: x.split('='), self.country_database.split(',')))

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        df_input_table_E = self._get_table(self.netapp_database, self.input_table_list[0]).toDF()
        #print("data count of table {}.{} is {}".format(self.netapp_database, self.input_table_list[0],
        #                                               df_input_table_E.count()))
        df_input_table_C_L4 = self._get_table(self.conform_database, self.input_table_list[1]).toDF()
        #print("data count of table {}.{} is {}".format(self.conform_database, self.input_table_list[1],
        #                                               df_input_table_C_L4.count()))

        # get 'me' database and tables
        country = self.country
        country_database = self.source_database + "_" + self.country_database_map[country]
        country_table_list = [input_table + "_" + country for input_table in self.input_table_list[2:]]

        # read data from country specific table argument passed(database, table)
        df_input_table_C = self._get_table(country_database, country_table_list[0]).toDF()
        # print(
        #     "data count of table {}.{} is {}".format(country_database, country_table_list[0], df_input_table_C.count()))
        df_input_table_M = self._get_table(country_database, country_table_list[1]).toDF()
        #print(
        #    "data count of table {}.{} is {}".format(country_database, country_table_list[1], df_input_table_M.count()))
        df_input_table_P = self._get_table(country_database, country_table_list[2]).toDF()
        #print(
        #    "data count of table {}.{} is {}".format(country_database, country_table_list[2], df_input_table_P.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table_E, df_input_table_C_L4,
                                       df_input_table_C, df_input_table_M, df_input_table_P)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        # convert all the columns alias to lower case
        df_input_table_E = args[0].select(
            [f.col(x).alias(x.lower()) for x in args[0].columns])
        # df_input_table_C_L4 - l4_dim_customer
        df_input_table_C_L4 = args[1]

        # ME tables
        df_input_table_C = args[2].select(
            [f.col(x).alias(x.lower()) for x in args[2].columns])
        df_input_table_M = args[3].select(
            [f.col(x).alias(x.lower()) for x in args[3].columns])
        df_input_table_P = args[4].select(
            [f.col(x).alias(x.lower()) for x in args[4].columns])

        # transformation
        # E.GRN = '7358900'
        df_table_1 = df_input_table_E.alias('E').join(
            df_input_table_C.alias('C'), f.col('E.grn') == f.col('C.global_acct_ref_num')) \
            .join(df_input_table_M.alias('M'), f.col('M.source_system') == f.col('C.source_system')) \
            .join(df_input_table_P.alias('P'), f.col('C.source_system') == f.col('P.source_system')) \
            .filter((f.col('M.id') == '90750000129162')
                    & (f.col('P.id') == '5250000021619')
                    & (f.col('E.grn') == '7358900')) \
            .select(
            f.lit('LB').alias('country'),
            f.lit('10000000321').alias('company_code'),
            f.concat(f.lit('LBX'), f.date_format(f.last_day(f.from_unixtime(
                f.unix_timestamp(f.col('E.start_date'), 'dd/MM/yyyy')).cast('date')), 'ddMMyyyy')).alias(
                'billing_document'),
            f.concat(f.col('C.source_system'), f.lit('_'), f.col('E.grn').cast('integer'), f.lit('_'),
                     f.date_format(f.last_day(f.from_unixtime(
                         f.unix_timestamp(f.col('E.start_date'), 'dd/MM/yyyy')).cast('date')), 'ddMMyyyy')).alias(
                'ref_id'),
            f.date_format(f.last_day(f.from_unixtime(
                f.unix_timestamp(f.col('E.start_date'), 'dd/MM/yyyy')).cast('date')), 'ddMMyyyy').alias(
                'sales_document'),
            f.date_format(f.last_day(f.from_unixtime(
                f.unix_timestamp(f.col('E.start_date'), 'dd/MM/yyyy')).cast('date')), 'ddMMyy').alias(
                'reference_document'),
            f.concat(f.col('C.source_system'), f.lit('_'), f.col('C.id')).alias('shipto_party'),
            f.concat(f.col('C.source_system'), f.lit('_'), f.col('C.inv_pt_id')).alias('billto_party'),
            f.concat(f.col('C.source_system'), f.lit('_'), f.col('C.cab_id')).alias('soldto_party'),
            f.concat(f.col('C.source_system'), f.lit('_'), f.col('C.acct_pt_id')).alias('payer'),
            f.col('C.source_system'),
            f.lit('7721').alias('work_grp_id'),
            f.col('M.id').alias('material_number'),
            f.col('M.mnmc').alias('material_mnmc'),
            f.col('M.descn').alias('material_description'),
            f.col('M.art_type_id').alias('item_category'),
            f.concat(f.col('P.source_system'), f.lit('_'), f.col('P.id')).alias('plant'),
            f.lit('UGL').alias('uom'),
            f.col('E.UGL').cast('double').alias('ugl'),
            (f.col('E.UGL').cast('double') * 3.78541253).alias('litres'),
            (f.col('E.UGL').cast('double') * 3.78541253 * 0.7989).alias('kg'),
            f.lit('USD').alias('currency'),
            f.col('E.usd_value').cast('double').alias('usd_value'),
            f.last_day(f.from_unixtime(
                f.unix_timestamp(f.col('E.start_date'), 'dd/MM/yyyy')).cast('date')).alias('delivery_date')
        )

        # E.GRN = '990033'
        df_table_2 = df_input_table_E.alias('E').join(
            df_input_table_C_L4.alias('C'), f.col('E.grn') == f.col('C.mdm_partner_id')) \
            .join(df_input_table_M.alias('M'),
                  f.col('M.source_system') == f.coalesce(f.col('C.airline_code'), f.lit('ISP_ESP0720'))) \
            .join(df_input_table_P.alias('P'), f.col('M.source_system') == f.col('P.source_system')) \
            .filter((f.col('M.id') == '90750000129162')
                    & (f.col('P.id') == '5250000021619')
                    & (f.col('E.grn') == '990033')) \
            .select(
            f.lit('LB').alias('country'),
            f.lit('10000000321').alias('company_code'),
            f.concat(f.lit('LBC'), f.date_format(f.last_day(f.from_unixtime(
                f.unix_timestamp(f.col('E.start_date'), 'dd/MM/yyyy')).cast('date')), 'ddMMyyyy')).alias(
                'billing_document'),
            f.concat(f.col('P.source_system'), f.lit('_'), f.col('E.grn').cast('integer'), f.lit('_'),
                     f.date_format(f.last_day(f.from_unixtime(
                         f.unix_timestamp(f.col('E.start_date'), 'dd/MM/yyyy')).cast('date')), 'ddMMyyyy')).alias(
                'ref_id'),
            f.date_format(f.last_day(f.from_unixtime(
                f.unix_timestamp(f.col('E.start_date'), 'dd/MM/yyyy')).cast('date')), 'ddMMyyyy').alias(
                'sales_document'),
            f.date_format(f.last_day(f.from_unixtime(
                f.unix_timestamp(f.col('E.start_date'), 'dd/MM/yyyy')).cast('date')), 'ddMMyy').alias(
                'reference_document'),
            f.concat(f.col('P.source_system'), f.lit('_ISP_LBCS_REC')).alias('shipto_party'),
            f.concat(f.col('P.source_system'), f.lit('_ISP_LBCS_REC')).alias('billto_party'),
            f.concat(f.col('P.source_system'), f.lit('_ISP_LBCS_REC')).alias('soldto_party'),
            f.concat(f.col('P.source_system'), f.lit('_ISP_LBCS_REC')).alias('payer'),
            f.col('P.source_system'),
            f.lit('7721').alias('work_grp_id'),
            f.col('M.id').alias('material_number'),
            f.col('M.mnmc').alias('material_mnmc'),
            f.col('M.descn').alias('material_description'),
            f.col('M.art_type_id').alias('item_category'),
            f.concat(f.col('P.source_system'), f.lit('_'), f.col('P.id')).alias('plant'),
            f.lit('UGL').alias('uom'),
            f.col('E.UGL').cast('double').alias('ugl'),
            (f.col('E.UGL').cast('double') * 3.78541253).alias('litres'),
            (f.col('E.UGL').cast('double') * 3.78541253 * 0.7989).alias('kg'),
            f.lit('USD').alias('currency'),
            f.col('E.usd_value').cast('double').alias('usd_value'),
            f.last_day(f.from_unixtime(
                f.unix_timestamp(f.col('E.start_date'), 'dd/MM/yyyy')).cast('date')).alias('delivery_date')
        )

        df_tfx_result = df_table_1.union(df_table_2)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
