# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    23-Feb-2021      Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_apc_alro_all into conform zone
# Author        :- Tingting Wan
# Date          :- 23-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql import DataFrame
from functools import reduce


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_isp_apc"
        self.report_file = "l3_isp_apc_alro_all"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        tran_latest_dfs = []
        self.country_list = ['al', 'ro']

        # process country wise data
        for country in self.country_list:
            # get country table
            country_table = self.input_table + "_" + country

            # read data from country specific table argument passed(database, table)
            df_input_table = self._get_table(self.source_database, country_table).toDF()
            print("data count of table {}.{} is {}".format(self.source_database, country_table, df_input_table.count()))

            # apply transformation on the dataframe argument passed(dataframe, country)
            df_tfx_table = self._apply_tfx(df_input_table, country)

            # Append each dataframe to list.
            tran_latest_dfs.append(df_tfx_table)

        # union country specific dataframes to get data for all the countries
        final_result_df = reduce(DataFrame.unionAll, tran_latest_dfs)
        print("data count after union All ", final_result_df.count())

        # write final result to required destination
        self.write_results(final_result_df)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table, country):

        # convert all the columns alias to lower case
        df_input_table = df_input_table.select([f.col(x).alias(x.lower()) for x in df_input_table.columns])

        if country == 'al':
            df_tfx_result = df_input_table.select(
                f.lit(country.upper()).alias('country_mnmc'),
                df_input_table.airport_mnmc.alias('airport_mnmc'),
                f.from_unixtime(f.unix_timestamp(df_input_table.period, 'dd/MM/yyyy')).cast('date').alias('period'),
                (df_input_table.paf * (-1)).cast('double').alias('paf'),
                (df_input_table.pav * (-1)).cast('double').alias('pav'),
                (df_input_table.oaf * (-1)).cast('double').alias('oaf'),
                (df_input_table.oav * (-1)).cast('double').alias('oav'),
                df_input_table.oic.cast('double').alias('oic'),
                f.lit(0).cast('double').alias('cop')
            )

        else:
            df_tfx_result = df_input_table.select(
                f.lit(country.upper()).alias('country_mnmc'),
                df_input_table.airport_mnmc.alias('airport_mnmc'),
                f.from_unixtime(f.unix_timestamp(df_input_table.period, 'dd/MM/yyyy')).cast('date').alias('period'),
                (df_input_table.paf * 1000 * (-1)).cast('double').alias('paf'),
                (df_input_table.pav * 1000 * (-1)).cast('double').alias('pav'),
                (df_input_table.oaf * 1000 * (-1)).cast('double').alias('oaf'),
                (df_input_table.oav * 1000 * (-1)).cast('double').alias('oav'),
                (df_input_table.oic * 1000).cast('double').alias('oic'),
                (df_input_table.cogs * 1000 * (-1)).cast('double').alias('cop')
            )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
