# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    26-May-2021      Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l5_ytd_xrates_all into conform zone
# Author        :- Tingting Wan
# Date          :- 26-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.netapp_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = 'l2_l5_ytd_xrates_usd'
        self.report_file = "l5_ytd_xrates_all"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.netapp_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table = self._get_table(self.netapp_database, self.input_table).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, input_table_list[0],
        #                                                df_input_table_1.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(self, df_input_table)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(self, df_input_table):
        # convert all the columns alias to lower case
        df_input_table = df_input_table.select(
            [f.col(x).alias(x.lower()) for x in df_input_table.columns])

        # transformation
        # Union table 1
        df_table_1 = df_input_table.select(
            f.lit('USD').alias('from_cur_mnmc'),
            f.col('currency').alias('to_cur_mnmc'),
            f.concat(f.substring(f.col('start_date'), 1, 8), f.lit('01')).cast('date').alias('start_date'),
            f.last_day(f.col('end_date')).alias('end_date'),
            f.col('average_ytd_rate').alias('ytd_exch_rate')
        )

        # union table 2
        # Create table B
        df_table_B = df_input_table.groupBy(f.col('currency')) \
            .agg(f.max(f.last_day(f.col('end_date'))).alias('max_date')) \
            .select(
            f.col('currency'),
            f.col('max_date')
        )
        df_table_B.createOrReplaceTempView('B')

        # creat table C
        df_input_table.createOrReplaceTempView('C')

        df_table_2 = self._spark.sql("""
         SELECT 'USD' AS from_cur_mnmc
         , C.Currency AS to_cur_mnmc
         , CAST(CONCAT(SUBSTRING(ADD_MONTHS('2020-01-01', A.pos), 1, 8), '01') AS DATE) AS start_date
         , LAST_DAY(ADD_MONTHS('2020-01-01', A.pos)) AS end_date
         , C.Average_YTD_Rate AS ytd_exch_rate
        FROM (SELECT POSEXPLODE(SPLIT(REPEAT("o", MONTHS_BETWEEN(CURRENT_DATE(), '2020-01-01')), "o"))) AS A, B, C
        WHERE  LAST_DAY(ADD_MONTHS('2020-01-01', A.pos)) > B.max_date
        AND    B.Currency = C.Currency
        AND    B.max_date = LAST_DAY(C.End_Date)
         """)

        print("data count OF df_table_2 ", df_table_2.count())
        df_tfx_result = df_table_1.union(df_table_2)
        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
