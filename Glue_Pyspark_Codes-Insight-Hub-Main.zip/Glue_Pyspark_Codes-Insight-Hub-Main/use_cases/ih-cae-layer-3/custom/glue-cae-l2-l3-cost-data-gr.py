# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    22-Feb-2021      Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_cost_data_gr into conform zone
# Author        :- Tingting Wan
# Date          :- 22-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_isp_cost_data_gr"
        self.report_file = "l3_isp_cost_data_gr"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        # print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_input_table.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_input_table)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table):
        # convert all the columns alias to lower case
        df_input_table = df_input_table.select([f.col(x).alias(x.lower()) for x in df_input_table.columns])

        # transformation

        df_tfx_result = df_input_table.groupBy(
            f.upper(f.trim(df_input_table.airport)).alias('airport_mnmc'),
            f.upper(f.trim(df_input_table.prodgrp)).alias('prod_grp'),
            f.substring(f.trim(df_input_table.grn), 1, 5).alias('customer_header'),
            f.trim(df_input_table.customer).alias('customer_name'),
            f.when(df_input_table.grn.isNotNull(), f.lit('C'))
                .when(df_input_table.customer.isNotNull(), f.lit('D'))
                .when(df_input_table.prodgrp.isNotNull(), f.lit('P'))
                .otherwise(f.lit('L')).alias('rec_type'),
            f.trim(df_input_table.sector).alias('sector_org'),
            f.when(f.upper(df_input_table.sector) == 'CA', f.lit('Commercial Airlines'))
                .when(f.upper(df_input_table.sector) == 'AIRLIN', f.lit('Commercial Airlines'))
                .when(f.upper(f.trim(df_input_table.sector)) == 'EXPORT', f.lit('Export'))
                .when(f.upper(f.trim(df_input_table.sector)) == 'GA', f.lit('General Aviation'))
                .when(f.substring(f.upper(f.trim(df_input_table.sector)), 1, 3) == 'MIL', f.lit('Military'))
                .when(f.upper(f.trim(df_input_table.sector)) == 'SUPPLY DEPOTS', f.lit('Supply Depots'))
                .when(f.upper(f.trim(df_input_table.sector)) == 'SUPPLY', f.lit('Supply'))
                .when(f.upper(f.trim(df_input_table.sector)) == 'SUPPLY AIR', f.lit('Supply'))
                .otherwise(f.lit('Unknown')).alias('sector_cae'),
            f.from_unixtime(f.unix_timestamp(((df_input_table.yearmonth * 100) + 1).cast('string'), 'yyyyMMdd')).cast(
                'date').alias('start_date'),
            f.last_day(f.from_unixtime(
                f.unix_timestamp(((df_input_table.yearmonth * 100) + 1).cast('string'), 'yyyyMMdd'))).alias('end_date')
        ) \
            .agg(
            f.sum(f.coalesce(df_input_table.litres, f.lit(0))).alias('litres'),
            f.sum(f.coalesce(df_input_table.outcome_greek_air_force, f.lit(0))).alias('lcl_mil_inc'),
            f.sum(f.coalesce(df_input_table.shell_eko_income, f.lit(0))).alias('lcl_tar_inc'),
            (f.sum(f.coalesce(df_input_table.outcome_greek_air_force, f.lit(0)))
             + f.sum(f.coalesce(df_input_table.shell_eko_income, f.lit(0)))).alias('lcl_adj_val'),
            f.sum(f.coalesce(df_input_table.depot_income, f.lit(0))).alias('lcl_dep_inc'),
            f.sum(f.coalesce(df_input_table.revenue, f.lit(0))).alias('lcl_rev_inc'),
            f.sum(f.coalesce(df_input_table.cso_income, f.lit(0))).alias('lcl_cso_inc'),
            f.sum(f.coalesce(df_input_table.safco_ofc_fees, f.lit(0))).alias('lcl_saf_inc'),
            (f.sum(f.coalesce(df_input_table.depot_income, f.lit(0)))
             + f.sum(f.coalesce(df_input_table.revenue, f.lit(0)))
             + f.sum(f.coalesce(df_input_table.cso_income, f.lit(0)))
             + f.sum(f.coalesce(df_input_table.safco_ofc_fees, f.lit(0)))).alias('lcl_net_val'),
            f.sum(f.coalesce(df_input_table.cop, f.lit(0))).alias('lcl_cop_val'),
            f.sum(f.coalesce(df_input_table.cop_lag, f.lit(0)) * (-1)).alias('lcl_lag_val'),
            f.sum(f.coalesce(df_input_table.gm, f.lit(0))).alias('lcl_gm_val'),
            f.sum(f.coalesce(df_input_table.other_income_est, f.lit(0))).alias('lcl_oic_val'),
            f.sum(f.coalesce(df_input_table.oaf, f.lit(0))).alias('lcl_oaf_val'),
            f.sum(f.coalesce(df_input_table.oav, f.lit(0))).alias('lcl_oav_val'),
            f.sum(f.coalesce(df_input_table.paf, f.lit(0))).alias('lcl_paf_val'),
            f.sum(f.coalesce(df_input_table.pav, f.lit(0))).alias('lcl_pav_val'),
            f.sum(f.coalesce(df_input_table.gp, f.lit(0))).alias('lcl_gp_val')
        ).select(
            f.col('airport_mnmc'),
            f.col('prod_grp'),
            f.col('customer_header'),
            f.col('customer_name'),
            f.col('rec_type'),
            f.col('sector_org'),
            f.col('sector_cae'),
            f.col('start_date'),
            f.col('end_date'),
            f.col('litres'),
            f.col('lcl_mil_inc'),
            f.col('lcl_tar_inc'),
            f.col('lcl_adj_val'),
            f.col('lcl_dep_inc'),
            f.col('lcl_rev_inc'),
            f.col('lcl_cso_inc'),
            f.col('lcl_saf_inc'),
            f.col('lcl_net_val'),
            f.col('lcl_cop_val'),
            f.col('lcl_lag_val'),
            f.col('lcl_gm_val'),
            f.col('lcl_oic_val'),
            f.col('lcl_oaf_val'),
            f.col('lcl_oav_val'),
            f.col('lcl_paf_val'),
            f.col('lcl_pav_val'),
            f.col('lcl_gp_val')
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
