# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    24-Feb-2021      Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_cost_data_mena into conform zone
# Author        :- Tingting Wan
# Date          :- 24-Feb-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql import DataFrame
from functools import reduce


class LcpCAEETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_isp_cost_data"
        self.report_file = "l3_isp_cost_data_mena"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        tran_latest_dfs = []
        self.country_list = ['ae', 'bh', 'eg', 'lb']

        # process country wise data
        for country in self.country_list:
            # get country table
            country_table = self.input_table + "_" + country

            # read data from country specific table argument passed(database, table)
            df_input_table = self._get_table(self.source_database, country_table).toDF()
            print("data count of table {}.{} is {}".format(self.source_database, country_table, df_input_table.count()))

            # apply transformation on the dataframe argument passed(dataframe)
            df_inner_table = self.apply_tfx_inner(df_input_table)
            # print("data count after transformation ", df_inner_table.count())

            # Append each dataframe to list.
            tran_latest_dfs.append(df_inner_table)

        # union All the countries - inner table
        df_inner_table = reduce(DataFrame.unionAll, tran_latest_dfs)

        # apply transformation on the main dataframe argument passed
        final_result_df = self._apply_tfx(df_inner_table)
        print("data count after union All ", final_result_df.count())

        # write final result to required destination
        self.write_results(final_result_df)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    def apply_tfx_inner(self, df_input_table):

        # convert all the columns alias to lower case
        df_input_table = df_input_table.select([f.col(x).alias(x.lower()) for x in df_input_table.columns])

        # transformation
        df_tfx_result = df_input_table.select(
            df_input_table.country,
            df_input_table.product_group,
            df_input_table.location,
            df_input_table.cost_type,
            df_input_table.start_date,
            df_input_table.end_date,
            df_input_table.cost_value)

        return df_tfx_result

    @staticmethod
    def _apply_tfx(df_input_table):

        # transformation
        # cost table
        df_cost_table = df_input_table.groupBy(
            df_input_table.country.alias('cty_mnmc'),
            df_input_table.product_group.alias('prod_grp'),
            df_input_table.location.alias('airport'),
            f.when(df_input_table.cost_type.isin('COP', 'COSA'), f.lit('COP'))
                .when(df_input_table.cost_type.isin('OAV', 'SEC_TRANS_STAFF', 'SEC_TRANS_OTHER'), f.lit('OAV'))
                .when(df_input_table.cost_type.isin('PAV', 'PRIM_TRANS'), f.lit('PAV'))
                .otherwise(df_input_table.cost_type).alias('cost_type'),
            f.from_unixtime(f.unix_timestamp(df_input_table.start_date, 'dd/MM/yyyy')).cast('date').alias('start_date'),
            f.from_unixtime(f.unix_timestamp(df_input_table.end_date, 'dd/MM/yyyy')).cast('date').alias('end_date')
        ) \
            .agg(
            f.sum(df_input_table.cost_value * 1000).cast('double').alias('cost')
        ).select(
            f.col('cty_mnmc'),
            f.col('prod_grp'),
            f.col('airport'),
            f.col('cost_type'),
            f.col('start_date'),
            f.col('end_date'),
            f.col('cost')
        )

        # outer table
        df_tfx_result = df_cost_table.select(
            df_cost_table.cty_mnmc,
            df_cost_table.prod_grp,
            df_cost_table.airport,
            df_cost_table.cost_type,
            df_cost_table.start_date,
            df_cost_table.end_date,
            f.when(df_cost_table.cost_type.isin('COP_LAG', 'OTHER_INCOME'), df_cost_table.cost)
                .otherwise(df_cost_table.cost * (-1)).alias('cost')
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpCAEETL()
    trl.execute()
