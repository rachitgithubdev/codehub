# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    09-Mar-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to l3_prot_ct1010_chart_of_acc into conform zone
# Author        :- Tingting Wan
# Date          :- 09-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPROTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_prot_ct1010"
        self.report_file = "l3_prot_ct1010_chart_of_acc"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # read data from country specific table argument passed(database, table)
        print('Reading data from source')
        df_input_table = self._get_table(self.source_database, self.input_table).toDF()
        print("Schema of table {}.{} is {}".format(self.source_database, self.input_table,
                                                   df_input_table.printSchema()))

        # apply transformation on the dataframe argument passed(dataframe)
        print('Applying transformations')
        df_tfx_table = self._apply_tfx(df_input_table)
        print("Schema after transformation ", df_tfx_table.printSchema())

        print('Writing the data in S3')
        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    @staticmethod
    def union_dataframe(final_result_df, country_df):
        # union the dataframe
        if bool(final_result_df.head(1)):
            final_result_df = final_result_df.union(country_df)
        else:
            final_result_df = country_df
        return final_result_df

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table):
        # convert all the columns alias to lower case
        print('Converting all the columns to small case')
        df_input_table = df_input_table.select([f.col(x).alias(x.lower()) for x in df_input_table.columns])

        # transformation

        df_tfx_result = df_input_table.select(
            df_input_table.ct1_filial,
            df_input_table.ct1_conta,
            df_input_table.ct1_desc01,
            df_input_table.ct1_desc02,
            df_input_table.ct1_desc03,
            df_input_table.ct1_desc04,
            df_input_table.ct1_desc05,
            df_input_table.ct1_classe,
            df_input_table.ct1_normal,
            df_input_table.ct1_res,
            df_input_table.ct1_bloq,
            df_input_table.ct1_dtblin,
            df_input_table.ct1_dtblfi,
            df_input_table.ct1_dc,
            df_input_table.ct1_ncusto.cast('double'),
            df_input_table.ct1_cc,
            df_input_table.ct1_cvd01,
            df_input_table.ct1_cvd02,
            df_input_table.ct1_cvd03,
            df_input_table.ct1_cvd04,
            df_input_table.ct1_cvd05,
            df_input_table.ct1_cvc01,
            df_input_table.ct1_cvc02,
            df_input_table.ct1_cvc03,
            df_input_table.ct1_cvc04,
            df_input_table.ct1_cvc05,
            df_input_table.ct1_ctasup,
            df_input_table.ct1_hp,
            df_input_table.ct1_acitem,
            df_input_table.ct1_accust,
            df_input_table.ct1_acclvl,
            df_input_table.ct1_dtexis,
            df_input_table.ct1_ctavm,
            df_input_table.ct1_ctared,
            df_input_table.ct1_dtexsf,
            df_input_table.ct1_moedvm,
            df_input_table.ct1_ctalp,
            df_input_table.ct1_ctapon,
            df_input_table.ct1_book,
            df_input_table.ct1_grupo,
            df_input_table.ct1_aglsld,
            df_input_table.ct1_rgnv1,
            df_input_table.ct1_rgnv2,
            df_input_table.ct1_rgnv3,
            df_input_table.ct1_ccobrg,
            df_input_table.ct1_itobrg,
            df_input_table.ct1_clobrg,
            df_input_table.ct1_trnsef,
            df_input_table.ct1_ctlalu,
            df_input_table.ct1_tplalu,
            df_input_table.ct1_aglut,
            df_input_table.ct1_lalur,
            df_input_table.ct1_lalhir,
            df_input_table.ct1_rateio,
            df_input_table.ct1_estour,
            df_input_table.ct1_codimp,
            df_input_table.ct1_aj_inf,
            df_input_table.ct1_natcta,
            df_input_table.ct1_diops,
            df_input_table.ct1_acativ,
            df_input_table.ct1_atobrg,
            df_input_table.ct1_acet05,
            df_input_table.ct1_05obrg,
            df_input_table.ct1_indnat,
            df_input_table.ct1_spedst,
            df_input_table.ct1_ntsped,
            df_input_table.ct1_acat01,
            df_input_table.ct1_at01ob,
            df_input_table.ct1_acat02,
            df_input_table.ct1_at02ob,
            df_input_table.ct1_acat03,
            df_input_table.ct1_at03ob,
            df_input_table.ct1_acat04,
            df_input_table.ct1_at04ob,
            df_input_table.ct1_tpo01,
            df_input_table.ct1_tpo02,
            df_input_table.ct1_tpo03,
            df_input_table.ct1_tpo04,
            df_input_table.ct1_intp,
            df_input_table.ct1_pvarc,
            df_input_table.ct1_acet06,
            df_input_table.ct1_06obrg,
            df_input_table.ct1_acet07,
            df_input_table.ct1_07obrg,
            df_input_table.ct1_acet08,
            df_input_table.ct1_08obrg,
            df_input_table.ct1_acet09,
            df_input_table.ct1_09obrg,
            df_input_table.ct1_userga,
            df_input_table.ct1_usergi,
            f.date_format(f.current_timestamp(), 'yyyyMMddHHmmss').alias('infa_ext_dt')
        )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPROTETL()
    trl.execute()
