# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    14-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_conf_stk_mvt_all into conform zone
# Author        :- Tingting Wan
# Date          :- 16-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql import DataFrame
from functools import reduce


class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 12:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 12")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'country',
                                   'country_database',
                                   'country_grpid',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_isp_conf_stk_mvt_stock_movement"
        self.report_file = "l3_isp_conf_stk_mvt_all"

        # generic variables  ===========================================
        self.country = args['country']
        self.country_database = args['country_database']
        self.country_grpid = args['country_grpid']

        # Generate list of countries for which JOB need to be run
        self.country_list = self.country.split(",")

        # Create country and database and work group id map
        self.country_database_map = dict(map(lambda x: x.split('='), self.country_database.split(',')))
        self.country_grpid_map = dict(map(lambda x: x.split('='), self.country_grpid.split('|')))

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))
        # print('it will process {} countries'.format(self.country_list))
        # print('it will process {} countries databases'.format(self.country_database_map))

    def execute(self):
        # create list of Transform Latest dataframes
        tran_latest_dfs = []

        # process country wise data
        for country in self.country_list:
            # get country database and table
            country_database = self.source_database + "_" + self.country_database_map[country]
            country_grpid = list(map(str, self.country_grpid_map[country].split(",")))
            # print('it will process {} grpids'.format(country_grpid))
            country_table = self.input_table + "_" + country

            # read data from country specific table argument passed(database, table)
            df_input_table = self._get_table(country_database, country_table).toDF()
            # print("data count of table {}.{} is {}".format(country_database, country_table, df_input_table.count()))

            # apply transformation on the dataframe argument passed(dataframe, country)
            df_tfx_table = self._apply_tfx(country, country_grpid, df_input_table)
            # print("data count after transformation ", df_tfx_table.count())

            # union country specific dataframes to get data for all the countries
            tran_latest_dfs.append(df_tfx_table)

            # unionByName all Transform Latest dataframes ONCE outside for loop. Removed the head() operation too.
            # distinct() is moved out of loop into write_results() method
            final_result_df = reduce(DataFrame.unionByName, tran_latest_dfs)

        # write final result to required destination
        self.write_results(final_result_df)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .distinct() \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    def _apply_tfx(self, country, country_grpid, df_input_table):

        # convert all the columns alias to lower case
        df_input_table = df_input_table.select([f.col(x).alias(x.lower()) for x in df_input_table.columns])

        if country == 'fr':
            df_tfx_result = df_input_table.select(
                df_input_table.id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.id).alias('ref_id'),
                df_input_table.cab_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.cab_id).alias('fk_cab_id'),
                df_input_table.mtl_art_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.mtl_art_id).alias('fk_mtl_art_id'),
                df_input_table.curcy_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.curcy_id).alias('fk_curcy_id'),
                df_input_table.stk_mvt_type_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.stk_mvt_type_id).alias('fk_stk_mvt_type_id'),
                df_input_table.stk_mvt_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.stk_mvt_id).alias('fk_stk_mvt_id'),
                df_input_table.actl_dlvy_date.cast("date"),
                df_input_table.loc_of_mvt_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.loc_of_mvt_id).alias('fk_loc_of_mvt_id'),
                df_input_table.loc_actl_temp.cast("double"),
                df_input_table.loc_actl_vol.cast("double"),
                df_input_table.loc_std_vol.cast("double"),
                df_input_table.loc_wght.cast("double"),
                df_input_table.loc_wght_vac.cast("double"),
                df_input_table.loc_density.cast("double"),
                df_input_table.dlvy_note_num.cast('string'),
                df_input_table.loc_of_mvt_id_dest,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.loc_of_mvt_id_dest).alias(
                    'fk_loc_of_mvt_id_dest'),
                df_input_table.cont_dens.cast("double"),
                df_input_table.loc_of_sale_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.loc_of_sale_id).alias('fk_loc_of_sales_id'),
                df_input_table.ord_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.ord_id).alias('fk_ord_id'),
                df_input_table.tot_ord_qty_kg.cast("double"),
                df_input_table.tot_ord_qty_l.cast("double"),
                df_input_table.recvd_date.cast("date"),
                df_input_table.expc_dlvy_date.cast("date"),
                df_input_table.qty.cast("double"),
                df_input_table.uom_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.uom_id).alias('fk_uom_id'),
                df_input_table.sales_agmt_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.sales_agmt_id).alias('fk_sales_agmt_id'),
                df_input_table.work_grp_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.work_grp_id).alias('fk_work_grp_id'),
                df_input_table.stk_mvt_sales_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.stk_mvt_sales_id).alias(
                    'fk_stk_mvt_sales_id'),
                df_input_table.cust_acct_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.cust_acct_id).alias('fk_cust_acct_id'),
                df_input_table.ref_qty_l.cast("double"),
                df_input_table.ref_qty_kg.cast("double"),
                df_input_table.ord_num, df_input_table.inv_ind, df_input_table.ext_ord_ref,
                df_input_table.fuel_point_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.fuel_point_id).alias('fk_fuel_point_id'),
                df_input_table.port_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.port_id).alias('fk_port_id'),
                df_input_table.flight_number, df_input_table.acrft_reg_number,
                df_input_table.tot_dlvy_vol_l.cast("double"),
                df_input_table.tot_dlvy_vol_kg.cast("double"),
                df_input_table.tot_dlvy_vol_l_std.cast("double"),
                df_input_table.tot_dlvy_vol_kg_std.cast("double"),
                df_input_table.stkd_item_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.stkd_item_id).alias('fk_stkd_item_id'),
                df_input_table.base_uom_regime_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.base_uom_regime_id).alias(
                    'fk_base_uom_regime_id'),
                df_input_table.loc_actl_temp_uom_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.loc_actl_temp_uom_id).alias(
                    'fk_loc_actl_temp_uom_id'),
                df_input_table.loc_actl_vol_uom_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.loc_actl_vol_uom_id).alias(
                    'fk_loc_actl_vol_uom_id'),
                df_input_table.loc_density_uom_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.loc_density_uom_id).alias(
                    'fk_loc_density_uom_id'),
                df_input_table.loc_dry_vol_uom_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.loc_dry_vol_uom_id).alias(
                    'fk_loc_dry_vol_uom_id'),
                df_input_table.loc_std_vol_uom_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.loc_std_vol_uom_id).alias(
                    'fk_loc_std_vol_uom_id'),
                df_input_table.loc_wght_uom_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.loc_wght_uom_id).alias('fk_loc_wght_uom_id'),
                df_input_table.loc_wght_vac_uom_id,
                f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.loc_wght_vac_uom_id).alias(
                    'fk_loc_wght_vac_uom_id'),
                f.lit('ISP_ESP0166').alias('source_system'))

        else:
            df_tfx_result = df_input_table.select(
                df_input_table.id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.id).alias('ref_id'),
                df_input_table.cab_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.cab_id).alias('fk_cab_id'),
                df_input_table.mtl_art_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.mtl_art_id).alias('fk_mtl_art_id'),
                df_input_table.curcy_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.curcy_id).alias('fk_curcy_id'),
                df_input_table.stk_mvt_type_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.stk_mvt_type_id).alias(
                    'fk_stk_mvt_type_id'),
                df_input_table.stk_mvt_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.stk_mvt_id).alias('fk_stk_mvt_id'),
                df_input_table.actl_dlvy_date.cast("date"),
                df_input_table.loc_of_mvt_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.loc_of_mvt_id).alias(
                    'fk_loc_of_mvt_id'),
                df_input_table.loc_actl_temp.cast("double"),
                df_input_table.loc_actl_vol.cast("double"),
                df_input_table.loc_std_vol.cast("double"),
                df_input_table.loc_wght.cast("double"),
                df_input_table.loc_wght_vac.cast("double"),
                df_input_table.loc_density.cast("double"),
                df_input_table.dlvy_note_num.cast('string'),
                df_input_table.loc_of_mvt_id_dest,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.loc_of_mvt_id_dest).alias(
                    'fk_loc_of_mvt_id_dest'),
                df_input_table.cont_dens.cast("double"),
                df_input_table.loc_of_sale_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.loc_of_sale_id).alias(
                    'fk_loc_of_sales_id'),
                df_input_table.ord_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.ord_id).alias('fk_ord_id'),
                df_input_table.tot_ord_qty_kg.cast("double"),
                df_input_table.tot_ord_qty_l.cast("double"),
                df_input_table.recvd_date.cast("date"),
                df_input_table.expc_dlvy_date.cast("date"),
                df_input_table.qty.cast("double"),
                df_input_table.uom_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.uom_id).alias('fk_uom_id'),
                df_input_table.sales_agmt_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.sales_agmt_id).alias(
                    'fk_sales_agmt_id'),
                df_input_table.work_grp_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.work_grp_id).alias('fk_work_grp_id'),
                df_input_table.stk_mvt_sales_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.stk_mvt_sales_id).alias(
                    'fk_stk_mvt_sales_id'),
                df_input_table.cust_acct_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.cust_acct_id).alias(
                    'fk_cust_acct_id'),
                df_input_table.ref_qty_l.cast("double"),
                df_input_table.ref_qty_kg.cast("double"),
                df_input_table.ord_num, df_input_table.inv_ind, df_input_table.ext_ord_ref.cast('string'),
                df_input_table.fuel_point_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.fuel_point_id).alias(
                    'fk_fuel_point_id'),
                df_input_table.port_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.port_id).alias('fk_port_id'),
                df_input_table.flight_number, df_input_table.acrft_reg_number,
                df_input_table.tot_dlvy_vol_l.cast("double"),
                df_input_table.tot_dlvy_vol_kg.cast("double"),
                df_input_table.tot_dlvy_vol_l_std.cast("double"),
                df_input_table.tot_dlvy_vol_kg_std.cast("double"),
                df_input_table.stkd_item_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.stkd_item_id).alias(
                    'fk_stkd_item_id'),
                df_input_table.base_uom_regime_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.base_uom_regime_id).alias(
                    'fk_base_uom_regime_id'),
                df_input_table.loc_actl_temp_uom_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.loc_actl_temp_uom_id).alias(
                    'fk_loc_actl_temp_uom_id'),
                df_input_table.loc_actl_vol_uom_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.loc_actl_vol_uom_id).alias(
                    'fk_loc_actl_vol_uom_id'),
                df_input_table.loc_density_uom_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.loc_density_uom_id).alias(
                    'fk_loc_density_uom_id'),
                df_input_table.loc_dry_vol_uom_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.loc_dry_vol_uom_id).alias(
                    'fk_loc_dry_vol_uom_id'),
                df_input_table.loc_std_vol_uom_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.loc_std_vol_uom_id).alias(
                    'fk_loc_std_vol_uom_id'),
                df_input_table.loc_wght_uom_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.loc_wght_uom_id).alias(
                    'fk_loc_wght_uom_id'),
                df_input_table.loc_wght_vac_uom_id,
                f.concat(df_input_table.source_system, f.lit('_'), df_input_table.loc_wght_vac_uom_id).alias(
                    'fk_loc_wght_vac_uom_id'),
                df_input_table.source_system)

        df_tfx_result = self.df_filter(country, country_grpid, df_tfx_result)
        return df_tfx_result
        # filter

    def df_filter(self, country, country_grpid, df_tfx_result):
        # Flag to check if dataframe contains matching country.
        # If yes, we later apply an additional filter
        COUNTRY_MATCH = False
        if country == "uk":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                df_tfx_result.work_grp_id.isin(country_grpid))
        elif country == "gr":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                df_tfx_result.work_grp_id.isin(country_grpid))
        elif country == "aa":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                (df_tfx_result.work_grp_id.isin(country_grpid)))
        elif country == "cy":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                df_tfx_result.work_grp_id.isin(country_grpid))
        elif country == "me":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                df_tfx_result.work_grp_id.isin(country_grpid))
        elif country == "mz":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                df_tfx_result.work_grp_id.isin(country_grpid))
        elif country == "tr":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                df_tfx_result.work_grp_id.isin(country_grpid))
        elif country == "za":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                df_tfx_result.work_grp_id.isin(country_grpid))
        elif country == "fr":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                df_tfx_result.work_grp_id.isin(country_grpid))

        if COUNTRY_MATCH:
            df_tfx_result.createOrReplaceTempView('df_tfx_result')
            df_tfx_result = self._spark.sql('select * from df_tfx_result')
        # print("df_tfx_result after : ", df_tfx_result.count())

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()