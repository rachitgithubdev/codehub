# ================================Revision History=================================================
# #
#  Change Version,  Change Author,        Change Date,    Change Component
#  0.1              Tingting Wan          14-Jun-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to trigger the crawler once glue JOB is complete
# Author        :- Tingting Wan
# Date          :- 14-Jun-2021
# Version       :- 0.1
# AWS component :- Lambda and Glue Crawler
# ================================================================================================

import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

client = boto3.client('glue')


def lambda_handler(event, context):
    logger.info('Starting the crawler : {}'.format(event['crawler_name']))
    # start the crawler
    response = client.start_crawler(Name=event['crawler_name'])

    logger.info('started the crawler : {}'.format(event['crawler_name']))
    logger.info(json.dumps(response, indent=4))


