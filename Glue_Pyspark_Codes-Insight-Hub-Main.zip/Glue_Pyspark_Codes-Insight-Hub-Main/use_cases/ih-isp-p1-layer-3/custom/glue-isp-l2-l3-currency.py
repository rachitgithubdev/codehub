# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    14-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-isp-l2-l3-currency into conform zone
# Author        :- Bakul Seth
# Date          :- 11-Jan-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================
import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql import DataFrame
from functools import reduce


class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'country',
                                   'country_database',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l2_isp_currency"
        self.report_file = "l3_isp_currency_all"

        # generic variables  ===========================================
        self.country = args['country']
        self.country_database = args['country_database']

        # Generate list of countries for which JOB need to be run
        self.country_list = self.country.split(",")

        # Create country and database map
        self.country_database_map = dict(map(lambda x: x.split('='), self.country_database.split(',')))

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))
        # print('it will process {} countries'.format(self.country_list))
        # print('it will process {} countries databases'.format(self.country_database_map))

    def execute(self):
        tran_latest_dfs = []

        # process country wise data
        for country in self.country_list:
            # get country database and table
            country_database = self.source_database + "_" + self.country_database_map[country]
            country_table = self.input_table + "_" + country

            # read data from country specific table argument passed(database, table)
            df_input_table = self._get_table(country_database, country_table).toDF()
            # print("data count of table {}.{} is {}".format(country_database, country_table, df_input_table.count()))

            # apply transformation on the dataframe argument passed(dataframe, country)
            df_tfx_table = self._apply_tfx(df_input_table, country)
            # print("data count after transformation ", df_tfx_table.count())

            # Append each dataframe to list.
            tran_latest_dfs.append(df_tfx_table)

        # union country specific dataframes to get data for all the countries
        final_result_df = reduce(DataFrame.unionAll, tran_latest_dfs)
        print("data count after union All ", final_result_df.count())

        # write final result to required destination, move distinct() into write function
        self.write_results(final_result_df)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset.distinct() \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_input_table, country):

        # convert all the columns alias to lower case
        df_input_table = df_input_table.select([f.col(x).alias(x.lower()) for x in df_input_table.columns])

        if country == 'fr':
            df_tfx_result = df_input_table.groupBy(df_input_table.id, df_input_table.name, df_input_table.mnmc,
                                                   f.lit('ISP_ESP0166')).count() \
                .select(df_input_table.id, df_input_table.name, df_input_table.mnmc,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table.id).alias('ref_id'),
                        f.lit('ISP_ESP0166').alias('source_system'))
        # elif country == 'ch':
        #     df_tfx_result = df_input_table.groupBy(df_input_table.id, df_input_table.name, df_input_table.mnmc,
        #                                            f.lit('ISP_ESP0723')).count()\
        #         .select(df_input_table.id, df_input_table.name, df_input_table.mnmc,
        #                 f.lit('ISP_ESP0723').alias('source_system'),
        #                 f.concat(f.lit('ISP_ESP0723'), f.lit('_'), df_input_table.id).alias('ref_id'))
        else:
            df_tfx_result = df_input_table.groupBy(df_input_table.id, df_input_table.name, df_input_table.mnmc,
                                                   df_input_table.source_system).count() \
                .select(df_input_table.id, df_input_table.name, df_input_table.mnmc,
                        f.concat(df_input_table.source_system, f.lit('_'), df_input_table.id).alias('ref_id'),
                        df_input_table.source_system)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()
