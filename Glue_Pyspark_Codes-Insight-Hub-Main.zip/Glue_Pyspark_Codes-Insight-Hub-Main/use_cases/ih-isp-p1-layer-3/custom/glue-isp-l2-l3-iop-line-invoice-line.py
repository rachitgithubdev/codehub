# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Bakul Seth      14-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_iop_line_all into conform zone
# Author        :- Bakul Seth
# Date          :- 16-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================


import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql import DataFrame # Added
from functools import reduce # Added


class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 12:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 12")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'country',
                                   'country_database',
                                   'country_grpid',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l2_isp_iop_line_invoice_line','l2_isp_iop_head_invoice_header']
        self.report_file = "l3_isp_iop_line_all"

        # generic variables  ===========================================
        self.country = args['country']
        self.country_database = args['country_database']
        self.country_grpid = args['country_grpid']

        # Generate list of countries for which JOB need to be run
        self.country_list = self.country.split(",")

        # Create country and database and work group id map
        self.country_database_map = dict(map(lambda x: x.split('='), self.country_database.split(',')))
        self.country_grpid_map = dict(map(lambda x: x.split('='), self.country_grpid.split('|')))

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('it will process {} countries'.format(self.country_list))
        print('it will process {} tables'.format(self.input_table_list))

    def execute(self):
        # create list of Transform Latest dataframes
        tran_latest_dfs = [] # added

        # process country wise data
        for country in self.country_list:
            # get country database and table
            country_database = self.source_database + "_" + self.country_database_map[country]
            country_grpid = list(map(str, self.country_grpid_map[country].split(",")))
            #print('it will process {} grpids'.format(country_grpid))
            # generate input table list
            input_table_list = []
            for table in self.input_table_list:
                country_table = table + "_" + country
                input_table_list.append(country_table) #added
            #print("input table list is {}".format(input_table_list))

            # read data from country specific table argument passed(database, table)
            df_country_table_1 = self._get_table(country_database, input_table_list[0]).toDF()
            #print("data count of table {}.{} is {}".format(country_database, input_table_list[0],
            #                                               df_country_table_1.count()))
            df_country_table_2 = self._get_table(country_database, input_table_list[1]).toDF()
            #print("data count of table {}.{} is {}".format(country_database, input_table_list[1],
            #                                               df_country_table_2.count()))


            # apply transformation on the dataframe argument passed(dataframe, country)
            df_tfx_table = self._apply_tfx(country,country_grpid,df_country_table_1,df_country_table_2)
            #print("data count after transformation ", df_tfx_table.count())

            # union country specific dataframes to get data for all the countries
            tran_latest_dfs.append(df_tfx_table) # added

        # unionByName all Transform Latest dataframes ONCE outside for loop. Removed the head() operation too.
        # distinct() is moved out of loop into write_results() method
        final_result_df = reduce(DataFrame.unionByName, tran_latest_dfs) # added

        # write final result to required destination
        self.write_results(final_result_df)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .distinct() \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)


    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table


    def _apply_tfx(self, country, country_grpid, *args):

        # convert all the columns alias to lower case
        df_input_table_1 = args[0].select(
            [f.col(x).alias(x.lower()) for x in args[0].columns])
        df_input_table_2 = args[1].select(
            [f.col(x).alias(x.lower()) for x in args[1].columns])

        if country == 'fr':
            df_tfx_result = df_input_table_1.join(
                df_input_table_2, (f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.inv_id)) ==
                                  (f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_2.inv_id)))\
                .select(df_input_table_1.inv_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.inv_id).alias('ref_inv_id'),
                        df_input_table_1.item_num, df_input_table_1.item_seq_num, df_input_table_1.inv_seq_num,
                        df_input_table_1.iop_line_type_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.iop_line_type_id).alias(
                            'fk_iop_line_type_id'),
                        df_input_table_1.item_mnmc, df_input_table_1.item_descn,
                        df_input_table_1.invg_val.cast('double').alias('invg_val'),
                        df_input_table_1.qty.cast('double').alias('qty'), df_input_table_1.uom_mnmc,
                        df_input_table_1.uom_name,
                        df_input_table_1.unit_prc_invg.alias('double').alias('unit_prc_invg'),
                        df_input_table_1.std_dens.cast('double').alias('std_dens'),
                        df_input_table_1.dlvy_temp.cast('double').alias('dlvy_temp'),
                        df_input_table_1.dlvd_qty_vol.cast('double').alias('dlvd_qty_vol'),
                        df_input_table_1.dlvd_qty_wt.cast('double').alias('dlvd_qty_wt'),
                        df_input_table_1.stk_mvt_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.stk_mvt_id).alias('fk_stk_mvt_id'),
                        f.to_timestamp(df_input_table_1.dlvd_date_time, "yyyy-MM-dd HH:mm:ss").alias('dlvd_date_time'),
                        df_input_table_1.mode_of_trnspt, df_input_table_1.loc_of_mvt_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.loc_of_mvt_id).alias('fk_loc_of_mvt_id'),
                        df_input_table_1.loc_of_mvt_name, df_input_table_1.work_grp_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.work_grp_id).alias('fk_work_grp_id'),
                        df_input_table_1.actl_dens.cast('double').alias('actl_dens'),
                        df_input_table_1.base_dens.cast('double').alias('base_dens'),
                        df_input_table_1.dlvy_num.cast('string'), df_input_table_1.los_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.los_id).alias('fk_los_id'),
                        df_input_table_1.los_name, df_input_table_1.ord_ref,
                        df_input_table_1.dlvd_wt_vac.cast('double').alias('dlvd_wt_vac'),
                        df_input_table_1.invg_val_disp_exc_vat.cast('double').alias('invg_val_disp_exc_vat'),
                        df_input_table_1.base_qty.cast('double').alias('base_qty'), df_input_table_1.base_uom_mnmc,
                        df_input_table_1.base_uom_name,
                        df_input_table_1.mtl_art_id.alias('mtl_art_id'),
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.mtl_art_id).alias('fk_mtl_art_id'),
                        df_input_table_1.art_type_id, df_input_table_1.acrft_reg_number.alias('acrft_reg_number'),
                        df_input_table_1.aircraft_type_name.alias('aircraft_type_name'),
                        df_input_table_1.flight_number.alias('flight_number'),
                        df_input_table_1.commodity_code.alias('commodity_code'),
                        df_input_table_1.stkd_item_mnmc.alias('stkd_item_mnmc'),
                        df_input_table_1.stkd_item_descn.alias('stkd_item_descn'),
                        df_input_table_1.loc_dest_id.alias('loc_dest_id'),
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_1.loc_dest_id).alias('fk_loc_dest_id'),
                        df_input_table_1.los_mnmc.alias('los_mnmc'),
                        f.to_timestamp(df_input_table_1.crt_date_time, "yyyy-MM-dd HH:mm:ss").alias('crt_date_time'),
                        df_input_table_1.fuel_point_name, f.lit('ISP_ESP0166').alias('source_system'),
                        df_input_table_2.bp_cmpy_id)

        else:
            df_tfx_result = df_input_table_1.join(
                df_input_table_2, (f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.inv_id)) ==
                                  (f.concat(df_input_table_2.source_system, f.lit('_'), df_input_table_2.inv_id)))\
                .select(df_input_table_1.inv_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.inv_id).alias('ref_inv_id'),
                        df_input_table_1.item_num, df_input_table_1.item_seq_num, df_input_table_1.inv_seq_num,
                        df_input_table_1.iop_line_type_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.iop_line_type_id).alias(
                            'fk_iop_line_type_id'),
                        df_input_table_1.item_mnmc, df_input_table_1.item_descn,
                        df_input_table_1.invg_val.cast('double').alias('invg_val'),
                        df_input_table_1.qty.cast('double').alias('qty'), df_input_table_1.uom_mnmc,
                        df_input_table_1.uom_name,
                        df_input_table_1.unit_prc_invg.alias('double').alias('unit_prc_invg'),
                        df_input_table_1.std_dens.cast('double').alias('std_dens'),
                        df_input_table_1.dlvy_temp.cast('double').alias('dlvy_temp'),
                        df_input_table_1.dlvd_qty_vol.cast('double').alias('dlvd_qty_vol'),
                        df_input_table_1.dlvd_qty_wt.cast('double').alias('dlvd_qty_wt'),
                        df_input_table_1.stk_mvt_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.stk_mvt_id).alias('fk_stk_mvt_id'),
                        f.to_timestamp(df_input_table_1.dlvd_date_time, "yyyy-MM-dd HH:mm:ss").alias('dlvd_date_time'),
                        df_input_table_1.mode_of_trnspt, df_input_table_1.loc_of_mvt_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.loc_of_mvt_id).alias('fk_loc_of_mvt_id'),
                        df_input_table_1.loc_of_mvt_name, df_input_table_1.work_grp_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.work_grp_id).alias('fk_work_grp_id'),
                        df_input_table_1.actl_dens.cast('double').alias('actl_dens'),
                        df_input_table_1.base_dens.cast('double').alias('base_dens'),
                        df_input_table_1.dlvy_num.cast('string'), df_input_table_1.los_id,
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.los_id).alias('fk_los_id'),
                        df_input_table_1.los_name, df_input_table_1.ord_ref,
                        df_input_table_1.dlvd_wt_vac.cast('double').alias('dlvd_wt_vac'),
                        df_input_table_1.invg_val_disp_exc_vat.cast('double').alias('invg_val_disp_exc_vat'),
                        df_input_table_1.base_qty.cast('double').alias('base_qty'), df_input_table_1.base_uom_mnmc,
                        df_input_table_1.base_uom_name,
                        df_input_table_1.mtl_art_id.alias('mtl_art_id'),
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.mtl_art_id).alias('fk_mtl_art_id'),
                        df_input_table_1.art_type_id, df_input_table_1.acrft_reg_number.alias('acrft_reg_number'),
                        df_input_table_1.aircraft_type_name.alias('aircraft_type_name'),
                        df_input_table_1.flight_number.alias('flight_number'),
                        df_input_table_1.commodity_code.alias('commodity_code'),
                        df_input_table_1.stkd_item_mnmc.alias('stkd_item_mnmc'),
                        df_input_table_1.stkd_item_descn.alias('stkd_item_descn'),
                        df_input_table_1.loc_dest_id.alias('loc_dest_id'),
                        f.concat(df_input_table_1.source_system, f.lit('_'), df_input_table_1.loc_dest_id).alias('fk_loc_dest_id'),
                        df_input_table_1.los_mnmc.alias('los_mnmc'),
                        f.to_timestamp(df_input_table_1.crt_date_time, "yyyy-MM-dd HH:mm:ss").alias('crt_date_time'),
                        df_input_table_1.fuel_point_name, df_input_table_1.source_system,
                        df_input_table_2.bp_cmpy_id)
        
        cols = ('bp_cmpy_id', 'country_grpid')
        df_tfx_result = self.df_filter(country, country_grpid, df_tfx_result).drop(df_tfx_result.bp_cmpy_id)
        return df_tfx_result    

    def df_filter(self, country, country_grpid, df_tfx_result):
            # Flag to check if dataframe contains matching country.
            # If yes, we later apply an additional filter
        COUNTRY_MATCH = False
        if country == "uk":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000324'))
        elif country == "gr":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin(
                        '10000000142'))
        elif country == "aa":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin(
                        '10000000324', '10000000142',
                        '97010000000013',
                        '10000000396',
                        '10000000072',
                        '10000000411',
                        '10000000905',
                        '10000000703',
                        '10000000234',
                        '10000000422',
                        '10000000057',
                        '97010000000001') == False)
        elif country == "cy":
            COUNTRY_MATCH = True
            df_tfx_result =  df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000703'))
        elif country == "me":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000396',
                                                                                                       '10000000072',
                                                                                                       '10000000411',
                                                                                                       '10000000905'))
        elif country == "mz":
            COUNTRY_MATCH = True
            df_tfx_result =  df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000422'))
        elif country == "tr":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000234'))
        elif country == "za":
            COUNTRY_MATCH = True
            df_tfx_result =  df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('10000000057'))
        elif country == "fr":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin('97010000000013'))
            
        if COUNTRY_MATCH:
            df_tfx_result.createOrReplaceTempView('df_tfx_result')
            df_tfx_result = self._spark.sql('select * from df_tfx_result')
        

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()
