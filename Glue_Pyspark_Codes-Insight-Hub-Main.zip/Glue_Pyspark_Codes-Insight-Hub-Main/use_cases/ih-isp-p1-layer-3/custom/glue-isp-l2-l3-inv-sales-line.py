# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    14-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate l3_isp_inv_sales_line_all into conform zone
# Author        :- Tingting Wan
# Date          :- 16-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================


import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from pyspark.sql import DataFrame
from functools import reduce


class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)
		# self._spark.conf.set("spark.sql.files.maxRecordsPerFile", 2000000)
        # self._spark.conf.set("spark.sql.shuffle.partitions", 12)

        # Command line argument verification
        if str(sys.argv).count('--') != 12:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 12")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'country',
                                   'country_database',
                                   'country_grpid',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l2_isp_inv_sales_header','l2_isp_inv_sales_line','l2_isp_port_plant']
        self.report_file = "l3_isp_inv_sales_line_all"

        # generic variables  ===========================================
        self.country = args['country']
        self.country_database = args['country_database']
        self.country_grpid = args['country_grpid']

        # Generate list of countries for which JOB need to be run
        self.country_list = self.country.split(",")

        # Create country and database and work group id map
        self.country_database_map = dict(map(lambda x: x.split('='), self.country_database.split(',')))
        self.country_grpid_map = dict(map(lambda x: x.split('='), self.country_grpid.split('|')))

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('it will process {} countries'.format(self.country_list))
        print('it will process {} tables'.format(self.input_table_list))

    def execute(self):
        tran_latest_dfs = []

        # process country wise data
        for country in self.country_list:
            # get country database and table
            country_database = self.source_database + "_" + self.country_database_map[country]
            country_grpid = list(map(str, self.country_grpid_map[country].split(",")))
            print('it will process {} grpids'.format(country_grpid))

            # generate input table list
            input_table_list = []
            for table in self.input_table_list:
                country_table = table + "_" + country
                input_table_list.append(country_table)
            print("input table list is {}".format(input_table_list))

            # read data from country specific table argument passed(database, table)
            df_country_table_header = self._get_table(country_database, input_table_list[0]).toDF()

            df_country_table_line = self._get_table(country_database, input_table_list[1]).toDF()

            df_country_table_port = self._get_table(country_database, input_table_list[2]).toDF()

            # apply transformation on the dataframe argument passed(dataframe, country)
            df_tfx_table = self._apply_tfx(country,country_grpid, df_country_table_header,df_country_table_line,df_country_table_port)

            # Append each dataframe to list.
            tran_latest_dfs.append(df_tfx_table)


        final_result_df = reduce(DataFrame.unionByName, tran_latest_dfs)
        #print("Final Write", final_result_df.count())
        # write final result to required destination
        self.write_results(final_result_df)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .distinct() \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    def _apply_tfx(self, country, country_grpid, *args):

        # convert all the columns alias to lower case
        df_input_table_header = args[0].select(
            [f.col(x).alias(x.lower()) for x in args[0].columns])
        df_input_table_line = args[1].select(
            [f.col(x).alias(x.lower()) for x in args[1].columns])
        df_input_table_port = args[2].select(
            [f.col(x).alias(x.lower()) for x in args[2].columns])
        

        if country == 'fr':
            df_tfx_result = df_input_table_line.join(df_input_table_header,
                                                     (f.concat(f.lit('ISP_ESP0166'),
                                                             f.lit('_'),
                                                             df_input_table_line.inv_sales_id))
                                                     == (f.concat(f.lit('ISP_ESP0166'),
                                                                f.lit('_'),
                                                                df_input_table_header.id))) \
                .select(df_input_table_line.inv_sales_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                               df_input_table_line.inv_sales_id).alias('fk_inv_sales_id'),
                        df_input_table_line.seq_num, df_input_table_line.art_name,
                        df_input_table_line.val_invg.cast('double').alias('val_invg'),
                        df_input_table_line.price_line_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                               df_input_table_line.price_line_id).alias(
                            'fk_price_line_id'),
                        df_input_table_line.dlvy_note_num,
                        df_input_table_line.loc_of_sale_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                               df_input_table_line.loc_of_sale_id).alias('fk_loc_of_sales_id'),
                        df_input_table_line.mtl_art_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                               df_input_table_line.mtl_art_id).alias(
                            'fk_mtl_art_id'),
                        df_input_table_line.sales_agmt_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                               df_input_table_line.sales_agmt_id).alias(
                            'fk_sales_agmt_id'),
                        df_input_table_line.uom_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_line.uom_id).alias(
                            'fk_uom_id'),
                        df_input_table_line.work_grp_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                               df_input_table_line.work_grp_id).alias(
                            'fk_work_grp_id'),
                        df_input_table_line.conf_stk_mvt_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                               df_input_table_line.conf_stk_mvt_id).alias(
                            'fk_conf_stk_mvt_id'),
                        df_input_table_line.price_invg.cast('double').alias('price_invg'),
                        df_input_table_line.curcy_id_prcg,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                               df_input_table_line.curcy_id_prcg).alias(
                            'fk_curcy_id_prcg'),
                        df_input_table_line.gross_val_invg.cast('double').alias('gross_val_invg'),
                        df_input_table_line.gross_val_local.cast('double').alias('gross_val_local'),
                        df_input_table_line.ord_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'), df_input_table_line.ord_id).alias(
                            'fk_ord_id'),
                        df_input_table_line.crt_date_time.cast('timestamp').alias('crt_date_time'),
                        df_input_table_line.cust_refnc,
                        df_input_table_line.fuel_point_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                               df_input_table_line.fuel_point_id).alias(
                            'fk_fuel_point_id'),
                        df_input_table_line.acrft_reg_number,
                        df_input_table_line.flight_number,
                        df_input_table_line.actl_dlvy_date.cast('date').alias('actl_dlvy_date'),
                        df_input_table_line.suspended_ind,
                        df_input_table_line.stkd_item_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                               df_input_table_line.stkd_item_id).alias(
                            'fk_stkd_item_id'),
                        df_input_table_line.actl_dlvy_date_time.cast('timestamp').alias('actl_dlvy_date_time'),
                        df_input_table_line.fixed_amt.cast('double').alias('fixed_amt'),
                        df_input_table_line.loc_std_vol.cast('double').alias('loc_std_vol'),
                        df_input_table_line.loc_std_vol_uom_id,
                        f.concat(f.lit('ISP_ESP0166'), f.lit('_'),
                               df_input_table_line.loc_std_vol_uom_id).alias(
                            'fk_loc_std_vol_uom_id'),
                        f.lit('ISP_ESP0166').alias('source_system'),
                        df_input_table_line.dest_port_id.alias('dest_port_id'),
                        df_input_table_header.bp_cmpy_id,
                        df_input_table_header.work_grp_id.alias('header_work_grp_id'))

        else:
            df_tfx_result = df_input_table_line.join(df_input_table_header,
                                                     (f.concat(df_input_table_line.source_system,
                                                             f.lit('_'),
                                                             df_input_table_line.inv_sales_id))
                                                     == (f.concat(df_input_table_header.source_system,
                                                                f.lit('_'),
                                                                df_input_table_header.id))) \
                .select(df_input_table_line.inv_sales_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'),
                               df_input_table_line.inv_sales_id).alias('fk_inv_sales_id'),
                        df_input_table_line.seq_num, df_input_table_line.art_name,
                        df_input_table_line.val_invg.cast('double').alias('val_invg'),
                        df_input_table_line.price_line_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'),
                               df_input_table_line.price_line_id).alias(
                            'fk_price_line_id'),
                        df_input_table_line.dlvy_note_num,
                        df_input_table_line.loc_of_sale_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'),
                               df_input_table_line.loc_of_sale_id).alias('fk_loc_of_sales_id'),
                        df_input_table_line.mtl_art_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'),
                               df_input_table_line.mtl_art_id).alias(
                            'fk_mtl_art_id'),
                        df_input_table_line.sales_agmt_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'),
                               df_input_table_line.sales_agmt_id).alias(
                            'fk_sales_agmt_id'),
                        df_input_table_line.uom_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'), df_input_table_line.uom_id).alias(
                            'fk_uom_id'),
                        df_input_table_line.work_grp_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'),
                               df_input_table_line.work_grp_id).alias(
                            'fk_work_grp_id'),
                        df_input_table_line.conf_stk_mvt_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'),
                               df_input_table_line.conf_stk_mvt_id).alias(
                            'fk_conf_stk_mvt_id'),
                        df_input_table_line.price_invg.cast('double').alias('price_invg'),
                        df_input_table_line.curcy_id_prcg,
                        f.concat(df_input_table_line.source_system, f.lit('_'),
                               df_input_table_line.curcy_id_prcg).alias(
                            'fk_curcy_id_prcg'),
                        df_input_table_line.gross_val_invg.cast('double').alias('gross_val_invg'),
                        df_input_table_line.gross_val_local.cast('double').alias('gross_val_local'),
                        df_input_table_line.ord_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'), df_input_table_line.ord_id).alias(
                            'fk_ord_id'),
                        df_input_table_line.crt_date_time.cast('timestamp').alias('crt_date_time'),
                        df_input_table_line.cust_refnc,
                        df_input_table_line.fuel_point_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'),
                               df_input_table_line.fuel_point_id).alias(
                            'fk_fuel_point_id'),
                        df_input_table_line.acrft_reg_number,
                        df_input_table_line.flight_number,
                        df_input_table_line.actl_dlvy_date.cast('date').alias('actl_dlvy_date'),
                        df_input_table_line.suspended_ind,
                        df_input_table_line.stkd_item_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'),
                               df_input_table_line.stkd_item_id).alias(
                            'fk_stkd_item_id'),
                        df_input_table_line.actl_dlvy_date_time.cast('timestamp').alias('actl_dlvy_date_time'),
                        df_input_table_line.fixed_amt.cast('double').alias('fixed_amt'),
                        df_input_table_line.loc_std_vol.cast('double').alias('loc_std_vol'),
                        df_input_table_line.loc_std_vol_uom_id,
                        f.concat(df_input_table_line.source_system, f.lit('_'),
                               df_input_table_line.loc_std_vol_uom_id).alias(
                            'fk_loc_std_vol_uom_id'),
                        df_input_table_line.source_system,
                        df_input_table_line.dest_port_id.alias('dest_port_id'),
                        df_input_table_header.bp_cmpy_id,
                        df_input_table_header.work_grp_id.alias('header_work_grp_id'))

        # drop bp_cmpy_id and dest_port_id and header_work_grp_id after filter
        cols = ('bp_cmpy_id', 'dest_port_id', 'header_work_grp_id')
        df_tfx_result = self.df_filter(country, country_grpid, df_input_table_port, df_tfx_result).drop(*cols)
        return df_tfx_result


    def df_filter(self, country, country_grpid, df_input_table_port, df_tfx_result):

        COUNTRY_MATCH = False

        if country == "uk":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.header_work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin(
                        '10000000324'))
        elif country == "gr":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.header_work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin(
                        '10000000142'))
        elif country == "aa":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    (df_tfx_result.header_work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin(
                        '10000000324', '10000000142',
                        '97010000000013',
                        '10000000396',
                        '10000000072',
                        '10000000411',
                        '10000000905',
                        '10000000703',
                        '10000000234',
                        '10000000422',
                        '10000000057',
                        '97010000000001') == False))
        elif country == "cy":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.header_work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin(
                        '10000000703'))
        elif country == "me":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.header_work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin(
                        '10000000396',
                        '10000000072',
                        '10000000411',
                        '10000000905'))
        elif country == "mz":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.header_work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin(
                        '10000000422'))
        elif country == "tr":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.header_work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin(
                        '10000000234'))
        elif country == "za":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.header_work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin(
                        '10000000057'))
        elif country == "fr":
            COUNTRY_MATCH = True
            df_tfx_result = df_tfx_result.filter(
                    df_tfx_result.header_work_grp_id.isin(country_grpid) & df_tfx_result.bp_cmpy_id.isin(
                        '97010000000013'))


        if COUNTRY_MATCH:
            df_tfx_result.createOrReplaceTempView('df_tfx_result')
            df_input_table_port.createOrReplaceTempView('df_input_table_port')
            df_tfx_result = self._spark.sql('select * from df_tfx_result where dest_port_id in (select id from df_input_table_port) or dest_port_id is null')

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()
