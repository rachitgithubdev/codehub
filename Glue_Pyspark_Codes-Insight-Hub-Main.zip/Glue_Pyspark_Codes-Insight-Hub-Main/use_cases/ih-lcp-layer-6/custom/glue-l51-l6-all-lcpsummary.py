# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Tingting Wan    18-Jan-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to l51-l6-all-lcpsummary into conform zone
# Author        :- Tingting Wan
# Date          :- 18-Dec-2020
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
import boto3
import json

class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database1']
        self.netapp_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l51_summary','l4_location_mapping_isp','l4_dim_location',
                                 'l4_isp_dim_location','l2_l5_dim_org_hierarchy_geography']
        self.report_file = "l6_all_lcpsummary"

        # print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and {}.{}* write it to {}'.format(self.source_database,
        #                                                                         self.input_table_list[0:3],
        #                                                                         self.netapp_database,
        #                                                                         self.input_table_list[4],
        #                                                                         self.destination_bucket))

    def execute(self):

        # generate input table list
        source_database = self.source_database
        netapp_database = self.netapp_database
        input_table_list = self.input_table_list
        #print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, input_table_list[0]).toDF()
        print("data count of table {}.{} is {}".format(source_database, input_table_list[0],
                                                       df_table_1.count()))
        df_table_2 = self._get_table(source_database, input_table_list[1]).toDF()
        print("data count of table {}.{} is {}".format(source_database, input_table_list[1],
                                                       df_table_2.count()))
        df_table_3 = self._get_table(source_database, input_table_list[2]).toDF()
        print("data count of table {}.{} is {}".format(source_database, input_table_list[2],
                                                       df_table_3.count()))
        df_table_4 = self._get_table(source_database, input_table_list[3]).toDF()
        print("data count of table {}.{} is {}".format(source_database, input_table_list[3],
                                                       df_table_4.count()))
        df_table_5 = self._get_table(netapp_database, input_table_list[4]).toDF()
        print("data count of table {}.{} is {}".format(netapp_database, input_table_list[4],
                                                       df_table_5.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2,
                                       df_table_3, df_table_4,
                                       df_table_5)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)
        
        print(" Invoking of Detokenization Process Started")
        eb_client = boto3.client('events')

        subtenant_id = 'aviation'
        source_glue_db_name = 'enrich_main_aviation_insight_hub'
        source_glue_table_name = 'l6_all_lcpsummary'
        detok_app_name = 'l6_all_lcpsummary'

        app_data_id = f'{subtenant_id}/{source_glue_db_name}/{source_glue_table_name}/{detok_app_name}'

        resp = eb_client.put_events(
            Entries=[
                {
                    'Source': 'com.bp.datahub.detok',
                    'DetailType': 'invoke_detok',
                    'Detail': json.dumps({'app_data_id': app_data_id}),
                    'EventBusName': f'subtenant-{subtenant_id}'
                }
            ]
        )
        
        print(" Invoking of Detokenization Process Completed")

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table\
            .write.option("compression", "snappy")\
            .mode('overwrite')\
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):

        # convert all the columns alias to lower case
        df_input_table_A = args[0].select(
            [f.col(x).alias(x.lower()) for x in args[0].columns])
        df_input_table_B = args[1].select(
            [f.col(x).alias(x.lower()) for x in args[1].columns])
        df_input_table_D = args[2].select(
            [f.col(x).alias(x.lower()) for x in args[2].columns])
        df_input_table_F = args[3].select(
            [f.col(x).alias(x.lower()) for x in args[3].columns])
        df_input_table_H = args[4].select(
            [f.col(x).alias(x.lower()) for x in args[4].columns])

        # join inner dataframes
        df_table_inner = df_input_table_A \
            .join(df_input_table_B,
                  (f.trim(df_input_table_A.trx_loc_key.substr(13, 14)) == df_input_table_B.isp_mapping)
                  & (df_input_table_A.source_system == 'ISP'), 'left') \
            .join(df_input_table_D, df_input_table_D.locationid == (
            f.when(df_input_table_A.source_system == 'ISP', df_input_table_B.location_id)
                .otherwise(f.lit('1'))), 'left') \
            .join(df_input_table_F, df_input_table_F.ref_id == (
            f.when(df_input_table_A.source_system == 'ISP', df_input_table_A.trx_loc_key)
                .otherwise(f.lit('1'))), 'left') \
            .join(df_input_table_H, df_input_table_H.iso_code_2 == (
            f.when(df_input_table_A.source_system == 'ISP', df_input_table_F.country_iso2)
                .otherwise(f.lit('1'))), 'left') \
            .select(df_input_table_A.source_system.alias('source_system'),
                    df_input_table_A.pricing_date.alias('calendar_date'),
                    df_input_table_A.billing_date.alias('billing_date'),
                    df_input_table_A.delivery_date.alias('delivery_date'),
                    f.when(df_input_table_D.pu.isNull(), df_input_table_H.pu)
                    .otherwise(df_input_table_D.pu).alias('pu'),
                    f.when((df_input_table_A.source_system == 'PRE') &
                           df_input_table_A.trx_loc_key.isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                             '5732',
                                                             '9280', '5527') &
                           df_input_table_A.sales_organisation.isin('DE01', 'AT0H'), f.lit('Continental Europe'))
                    .when((df_input_table_A.source_system == 'PRE') &
                          df_input_table_A.trx_loc_key.isin('5P36', '5P39', '5604', '2201', '5816', '5819', '5629',
                                                            '5732',
                                                            '9280', '5527') &
                          (df_input_table_A.sales_organisation.isin('DE01', 'AT0H') == False), f.lit('UK & Nordics'))
                    .when(df_input_table_D.cluster.isNull() & (df_input_table_A.source_system == 'PR4_HIST'),
                          f.lit('N America'))
                    .when(df_input_table_D.cluster.isNull(), df_input_table_H.cluster)
                    .otherwise(df_input_table_D.cluster).alias('cluster'),
                    f.when(df_input_table_D.location_country == 'PORTUGAL/AZORES', f.lit('PORTUGAL'))
                    .when(df_input_table_D.location_country == 'SPAIN/CANARY ISLANDS', f.lit('SPAIN'))
                    .when(df_input_table_D.location_country.isNull(), df_input_table_H.country)
                    .otherwise(df_input_table_D.location_country).alias('country'),
                    df_input_table_A.customer_country.alias('customer_country'),
                    df_input_table_A.grn_header.alias('global_ref_num'),
                    df_input_table_A.cc_grn.alias('cc_grn'),
                    df_input_table_A.customer_account_name.alias('cust_acct_name'),
                    df_input_table_A.grn.alias('global_acct_ref_num'),
                    df_input_table_A.account_manager.alias('account_holder_name'),
                    f.when(f.trim(df_input_table_A.sector).isNull(), f.lit(''))
                    .otherwise(df_input_table_A.sector).alias('sector'),
                    df_input_table_A.sales_organisation.alias('sales_organization'),
                    f.when(df_input_table_D.iata.isNotNull(),
                           f.concat(df_input_table_D.iata, f.lit('-'), df_input_table_D.location_name))
                    .when(df_input_table_D.iata.isNull() & df_input_table_D.icao.isNull() & (
                                df_input_table_A.source_system == 'ISP')
                          & df_input_table_D.location_name.isNull(),
                          f.concat(f.lit('@'), df_input_table_F.location_name))
                    .otherwise(df_input_table_D.location_name).alias('plant'),
                    df_input_table_A.material_description.alias('material_description'),
                    f.when((f.month(f.current_date()) > f.lit(3)) &
                           (f.year(df_input_table_A.billing_date) < (f.year(f.current_date()) - 1)) &
                           (f.year(df_input_table_A.delivery_date) < (f.year(f.current_date()) - 1)), f.lit(None))
                    .when((f.month(f.current_date()) <= f.lit(3)) &
                          (f.year(df_input_table_A.billing_date) < (f.year(f.current_date()) - 2)) &
                          (f.year(df_input_table_A.delivery_date) < (f.year(f.current_date()) - 2)), f.lit(None))
                    .otherwise(df_input_table_A.billing_document).alias('billing_document'),
                    f.when(df_input_table_A.source_system == 'ISP',
                           f.trim(df_input_table_A.payer.substr(f.lit(13), f.length(df_input_table_A.payer))))
                    .otherwise(df_input_table_A.payer).alias('ib_global_cust_ref'),
                    f.when(df_input_table_A.source_system == 'ISP',
                           f.trim(df_input_table_A.soldto_party.substr(f.lit(13),
                                                                       f.length(df_input_table_A.soldto_party))))
                    .otherwise(df_input_table_A.soldto_party).alias('sold_to_party'),
                    df_input_table_A.local_currency.alias('local_currency'),
                    f.date_format(df_input_table_A.last_modified_date.cast('date'), 'dd-MM-yyyy HH:mm:ss').cast(
                        'string').alias(
                        'last_modified_date'),
                    f.when(df_input_table_D.location_name.isNull() & (df_input_table_A.source_system == 'ISP'),
                           df_input_table_F.location_name)
                    .otherwise(df_input_table_D.location_name).alias('location_name'),
                    df_input_table_D.cs_and_o_location_flag.alias('cs_and_o_location'),
                    df_input_table_A.qty_in_m3.alias('qty_in_m3'),
                    df_input_table_A.qty_in_usg.alias('quantity_gallon'),
                    df_input_table_A.qty_in_litres.alias('qty_in_litres'),
                    df_input_table_A.gross_profit_lc.alias('wf_cond_value_lc'),
                    df_input_table_A.gross_profit_usd.alias('gross_profit_usd'),
                    df_input_table_A.l4_on_airfield_costs_usd.alias('on_airfield_cost_usd'),
                    df_input_table_A.l4_pre_airfield_sh_usd,
                    df_input_table_A.l4_pre_airfield_transport_usd,
                    (f.coalesce(df_input_table_A.l4_pre_airfield_sh_usd, f.lit(0))
                     + f.coalesce(df_input_table_A.l4_pre_airfield_transport_usd, f.lit(0))).alias(
                        'pre_airfield_cost_usd'),
                    df_input_table_A.l4_on_airfield_costs_lc.alias('on_airfield_cost_lc'),
                    (f.coalesce(df_input_table_A.l4_pre_airfield_sh_lc, f.lit(0))
                     + f.coalesce(df_input_table_A.l4_pre_airfield_transport_lc, f.lit(0))).alias(
                        'pre_airfield_cost_lc'),
                    df_input_table_A.intercompany_flag,
                    f.when((f.month(f.current_date()) > f.lit(3)) &
                           ((f.year(df_input_table_A.billing_date) >= (f.year(f.current_date()) - 2)) |
                            (f.year(df_input_table_A.delivery_date) >= (f.year(f.current_date()) - 2))), f.lit(1))
                    .when((f.month(f.current_date()) <= f.lit(3)) &
                          ((f.year(df_input_table_A.billing_date) >= (f.year(f.current_date()) - 3)) |
                           (f.year(df_input_table_A.delivery_date) >= (f.year(f.current_date()) - 3))), f.lit(1))
                    .otherwise(f.lit(0)).alias('BILLING_DATE_FILTER'))
        #print("df_table_inner:", df_table_inner.count())

        # outer dataframe
        df_table_outer = df_table_inner.filter(
            (df_table_inner.BILLING_DATE_FILTER == f.lit(1)) & (df_table_inner.intercompany_flag == 'N')) \
            .groupBy(df_table_inner.source_system,
                     df_table_inner.calendar_date,
                     df_table_inner.billing_date,
                     df_table_inner.delivery_date,
                     df_table_inner.pu,
                     df_table_inner.cluster,
                     df_table_inner.country,
                     df_table_inner.customer_country,
                     df_table_inner.cc_grn,
                     df_table_inner.global_ref_num,
                     df_table_inner.cust_acct_name,
                     df_table_inner.global_acct_ref_num,
                     df_table_inner.account_holder_name,
                     df_table_inner.sector,
                     df_table_inner.sales_organization,
                     df_table_inner.plant,
                     df_table_inner.material_description,
                     df_table_inner.billing_document,
                     df_table_inner.ib_global_cust_ref,
                     df_table_inner.sold_to_party,
                     df_table_inner.local_currency,
                     df_table_inner.last_modified_date,
                     df_table_inner.location_name,
                     df_table_inner.cs_and_o_location) \
            .agg(f.sum(df_table_inner.qty_in_m3).alias('qty_in_m3'),
                 f.sum(df_table_inner.quantity_gallon).alias('quantity_gallon'),
                 f.sum(df_table_inner.qty_in_litres).alias('qty_in_litres'),
                 f.sum(df_table_inner.wf_cond_value_lc).alias('wf_cond_value_lc'),
                 f.sum(df_table_inner.gross_profit_usd).alias('gross_profit_usd'),
                 f.sum(df_table_inner.on_airfield_cost_usd).alias('on_airfield_cost_usd'),
                 f.sum(df_table_inner.pre_airfield_cost_usd).alias('pre_airfield_cost_usd'),
                 f.sum(df_table_inner.on_airfield_cost_lc).alias('on_airfield_cost_lc'),
                 f.sum(df_table_inner.pre_airfield_cost_lc).alias('pre_airfield_cost_lc')
                 )
        df_tfx_result = df_table_outer.select(f.when(df_table_outer.source_system == 'PR4_HIST', f.lit('PR4'))
                                              .otherwise(df_table_outer.source_system).alias('source_system'),
                                              df_table_outer.calendar_date,
                                              df_table_outer.billing_date,
                                              df_table_outer.delivery_date,
                                              df_table_outer.pu,
                                              df_table_outer.cluster,
                                              df_table_outer.country,
                                              df_table_outer.customer_country,
                                              df_table_outer.cc_grn,
                                              df_table_outer.global_ref_num,
                                              df_table_outer.cust_acct_name,
                                              df_table_outer.global_acct_ref_num,
                                              df_table_outer.account_holder_name,
                                              df_table_outer.sector,
                                              df_table_outer.sales_organization,
                                              df_table_outer.plant,
                                              df_table_outer.material_description,
                                              df_table_outer.billing_document,
                                              df_table_outer.ib_global_cust_ref,
                                              df_table_outer.sold_to_party,
                                              df_table_outer.local_currency,
                                              df_table_outer.last_modified_date,
                                              df_table_outer.location_name,
                                              f.when(df_table_outer.cs_and_o_location.isNull(), f.lit('N'))
                                              .otherwise(df_table_outer.cs_and_o_location).alias('cs_and_o_location'),
                                              df_table_outer.qty_in_m3,
                                              df_table_outer.quantity_gallon,
                                              df_table_outer.qty_in_litres,
                                              df_table_outer.wf_cond_value_lc,
                                              df_table_outer.gross_profit_usd,
                                              df_table_outer.on_airfield_cost_usd,
                                              df_table_outer.pre_airfield_cost_usd,
                                              df_table_outer.on_airfield_cost_lc,
                                              df_table_outer.pre_airfield_cost_lc
                                              )
        #print("df_tfx_result", df_tfx_result.count())

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()
