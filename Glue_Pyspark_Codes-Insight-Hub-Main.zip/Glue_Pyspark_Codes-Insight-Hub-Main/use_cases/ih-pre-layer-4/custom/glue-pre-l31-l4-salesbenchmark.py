# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Hasan Chaudhary 27-Apr-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-pre-l3-l31-salesbenchmark.py into conform zone
# Author        :- Hasan Chaudhary
# Date          :- 27-Apr-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from awsglue.job import Job


class LcpIspETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 10:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 10")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database1',
                                   'source_database2',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database1']
        self.netapp_database = args['source_database2']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table_list = ['l31_pre_sales_benchmark', 'l2_pre_benchmark_adj_hist']
        self.report_file = "l4_pre_fact_sales_benchmark"

        # print('Glue ETL Job {} is starting '.format(self.job_name))
        # print('JOB will read data from {}.{}* and {}.{}* write it to {}'.format(self.source_database,
        #                                                                         self.input_table_list[0],
        #                                                                         self.netapp_database,
        #                                                                         self.input_table_list[1],
        #                                                                         self.destination_bucket))

    def execute(self):
        # generate input table list
        source_database = self.source_database
        netapp_database = self.netapp_database
        input_table_list = self.input_table_list
        print("input table list is {}".format(input_table_list))

        # read data from country specific table argument passed(database, table)
        df_benchmark = self._get_table(source_database, input_table_list[0]).toDF()
        #print("data count of table {}.{} is {}".format(source_database, input_table_list[0],
        #                                               df_benchmark.count()))

        df_benchmark2 = self._get_table(netapp_database, input_table_list[1]).toDF()
        #print("data count of table {}.{} is {}".format(netapp_database, input_table_list[1],
        #                                               df_benchmark2.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_benchmark, df_benchmark2)
        #print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(*args):
        
        df_benchmark = args[0]
        df_benchmark2 = args[1].filter(args[1].billing_date < '2021-02-15')

        # applying transformation

        df_benchmark = df_benchmark.select(f.lit('PRE').alias('source_system'),
                                           df_benchmark.vbeln.alias('billing_document'),
                                           df_benchmark.posnr.alias('billing_item'),
                                           f.concat(f.lit('PRE_'), df_benchmark.vbeln, f.lit('_'),
                                                    df_benchmark.posnr).alias('ref_id'),
                                           df_benchmark.fkart.alias('billing_type'),
                                           df_benchmark.vbtyp.alias('sales_doc_category'),
                                           df_benchmark.cogs.alias('cogs_lc'), df_benchmark.bm_pp.alias('bm_pp'),
                                           df_benchmark.bm_pp_c.alias('bm_pp_c'),
                                           df_benchmark.alt_bm_pp.alias('alt_bm_pp'),
                                           df_benchmark.waers.alias('currency'),
                                           df_benchmark.zzavcurr.alias('exchange_rate_pp'),
                                           df_benchmark.exchange_rate.alias('exchange_rate'),
                                           df_benchmark.vkorg.alias('sales_organisation'),
                                           df_benchmark.vtweg.alias('distribution_channel'),
                                           df_benchmark.spart.alias('division'),
                                           df_benchmark.matnr.alias('material_number'),
                                           df_benchmark.fkdat.alias('billing_date'),
                                           df_benchmark.datefrom.alias('date_from'),
                                           df_benchmark.dateto.alias('date_to'),
                                           f.lit('ZBCA').alias('condition_type'),
                                           f.when(df_benchmark.amount_lc.isNull(), f.lit(0))
										    .otherwise(df_benchmark.amount_lc).alias('amount_lc'),
										   f.when(df_benchmark.amount_gc.isNull(), f.lit(0))
										    .otherwise(df_benchmark.amount_gc).alias('amount_gc'))
											
        df_benchmark = df_benchmark.select(df_benchmark.source_system,
                                           df_benchmark.billing_document,
                                           df_benchmark.billing_item,
                                           df_benchmark.ref_id,
                                           df_benchmark.billing_type,
                                           df_benchmark.sales_doc_category,
                                           df_benchmark.cogs_lc, df_benchmark.bm_pp,
                                           df_benchmark.bm_pp_c,
                                           df_benchmark.alt_bm_pp,
                                           df_benchmark.currency,
                                           df_benchmark.exchange_rate_pp,
                                           df_benchmark.exchange_rate,
                                           df_benchmark.sales_organisation,
                                           df_benchmark.distribution_channel,
                                           df_benchmark.division,
                                           df_benchmark.material_number,
                                           df_benchmark.billing_date,
                                           df_benchmark.date_from,
                                           df_benchmark.date_to,
                                           df_benchmark.condition_type,
                                           f.when(df_benchmark.sales_doc_category.isin(['N', 'P', 'S']), df_benchmark.amount_lc * -1)
										    .otherwise(df_benchmark.amount_lc).alias('amount_lc'),
										   f.when(df_benchmark.sales_doc_category.isin(['N', 'P', 'S']), df_benchmark.amount_gc * -1)
										   .otherwise(df_benchmark.amount_gc).alias('amount_gc'))
										   
        df_benchmark2 = df_benchmark2.select(df_benchmark2.source_system, df_benchmark2.billing_document,
                                             df_benchmark2.billing_item,
                                             df_benchmark2.ref_id, df_benchmark2.billing_type,
                                             df_benchmark2.sales_doc_category,
                                             df_benchmark2.cogs_lc, df_benchmark2.bm_pp, df_benchmark2.bm_pp_c,
                                             df_benchmark2.alt_bm_pp, df_benchmark2.currency,
                                             df_benchmark2.exchange_rate_pp,
                                             df_benchmark2.exchange_rate, df_benchmark2.sales_organisation,
                                             df_benchmark2.distribution_channel,
                                             df_benchmark2.division, df_benchmark2.material_number,
                                             df_benchmark2.billing_date,
                                             df_benchmark2.date_from, df_benchmark2.date_to,
                                             df_benchmark2.condition_type,
                                             df_benchmark2.amount_lc, df_benchmark2.amount_gc)

        df_tfx_result = df_benchmark.union(df_benchmark2)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpIspETL()
    trl.execute()
