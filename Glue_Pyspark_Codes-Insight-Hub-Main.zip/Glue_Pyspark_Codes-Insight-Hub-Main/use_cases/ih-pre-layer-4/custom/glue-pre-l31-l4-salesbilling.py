# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1              Hasan Chaudhary 16-Mar-2021     Initial version
# =================================================================================================
# Description   :- The aim of the code is to generate glue-pre-l31-l4-salesbilling.py into conform zone
# Author        :- Hasan Chaudhary
# Date          :- 16-Mar-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job


class LcpPreETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 11:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 11")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_table = "l31_pre_sales_billing"
        self.report_file = "l4_pre_fact_sales_billing"

        print('Glue ETL Job {} is starting '.format(self.job_name))
        print('JOB will read data from {}.{}* and write it to {}'.format(self.source_database, self.input_table,
                                                                         self.destination_bucket))

    def execute(self):
        # Call individual function to Get the tables data from Glue Catalog
        schema = StructType([])
        final_result_df = self._spark.createDataFrame(self._spark.sparkContext.emptyRDD(), schema)

        # read data from country specific table argument passed(database, table)
        df_sales_billing = self._get_table(self.source_database, self.input_table).toDF()
        #print("data count of table {}.{} is {}".format(self.source_database, self.input_table, df_sales_billing.count()))

        # apply transformation on the dataframe argument
        df_tfx_table = self._apply_tfx(df_sales_billing)
        #print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, target_dataset):
        final_path = self.destination_bucket + "/" + self.report_file
        print('final_path', final_path)
        target_dataset \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_sales_billing):

        df_tfx_result = df_sales_billing.select(f.lit('PRE').alias('source_system'),
					df_sales_billing.vbeln_billing_doc.alias('billing_document'),
					f.concat(f.lit('PRE_'),df_sales_billing.vbeln_billing_doc,f.lit('_'),df_sales_billing.posnr_item).alias('ref_id'),
					df_sales_billing.fkart_billing_type.alias('billing_type'),
					df_sales_billing.fktyp_billingcategory.alias('billing_category'),
					df_sales_billing.vbtyp_document_cat.alias('sales_doc_category'),
					df_sales_billing.waerk_doc_currency.alias('document_currency'),
					df_sales_billing.vkorg_sales_org.alias('sales_organisation'),
					df_sales_billing.vtweg_distr_channel.alias('distribution_channel'),
					df_sales_billing.kalsm_pric_procedure.alias('pricing_procedure'),
					df_sales_billing.knumv_doc_condition.alias('doc_condition_no'),
					f.concat(f.lit('PRE_'), df_sales_billing.knumv_doc_condition).alias('fk_doc_condition_no'),
					df_sales_billing.vsbed_shipping_cond.alias('shipping_condition'),
					df_sales_billing.fkdat_billing_date.alias('billing_date'),
					df_sales_billing.rfbsk_posting_status.alias('posting_status'),
					df_sales_billing.kurrf_exchrate_acct.alias('exchange_rate_accntg'),
					df_sales_billing.zterm_payt_terms.alias('terms_of_payment'),
					df_sales_billing.bukrs_company_code.alias('company_code'),
					df_sales_billing.netwr_net_value_vbrk.alias('total_net_value'),
					df_sales_billing.erzet_time_vbrk.alias('header_time'),
					df_sales_billing.erdat_created_on_vbrk.alias('header_created_on'),
					df_sales_billing.stwae_stats_currency.alias('statistics_currency'),
					df_sales_billing.kurst_exch_rate_type.alias('exchange_rate_type'),
					df_sales_billing.spart_division.alias('division'),
					df_sales_billing.cmwae_currency.alias('local_currency'),
					df_sales_billing.cmkuf_exchange_rate.alias('cred_data_exch_rate'),
					df_sales_billing.logsys_logical_system.alias('logical_system'),
					df_sales_billing.kurrf_dat_translatn_date.alias('translation_date'),
					df_sales_billing.posnr_item.alias('billing_item'),
					df_sales_billing.fkimg_billed_qty.alias('billed_quantity'),
					df_sales_billing.vrkme_sales_unit.alias('sales_unit'),
					df_sales_billing.meins_base_unit.alias('base_unit_of_measure'),
					df_sales_billing.fklmg_billqty_in_sku.alias('billing_qty_in_sku'),
					df_sales_billing.lmeng_required_qty.alias('required_quantity'),
					df_sales_billing.ntgew_net_weight.alias('net_weight'),
					df_sales_billing.brgew_gross_weight.alias('gross_weight'),
					df_sales_billing.gewei_weight_unit.alias('weight_unit'),
					df_sales_billing.volum_volume.alias('volume'),
					df_sales_billing.voleh_volume_unit.alias('volume_unit'),
					df_sales_billing.prsdt_pricing_date.alias('pricing_date'),
					df_sales_billing.kursk_exchange_rate.alias('exchange_rate'),
					df_sales_billing.netwr_net_value_vbrp.alias('net_value'),
					df_sales_billing.vgbel_reference_doc.alias('reference_document'),
					df_sales_billing.vgpos_reference_item.alias('reference_item'),
					df_sales_billing.vgtyp_precdoccateg.alias('preceding_doc_categ'),
					df_sales_billing.aubel_sales_document.alias('sales_document'),
					df_sales_billing.aupos_item.alias('sales_document_item'),
					df_sales_billing.matnr_material.alias('material_number'),
					df_sales_billing.maktx_material_description.alias('material_description'),
					df_sales_billing.pstyv_item_category.alias('item_category'),
					df_sales_billing.vstel_shipping_point.alias('shipping_point_receiving_pt'),
					df_sales_billing.werks_plant.alias('plant'),
					df_sales_billing.aland_country.alias('country'),
					df_sales_billing.vkbur_sales_office.alias('sales_office'),
					df_sales_billing.erdat_created_on_vbrp.alias('line_created_on'),
					df_sales_billing.erzet_time_vbrp.alias('line_time'),
					df_sales_billing.stcur_exchrate_stats.alias('exchange_rate_stats'),
					df_sales_billing.prctr_profit_center.alias('profit_centre'),
					df_sales_billing.konda_auft_pricegrouporder.alias('price_group_order'),
					df_sales_billing.pltyp_auft_price_list_ord.alias('price_list_ord'),
					df_sales_billing.augru_auft_order_reason.alias('order_reason'),
					df_sales_billing.oid_extbol_externbol_no.alias('extern_bol_no'),
					df_sales_billing.oicontnr_contractnr.alias('contract_nr'),
					df_sales_billing.oic_kmpos_refcontractitm.alias('ref_contractitm'),
					df_sales_billing.oic_time_time.alias('pricing_time'),
					df_sales_billing.oiinvcyc9_invcycle_ind.alias('inv_cycle_ind'),
					df_sales_billing.zzsup_loc_standard_supply_loc.alias('standard_supply_loc'),
					df_sales_billing.zzimport_reg_standard_refinery.alias('standard_refinery'),
					df_sales_billing.zzvesselname_vessel_name.alias('vessel_name'),
					df_sales_billing.zztermtype_pros_term_type.alias('term_type'),
					df_sales_billing.zzflnum_flight_number.alias('flight_number'),
					df_sales_billing.zzairctycd_aircraft_tycode.alias('aircraft_type_code'),
					df_sales_billing.zztailno_aircraft_reg.alias('aircraft_registration'),
					df_sales_billing.zzcontract_type_contr_doc_type.alias('contr_doc_type'),
					df_sales_billing.zzorigplant_orignal_plant.alias('original_plant'),
					df_sales_billing.vsart_shptype_stage.alias('shp_type_stage'),
					df_sales_billing.zzbillunit_billing_unit.alias('billing_unit'),
					df_sales_billing.ssr_ccins_pc_type.alias('pc_type'),
					df_sales_billing.ssr_cctyp_ssr_pc_category.alias('ssr_pc_category'),
					df_sales_billing.zsds_chot_channel_of_trade.alias('channel_of_trade'),
					df_sales_billing.zzconsass_cons_assgn.alias('cons_assgn'),
					df_sales_billing.zz_distric_district.alias('district'),
					df_sales_billing.oircmetrev_met_event_type.alias('met_event_type'),
					df_sales_billing.zzavgcurrdocloc_average_exchange_rat.alias('average_exch_rate'),
					df_sales_billing.zzdminus1rate_d_1_exc_rate.alias('d1_exchange_rate'),
					f.when(df_sales_billing.zzqty_to.isNull(), f.lit(0))
					 .otherwise(df_sales_billing.zzqty_to).alias('metric_tons'),
					f.when(df_sales_billing.zzqty_l.isNull(), f.lit(0))
					 .otherwise(df_sales_billing.zzqty_l).alias('litres'),
					f.when(df_sales_billing.zzqty_ugl.isNull(), f.lit(0))
					 .otherwise(df_sales_billing.zzqty_ugl).alias('ugl'),
					f.when(df_sales_billing.zzqty_m3.isNull(), f.lit(0))
					 .otherwise(df_sales_billing.zzqty_m3).alias('m3'),
					f.when(df_sales_billing.kunnr_customer_shipto == 'NULL', f.lit('')).otherwise(df_sales_billing.kunnr_customer_shipto).alias('shipto_party'),
					f.when(df_sales_billing.kunnr_customer_billto == 'NULL', f.lit('')).otherwise(df_sales_billing.kunnr_customer_billto).alias('billto_party'),
					f.when(df_sales_billing.kunnr_customer_soldto == 'NULL', f.lit('')).otherwise(df_sales_billing.kunnr_customer_soldto).alias('soldto_party'),
					f.when(df_sales_billing.kunnr_customer_payer == 'NULL', f.lit('')).otherwise(df_sales_billing.kunnr_customer_payer).alias('payer'),
					f.when(df_sales_billing.kunnr_customer_dest_airport == 'NULL', f.lit('')).otherwise(df_sales_billing.kunnr_customer_dest_airport).alias('destination_airport'),
					f.when(df_sales_billing.kunnr_customer_final_dest_partner == 'NULL', f.lit('')).otherwise(df_sales_billing.kunnr_customer_final_dest_partner).alias('final_destination_partner'),
					f.when(df_sales_billing.kunnr_customer_parent_partner == 'NULL', f.lit('')).otherwise(df_sales_billing.kunnr_customer_parent_partner).alias('parent_partner'),
					f.when(df_sales_billing.kunnr_customer_vendor == 'NULL', f.lit('')).otherwise(df_sales_billing.kunnr_customer_vendor).alias('vendor'),
					f.when(df_sales_billing.kunnr_customer_sales_rep == 'NULL', f.lit('')).otherwise(df_sales_billing.kunnr_customer_sales_rep).alias('sales_rep'),
					f.when(df_sales_billing.kunnr_customer_agent_id == 'NULL', f.lit('')).otherwise(df_sales_billing.kunnr_customer_agent_id).alias('agent_id'),
					df_sales_billing.zzexchrate_wf_c_exchange_rate.alias('zzexchrate_wf_c_exchange_rate'),
					df_sales_billing.auart_delivery_method.alias('delivery_method'))

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpPreETL()
    trl.execute()
