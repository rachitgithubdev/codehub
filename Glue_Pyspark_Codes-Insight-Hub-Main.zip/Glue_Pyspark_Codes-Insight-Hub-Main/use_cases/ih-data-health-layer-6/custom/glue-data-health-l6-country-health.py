# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1               Liz Harvey     14-May-2021     Initial Version
# =================================================================================================
# Description   :- The aim of the code is to l6_country_health into conform zone
# Author        :- Liz Harvey
# Date          :- 14-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class LcpDHTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_tables = ['l6_volume', 'l6_sign_off', 'l6_reported_costs', 'l6_cop_act_costs', 'l6_apc_act_costs',
                             'l6_last_refresh', 'l6_null_customers', 'l6_null_locations']
        self.report_file = "l6_country_health"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        # generate input table list
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, self.input_tables[0]).toDF()
        print("data count of table {}.{} is {}".format(source_database, self.input_tables[0],
                                                       df_table_1.count()))
        df_table_2 = self._get_table(source_database, self.input_tables[1]).toDF()
        print("data count of table {}.{} is {}".format(source_database, self.input_tables[1],
                                                       df_table_2.count()))
        df_table_3 = self._get_table(source_database, self.input_tables[2]).toDF()
        print("data count of table {}.{} is {}".format(source_database, self.input_tables[2],
                                                       df_table_3.count()))
        df_table_4 = self._get_table(source_database, self.input_tables[3]).toDF()
        print("data count of table {}.{} is {}".format(source_database, self.input_tables[3],
                                                       df_table_4.count()))
        df_table_5 = self._get_table(source_database, self.input_tables[4]).toDF()
        print("data count of table {}.{} is {}".format(source_database, self.input_tables[4],
                                                       df_table_5.count()))
        df_table_6 = self._get_table(source_database, self.input_tables[5]).toDF()
        print("data count of table {}.{} is {}".format(source_database, self.input_tables[5],
                                                       df_table_6.count()))
        df_table_7 = self._get_table(source_database, self.input_tables[6]).toDF()
        print("data count of table {}.{} is {}".format(source_database, self.input_tables[6],
                                                       df_table_7.count()))
        df_table_8 = self._get_table(source_database, self.input_tables[7]).toDF()
        print("data count of table {}.{} is {}".format(source_database, self.input_tables[7],
                                                       df_table_8.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2, df_table_3, df_table_4, df_table_5, df_table_6,
                                       df_table_7, df_table_8)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_table_1, df_table_2, df_table_3, df_table_4, df_table_5, df_table_6, df_table_7, df_table_8):
        df_tfx_result = df_table_1.alias("vol").join(df_table_2.alias("so"),
                                                     (f.col("vol.country") == f.col("so.country"))
                                                     & (f.col("vol.source_system") == f.col("so.source_system")),
                                                     "left") \
            .join(df_table_3.alias("rc"), (f.col("vol.country") == f.col("rc.country"))
                  & (f.col("vol.source_system") == f.col("rc.source_system")), "left") \
            .join(df_table_4.alias("cop"), (f.col("vol.country") == f.col("cop.country"))
                  & (f.col("vol.source_system") == f.col("cop.source_system")), "left") \
            .join(df_table_5.alias("apc"), (f.col("vol.country") == f.col("apc.country"))
                  & (f.col("vol.source_system") == f.col("apc.source_system")), "left") \
            .join(df_table_6.alias("lf"), (f.col("vol.country") == f.col("lf.country"))
                  & (f.col("vol.source_system") == f.col("lf.source_system")), "left") \
            .join(df_table_7.alias("nc"), (f.col("vol.country") == f.col("nc.country"))
                  & (f.col("vol.source_system") == f.col("nc.source_system")), "left") \
            .join(df_table_8.alias("nl"), (f.col("vol.country") == f.col("nl.country"))
                  & (f.col("vol.source_system") == f.col("nl.source_system")), "left") \
            .filter(f.col("vol.country").isNotNull()) \
            .groupBy(f.col("vol.source_system"),
                     f.col("vol.pu"),
                     f.col("vol.cluster"),
                     f.col("vol.country"),
                     f.col("so.signed_off")) \
            .agg((f.sum(f.col("null_customers"))).alias("missing_customer_data"),
                 (f.sum(f.col("null_locations"))).alias("missing_location_data"),
                 (f.max(f.col("volume_latest"))).alias("volume_latest"),
                 (f.max(f.col("reported_cost_latest"))).alias("reported_cost_latest"),
                 (f.max(f.col("cop_actual_cost_latest"))).alias("cop_actual_cost_latest"),
                 (f.max(f.col("apc_actual_cost_latest"))).alias("apc_actual_cost_latest"),
                 (f.max(f.col("last_refresh"))).alias("last_refresh"),
                 ((f.min(f.col("min_invoice_date"))).cast("date")).alias("first_invoice_date"),
                 ((f.max(f.col("max_invoice_date"))).cast("date")).alias("last_invoice_date")) \
            .select(f.col("source_system").alias("source_system"),
                    f.col("pu").alias("pu"),
                    f.col("cluster").alias("cluster"),
                    f.col("country").alias("country"),
                    f.col("signed_off").alias("signed_off"),
                    f.col("volume_latest"),
                    f.col("reported_cost_latest"),
                    f.col("cop_actual_cost_latest"),
                    f.col("apc_actual_cost_latest"),
                    f.col("last_refresh"),
                    f.col("missing_customer_data"),
                    f.col("missing_location_data"),
                    f.col("first_invoice_date"),
                    f.col("last_invoice_date")
                    )

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpDHTETL()
    trl.execute()