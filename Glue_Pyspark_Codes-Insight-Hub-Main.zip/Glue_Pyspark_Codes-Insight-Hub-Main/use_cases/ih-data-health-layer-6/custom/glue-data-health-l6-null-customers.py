# ================================Revision History=================================================
# #
#  Change Version,  Change Author,  Change Date,    Change Component
#  0.1               Liz Harvey     17-May-2021     Initial Version
# =================================================================================================
# Description   :- The aim of the code is to l6_null_customers into conform zone
# Author        :- Liz Harvey
# Date          :- 17-May-2021
# Version       :- 0.1
# AWS component :- S3 and Glue
# ================================================================================================

import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import functions as f
from pyspark.sql.types import *
from awsglue.job import Job
from functools import reduce
from pyspark.sql import DataFrame


class LcpDHTETL:
    def __init__(self):
        # GlueContext and sparkSession creation
        self._gc = GlueContext(SparkContext.getOrCreate())
        self._spark = self._gc.sparkSession
        self.job = Job(self._gc)

        # Command line argument verification
        if str(sys.argv).count('--') != 9:
            print("Incorrect command line argument passed to JOB")
            print("Argument expected : 9")
            print("Argument passed : ", str(sys.argv).count('--'), sys.argv)

        # Read the Environmental Variables from AWS Cloud Formation(template.yaml)
        args = getResolvedOptions(sys.argv,
                                  ['JOB_NAME',
                                   'source_database',
                                   'destination_bucket',
                                   'environment'])
        self.job.init(args['JOB_NAME'], args)

        # Assign Environmental variable to local variables
        # common variables ===========================================
        self.job_name = args['JOB_NAME']
        self.source_database = args['source_database']
        self.destination_bucket = args['destination_bucket']

        # report specific =============================================
        self.input_tables = ['l51_summary', 'l5_dim_org_hierarchy_geography']
        self.report_file = "l6_null_customers"

        print('Glue ETL Job {} is starting '.format(self.job_name))

    def execute(self):
        # generate input table list
        source_database = self.source_database

        # read data from country specific table argument passed(database, table)
        df_table_1 = self._get_table(source_database, self.input_tables[0]).toDF()
        print("data count of table {}.{} is {}".format(source_database, self.input_tables[0],
                                                       df_table_1.count()))
        df_table_2 = self._get_table(source_database, self.input_tables[1]).toDF()
        print("data count of table {}.{} is {}".format(source_database, self.input_tables[1],
                                                       df_table_2.count()))

        # apply transformation on the dataframe argument passed(dataframe, country)
        df_tfx_table = self._apply_tfx(df_table_1, df_table_2)
        print("data count after transformation ", df_tfx_table.count())

        self.write_results(df_tfx_table)

    def write_results(self, df_tfx_table):
        final_path = self.destination_bucket + '/' + self.report_file
        print('final_path', final_path)
        df_tfx_table \
            .write.option("compression", "snappy") \
            .mode('overwrite') \
            .parquet(final_path)

    def _get_table(self, source_database, table_name):
        print('reading data from {}.{}'.format(source_database, table_name))
        table = self._gc.create_dynamic_frame.from_catalog(
            database=source_database,
            table_name=table_name,
            transformation_ctx='target_table'
        )
        return table

    @staticmethod
    def _apply_tfx(df_table_1, df_table_2):
        df_isp = df_table_1.alias("l51").join(df_table_2.alias("dohg"),
                                              f.col("l51.costing_country") == f.col("dohg.iso_code_2"), "left") \
            .filter((f.col("l51.source_system") == "ISP") &
                    (f.col("l51.customer_account_name").isNull())) \
            .groupBy(f.col("l51.source_system"),
                     f.col("dohg.pu"),
                     f.col("dohg.cluster"),
                     f.col("dohg.country")) \
            .agg(f.count(f.col("*")).alias("null_customers")) \
            .select(f.col("source_system"),
                    f.col("pu"),
                    f.col("cluster"),
                    f.col("country"),
                    f.col("null_customers"))

        df_pre = df_table_1.alias("l51").join(df_table_2.alias("dohg"),
                                              f.substring(f.col("l51.sales_organisation"), 1, 2) == f.col(
                                                  "dohg.iso_code_2"), "left") \
            .filter((f.col("l51.source_system") == "PRE") &
                    (f.col("l51.customer_account_name").isNull())) \
            .groupBy(f.col("l51.source_system"),
                     f.col("dohg.pu"),
                     f.col("dohg.cluster"),
                     f.col("dohg.country")) \
            .agg(f.count(f.col("*")).alias("null_customers")) \
            .select(f.col("source_system"),
                    f.col("pu"),
                    f.col("cluster"),
                    f.col("country"),
                    f.col("null_customers"))

        df_pro = df_table_1.alias("l51").join(df_table_2.alias("dohg"),
                                              (f.when(f.col("l51.sales_organisation") == "01", "BR")
                                               .otherwise("ZZ")) == f.col("dohg.iso_code_2"), "left") \
            .filter((f.col("l51.source_system") == "BRA") &
                    (f.col("l51.customer_account_name").isNull())) \
            .groupBy(f.col("l51.source_system"),
                     f.col("dohg.pu"),
                     f.col("dohg.cluster"),
                     f.col("dohg.country")) \
            .agg(f.count(f.col("*")).alias("null_customers")) \
            .select(f.lit("PRO").alias("source_system"),
                    f.col("pu"),
                    f.col("cluster"),
                    f.col("country"),
                    f.col("null_customers"))

        df_pr4 = df_table_1.alias("l51").join(df_table_2.alias("dohg"),
                                              (f.when(f.substring(f.col("l51.sales_organisation"), 1, 2) == "CN", "CA")
                                               .otherwise(f.substring(f.col("l51.sales_organisation"), 1, 2))) == f.col(
                                                  "dohg.iso_code_2"), "left") \
            .filter((f.col("l51.source_system") == "PR4_HIST") &
                    (f.col("l51.customer_account_name").isNull())) \
            .groupBy(f.col("l51.source_system"),
                     f.col("dohg.pu"),
                     f.col("dohg.cluster"),
                     f.col("dohg.country")) \
            .agg(f.count(f.col("*")).alias("null_customers")) \
            .select(f.col("source_system"),
                    f.col("pu"),
                    f.col("cluster"),
                    f.col("country"),
                    f.col("null_customers"))

        df_sun = df_table_1.alias("l51").join(df_table_2.alias("dohg"),
                                              f.col("l51.costing_country") == f.col("dohg.iso_code_2"), "left") \
            .filter((f.col("l51.source_system") == "SUN") &
                    (f.col("l51.customer_account_name").isNull())) \
            .groupBy(f.col("l51.source_system"),
                     f.col("dohg.pu"),
                     f.col("dohg.cluster"),
                     f.col("dohg.country")) \
            .agg(f.count(f.col("*")).alias("null_customers")) \
            .select(f.col("source_system"),
                    f.col("pu"),
                    f.col("cluster"),
                    f.col("country"),
                    f.col("null_customers"))

        dfs = [df_isp, df_pre, df_pro, df_pr4, df_sun]
        df_tfx_result = reduce(DataFrame.unionAll, dfs)

        return df_tfx_result


if __name__ == '__main__':
    trl = LcpDHTETL()
    trl.execute()