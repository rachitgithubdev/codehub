# Introduction 
Sample git repository to store a subtenant's use cases

# Folder Structure
## _template_data_prep
This folder contains a template of the folders and files required for a data_prep pipeline (raw to clean/latest). This folder shouldn't be packaged and deployed to the AWS accounts.

## _template_use_case
This folder contains a template of the folders and files required for a standalone pipeline (enrich/conform). This folder shouldn't be packaged and deployed to the AWS accounts.

## _shared_resources/datalakeLibrary
This folder contains common python functions that can be used across the data_prep or use_case pipelines. This must be packaged and deployed to the AWS accounts
```
    ├── datalakeLibrary 
    │   ├── README.md
    │   └── python
    │       └── datalake_library
    │           ├── configuration
    │           ├── interfaces
    │           ├── octagon
    │           └── transforms
    │               ├── stage_a_transforms
    │               │   ├── light_transform_blueprint.py
    │               │   ├── ...
    │               ├── stage_b_transforms
    │               │   ├── heavy_transform_blueprint.py
    │               │   └── ...
    │               └── dataset_mappings.json
    │               └── transform_handler.py
```
## _shared_resources/pipLibrary
This folder contains python modules that are required by the data_prep or use_case pipelines. This must be packaged and deployed to the AWS accounts
```
    │── pipLibrary
    │   ├── AWSDataWrangler
    │   ├── external_layers.json
    │   ├── Pandas
    │   ├── requirements.txt
    │   ├── README.md
    │   ├── build.sh
    │   └── requirements.txt
```
## use_cases
This folder contains the files that are deployed to the Tenant AWS accounts. The files will uploaded to the appropriate s3 location and picked up by the Orchestration Framework

### important files
* env.ini: used by Orchestration Framework to set environment variables: https://basproducts.atlassian.net/wiki/spaces/DH/pages/2050654910/Pipeline+Folder+Structure+and+Definition+Files#Pipeline-Definition
* deployment_of_use_case.json: used to control the Orchestration framework pipelines deployed: https://basproducts.atlassian.net/wiki/spaces/DH/pages/2135589296/Use+case+deployment#Zip-file-content
* deployment_use_case.json: used to control the SDLF standalone pipelines deployed and their registration: https://basproducts.atlassian.net/wiki/spaces/DH/pages/2135589296/Use+case+deployment#Zip-file-content
* deployment_data_prep.json: used to control the SDLF data preparation piplines deployed and their registration: https://basproducts.atlassian.net/wiki/spaces/DH/pages/2628878572/Data+Preparation+Pipeline

## use_cases/DDL_flyway (Orchestration Framework)
This folder contains the sql files executed by flyway in order to create the objects in the various Redshift schemas. There must be 1 folder per schemas

For more details on the naming convention of sql files for flyway, refer to https://flywaydb.org/getstarted/how

## use_cases/sample-pipeline-top50 (Orchestration Framework)
This folder contains the pipeline details for the use case `sample-pipeline-top50`. The file `main.json` defines the workflow of sql scripts to execute.

For more details on the pipeline definition, refer to https://basproducts.atlassian.net/wiki/spaces/DH/pages/2050654910/Pipeline+Folder+Structure+and+Definition+Files#Pipeline-Definition

## use_cases/sample-standalone
important files:
* event_registration.json: events that will trigger the execution of a specific stage for that SDLF pipeline

# ADO pipeline
`azure-package.yml` is an example pipeline that can be used to package the subtenant's use cases into a zip file and upload it to Artifactory so it can be deployed.
Because artifactory is only accessible from the BP network, the ADO pipeline should use a BP hosted pool, like `GenericPool` or `GenericPoolLinux`

# References
Useful links:
* Subtenant onboarding: https://basproducts.atlassian.net/wiki/spaces/DH/pages/2132412525/Subtenant+Onboarding
* Use case deployment: https://basproducts.atlassian.net/wiki/spaces/DH/pages/2135589296/Use+case+deployment
* Orchestration framework: https://basproducts.atlassian.net/wiki/spaces/DH/pages/2050556175
* Azure DevOps support: https://teams.microsoft.com/l/team/19%3af203ca39213c4307aa77d3134a57f1e3%40thread.skype/conversations?groupId=cc0f636d-9356-4bca-9c28-982b58d1ad30&tenantId=ea80952e-a476-42d4-aaf4-5457852b0f7e
* Artifactory support: https://teams.microsoft.com/l/channel/19%3a29018bd997394c01a378326d4929cbf0%40thread.skype/Artifactory?groupId=03c21413-9b22-4b9e-ae33-9a716a44a6a1&tenantId=ea80952e-a476-42d4-aaf4-5457852b0f7e
