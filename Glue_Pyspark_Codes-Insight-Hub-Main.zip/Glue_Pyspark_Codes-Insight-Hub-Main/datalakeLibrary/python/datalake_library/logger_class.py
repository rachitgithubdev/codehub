
# --------------------------------------------------------------------------------------------------------------#
# COMMON LOGGING CLASS FOR GLUE AND LAMBDA CODE                                                                 #
# This logging class constructs the info or warn or error...
#                               ...message into JSON format with all the additional attributes
# Output e.g.,
# --------------------------------------------------------------------------------------------------------------#
import logging
import sys
import time
import json
try:
    from awsglue.utils import getResolvedOptions
except: 
    pass

class CommonLogging(object):
    def __init__(self, job_args=None):
        MSG_FORMAT = '%(message)s'
        global logger
        self.logger = logging.getLogger()
        logging.basicConfig(format=MSG_FORMAT, stream=sys.stdout)
        self.logger.setLevel(logging.INFO)
        try:
            self.log_glue_args = getResolvedOptions(args=sys.argv, options=job_args)
            self.service = 'Glue'
        except:
            try:
                self.event = job_args
                self.service = 'Unknown'
            except:
                print("no cli/event args")

    def message_template(self):
        message_template = {}
        self.keys = ['TIMESTAMP', 'SERVICE', 'SUBTENANT', 'PIPELINE', 'DATABASE', 'TABLE', 'GLUE_JOB_RUN_ID', 'STATUS',
                     'MESSAGE']
        message_template = dict.fromkeys(self.keys)
        return message_template

    def construct_message(self, msg_type, message):
        constructed_message = self.message_template()
        constructed_message['TIMESTAMP'] = int(time.time())
        constructed_message['STATUS'] = msg_type
        constructed_message['MESSAGE'] = message
        constructed_message['SERVICE'] = self.service
        try:
            constructed_message['PIPELINE'] = self.log_glue_args['PIPELINE']
            constructed_message['SUBTENANT'] = self.log_glue_args['SUBTENANT']
            constructed_message['DATABASE'] = self.log_glue_args['TARGET_DATABASE']
            constructed_message['GLUE_JOB_RUN_ID'] = self.log_glue_args['JOB_RUN_ID']
        except:
            try:
                constructed_message['PIPELINE'] = self.event['dataset']
                constructed_message['SUBTENANT'] = self.event['team']
                constructed_message['DATABASE'] = self.event['source_database']
                constructed_message['TABLE'] = self.event['source_table']
                constructed_message['SERVICE'] = 'Lambda'
            except:
                print("not enough job parameters found")

        return constructed_message

    def info(self, msg, extra_i=None):
        self.message = msg
        self.msg_type = "INFO"
        self.info_message = self.construct_message(self.msg_type, self.message)
        if extra_i:
            self.info_message.update(extra_i)
        self.logger.info(json.dumps(self.info_message))

    def warning(self, msg, extra_w=None):
        self.message = msg
        self.msg_type = "WARNING"
        self.warning_message = self.construct_message(self.msg_type, self.message)
        if extra_w:
            self.warning_message.update(extra_w)
        self.logger.warning(json.dumps(self.warning_message))

    def error(self, msg, extra_e=None):
        self.message = msg
        self.msg_type = "ERROR"
        self.error_message = self.construct_message(self.msg_type, self.message)
        if extra_e:
            self.error_message.update(extra_e)
        self.logger.error(json.dumps(self.error_message))
        raise
