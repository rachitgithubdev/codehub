#######################################################
# Blueprint example of a light transformation
# that is just a pass-through function.
# The SDLF always has a 2-stage approach of light and
# heavy transforms, but if no processing/transform
# required for the light stage, this blueprint can be
# used. 
#######################################################
# License: Apache 2.0
#######################################################


#######################################################
# Use the common datalake library logging function
#######################################################
from datalake_library.commons import init_logger

logger = init_logger(__name__)

#######################################################
# Function receives details of file for processing,
# and returns same so SDLF common code can add to SQS
# queue for processing by Stage B heavy transform
#######################################################

class CustomTransform():
    def __init__(self):
        logger.info("S3 Blueprint Light Transform initiated")

    def transform_object(self, bucket, key, team, dataset, database):
        # IMPORTANT This stage is purely a pass through
        # Raw key will be passed to Stage B

        # IMPORTANT S3 path(s) must be stored in a list
        processed_keys = [key]
        return processed_keys
