########################################################
## Blueprint example of a custom transformation
## that start a Step Functions state machine to run a
## custom orchestration pipeline
#######################################################
## License: Apache 2.0
#######################################################
## Author: garetheagar
#######################################################

import boto3
import json
import time
import datetime as dt
from datalake_library.commons import init_logger

logger = init_logger(__name__)

# Create boto3 clients for SSM (parameter store) and stepfunctions
ssm = boto3.client('ssm')
sfn = boto3.client('stepfunctions')

def datetimeconverter(o):
    if isinstance(o, dt.datetime):
        return o.__str__()

class CustomTransform():
    def __init__(self):
        logger.info("SDLF Standalone Stage Pipeline initiated - Step Function Runner")

    def transform_object(self, bucket, keys, team, dataset, database=None, peh_id='none'):
        #######################################################
        ## We assume a Step Function state machine has already 
        ## been created based on subtenant requirements.
        ## This function makes an API call to start it
        #######################################################

        logger.info(f"Running standalone_stage_start-sfn from datalake library")

        # Log the parameters passed to the heavy transform
        logger.debug("Parameters received by Lambda function")
        logger.debug("--------------------------------------")
        logger.debug(f'team: {team}')
        logger.debug(f'dataset: {dataset}')
        logger.debug(f'database: {database}')
        logger.debug(f'bucket: {bucket}')
        logger.debug(f'keys: {keys}')

        # Use SSM to find various environment parameters that we pass to the
        # step function
        raw_bucket = ssm.get_parameter(Name='/Datahub/S3/RawBucket')['Parameter']['Value']
        transform_bucket = ssm.get_parameter(Name='/Datahub/S3/TransformBucket')['Parameter']['Value']
        conform_bucket = ssm.get_parameter(Name='/Datahub/S3/ConformBucket')['Parameter']['Value']
        enrich_bucket = ssm.get_parameter(Name='/Datahub/S3/EnrichBucket')['Parameter']['Value']
        tenant = ssm.get_parameter(Name='/Datahub/Misc/pTenant')['Parameter']['Value']
        env = ssm.get_parameter(Name='/Datahub/Misc/pEnvironment')['Parameter']['Value']
        account = ssm.get_parameter(Name='/Datahub/Misc/pApp')['Parameter']['Value']
        subtenant = team
        pipeline = dataset

        # Use the first key to determine source db and table
        source_key_list = []
        if keys is not None:
            key_split = keys[0].split('/')
            source_database = key_split[0]
            source_table = key_split[1]
            processed_keys_path = f's3://{conform_bucket}/custom/main/{team}/{source_database}/clean_{source_table}/'
            logger.info(f"processed_keys_path: {processed_keys_path}")

            
            for key in keys:
                source_key_list.append(key)
                logger.info(f"Added to source_key_list: {key}")
        else:
            processed_keys_path = None
        
        # Log the dervied parameters and paths
        logger.info(f"source_bucket: {bucket}")
        logger.info(f"raw_bucket: {raw_bucket}")
        logger.info(f"transform_bucket: {transform_bucket}")
        logger.info(f"conform_bucket: {conform_bucket}")
        logger.info(f"enrich_bucket: {enrich_bucket}")

        logger.info(f"tenant: {tenant}")
        logger.info(f"env: {env}")
        logger.info(f"account: {account}")
        logger.info(f"subtenant: {subtenant}")
        logger.info(f"pipeline: {pipeline}")

        # Configure the input_data that will be passed to the state machine
        input_data = {}
        input_data['source_files'] = json.dumps(source_key_list)
        input_data['source_bucket'] = bucket
        input_data['raw_bucket'] = raw_bucket
        input_data['transform_bucket'] = transform_bucket
        input_data['conform_bucket'] = conform_bucket
        input_data['enrich_bucket'] = enrich_bucket
        input_data['processed_keys_path'] = processed_keys_path
        
        input_data['target_database'] = database
        input_data['tenant'] = tenant
        input_data['env'] = env
        input_data['account'] = account
        input_data['subtenant'] = subtenant
        input_data['pipeline'] = pipeline
        
        if peh_id is not 'none':
            input_data['peh_id'] = peh_id

        sfn_input = json.dumps(input_data)

        # Get current timestamp to use in the execution name of the state
        # machine
        ts = time.time()
        execution_name = f'Standalone-lambda-trigger-state-machine-{ts}'

        # This function assumes that a Step Function was created by subtenant
        # custom CFN template, and that as part of that it create a system
        # manager parameter store key/pair containing the step function ARN
        sm_parameter_name = f'/Datahub/SM/{team}/standalone/{dataset}-SM'
        sm_arn = ssm.get_parameter(Name=sm_parameter_name)['Parameter']['Value']
        logger.info(f'Calling Standalone Step Function state machine with ARN: {sm_arn}')
        
        # Start the state machine
        sm_response = sfn.start_execution(
            stateMachineArn=sm_arn,
            name=execution_name,
            input=sfn_input
        )

        # Collecting details about Step Function after submission
        json_data = json.loads(json.dumps(sm_response, default=datetimeconverter))
        sfn_details = {
            "sfnARN" : sm_arn,
            "sfnRunId": json_data.get('executionArn'),
            "jobStatus": 'STARTED'
        }

        #######################################################
        ## IMPORTANT
        ## This function must return a dictionary object with at least a reference to:
        ## 1) processedKeysPath (i.e. S3 path where job outputs data without the s3://stage-bucket/ prefix)
        ## 2) jobDetails (i.e. a Dictionary holding information about the job
        ## A jobStatus key MUST be present in jobDetails as it's used to determine the status of the job 
        ## Example: {processedKeysPath' = 'post-stage/engineering/legislators',
        ## 'jobDetails': {'sfnARN': 'arnarnarn', 'sfnRunId': 'executionarn', 'jobStatus': 'STARTED'}}
        #######################################################
        response = {
            'processedKeysPath': processed_keys_path,
            'jobDetails': sfn_details
        }

        return response

    def check_job_status(self, bucket, keys, processed_keys_path, job_details):
        # This function checks the status of the currently running state machine
        sfn_response = sfn.describe_execution(executionArn=job_details['sfnRunId'])
        json_data = json.loads(json.dumps(sfn_response, default=datetimeconverter))
        # IMPORTANT update the status of the job based on the job_response (e.g RUNNING, SUCCEEDED, FAILED)
        logger.info(f'Determining standalone state machine status ...')
        jobStatus = json_data.get('status')
        job_details['jobStatus'] = jobStatus
        sfnOutput = json_data.get('output')
        if sfnOutput:
            logger.debug(f"Converting sfnOutput to json")
            sfnOutput = json.loads(sfnOutput)
        job_details['sfnOutput'] = sfnOutput
        logger.info(f"sfnOutput: {sfnOutput}")
        logger.info(f'Standalone State Machine Status: {jobStatus}')

        #######################################################
        ## IMPORTANT
        ## This function must return a dictionary object with at least a reference to:
        ## 1) processedKeysPath (i.e. S3 path where job outputs data without the s3://stage-bucket/ prefix)
        ## 2) jobDetails (i.e. a Dictionary holding information about the job
        ## e.g. jobName and jobId for Glue or clusterId and stepId for EMR
        ## A jobStatus key MUST be present in jobDetails as it's used to determine the status of the job) 
        ## Example: {processedKeysPath' = 'post-stage/legislators',
        ## 'jobDetails': {'jobName': 'legislators-glue-job', 'jobId': 'jr-2ds438nfinev34', 'jobStatus': 'RUNNING'}}
        #######################################################
        response = {
            'processedKeysPath': processed_keys_path,
            'jobDetails': job_details
        }
        
        return response
