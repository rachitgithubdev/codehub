**Important**: This repository uses [Git Submodules](https://www.vogella.com/tutorials/GitSubmodules/article.html). To clone the repository and all its submodules into your local machine, use:
```bash 
git clone --single-branch --branch mainline --recursive ssh://git.amazon.com/pkg/DataLakeOffering
for dir in ./DataLakeOffering/*/; do cd "$dir" && git checkout mainline && cd ../../; done
cd ./DataLakeOffering/
```

# Overview

Video: [SDLF - 10,000 Feet Overview](https://broadcast.amazon.com/videos/182305)

## Motivation

The motivation behind this work stemmed from the realization that AWS customers have little to no prior knowledge when it comes to deploying data lakes on AWS, nor do they want to spend time creating one. On the other hand, they possess a deep understanding of 1) their data (schema, metadata, sources....) and 2) their transformations (i.e. the business logic and code to apply on this data) which AWS ProServe consultants lack and should be focusing on instead of setting the foundations for a data lake. The objective of this Serverless Data Lake Framework is to bridge this gap by offering a modular solution which abstracts the AWS architecture of the data lake away from the customer, and thus allows them and consultants to focus exclusively on integrating the data and custom transformations. In short, building a data lake becomes undifferentiated heavy lifting.

## A Working Backwards Approach

More specifically, the following tenets were used as working backwards guiding principles in the design:
- *Delivering Value*: Enabling ProServe consultants to focus on delivering value to customers with their data, not on building the foundations of a data lake
- *Speed matters*: Accelerating the delivery of enterprise data lakes on AWS from several months to a few weeks
- *Modularity and Flexibility*:
    - A framework that can easily be tailored to the customer's specific needs (e.g. number and order of the processing steps…)
    - … and allows seamless integration of custom code using any AWS Analytical service for processing (λ, Fargate, SageMaker, Glue, EMR…)
- *Automated*: Effortless, reproducible and fast deployments with low operations/maintenance and easy administration
- *Serverless*: Every single service in this framework is serverless, taking advantage of its low cost, enhanced scalability and avoiding networking headaches to customers

The result is a serverless and event-driven framework aimed at accelerating the delivery of enterprise data lakes on AWS by shortening the deployment time to production. It can be used by AWS consultants, partners and customers to implement the foundational structure of a data lake following best practices. Three customers in EMEA (Jagex, Formula 1 (Public Reference) and Amazon ICC), two in NA (ACI and Hudl (Public Reference)), two in LATAM (VTR and Puntos Colombia) and another in APAC (David Jones) have adopted this framework in production.

You can find links to our newsletter, first call deck, training videos and more in our ProServe Data & Analytics [Wiki](https://w.amazon.com/bin/view/AWS/Teams/Proserve/ETIP/Analytics/Tools&Frameworks/)

# Structure
![Structure](docs/code-repositories-structure.png)

The above diagram details the role of each code repository and how they interact with each other to define the overall structure of the framework. Following the single responsibility principle, each repository is responsible for a **single** piece of the overall data lake's functionality. This way we not only avoid developing a monolithic solution, but also ensure that code changes are localized and have a limited impact. We have also heavily invested in code and architecture **abstraction** to reduce complexity and allow efficient design and flexible implementations.

1. ```common-cloudformation``` repository implements the foundational elements of the data lake, namely the S3 buckets, DynamoDB tables and some IAM roles. It's deployed once only and is consumed by all systems and users across the lake
2. ```common-team``` repository is deployed once for each **team** (e.g. a pizza team of developers or an entire BU such as a marketing or finance department) that wish to onboard into the data lake. A team is responsible for their pipelines, datasets and repositories which are unique to the team and completely segregated from others. Teams are also isolated from a security standpoint through least-privilege IAM policies
3. ```common-pipeline``` is used to deploy team-specific **pipelines**. A team can implement one or more pipelines depending on their needs. Each pipeline is divided into **stages** (i.e. pre-stage, post-stage, analytics-stage), which correspond to different areas within the lake as data is transformed and moved. As many stages as necessary can be defined and modified for a pipeline. Step Functions, Lambdas and SQS/Dead Letter queues are implemented in this step
3. ```common-dataset``` deploys a team-specific dataset. A dataset must be unique within a given team
4. ```common-datalakeLibrary``` holds the **application** and **transformation code**. This is where each team pushes the code and transformations that they wish to apply to their datasets through their pipelines. Every time the code is updated by the team, the change is automatically propagated across the pipelines that they own
5. ```common-pipLibrary``` can be leveraged by each team when specific Pip libraries are required by certain transformations (e.g. Pandas, DataWrangler...). It can be attached to all or only specific pipelines

The main objective behind this approach is that you can manage and maintain your entire data lake from these repositories through simple Git commits. At no point is interaction with the AWS console necessary (in fact it's discouraged as explained below). This provides a number of advantages:
- **Traceability and version control**: Using version control ensures that any change to the data lake is scrutinized before it enters production. We not only know who made the change and when but we can have checks and balances in place through automated testing. By omitting to enforce CI/CD best practices (e.g. allowing manual changes made through the console), there would be no way to track changes or to roll them back
- **Scalability and reproducibility**: Deploying and removing a customized, production-grade data lake can be done in minutes and we can scale to multiple accounts and environments easily. This is in comparison to a manual approach which would be tedious, slow, prone to errors and unable to scale

# Architecture

![Architecture](docs/datalake-architecture.png)

Video: [SDLF - Implementation Demo](https://broadcast.amazon.com/videos/182324)

The architecture relies on CloudWatch, Lambda, SQS, DynamoDB and Glue to ingest, store, transform, analyze and move data across the data lake.

As a file lands into the RAW bucket under the ```<team>/<dataset>``` prefix an S3 Events Notification is created and placed in a queue. The message is picked up by a Lambda which routes it to the appropriate pre-stage state machine queue (StageA). Processing begins as the Objects Catalog DynamoDB table is updated with details about the landed file (S3 Path, timestamp...) before a light transformation Lambda is applied. The code for this light transformation would have previously been pushed into a CodeCommit repository by the data engineer and potentially gone through a code review and testing phase before entering production. 
5 minutes later (customizable), a CloudWatch Event rule fires the post-stage state machine (StageB) and similar steps are triggered, but this time a heavy transformation is applied on a batch of files. This heavy transformation can be an API call to another Big Data or ML AWS service (Glue Job, Fargate Task, EMR Step, SageMaker Notebook...) and the code is again provided by the customer. The state machine waits for the job to reach a ```SUCCEEDED``` state before the output is crawled via Glue. 

The biggest advantage of this framework is its flexibility and modularity. Any step and stage in the state machines and their associated application and infrastructure code can easily be customized to fulfill the customer's requirements. 

Finally, this entire infrastructure is templatized with CloudFormation which ensures repeatable and reliable deployments.

# Road Map
| Feature       | Foundational Stack and Documentation  | ELK Stack  |  Octagon Integration  |  SQS Decoupling  |  Team and Pipeline Constructs  |  EMR and Deequ  |  CDC Ingestion  |  Alarms and Notifications  |  Least-Privilege Policies  |  KMS Encryption  | CloudTrail Auditing  |
| ------------- |:-------------:|:-------------:|:-------------:|:-------------:|:-------------:|:-------------:|:-------------:|:-------------:|:-------------:|:-------------:|-----:|
| Task Progress |	Completed  |	Completed  | Completed | Completed | Completed | Completed | Completed | Completed | Completed | Completed | Completed |
| ETA  |	10/2019  | 11/2019 | 12/2019 | 12/2019 | 01/2020 | 02/2020 | 02/2020 | 03/2020 | 03/2020 | 04/2020 | 04/2020 |
| Component  |	Foundation  | Monitoring | Monitoring | Foundation | Foundation | Processing | Ingestion | Alerting | Security | Security | Auditing |
| Status  |	![Green](docs/icons/green.png)  | ![Green](docs/icons/green.png) | ![Green](docs/icons/green.png) | ![Green](docs/icons/green.png) | ![Green](docs/icons/green.png) | ![Green](docs/icons/green.png) | ![Green](docs/icons/green.png) | ![Green](docs/icons/green.png) | ![Green](docs/icons/green.png) | ![Green](docs/icons/green.png) | ![Green](docs/icons/green.png) |

# Quick Start Deployment

Below is a quick start to deploying the Serverless Data Lake Framework and Octagon. A training video series is also available on [Broadcast](https://broadcast.amazon.com/channels/18243/playlists/3358). For more detailed instructions and access to advanced features, please refer to the README.md documentation in each repository. Estimated time for completion: **40-45 minutes**.

If you wish to go further with the framework, the Data and Analytics GSP is happy to help you with your first customer deployment. Please reach out to [@jaidi](https://phonetool.amazon.com/users/jaidi).

## Prerequisites

The prerequisites to deploy the framework are:
- A new, unused AWS Account. A newly created AWS Isengard account for example
- A role with Admin permissions

## Deployment

1. Log in to the AWS account console using the **Admin role** and select an AWS region. We recommend choosing a mature region where most services are available (e.g. eu-west-1, us-east-1...) - Video: [SDLF - Deploying the Foundations](https://broadcast.amazon.com/videos/183660)

2. Set up a [Cloud9 Environment](https://docs.aws.amazon.com/cloud9/latest/user-guide/create-environment-main.html) in that AWS region (t2.small or higher, Linux AMI) and log into it. Using a Cloud9 environment ensures that required software (e.g. Git) is pre-installed and that neither your computer nor the Cloud9 instance are polluted by existing environment variables

3. In your web browser, connect to the following internal website [http://ec2-35-166-59-154.us-west-2.compute.amazonaws.com](http://ec2-35-166-59-154.us-west-2.compute.amazonaws.com) and generate a pre-signed S3 URL by clicking on the button. This URL expires after a few minutes

4. Back in Cloud9, run the below command to pull the data lake artifacts, replacing ```<S3_presigned_url>``` with the value generated in the previous step:
    ```bash 
   wget -O ServerlessDatalakeArtifacts.zip <S3_presigned_url>
    ```
    example:
    ```bash 
    ```
   a zip file will appear in the home directory. Unzip it:
    ```bash
   unzip ServerlessDatalakeArtifacts.zip
    ```
   Two directories should be visible:
    ```bash
    ./
    ├── Octagon
    └── ServerlessDatalakeArtifacts
    ```

5. **[OPTIONAL]** The following is an optional step where you can deploy [Octagon](https://code.amazon.com/packages/Octagon/trees/mainline), a pipeline monitoring dashboard which allows business stakeholders and cloud engineers to view and manage the current state of their data pipelines such as ingestion and transformation jobs. If you decide to implement it, run the below command:
    ```bash
    cd ~/environment/Octagon/automated-deployment/
    ./deploy.sh -e dev # dev, test or prod
    ```
    which creates a CodePipeline in the account to automatically deploy the solution. The entire process can take between 35 and 40 minutes and you can monitor it on the console in CodeBuild. However, we do not have to wait for it to complete and you can proceed with the remaining steps below while Octagon is being implemented in the background.

6. Back in the home directory, navigate into the ```ServerlessDatalakeArtifacts``` directory:
   ```
   cd ~/environment/ServerlessDatalakeArtifacts
    ```
   It contains the nine repositories used by the framework:
    ```bash
    ./
    ├── deploy_repos.sh
    └── ServerlessDatalakeArtifacts
        ├── common-cloudformation # Deployed once to implement the data lake infrastructure
        ├── common-team # Deployed for each new team
        ├── common-pipeline # Deployed for each new pipeline
        ├── stageA # Deploys the StageA state machine for each pipeline
        ├── stageB # Deploys the StageB state machine for each pipeline
        ├── common-datalakeLibrary_bkp # CodeCommit repository where customer can push their custom application and transformation code
        ├── common-pipLibrary_bkp # Used to generate Pip Libraries loaded as Lambda Layers
        ├── common-dataset # Deployed for each new team-specific dataset
        └── common-utils # Sample data for testing
    ``` 

7. Run the ```deploy_repos.sh``` script to create the required CodeCommit repositories:
    ```bash
   ./deploy_repos.sh
    ```
    The command creates and pushes code from the nine repositories into CodeCommit in the same region as your Cloud9 instance

8. We start by deploying the foundations of the data lake, including the S3 bucket(s), KMS Key, Cloud Trail and the DynamoDB Objects Catalog table. Navigate to:
    ```bash 
   cd ~/environment/ServerlessDatalakeArtifacts/common-cloudformation/
    ```
    and take a look at the ```parameters.json``` file:
    ```bash
    [
        {
            "ParameterKey": "pOrganizationName",
            "ParameterValue": "forecourt" # 10 characters or less, lowercase and numbers only
        },
        {
            "ParameterKey": "pApplicationName",
            "ParameterValue": "datalake"
        },
        {
            "ParameterKey": "pEnvironment",
            "ParameterValue": "dev" # dev, test or prod
        },
        {
            "ParameterKey": "pNumBuckets",
            "ParameterValue": "3" # 3 or 1
        },
        {
            "ParameterKey": "pSNSNotificationsEmail",
            "ParameterValue": "nobody@amazon.com"
        }
    ]
    ```
    where the name of the organization owning the data lake (```pOrganizationName```) can be updated. You can also choose between an architecture with three buckets (RAW, STAGE, ANALYTICS) versus one central bucket. If you prefer the latter, change the last parameter to "1". Optionally, you can choose to also deploy an Elasticsearch, Logstash, Kibana (ELK) stack to introduce a low-level monitoring layer to the framework. Follow the instructions in this [README.md](https://code.amazon.com/packages/Common-cloudformation/blobs/mainline/--/docs/kibana/ELK_README.md) if you wish to include this option, but please bear in mind that it will add another 15 minutes to deployment time due to the Elasticsearch domain creation. Lastly, you can specify an email address to receive alerts from the CloudWatch alarms in place to monitor the data lake infrastructure.
    
    Once the parameters are configured run the below command:
    ```bash
   ./deploy.sh 
    ```
    It will launch CloudFormation stacks to deploy the foundational data lake resources in the account. You can follow the progress of this operation in the CloudFormation console

9. Once the stack is in ```CREATE_COMPLETE```, we can deploy infrastructure for a specific ```team``` - Video: [SDLF - Deploying a Team](https://broadcast.amazon.com/videos/185799). Navigate to:
    ```bash 
   cd ~/environment/ServerlessDatalakeArtifacts/common-team/
    ```
    and take a look at the ```parameters.json``` file:
    ```bash
    [
        {
            "ParameterKey": "pTeamName",
            "ParameterValue": "engineering" # 12 characters or less, lowercase and numbers only
        },
        {
            "ParameterKey": "pEnvironment",
            "ParameterValue": "dev" # dev, test or prod
        },
        {
            "ParameterKey": "pDatalakeLibraryRepositoryName",
            "ParameterValue": "common-datalakeLibrary" # team-specific datalake-library
        },
        {
            "ParameterKey": "pPipLibrariesRepositoryName",
            "ParameterValue": "common-pipLibrary" # team-specific pip-library
        },
        {
            "ParameterKey": "pSNSNotificationsEmail",
            "ParameterValue": "nobody@amazon.com" # team-specific email to receive CloudWatch alarms notifications
        }
    ]
    ```
    ```<pTeamName>``` refers to the team that will manage pipelines and the associated application code and custom transformations within the lake. You can create multiple teams (e.g. engineering, marketing, finance) by changing the parameters in the file and running:
    ```bash
   ./deploy.sh
    ```
    **Important:** For the purposes of this demo deployment, keep ```engineering``` in the ```parameters.json``` file and run the above command. A CloudFormation stack will create team-specific IAM policies (following the least-privilege principle), CodeBuilds and CodePipelines to manage the team's pipelines. 
    
10. Once the team stack is in ```CREATE_COMPLETE```, we deploy a team-specific pipeline - Video: [SDLF - Deploying a Pipeline](https://broadcast.amazon.com/videos/186138). Navigate to:
    ```bash 
    cd ~/environment/ServerlessDatalakeArtifacts/common-pipeline/
    ```
    and take a look at the ```parameters.json``` file:
    ```bash
    [
        {
            "ParameterKey": "pTeamName",
            "ParameterValue": "engineering" # 12 characters or less, lowercase and numbers only
        },
        {
            "ParameterKey": "pPipelineName",
            "ParameterValue": "main" # 10 characters or less, lowercase and numbers only
        },
        {
            "ParameterKey": "pEnvironment",
            "ParameterValue": "dev" # dev, test or prod
        },
        {
            "ParameterKey": "pStageAStateMachineRepository",
            "ParameterValue": "stageA" # team-specific StageA repository
        },
        {
            "ParameterKey": "pStageBStateMachineRepository",
            "ParameterValue": "stageB" # team-specific StageB repository
        },
        {
            "ParameterKey": "pStageABranch",
            "ParameterValue": "master" # pipeline-specific StageA git branch
        },
        {
            "ParameterKey": "pStageBBranch",
            "ParameterValue": "master" # pipeline-specific StageB git branch
        }
    ]
    ```
    ```<pTeamName>``` refers to the same team name entered in the previous step. ```<pPipelineName>``` is the name of the pipeline where the stage A and B step functions are defined. A team can create one or more pipelines within the lake (e.g. cdc, ml...)

    **Important:** For the purposes of this demo, keep the ```parameters.json``` file as is and run:
    ```bash
    ./deploy.sh
    ```
    Five CloudFormation stacks will create the pipeline, including the step functions, SQS and Dead-letter queues, and their associated Lambdas.

11. Please ensure that five stacks were deployed in the previous step (one parent, two for stageA and two for stageB) before proceeding further. If some are missing, look for any errors in CodePipeline. Once the pipeline stacks are in ```CREATE_COMPLETE```, we can move on to deploying a dataset - Video: [SDLF - Deploying a Dataset](https://broadcast.amazon.com/videos/188392). It's important to understand that a dataset can be anything from a single table to an entire database with multiple tables for example. It will depend on how the customer wishes to organize their data but an overall good practice is to limit the infrastructure deployed to the minimum to avoid unnecessary overhead and cost. So in general the more you group together infrastructure wise and abstract at the code level the better. Navigate to:
    ```bash 
    cd ~/environment/ServerlessDatalakeArtifacts/common-dataset/
    ```
    and take a look at the ```parameters.json``` file:
    ```bash
    [
        {
            "ParameterKey": "pTeamName",
            "ParameterValue": "engineering" # 12 characters or less, lowercase and numbers only
        },
        {
            "ParameterKey": "pPipelineName"
            "ParameterValue": "main" # 10 characters or less, lowercase and numbers only
        },
        {
            "ParameterKey": "pDatasetName",
            "ParameterValue": "legislators" # 14 characters or less, lowercase and numbers only
        },
        {
            "ParameterKey": "pEnvironment",
            "ParameterValue": "dev" # dev, test or prod
        }
    ]
    ```
    ```<pTeamName>``` and ```<pPipelineName>``` are the same than in the previous step. ```<pDatasetName>``` is the name of a team-specific dataset (e.g customers, orders, flights...) 

    **Important:** For the purposes of this demo, keep the ```parameters.json``` file as is and run:
    ```bash
    ./deploy.sh
    ```
    A CloudFormation stack will create dataset-specific resources, namely an SQS queue, a trigger and a Glue crawler

12. Time for the customer to provide their custom transformations which represent the code that will be executed in the light and heavy transformation Lambdas (See Architecture Diagram). The ```common-datalakeLibrary``` CodeCommit repository is where they can Git push their Python code:
    ```bash
    ./
        ├── README.md
        └── python
            └── datalake_library
                ├── configuration
                ├── interfaces
                ├── octagon
                └── transforms
                    ├── stage_a_transforms
                    │   ├── light_transform_blueprint.py # Light Transform for StageA provided by the customer for legislators dataset
                    │   ├── ...
                    ├── stage_b_transforms
                    │   ├── heavy_transform_blueprint.py # Heavy Transform for StageB provided by the customer for legislators dataset
                    │   └── ...
                    └── dataset_mappings.json # Configuration file mapping the dataset to the light/heavy transformations code
                    └── transform_handler.py
    ```
    You can explore how this custom code is executed within the Lambdas in the framework by looking at those Python files in more detail in the [common-datalakeLibrary](https://code.amazon.com/packages/Common-datalakeLibrary/blobs/mainline/--/README.md) repository. Once the code has been developed, it must be mapped to the relevant dataset. This is achieved by the ```dataset_mappings.json``` configuration file which is responsible for mapping the transforms to the correct dataset entry. Opening this file would reveal an example of a mapping between the ```legislators``` dataset that we created earlier and the two transformation Python files:
    ```bash
    [
        {
            "name": "legislators",
            "transforms": {
                "stage_a_transform": "light_transform_blueprint",
                "stage_b_transform": "heavy_transform_blueprint"
            }
        }
    ]
    ```
    **Important:** Each time a new transformation Python file is created, it must be mapped to the relevant dataset for it to take effect.

    As soon as you commit the code and mapping changes to the ```common-datalakeLibrary``` repository, a pipeline is executed and applies these changes to the transformation Lambdas.

13. You can check that the mapping has been correctly applied by navigating into DynamoDB and opening the ```octagon-Dataset-<pEnvironment>``` table. In there, you should find an ```engineering-legislators``` item (i.e. ```team-dataset```). As you can notice, this entry is mapped to the light and heavy Python files created by the customer as defined in the ```dataset_mappings.json``` file. We have also specified which pipeline will be processing the dataset (```main```) and the max and min number of objects to process in the StageB phase. In addition to these mandatory attributes, you can supply any other relevant metadata following the example below. This metadata will be particularly relevant when we reach the Octagon section:
    ```bash
    {
        "name": "engineering-legislators",
        "pipeline": "main",
        "transforms": {
            "stage_a_transform": "light_transform_blueprint",
            "stage_b_transform": "heavy_transform_blueprint"
        },
        "":
        "max_items_process": {
            "stage_b": 100,
            "stage_c": 100
        },
        "min_items_process": {
            "stage_b": 1,
            "stage_c": 1
        },
        "classification": "Public",
        "description": "US Legislators Data",
        "frequency": "DAILY",
        "owner": "Every Politician",
        "owner_contact": "politician@whitehouse.org",
        "tags": [
            {
            "key": "cost",
            "value": "parliament division"
            }
        ],
        "type": "TRANSACTIONAL",
        "version": 1
    }
    ```

    Similarly, we have populated the ```octagon-Pipelines-<pEnvironment>``` table with the information specified in the ```parameters.json``` file. It corresponds to the metadata for the ```engineering``` team ```main``` pipeline (Stage A and B). You can supply additional details such as the ```owner``` or ```tags``` following the examples below:
    ```bash
    {
        "name": "engineering-main-stage-a",
        "description": "Main Pipeline to Ingest Data",
        "ingestion_frequency": "WEEKLY",
        "modules": [
            {
            "name": "pandas",
            "version": "0.24.2"
            },
            {
            "name": "Python",
            "version": "3.7"
            }
        ],
        "owner": "Upper House",
        "owner_contact": "senate@",
        "status": "ACTIVE",
        "tags": [
            {
            "key": "org",
            "value": "SENATE"
            }
        ],
        "type": "INGESTION",
        "version": 1
    }
    ```
    and
    ```bash
    {
        "name": "engineering-main-stage-b",
        "description": "Main Pipeline to Merge Data",
        "ingestion_frequency": "WEEKLY",
        "modules": [
            {
            "name": "PySpark",
            "version": "1.0"
            }
        ],
        "owner": "Lower House",
        "owner_contact": "congress@",
        "status": "ACTIVE",
        "tags": [
            {
            "key": "org",
            "value": "CONGRESS"
            }
        ],
        "type": "TRANSFORM",
        "version": 1
    }
    ```

14. The data lake is now fully deployed and it is time to test it with sample data. Back in the Cloud9 environment, run these commands:
    ```bash
    cd ~/environment/ServerlessDatalakeArtifacts/common-utils/pipeline-examples/legislators/
    ./deploy.sh
    ```
    It will first create a sample Glue Job (inspired by this [tutorial](https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-python-samples-legislators.html)) and then start sending data to the lake for testing.

    A certain number of json files containing various information about US politics have been uploaded to the RAW S3 bucket under the ```engineering/legislators``` prefix (```raw/engineering/legislators``` if you chose one central bucket) and the entire pipeline is triggered. By navigating to the Step Functions console, you can follow how each file is first processed in the stageA state machine where it is parsed and then saved to the ```pre-stage/engineering/legislators``` prefix in the STAGE bucket. This business logic was provided by your customer (the White House) and you have successfully integrated it to the framework. Shortly afterwards (0-5 minutes), a stageB state machine is triggered and the heavy transformation applied to a batch of files that are merged together. The final output is then crawled in Glue, and various tables about US legislation are automatically created in [Athena](https://aws.amazon.com/athena/getting-started/) and can be queried (*NB:* Make sure to create a bucket to store Athena results before attempting to query data)

15. If you have opted to implement Octagon, it is probably fully deployed by now. Check that is the case by navigating into CloudFormation and ensuring that the ```octagon-dev-webui-codepipeline``` is in the ```CREATE_COMPLETE``` state. 

    Octagon implements a Web Firewall to prevent non-authorized IP addresses from reaching the Web UI. You can disable the WAF by navigating to CloudFront and editing the Octagon distribution to None in ```AWS WAF Web ACL```. If you decide to keep the WAF then you will need to whitelist your IP address. Navigate into the ```WAF & Shield``` service in the console and click on ```Switch to AWS WAF Classic``` located in the left hand-side menu. Then choose ```IP Addresses``` and ```Whitelist Amazon IPs```. Add your address into the existing range of IPs (e.g. ```54.240.197.224/32```). **Note:** You can find your current IP by typing what is my IP in Google. Please also note that if you are logged in to the network through the VPN, you will also have to add the IP you used to connect to the Amazon network (i.e. the one that appears in your configuration **before** you connect to the VPN)

    **IMPORTANT**: If you are deploying Octagon from an Isengard account, ```Block public access (account settings)``` is probably enabled by default in S3. You'll have to disable it in the S3 console (left-hand side menu) 

16. Finally, navigate into ```AWS CloudFront``` in the console and click on the Octagon distribution. Ensure that the ```Distribution Status``` is Deployed and not In Progress. Locate the Domain Name (e.g. ```d2r5r23eb850ss.cloudfront.net```) and follow this URL in your browser. A ```Cognito``` landing page should appear where you need to register. Once you complete the registration step, you will be able to log in and the following dashboard will be presented to you:

    ![Octagon Landing Page](docs/octagon-landing-page.png)

    The menu located on the left hand-side highlights the different components that can be monitored through Octagon. For instance, the ```Pipeline Executions``` section lists all the pipeline executions that were triggered in the data lake through the ```engineering-legislators``` example. Various filters are available, such as failed executions on specific pipelines.

    More details on the Octagon Web UI can be found in their [documentation](https://code.amazon.com/packages/Octagon/trees/mainline/--/documentation).

Congratulations! You have deployed a production-grade data lake within minutes using Git commands exclusively.

## Going further

Below are generic instructions for adding a team, pipeline, stage, dataset and/or pip Library to the data lake. For a hands-on example showcasing these features, please follow this [tutorial](https://code.amazon.com/packages/Common-utils/blobs/mainline/--/pipeline-examples/cloudfront/README.md) which also demonstrates how to include EMR and Deequ steps. More tutorials are also available [here](https://code.amazon.com/packages/Common-utils/blobs/mainline/--/README.md).

### Adding datasets
Assuming the team and pipeline names have not changed, to add a new dataset to the framework, simply update the ```<pDatasetName>``` value in the ```parameters.json``` file located in the team-specific ```common-dataset``` repository and run the deploy command again:
```bash
./deploy.sh
```
Then follow steps 12 and 13 once more to upload your custom code and create a mapping in DynamoDB to the relevant team, pipeline and dataset. You can use the blue prints [(light)](https://code.amazon.com/packages/Common-datalakeLibrary/blobs/mainline/--/python/datalake_library/transforms/stage_a_transforms/light_transform_blueprint.py)/[(heavy)](https://code.amazon.com/packages/Common-datalakeLibrary/blobs/mainline/--/python/datalake_library/transforms/stage_b_transforms/heavy_transform_blueprint.py) created for the ```legislators``` dataset as an example. Uploading a file to ```s3://<raw_bucket>/<pTeamName>/<pDatasetName>``` (```s3://<central_bucket>/raw/<pTeamName>/<pDatasetName>``` if you chose a central bucket) would then start the full processing pipeline.

The modular nature of the framework is fully apparent here, as both the **application** and **infrastructure** code for the stage A and B state machines can be dataset **specific**. 

### Adding pipelines
Adding a new pipeline is achieved by first creating new git branches in the ```stageA``` and ```stageB``` repositories:
```bash
# Run in both stageA and stageB repositories
git checkout -b <pPipelineName>
# Apply your code changes to the order or number of steps and then:
git add .
git commit -m "Creating new pipeline"
git push --set-upstream origin <pPipelineName>
```
This operation ensures that code changes applied to each pipeline (e.g. number and order of steps) are ```segregated```. Once your pipeline-specific changes are pushed to the repository, return to the team-specific ```common-pipeline``` repository and update the ```pPipelineName``` to the new pipeline name, and ```pStageABranch```, ```pStageBBranch``` parameters in the ```parameters.json``` file to the new branches. Then run:
```bash
./deploy.sh
```
More details  can be found in the [common-pipeline README.md](https://code.amazon.com/packages/Common-pipeline/blobs/mainline/--/README.md).

### Adding an Analytics stage (StageC)
The framework is not limited to two stages (A and B). In fact, as many stages as necessary can be generated. To add an analytics stage for example, one simply has to create a repository named ```stageC``` and modify the ```common-pipeline``` repository accordingly. More details in the [common-pipeline README.md](https://code.amazon.com/packages/Common-pipeline/blobs/mainline/--/README.md).

### Adding a team
To introduce a new team to the data lake, create team-specific copies of the repositories in CodeCommit: 
```bash
./
├── <pTeamName>-team # Deployed for each new team
├── <pTeamName>-pipeline # Deployed for each new pipeline
├── <pTeamName>-stageA # Deploys the StageA state machine for each pipeline
├── <pTeamName>-stageB # Deploys the StageB state machine for each pipeline
├── <pTeamName>-datalakeLibrary_bkp # CodeCommit repository where customer can push their custom application and transformation code
└── <pTeamName>-pipLibrary_bkp # Used to generate Pip Libraries loaded as Lambda Layers
```
Then simply go through steps 9-13 of this tutorial, making sure to update each ```parameters.json``` file with the correct values. 
More details in the [common-team README.md](https://code.amazon.com/packages/Common-team/blobs/mainline/--/README.md).

### Adding a Pip Library as a Lambda Layer
One can also add an external Pip Library as a Lambda Layer shared across all the Lambda functions in the account. For instance, the popular Pandas and Numpy libraries can be attached to perform more complex analysis in the Light/Heavy transforms. More details in the [common-pipLibrary README.md](https://code.amazon.com/packages/Common-pipLibrary/blobs/mainline/--/README.md).

### Redriving a pipeline
Details on how to redrive a pipeline that failed can be found in this [README](https://code.amazon.com/packages/DataLakeOffering/blobs/mainline/--/docs/octagon/Redrive.md).

## Clean up
Follow these steps, **in order**, to clean up after you are done exploring the framework:
1. Empty all S3 buckets that were created by the two solutions
2. Delete all DynamoDB tables
3. Delete the `sdlf-engineering-main-stageA` and `sdlf-engineering-main-stageB` CloudFormation stacks first and wait for them to be deleted before proceeding with other stacks
4. Delete the remaining CloudFormation stacks in reverse order of creation
5. Delete the repositories in CodeCommit

**Note**: If you have deployed an ELK stack you will have to delete the Cognito Domain Name for the Kibana stack to be destroyed

# Credits
Credits, in no particular order, to:
- The Data Lake Quick Start team ([Sara Chen](https://phonetool.amazon.com/users/sarchen), [Konstantinos Mavrodis](https://phonetool.amazon.com/users/konmav), [Ash Obhrai](https://phonetool.amazon.com/users/ashobha), [Mattia Berlusconi](https://phonetool.amazon.com/users/mattiabe), [Raphael Sack](https://phonetool.amazon.com/users/raphsack))
- The LATAM Serverless Data Lake Framework team ([Samuel Schmidt](https://phonetool.amazon.com/users/samschs), [Eduardo Barroso](https://phonetool.amazon.com/users/edbarros), [Bruno Ramirez](https://phonetool.amazon.com/users/huebruno), [Igor Tavares](https://phonetool.amazon.com/users/igotavar), [Rocha Andre](https://phonetool.amazon.com/users/rocand), [Koike Rafael](https://phonetool.amazon.com/users/koiker), [Fabricio Quiles](https://phonetool.amazon.com/users/fabhq))
- ProServe consultants ([Muhammad Ali](https://phonetool.amazon.com/users/awsali), [Kirankumar Chandrashekar](https://phonetool.amazon.com/users/kirankuc), [Winnie Tung](https://phonetool.amazon.com/users/wtung), [Nick Corbett](https://phonetool.amazon.com/users/corbetn), [Arpan Shah](https://phonetool.amazon.com/users/arpansha), [Jason Berkowitz](https://phonetool.amazon.com/users/jberkowi), [Dipankar Ghosal](https://phonetool.amazon.com/users/dgghosal))

for their various contributions to this work.

For more details and questions, please reach out to [@jaidi](https://phonetool.amazon.com/users/jaidi)