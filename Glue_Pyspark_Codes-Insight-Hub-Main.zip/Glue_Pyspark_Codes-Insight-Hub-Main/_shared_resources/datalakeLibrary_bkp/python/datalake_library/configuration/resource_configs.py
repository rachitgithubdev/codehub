import os

import boto3

from .base_config import BaseConfig
from ..commons import init_logger


class S3Configuration(BaseConfig):
    def __init__(self, log_level=None, ssm_interface=None):
        """
        Complementary S3 config stores the S3 specific parameters
        :param log_level: level the class logger should log at
        :param ssm_interface: ssm interface, normally boto, to read parameters from parameter store
        """
        self.log_level = log_level or os.getenv('LOG_LEVEL', 'INFO')
        self._logger = init_logger(__name__, self.log_level)
        self._ssm = ssm_interface or boto3.client('ssm')
        super().__init__(self.log_level, self._ssm)

        self._fetch_from_environment()
        self._fetch_from_ssm()

    def _fetch_from_environment(self):
        # Placeholder for future use
        # Example: self._sample_key = os.getenv('SAMPLE_OS_KEY', None)
        return None

    def _fetch_from_ssm(self):
        self._artifacts_bucket = None
        self._raw_bucket = None
        self._transform_bucket = None
        self._conform_bucket = None
        self._enrich_bucket = None

    @property
    def artifacts_bucket(self):
        if not self._artifacts_bucket:
            self._artifacts_bucket = self._get_ssm_param('/Datahub/S3/ArtifactsBucket')
        return self._artifacts_bucket

    @property
    def raw_bucket(self):
        if not self._raw_bucket:
            self._raw_bucket = self._get_ssm_param('/Datahub/S3/RawBucket')
        return self._raw_bucket

    @property
    def transform_bucket(self):
        if not self._transform_bucket:
            self._transform_bucket = self._get_ssm_param('/Datahub/S3/TransformBucket')
        return self._transform_bucket

    @property
    def conform_bucket(self):
        if not self._conform_bucket:
            self._conform_bucket = self._get_ssm_param('/Datahub/S3/ConformBucket')
        return self._conform_bucket

    @property
    def enrich_bucket(self):
        if not self._enrich_bucket:
            self._enrich_bucket = self._get_ssm_param('/Datahub/S3/EnrichBucket')
        return self._enrich_bucket


class DynamoConfiguration(BaseConfig):
    def __init__(self, log_level=None, ssm_interface=None):
        """
        Complementary Dynamo config stores the parameters required to access dynamo tables
        :param log_level: level the class logger should log at
        :param ssm_interface: ssm interface, normally boto, to read parameters from parameter store
        """
        self.log_level = log_level or os.getenv('LOG_LEVEL', 'INFO')
        self._logger = init_logger(__name__, self.log_level)
        self._ssm = ssm_interface or boto3.client('ssm')
        super().__init__(self.log_level, self._ssm)

        self._fetch_from_ssm()

    def _fetch_from_ssm(self):
        self._object_metadata_table = None
        self._transform_mapping_table = None

    @property
    def object_metadata_table(self):
        if not self._object_metadata_table:
            self._object_metadata_table = self._get_ssm_param('/Datahub/Dynamo/ObjectCatalog')
        return self._object_metadata_table

    @property
    def transform_mapping_table(self):
        if not self._transform_mapping_table:
            self._transform_mapping_table = self._get_ssm_param('/Datahub/Dynamo/TransformMapping')
        return self._transform_mapping_table


class SQSConfiguration(BaseConfig):
    def __init__(self, team, stage, dataset, log_level=None, ssm_interface=None):
        """
        Complementary SQS config stores the parameters required to access SQS
        :param log_level: level the class logger should log at
        :param ssm_interface: ssm interface, normally boto, to read parameters from parameter store
        """
        self.log_level = log_level or os.getenv('LOG_LEVEL', 'INFO')
        self._logger = init_logger(__name__, self.log_level)
        self._ssm = ssm_interface or boto3.client('ssm')
        self._team = team
        self._stage = stage
        self._dataset = dataset
        super().__init__(self.log_level, self._ssm)

        self._fetch_from_ssm()

    def _fetch_from_ssm(self):
        self._stage_queue_name = None
        self._stage_dlq_name = None

    @property
    def get_stage_queue_name(self):
        if not self._stage_queue_name:
            self._stage_queue_name = self._get_ssm_param('/Datahub/SQS/{}/{}/{}{}Queue'.format(
                self._team, 'main', self._stage, self._dataset))
        return self._stage_queue_name

    @property
    def get_stage_dlq_name(self):
        if not self._stage_dlq_name:
            self._stage_dlq_name = self._get_ssm_param('/Datahub/SQS/{}/{}/{}{}DLQ'.format(
                self._team, 'main', self._stage, self._dataset))
        return self._stage_dlq_name


class StateMachineConfiguration(BaseConfig):
    def __init__(self, team, pipeline, dataset, stage, log_level=None, ssm_interface=None):
        """
        Complementary State Machine config stores the parameters required to access State Machines
        :param log_level: level the class logger should log at
        :param ssm_interface: ssm interface, normally boto, to read parameters from parameter store
        """
        self.log_level = log_level or os.getenv('LOG_LEVEL', 'INFO')
        self._logger = init_logger(__name__, self.log_level)
        self._ssm = ssm_interface or boto3.client('ssm')
        self._team = team
        self._dataset = dataset
        self._pipeline = pipeline
        self._stage = stage
        super().__init__(self.log_level, self._ssm)

        self._fetch_from_ssm()

    def _fetch_from_ssm(self):
        self._stage_state_machine_arn = None

    @property
    def get_stage_state_machine_arn(self):
        if not self._stage_state_machine_arn:
            self._stage_state_machine_arn = self._get_ssm_param('/Datahub/SM/{}/{}/{}{}SM'.format(self._team, self._pipeline, self._dataset, self._stage))
        return self._stage_state_machine_arn
