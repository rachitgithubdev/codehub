########################################################
## Blueprint example of a custom transformation
## that start a Step Functions state machine to run a
## custom orchestration pipeline
#######################################################
## License: Apache 2.0
#######################################################
## Author: garetheagar
#######################################################

import boto3
import json
import time
import datetime as dt
from datalake_library.commons import init_logger

logger = init_logger(__name__)

# Create a client for the AWS Analytical service to use
ssm = boto3.client('ssm')
sfn = boto3.client('stepfunctions')

def datetimeconverter(o):
    if isinstance(o, dt.datetime):
        return o.__str__()

class CustomTransform():
    def __init__(self):
        logger.info("Glue Job Blueprint Heavy Transform initiated")

    def transform_object(self, team, dataset):
        #######################################################
        ## We assume a Step Function state machine has already 
        ## been created based on subtenant requirements.
        ## This function makes an API call to start it
        #######################################################
        env = ssm.get_parameter(Name='/Datahub/Misc/pEnvironment')['Parameter']['Value']
        
        sm_parameter_name = f'/Datahub/SM/{team}/custom/{dataset}-SM'
        sm_arn = ssm.get_parameter(Name=sm_parameter_name)['Parameter']['Value']
        logger.info(f'Calling Step Function state machine with ARN: {sm_arn}')
        ts = time.time()
        execution_name = f'Standalone-lambda-trigger-state-machine-{ts}'

        input_data = {}
        input_data['team'] = team
        input_data['dataset'] = dataset
        ##########################################################
        ## Insert any additional data that you want to pass to the
        ## Step Function
        ##########################################################
        # input_data['additional_data_1'] = data1
        # input_data['additional_data_2'] = data2
        
        sfn_input = json.dumps(input_data)

        # Start the state machine
        sm_response = sfn.start_execution(
            stateMachineArn=sm_arn,
            name=execution_name,
            input=sfn_input
        )

        # Collecting details about Step Function after submission
        json_data = json.loads(json.dumps(sm_response, default=datetimeconverter))
        sfn_details = {
            "sfnARN" : sm_arn,
            "sfnRunId": json_data.get('executionArn'),
            "jobStatus": 'STARTED'
        }

        #############################################################
        ## IMPORTANT
        ## This function must return a dictionary object with a dict
        ## containing jobDetails information
        #############################################################
        response = {
            'jobDetails': sfn_details
        }

        return response

    def check_job_status(self, job_details):
        # This function checks the status of the currently running state machine
        sfn_response = sfn.describe_execution(executionArn=job_details['sfnRunId'])
        json_data = json.loads(json.dumps(sfn_response, default=datetimeconverter))
        # IMPORTANT update the status of the job based on the job_response (e.g RUNNING, SUCCEEDED, FAILED)
        logger.info(f'Determining state machine status ...')
        jobStatus = json_data.get('status')
        job_details['jobStatus'] = jobStatus
        sfnOutput = json_data.get('output')
        job_details['sfnOutput'] = sfnOutput
        logger.info(f'State Machine Status: {jobStatus}')

        #############################################################
        ## IMPORTANT
        ## This function must return a dictionary object with a dict
        ## containing jobDetails information
        #############################################################
        response = {
            'jobDetails': job_details
        }
        
        return response
