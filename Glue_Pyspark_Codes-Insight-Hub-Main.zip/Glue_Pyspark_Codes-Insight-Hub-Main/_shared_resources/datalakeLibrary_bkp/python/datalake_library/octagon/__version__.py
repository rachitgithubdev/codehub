# Octagon Python API

__title__ = "Octagon"
__version__ = "1.0"
