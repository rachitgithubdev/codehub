import csv


class DuplicateRemoval:

    def __init__(self):
        self.infile = open('resources/Dataset1.csv', 'r')
        self.outfile = csv.writer(open('Output/output1.csv', 'w'))
        self.reader = csv.reader(self.infile)

    def execute(self):

        entries = set()

        for row in self.reader:
            key = (row[0] + row[1])
            if key not in entries:
                self.outfile.writerow(row)
                entries.add(key)
        self.infile.close()


if __name__ == '__main__':
    x = DuplicateRemoval()
    x.execute()