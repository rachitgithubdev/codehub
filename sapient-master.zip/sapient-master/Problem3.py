import logging
from pyspark.sql.functions import unix_timestamp, lag
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, LongType
from pyspark.sql import SparkSession
import pandas as pd
import pyarrow.csv as pv
import pyarrow.parquet as pq
from pyspark.sql.window import Window
import pyspark.sql.functions as F
import pyspark.sql.functions as func

logger = logging.getLogger(__name__)


class Clickstream():
    def __init__(self):
        self.spark = SparkSession \
                     .builder \
                     .appName("PySpark clickstream") \
                     .getOrCreate()
        self.df = self.spark.read.csv("resources/Dataset3.csv", header=True)

    def execute(self):
        schema = StructType([StructField("userid", StringType()),
                             StructField("timestamp", TimestampType())])
        self.df = self.spark.read.csv("resources/Dataset3.csv", header=True)
        self.df = self.df.withColumn("clicktime", self.df["timestamp"].cast(TimestampType()))
        last_event = self.df.withColumn("last_event", lag('clicktime')\
                                        .over(Window.partitionBy('userid')\
                                              .orderBy('clicktime')).cast(TimestampType()))
        last_event = last_event.withColumn("Current_Timestamp", F.current_timestamp())
        activity_hrs = last_event.withColumn\
            ("activity_time", (F.current_timestamp().cast("long") - F.col("clicktime").cast("long")) / 60.0)
        lag_in_min = activity_hrs.withColumn("date_diff_min", (
                F.col("clicktime").cast("long") - F.col("last_event").cast("long")) / 60.0)
        lag_in_min = lag_in_min.filter((F.col('date_diff_min') > 30))
        user_activity = lag_in_min.withColumn\
            ("Session_Active", (F.when(F.col("activity_time") < 120, 'In Process').otherwise('Processed')))
        new_session_check = user_activity.withColumn\
            ('New_Session_ID_Check', F.when((F.col('date_diff_min') >= 120) & (F.col('activity_time') >= 60), func.round((F.col('date_diff_min')/120)).cast('integer')).otherwise('NULL'))#.show(truncate=False)
        analysis = new_session_check.withColumn('Date', func.to_date(func.col("clicktime")))  # .show(truncate=False)
        analysis = analysis.withColumn('total_time', (F.sum('date_diff_min').over(Window.partitionBy('date', 'userid'))))

        analysis = analysis.withColumn('active_total_time',
                                      (F.sum('activity_time').over(Window.partitionBy('date', 'userid'))))
        analysis = analysis.withColumn('active_total_time_new',
                                       (F.sum('activity_time').over(Window.partitionBy('date', 'userid'))))
        analysis = analysis.withColumn('time_spent_day', F.when(F.col('Session_Active') == 'In Process', (F.col("total_time")+F.col("active_total_time"))).otherwise(F.col("total_time")))#.show(truncate=False)
        analysis = analysis.withColumn('Month', F.month('Date'))  # .show(truncate=False)
        analysis = analysis.withColumn('total_time_month', (
            F.sum('date_diff_min').over(Window.partitionBy('Month', 'userid'))))# .show(truncate=False)
        analysis = analysis.withColumn('time_spent_month', F.when(F.col('Session_Active') == 'In Process', (
                    F.col("total_time_month") + F.col("active_total_time"))).otherwise(F.col("total_time_month")))#.show(truncate=False)
        analysis = analysis.withColumn('Year', F.year('Current_Timestamp')).withColumn('Mon', F.month(
            'Current_Timestamp')).withColumn('DT', F.substring('Current_Timestamp', 9, 2)).withColumn('HR', F.hour(
            'Current_Timestamp'))#.show(truncate = False)
        self.dfq = analysis.createGlobalTempView("Analysis")
        self.spark.sql(
            "SELECT sum(New_Session_ID_Check) as Sessions_Day,Date FROM global_temp.Analysis group by Date").show()
        self.spark.sql(
            "SELECT Date,userid,time_spent_day from global_temp.Analysis group by Date,userid,time_spent_day order by Date desc").show()
        self.spark.sql(
            "SELECT Month,userid,time_spent_month from global_temp.Analysis group by Month,userid,time_spent_month order by Month desc").show()
        analysis.write.partitionBy("Year", "Mon", "DT", "HR").mode('overwrite') \
            .parquet('Output/output3.parquet')
        # analysis.write.partitionBy("Year","Mon","DT").bucketBy(16, 'userid').sortBy('userid').saveAsTable('bucketed', format='parquet')


if __name__ == '__main__':
    x = Clickstream()
    x.execute()