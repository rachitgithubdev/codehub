import pandas as pd
import logging
import pyarrow.csv as pv
import pyarrow.parquet as pq
from pyspark.sql.window import Window
import pyspark.sql.functions as F
import pyspark.sql.functions as func
from pyspark.sql.functions import lag
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, LongType
from pyspark.sql import SparkSession

logger = logging.getLogger(__name__)


class Clickstream():
    def __init__(self):
        self.spark = SparkSession \
                     .builder \
                     .appName("PySpark clickstream") \
                     .getOrCreate()
        self.df = self.spark.read.csv("resources/Dataset2.csv", header=True)

    def execute(self):
        schema = StructType([StructField("userid", StringType()),
                             StructField("timestamp", TimestampType())])
        self.df = self.df.withColumn("clicktime", self.df["timestamp"].cast(TimestampType()))
        last_event = self.df.withColumn("last_event", lag('clicktime')\
                                        .over(Window.partitionBy('userid')\
                                              .orderBy('clicktime')).cast(TimestampType()))
        last_event = last_event.withColumn("Current_Timestamp", F.current_timestamp())
        activity_hrs = last_event.withColumn\
            ("activity_time", (F.current_timestamp().cast("long") - F.col("clicktime").cast("long")) / 60.0)
        lag_in_min = activity_hrs.withColumn("date_diff_min", (
                F.col("clicktime").cast("long") - F.col("last_event").cast("long")) / 60.0)
        lag_in_min = lag_in_min.filter(F.col('date_diff_min') > 30.0)
        user_activity = lag_in_min.withColumn\
            ("Session_Active", (F.when(F.col("activity_time") < 120, 'In Process').otherwise('Processed')))
        new_session_check = user_activity.withColumn\
            ('New_Session_ID_Check', F.when((F.col('date_diff_min') >= 120) & (F.col('activity_time') >= 60), func.round((F.col('date_diff_min')/120)).cast('integer')).otherwise('NULL')).show(truncate=False)
        self.df.write.mode('overwrite').parquet('Output/output2.parquet')


if __name__ == '__main__':
    x = Clickstream()
    x.execute()